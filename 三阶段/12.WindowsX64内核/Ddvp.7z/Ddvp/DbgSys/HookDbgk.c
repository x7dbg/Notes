//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * Hook DbgkCreateThread DbgkExitProcess, DbgkExitThread, DbgkMapViewOfSection
 * DbgkUnMapViewOfSection DbgkForwardException ����
 */
//===========================================================================

#include <ntifs.h>
#include "defines.h"
#include "ExtDef.h"
#include "SysMisc.h"
#include "WinBaseEx.h"
#include "IoControlCode.h"
#include "debug.h"
#include "DbgItem.h"
#include "DbgkUtil.h"
#include "driver.h"
#include "HookDbgk.h"
#include "ReloadKernel.h"
//---------------------------------------------------------------------------


extern DBG_RELOAD_KERNEL g_StReloadKernel;
//---------------------------------------------------------------------------

BYTE	OldBufferDbgkExitProcess[5];
BYTE	NewBufferDbgkExitProcess[5];
BYTE	PortBufferDbgkExitProcess[10];
PBYTE	DebugPortCmpOffset;
ULONG	ulDebugPortHookLength;
PDbgkExitProcess	OldDbgkExitProcess;
PDbgkExitProcess	JmpOldDbgkExitProcess;

BYTE	OldBufferKiDispatchException[5];
BYTE	NewBufferKiDispatchException[5];
BYTE	PortBufferKiDispatchException[8];
PKiDispatchException	OldKiDispatchException;
PKiDispatchException	JmpOldKiDispatchException;


BYTE	OldBufferDbgkExitThread[5];
BYTE	NewBufferDbgkExitThread[5];
PDbgkExitThread	OldDbgkExitThread;
PDbgkExitThread	JmpOldDbgkExitThread;

BYTE	OldBufferDbgkMapViewOfSection[5];
BYTE	NewBufferDbgkMapViewOfSection[5];
PDbgkMapViewOfSection	OldDbgkMapViewOfSection;
PDbgkMapViewOfSection	JmpOldDbgkMapViewOfSection;

BYTE	OldBufferDbgkUnMapViewOfSection[5];
BYTE	NewBufferDbgkUnMapViewOfSection[5];
PDbgkUnMapViewOfSection	OldDbgkUnMapViewOfSection;
PDbgkUnMapViewOfSection	JmpOldDbgkUnMapViewOfSection;

BYTE	OldBufferDbgkForwardException[5];
BYTE	NewBufferDbgkForwardException[5];
PDbgkForwardException OldDbgkForwardException;
PDbgkForwardException JmpOldDbgkForwardException;

BYTE	OldBufferKiAttachProcess[5];
BYTE	NewBufferKiAttachProcess[5];
PKiAttachProcess OldKiAttachProcess;
PKiAttachProcess JmpOldKiAttachProcess;
PKiAttachProcess NewKiAttachProcess;


//---------------------------------------------------------------------------



BOOL
__declspec( naked )
Naked_KiDispatchException(
    IN PEXCEPTION_RECORD ExceptionRecord,
    IN PKEXCEPTION_FRAME ExceptionFrame,
    IN PKTRAP_FRAME TrapFrame,
    IN KPROCESSOR_MODE PreviousMode,
    IN BOOLEAN FirstChance )
{
    __asm
    {
        pushad

        mov		eax, dword ptr [esp+0x20+4]
        mov		ecx, dword ptr [esp+0x20+8]
        mov		edx, dword ptr [esp+0x20+0xc]
        mov		ebx, dword ptr [esp+0x20+0x10]
        mov		esi, dword ptr [esp+0x20+0x14]

        push	esi			// FirstChance
        push	ebx			// PreviousMode
        push	edx			// TrapFrame
        push	ecx			// ExceptionFrame
        push	eax			// ExceptionRecord
        call	_KiDispatchException

        mov		dword ptr [esp+0x20-4], eax		// ����ֵ
        popad

        //
        // ����FALSE��ʾ����ԭ���ĵط�����, KiDispatchException�ǲ���Ҫ���ص�.
        //
        cmp		eax, TRUE
        jnz		_Else

        //
        // ����ret ���ٶ���û�������. ֻҪ���ص�ַ���˾���. ��Ϊ������һ��.
        // mov     esp, ebp                ; (esp) -> trap frame
        //
        ret     0x14

        _Else:
        //
        // ԭ����KiDispatchException��������..
        //
        push	0x390
        jmp		JmpOldKiDispatchException
    }
}
//
// Hook סϵͳ�� DbgkCreateThread ����
//
NTSTATUS
HookKiDispatchException(
    PKiDispatchException lpKiDispatchException )
{

    if( OldKiDispatchException )
    {
        return STATUS_UNSUCCESSFUL;
    }

    OldKiDispatchException = lpKiDispatchException;

    JmpOldKiDispatchException = ( PKiDispatchException )( ( PBYTE )OldKiDispatchException + 5 );

    SafeCopyMemory( OldBufferKiDispatchException, lpKiDispatchException,
                    sizeof( OldBufferKiDispatchException ) );

    _Jump( lpKiDispatchException, Naked_KiDispatchException, 0 );

    SafeCopyMemory( NewBufferKiDispatchException, lpKiDispatchException,
                    sizeof( OldBufferKiDispatchException ) );

    KdPrint( ( "Ddvp-> Call HookKiDispatchException Old Routine: %p New Routine: %p \n",
               OldKiDispatchException, Naked_KiDispatchException	) );

    return STATUS_SUCCESS;

}

VOID
UnHookKiDispatchException( )
{
    SIZE_T Size;

    if( !OldKiDispatchException )
    {
        return;
    }

    Size = RtlCompareMemory( NewBufferKiDispatchException, OldKiDispatchException,
                             sizeof( NewBufferKiDispatchException ) );

    if( Size == sizeof( NewBufferKiDispatchException ) )
    {
        KdPrint( ( "Ddvp-> Call UnHookKiDispatchException\n" ) );

        SafeCopyMemory( OldKiDispatchException, OldBufferKiDispatchException,
                        sizeof( OldBufferKiDispatchException ) );

        RtlZeroMemory( OldBufferKiDispatchException, sizeof( OldBufferKiDispatchException ) );

        RtlZeroMemory( NewBufferKiDispatchException, sizeof( NewBufferKiDispatchException ) );

        OldKiDispatchException = NULL;
        JmpOldKiDispatchException = NULL;
    }
}


BOOL NTAPI DebuggerCallKiAttachProcess()
{

    PEPROCESS Process = PsGetCurrentProcess();
    DBG_ITEM* DbgItem;

    DbgItem = DbgItemFindItem( Process, NULL );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            KdPrint( ( "Ddvp-> Call  Naked_KiAttachProcess ����� Eprocess: %p \n", DbgItem->Debugged ) );
            DbgItemDeRefItem( DbgItem );
            return TRUE;
        }
        return FALSE;
    }

    // KdPrint( ( "Ddvp->  Eprocess %s ����KiAttachProcess \n", GetEprocessNamePointer( DbgItem->Debugger ) ) );

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }

    return TRUE;
}

VOID
__declspec( naked )
Naked_KiAttachProcess( IN PKTHREAD Thread,
                       IN PKPROCESS Process,
                       IN PKLOCK_QUEUE_HANDLE ApcLock,
                       IN PRKAPC_STATE SavedApcState )
{



    __asm
    {
        pushad
        call	DebuggerCallKiAttachProcess
        mov		dword ptr [esp+0x1c], eax
        popad
        or		eax, eax
        jz		_Else

        jmp		NewKiAttachProcess

        _Else:

        // ����ԭ����KiAttachProcess
        mov     edi, edi
        push    ebp
        mov     ebp, esp
        mov 	eax, OldKiAttachProcess
        add		eax, 5
        jmp		eax
    }

}

VOID
UnHookKiAttachProcess( )
{
    SIZE_T Size;

    if( !OldKiAttachProcess )
    {
        return;
    }

    Size = RtlCompareMemory( NewBufferKiAttachProcess, OldKiAttachProcess,
                             sizeof( NewBufferKiAttachProcess ) );

    if( Size == sizeof( NewBufferKiAttachProcess ) )
    {
        KdPrint( ( "Ddvp-> Call UnHookKiAttachProcess\n" ) );

        SafeCopyMemory( OldKiAttachProcess, OldBufferKiAttachProcess,
                        sizeof( OldBufferKiAttachProcess ) );

        RtlZeroMemory( OldBufferKiAttachProcess, sizeof( OldBufferKiAttachProcess ) );

        RtlZeroMemory( NewBufferKiAttachProcess, sizeof( NewBufferKiAttachProcess ) );

        OldKiAttachProcess = NULL;
        JmpOldKiAttachProcess = NULL;
    }
}


NTSTATUS
HookKiAttachProcess(
    PKiAttachProcess lpKiAttachProcess,
    PKiAttachProcess lpNewKiAttachProcess )
{

    if( OldKiAttachProcess )
    {
        return STATUS_UNSUCCESSFUL;
    }

    OldKiAttachProcess = lpKiAttachProcess;
    NewKiAttachProcess = lpNewKiAttachProcess;

    JmpOldKiAttachProcess = ( PKiAttachProcess )( ( PBYTE )OldKiAttachProcess + 5 );

    SafeCopyMemory( OldBufferKiAttachProcess, lpKiAttachProcess,
                    sizeof( OldBufferKiAttachProcess ) );

    _Jump( lpKiAttachProcess, Naked_KiAttachProcess, 0 );

    SafeCopyMemory( NewBufferKiAttachProcess, lpKiAttachProcess,
                    sizeof( OldBufferKiAttachProcess ) );

    KdPrint( ( "Ddvp-> Call HookKiAttachProcess Old Routine: %p New Routine: %p \n",
               OldKiAttachProcess, Naked_KiAttachProcess	) );

    return STATUS_SUCCESS;

}

