#include "CTestFrame.h"

IMPLEMENT_DYNAMIC(CTestFrame, CFrameWnd)