﻿
// MyArkDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "MyArk.h"
#include "MyArkDlg.h"
#include "afxdialogex.h"
#include "CFileManager.h"
#include "CRegedit.h"
#include "Data.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CMyArkDlg 对话框



CMyArkDlg::CMyArkDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_MYARK_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_hSCManager = NULL;
	m_hService = NULL;


}

void CMyArkDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TAB, m_TabCtrl);
}

BEGIN_MESSAGE_MAP(CMyArkDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB, &CMyArkDlg::OnSelchangeTab)
END_MESSAGE_MAP()


// CMyArkDlg 消息处理程序

BOOL CMyArkDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();


	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

    // 加载驱动
	DWORD nRet = Install(DRV_NAME, DRV_PATH);
	if (nRet < 0)
	{
		AfxMessageBox(L"驱动安装失败！");
		return FALSE;
	}
    //使用
    g_hDevice = CreateFileA(SYM_NAME,           // open MYFILE.TXT 
        GENERIC_ALL,               // open for reading 
        FILE_SHARE_READ,           // share for reading 
        NULL,                      // no security 
        OPEN_EXISTING,             // existing file only 
        FILE_ATTRIBUTE_NORMAL,     // normal file 
        NULL);                     // no attr. template 

    if (g_hDevice == INVALID_HANDLE_VALUE)
    {
        DisplayError(L"CreateFile");
    }

	

	m_TabCtrl.InsertItem(0, L"文件");
	m_TabCtrl.InsertItem(1, L"注册表");

	m_pDialog[0] = new CFileManager();
	m_pDialog[1] = new CRegedit();
	m_pDialog[0]->Create(IDD_FILE, &m_TabCtrl);
	m_pDialog[1]->Create(IDD_REGEDIT, &m_TabCtrl);

	CRect pos = {};
	m_TabCtrl.GetClientRect(pos);		//转换为客户端坐标
	pos.DeflateRect(2, 30, 3, 2);	// 移动坐标

	m_pDialog[0]->MoveWindow(pos);
	m_pDialog[0]->ShowWindow(SW_SHOW);
	m_pDialog[1]->ShowWindow(SW_HIDE);
	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CMyArkDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CMyArkDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CMyArkDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CMyArkDlg::OnSelchangeTab(NMHDR* pNMHDR, LRESULT* pResult)
{
	CRect cRect;
	GetClientRect(cRect);
	cRect.DeflateRect(2, 30, 3, 2);
	// 获取所选TAB项
	DWORD dwSel = m_TabCtrl.GetCurSel();
	for (DWORD i = 0; i < DIALOG_NUM; ++i)
	{
		if (dwSel == i)
		{
			m_pDialog[i]->MoveWindow(cRect);
			m_pDialog[i]->ShowWindow(SW_SHOW);
		}
		else
		{
			m_pDialog[i]->ShowWindow(SW_HIDE);
		}
	}
	*pResult = 0;
}

void CMyArkDlg::DisplayError(const wchar_t * lpszName)
{
	LPVOID lpMsgBuf;
	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER |
		FORMAT_MESSAGE_FROM_SYSTEM |
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		0, // Default language
		(LPTSTR)&lpMsgBuf,
		0,
		NULL
	);
	// Process any inserts in lpMsgBuf.
	// ...
	// Display the string.
	MessageBoxW((LPCTSTR)lpMsgBuf,lpszName, MB_OK | MB_ICONINFORMATION);
	// Free the buffer.
	LocalFree(lpMsgBuf);
}

//安装驱动
DWORD CMyArkDlg::Install(const char* pszDrvName, const char* pszPath)
{
	DWORD dwLength = 0;
	DWORD dwResult = 0;
	char lszBinaryPathName[MAXBYTE] = { 0 };
	//获取路径
	dwLength = GetFullPathNameA(pszPath, sizeof(lszBinaryPathName), lszBinaryPathName, NULL);

	if (dwLength == 0)
	{
		dwResult = -1;
		DisplayError(L"GetFullPathName");
		goto RET;
	}
	m_hSCManager = OpenSCManagerA(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (m_hSCManager == NULL)
	{
		dwResult = -2;
		DisplayError(L"OpenSCManager");
		goto RET;
	}


	m_hService = CreateServiceA(
		m_hSCManager,              // SCManager database 
		pszDrvName,                // name of service 
		pszDrvName,                // service name to display 
		SERVICE_ALL_ACCESS,        // 访问权限
		SERVICE_KERNEL_DRIVER,     // service type 服务类型 内核驱动 
		SERVICE_DEMAND_START,      // start type  启动方式
		SERVICE_ERROR_NORMAL,      // error control type 错误控制类型
		lszBinaryPathName,         // service's binary 
		NULL,                      // no load ordering group 
		NULL,                      // no tag identifier 
		NULL,                      // no dependencies 
		NULL,                      // LocalSystem account 
		NULL);                     // no password 

	if (m_hService == NULL)
	{
		if (GetLastError() == ERROR_SERVICE_EXISTS) //判断服务是否已经存在
		{
			//打开
			m_hService = OpenServiceA(
				m_hSCManager,          // SCM database 
				pszDrvName,          // service name
				SERVICE_ALL_ACCESS);

			if (m_hService == NULL)
			{
				dwResult = -3;
				DisplayError(L"OpenService");
				goto RET;
			}
		}
		else
		{
			dwResult = -4;
			DisplayError(L"CreateService");
			goto RET;
		}
	}


	//启动服务
	if (!StartService(
		m_hService,  // handle to service 
		0,           // number of arguments 
		NULL))      // no arguments 
	{
		dwResult = -5;
		DisplayError(L"StartService");
		goto RET;
	}
	return dwResult;

RET:
	if (m_hService != NULL)
		CloseServiceHandle(m_hService);
	if (m_hSCManager != NULL)
		CloseServiceHandle(m_hSCManager);

	return dwResult;
}
//卸载驱动
void CMyArkDlg::Unload(const char* lpszName)
{

	CloseHandle(g_hDevice);

	// 停止服务
	SERVICE_STATUS status;
	// 检查服务状态
	BOOL bRet = QueryServiceStatus(m_hService, &status);
	// 如果不处于暂停状态
	if (status.dwCurrentState != SERVICE_STOPPED)
	{
		// 停止服务
		ControlService(m_hService, SERVICE_CONTROL_STOP, &status);
		// 直到服务停止
		while (QueryServiceStatus(m_hService, &status) == TRUE)
		{
			Sleep(status.dwWaitHint);
			break;
		}
	}

	//删除服务
	if (!DeleteService(m_hService))
	{
		DisplayError(L"DeleteService");
	}
	if (m_hService != NULL)
		CloseServiceHandle(m_hService);
	if (m_hSCManager != NULL)
		CloseServiceHandle(m_hSCManager);


	return;

}
BOOL CMyArkDlg::DestroyWindow()
{
	// TODO: 在此添加专用代码和/或调用基类
	Unload(DRV_NAME);
	for (size_t i = 0; i < DIALOG_NUM; i++)
	{
		if (m_pDialog[i] != nullptr)
		{
			delete[] m_pDialog[i];
		}
	}
	return CDialogEx::DestroyWindow();
}