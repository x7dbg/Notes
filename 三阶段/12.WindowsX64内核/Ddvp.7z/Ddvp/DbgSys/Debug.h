#ifndef _DEBUG_
#define _DEBUG_

#pragma pack (push, 1)

typedef struct tagVerison
{
	ULONG ulMainVersion;
	ULONG ulChildVersion;
	char SzBuildTime[128];

} DICHLORVOS_VERISON, *PDICHLORVOS_VERISON;

#pragma pack( pop )

extern SYMBOLS_INFO			g_StSymbolsInfo;


NTSTATUS DbgObjIrpCreate( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjGetVersion( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjIrpClose( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjCreateProcessAfter( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjNtWaitForDebugEvent( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjContinueDebugEvent( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjDebugActiveProcess( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjNtWriteVirtualMemory( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjNtReadVirtualMemory( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjNtOpenProcess( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjCreateProcessBefore( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjNtGetContextThread( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjNtSetContextThread( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjNtSuspendThread( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjNtResumeThread( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjCreateProcessClean( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjCheckBiosIsEnabled( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjNtOpenThread( SYSTEM_CALL *lpStSysCall );
NTSTATUS DbgObjNtProtectVirtualMemory( SYSTEM_CALL *lpStSysCall );
#endif
