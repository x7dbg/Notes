//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ��������֧���û�̬�������õ�����, ģ��󲿷ֺ͵����йصĺ���.
 *
 */
//===========================================================================

#include <ntddk.h>
#include "defines.h"
#include "ExtDef.h"
#include "SysMisc.h"
#include "WinBaseEx.h"
#include "IoControlCode.h"
#include "KiFastCallEntry.h"
#include "ReloadKernel.h"
#include "Driver.h"
#include "DbgItem.h"

//---------------------------------------------------------------------------

KMUTEX				g_GlobleMutex;
DBG_RELOAD_KERNEL	g_StReloadKernel;
SYMBOLS_INFO		g_StSymbolsInfo;
PSERVICE_DESCRIPTOR_TABLE KeServiceDescriptorTableShadow;
//---------------------------------------------------------------------------

VOID DriverUnload( IN PDRIVER_OBJECT DriverObject )
{

    KdPrint( ( "Ddvp-> Call DriverUnload \n" ) );

    DbgObjFreeKernel( &g_StReloadKernel );

    DbgObjUnHookNtTerminateProcess();

    //KeReleaseMutex ( &g_GlobleMutex, FALSE );

    return;
}

//
// �����������
//
NTSTATUS DriverEntry(
    IN PDRIVER_OBJECT  DriverObj,
    IN PUNICODE_STRING RegPath
)
{
    HANDLE h_key  = NULL;
    NTSTATUS Status = STATUS_UNSUCCESSFUL;

    DbgPrint( ( "Ddvp-> Version %d.%d Build Time : %s \n",
               MAIN_VERSION, CHILD_VERSION, "" __DATE__ "/" __TIME__ ) );

    //
    // ��дShadow SSDT �ĵ�ַ
    //
    KeServiceDescriptorTableShadow = ( PSERVICE_DESCRIPTOR_TABLE )
                                     ( ( ULONG_PTR )KeServiceDescriptorTable-0x40 );
	
	KdPrint( ( "Ddvp-> KeServiceDescriptorTableShadow Address :%p \n", 
		KeServiceDescriptorTableShadow ) );

    //
    // �����ں�ģ��, ntoskrnl.exe
    //
    Status = DbgObjOverLoadKernel( &g_StReloadKernel );
    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> DbgObjOverLoadKernel ʧ��\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

    KdPrint( ( "Ddvp-> ��ntos��ַ: %p, �µ�ntos��ַ: %p \n",
               g_StReloadKernel.OriginalKernelBase, g_StReloadKernel.NewKernelBase ) );

    //
    // Hook NtTerminateProcess ��R3����ͨѶ
    //
    Status = DbgObjHookNtTerminateProcess();
    if( !NT_SUCCESS( Status ) )
    {
        DbgObjFreeKernel( &g_StReloadKernel );

        KdPrint( ( "Ddvp-> Hook NtTerminateProcess  ʧ��\n" ) );
        return Status;
    }

    KeInitializeMutex( &g_GlobleMutex, 0 );

    DbgItemInitDbgItem();

    //
    // ����ж������
    //
    DriverObj->DriverUnload = &DriverUnload;

    return STATUS_SUCCESS;
}

