#pragma once
#ifndef VT_WIN7_KERNEL_CODE_ASM
#define VT_WIN7_KERNEL_CODE_ASM

// KiSystemCall64 ����
EXTERN_C void Win7_SysCallEntryPointer();

#endif