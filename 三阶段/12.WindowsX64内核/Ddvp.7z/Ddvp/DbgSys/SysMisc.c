//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ����ļ���һЩ�����Ժ���. ����Ŀ������
 */
//===========================================================================

#include <ntifs.h>
#include "defines.h"
#include "WinBaseEx.h"
#include "IoControlCode.h"
#include "SysMisc.h"
#include "ExtDef.h"
#include "Version.h"
#include "Assembly.h"
#include "debug.h"
#include "ReloadKernel.h"
#include "DbgItem.h"

typedef NTSTATUS( *SYS_CALL_ROUTINE )( SYSTEM_CALL *lpStSysCall );

#define MAX_DBG_ROUTINE 20

wchar_t* DbgRoutineName[ MAX_DBG_ROUTINE + 1] =
{
    L"DbgObjIrpCreate",
    L"DbgObjIrpClose",
    L"DbgObjGetVersion",
    L"DbgObjCreateProcessBefore",
    L"DbgObjCreateProcessClean",
    L"DbgObjCreateProcessAfter",
    L"DbgObjNtWaitForDebugEvent",
    L"DbgObjContinueDebugEvent",
    L"DbgObjDebugActiveProcess",
    L"DbgObjNtOpenProcess",
    L"DbgObjNtOpenThread",
    L"DbgObjNtReadVirtualMemory",
    L"DbgObjNtWriteVirtualMemory",
    L"DbgObjNtGetContextThread",
    L"DbgObjNtSetContextThread",
    L"DbgObjNtSuspendThread",
    L"DbgObjNtResumeThread",
    L"DbgObjCheckBiosIsEnabled",
	L"DbgObjNtProtectVirtualMemory"
};


static SYS_CALL_ROUTINE SysCallTable[] =
{
    DbgObjIrpCreate,		// 0x00
    DbgObjIrpClose,			//
    DbgObjGetVersion,		// 0x01
    DbgObjCreateProcessBefore,
    DbgObjCreateProcessClean,
    DbgObjCreateProcessAfter,
    DbgObjNtWaitForDebugEvent,
    DbgObjContinueDebugEvent,
    DbgObjDebugActiveProcess,
    DbgObjNtOpenProcess,
    DbgObjNtOpenThread,
    DbgObjNtReadVirtualMemory,
    DbgObjNtWriteVirtualMemory,
    DbgObjNtGetContextThread,
    DbgObjNtSetContextThread,
    DbgObjNtSuspendThread,
    DbgObjNtResumeThread,
    DbgObjCheckBiosIsEnabled,
	DbgObjNtProtectVirtualMemory
};

#define SC_MAX       (sizeof(SysCallTable)/sizeof(SysCallTable[0]))

#define SC_DAT_LIMIT (1024*1024)


static PZWTERMINATEPROCESS OldNtTerminateProcess;
static wchar_t SzCreatePrcessName[MAX_PATH] = {0};

extern KMUTEX				g_GlobleMutex;
extern DBG_RELOAD_KERNEL	g_StReloadKernel;
//---------------------------------------------------------------------------

VOID SetCreateProcessName( wchar_t* lpExeName )
{
    int i;

    KeWaitForSingleObject( &g_GlobleMutex, Executive,
                           KernelMode, FALSE, NULL );

    for( i = 0; i < sizeof( SzCreatePrcessName ) / sizeof( wchar_t ); i++ )
    {
        SzCreatePrcessName[i] = lpExeName[i];

        if( SzCreatePrcessName[i] == L'\0' )
        {
            break;
        }
    }

    KeReleaseMutex( &g_GlobleMutex, FALSE );
}

VOID CleanCreateProcessName()
{
    KeWaitForSingleObject( &g_GlobleMutex, Executive,
                           KernelMode, FALSE, NULL );

    RtlZeroMemory( SzCreatePrcessName, sizeof( SzCreatePrcessName ) );

    KeReleaseMutex( &g_GlobleMutex, FALSE );
}

BOOL CompareProcessName( PEPROCESS Process )
{
    BOOL bRet;
    ANSI_STRING SzExeName;
    UNICODE_STRING USzExeName;
    UNICODE_STRING USzCreateName;

    KeWaitForSingleObject( &g_GlobleMutex, Executive,
                           KernelMode, FALSE, NULL );

    RtlInitAnsiString( &SzExeName, GetEprocessNamePointer( Process ) );

    RtlAnsiStringToUnicodeString( &USzExeName, &SzExeName, TRUE );

    RtlInitUnicodeString( &USzCreateName, SzCreatePrcessName );

    if( 0 == RtlCompareUnicodeString( &USzExeName, &USzCreateName, TRUE ) )
    {
        bRet = TRUE;
    }
    else
    {
        bRet = FALSE;
    }

    KdPrint( ( "Ddvp-> Call SetCreateProcessName:%wsExe Name:%wsbRet:%d \n",
               USzCreateName.Buffer, USzExeName.Buffer, bRet ) );

    RtlFreeUnicodeString( &USzExeName );

    KeReleaseMutex( &g_GlobleMutex, FALSE );
    return bRet;
}



VOID _Sleep( ULONG ulMilliseconds )
{
    LARGE_INTEGER liTime;

    PAGED_CODE();

    /* Convert milliseconds to 100-nanosecond increments using:
    *
    *     1 ns = 10 ^ -9 sec
    *   100 ns = 10 ^ -7 sec (1 timer interval)
    *     1 ms = 10 ^ -3 sec
    *     1 ms = (1 timer interval) * 10^4
    */
    ulMilliseconds = ulMilliseconds * 10000;

    //
    // Negative value means relative time, not absolute
    //
    liTime = RtlConvertLongToLargeInteger( -( LONG )ulMilliseconds );

    KeDelayExecutionThread( KernelMode, TRUE, &liTime );
}

//
// ����R3������
//
int DbgLockBuffer(
    BUFFER_LOCK *lpStBufferLock, void *Buffer, ULONG ulSize
)
{
    PVOID lpData = NULL;
    int Locked = 0;
    int iRet = 0;

    lpStBufferLock->mdl = NULL;
    lpStBufferLock->lpData = NULL;

    do
    {
        if( ( lpStBufferLock->mdl = IoAllocateMdl( Buffer, ulSize, FALSE, FALSE, NULL ) ) == NULL )
        {
            break;
        }

        __try
        {
            MmProbeAndLockPages( lpStBufferLock->mdl, UserMode, IoModifyAccess );

            Locked = 1;
        }

        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            break;
        }

        if( ( lpData = MmMapLockedPages( lpStBufferLock->mdl, KernelMode ) ) == NULL )
        {
            break;
        }

        lpStBufferLock->lpData = lpData;
        iRet = 1;
    }
    while( 0 );

    if( lpData == NULL )
    {
        if( Locked != 0 )
        {
            MmUnlockPages( lpStBufferLock->mdl );
        }

        if( lpStBufferLock->mdl != NULL )
        {
            IoFreeMdl( lpStBufferLock->mdl );
        }
    }

    return iRet;
}

//
// ����һ��R3�ڴ�
//
void DbgUnLockBuffer( BUFFER_LOCK *lpStBufferLock )
{
    MmUnmapLockedPages( lpStBufferLock->lpData, lpStBufferLock->mdl );

    MmUnlockPages( lpStBufferLock->mdl );

    IoFreeMdl( lpStBufferLock->mdl );
}


void SetBits( ULONG* dw, int lowBit, int bits, int newValue )
{
    DWORD_PTR mask = ( 1 << bits ) - 1;
    *dw = ( *dw & ~( mask << lowBit ) ) | ( newValue << lowBit );
}

//===========================================================================
//	��߷�װһ����ȫ�����ڴ�ĺ���, ���Ƕ�ϵͳRtlCopyMemory�ķ�װ
// ����ֵ:	���ִ�гɹ�, ����TRUE, ���򷵻�FALSE
//===========================================================================
BOOL SafeCopyMemory( PVOID pDest, PVOID pSrc, ULONG dwSize )
{
    BOOL bRet;
    KIRQL Irql;

    __try
    {
        Irql = KeRaiseIrqlToDpcLevel();

        WriteProtectedOpen();

        __asm
        {
            mov		edi, pDest
            mov		esi, pSrc
            mov		ecx, dwSize
            rep		movsb
        }

        WriteProtectedClose();

        KeLowerIrql( Irql );

        bRet = TRUE;

    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {
        bRet = FALSE;
    }
    return bRet;

}

//===========================================================================
//	��ȫ��д��һ��jmp��ַ
//pAddress	:Ҫд��ĵ�ַ
//pFunction	:д��Ҫ��ת���ĵ�ַ
//����ֵ	:�ɹ�����TRUE, ���򷵻�FALSE
//===========================================================================
BOOL _Jump( PVOID pAddress, PVOID pFunction, ULONG ulNop )
{
    KIRQL Irql;
    ULONG i;

    __try
    {

        Irql = KeRaiseIrqlToDpcLevel();

        WriteProtectedOpen();

        *( BYTE* )pAddress = 0xE9;

        *( ULONG* )( ( ( BYTE* )pAddress ) + 1 ) = Set_Jump( pAddress, pFunction );

        for( i = 0; i < ulNop; i++ )
        {
            *( ( ( BYTE* )pAddress ) + 5 + i ) = 0x90;
        }

        WriteProtectedClose( );

        KeLowerIrql( Irql );

        return TRUE;

    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {
        return FALSE;
    }
}

//===========================================================================
//	��ȫ��д��һ��call��ַ
//pAddress	:Ҫд��ĵ�ַ
//pFunction	:д��Ҫ��ת���ĵ�ַ
//����ֵ	:�ɹ�����TRUE, ���򷵻�FALSE
//===========================================================================
BOOL _Call( PVOID pAddress, PVOID pFunction, ULONG ulNop )
{
    KIRQL Irql;
    ULONG i;

    __try
    {

        Irql = KeRaiseIrqlToDpcLevel();

        WriteProtectedOpen();

        *( BYTE* )pAddress = 0xE8;

        *( ULONG* )( ( ( BYTE* )pAddress ) + 1 ) = Set_Call( pAddress, pFunction );

        for( i = 0; i < ulNop; i++ )
        {
            *( ( ( BYTE* )pAddress ) + 5 + i ) = 0x90;
        }

        WriteProtectedClose( );

        KeLowerIrql( Irql );

        return TRUE;

    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {
        return FALSE;
    }
}



//
// ɾ��һ��Ӳ���ϵ�, lpContextֻʹ����Ӳ���ϵ㲿��.dr0-dr7
//
NTSTATUS __stdcall RemoveHardwareBreakPoint(
    PCONTEXT lpContext,
    ULONG Address )
{

    int FlagBit = 0;

    //
    // �����ж�dr0-dr3�Ǹ��Ĵ�����Ҫɾ���Ķϵ��ַ
    //
    if( Address == lpContext->Dr0 )
    {
        FlagBit = 0;
        lpContext->Dr0 = 0;
    }
    else if( Address == lpContext->Dr1 )
    {
        FlagBit = 2;
        lpContext->Dr1 = 0;
    }
    else if( Address == lpContext->Dr2 )
    {
        FlagBit = 4;
        lpContext->Dr2 = 0;

    }
    else if( Address == lpContext->Dr3 )
    {
        FlagBit = 6;
        lpContext->Dr3 = 0;

    }
    else
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpContext->Dr7 &= ~( 1 << FlagBit );

    return STATUS_SUCCESS;
}

//
// ����һ��Ӳ���ϵ�, lpContextֻʹ����Ӳ���ϵ㲿��.dr0-dr7
//
NTSTATUS __stdcall SetHardwareBreakPoint(
    PCONTEXT lpContext,
    ULONG HwBreakType,
    ULONG HwBreakSize,
    PVOID Address )
{

    int FlagBit = 0;
    int Status = 0;
    int Length = 0;
    ULONG ulReg;
    BOOL Dr0Busy = FALSE;
    BOOL Dr1Busy = FALSE;
    BOOL Dr2Busy = FALSE;
    BOOL Dr3Busy = FALSE;


    //
    // �ж�dr0-dr3�Ƿ�������Ӳ���ϵ�
    //
    if( lpContext->Dr7 & 1 )
    {
        Dr0Busy = TRUE;
    }
    if( lpContext->Dr7 & 4 )
    {
        Dr1Busy = TRUE;
    }
    if( lpContext->Dr7 & 16 )
    {
        Dr2Busy = TRUE;
    }
    if( lpContext->Dr7 & 64 )
    {
        Dr3Busy = TRUE;
    }
//---------------------------------------------------------------------------

    //
    // , �����ѡһ����æ��Ӳ���ϵ�Ĵ���. �¶ϵ�, �����æ����ʧ��
    //
    if( !Dr0Busy )
    {
        ulReg = 0;
        lpContext->Dr0 = ( DWORD_PTR )Address;
        Dr0Busy = TRUE;
    }
    else if( !Dr1Busy )
    {
        ulReg = 1;
        lpContext->Dr1 = ( DWORD_PTR )Address;
        Dr1Busy = TRUE;
    }
    else if( !Dr2Busy )
    {
        ulReg = 2;
        lpContext->Dr2 = ( DWORD_PTR )Address;
        Dr2Busy = TRUE;
    }
    else if( !Dr3Busy )
    {
        ulReg = 3;
        lpContext->Dr3 = ( ULONG )Address;
        Dr3Busy = TRUE;
    }
    else
    {
        return STATUS_UNSUCCESSFUL;
    }
//---------------------------------------------------------------------------

    //
    // �ϵ�����
    //
    lpContext->Dr6 = 0;

    if( HwBreakType == HWBRK_TYPE_CODE )
    {
        Status = 0;
    }
    if( HwBreakType == HWBRK_TYPE_READWRITE )
    {
        Status = 3;
    }
    if( HwBreakType == HWBRK_TYPE_WRITE )
    {
        Status = 1;
    }
//---------------------------------------------------------------------------
    //
    // �ϵ㳤��
    //

    if( HwBreakSize == HWBRK_SIZE_1 )
    {
        Length = 0;
    }
    if( HwBreakSize == HWBRK_SIZE_2 )
    {
        Length = 1;
    }
    if( HwBreakSize == HWBRK_SIZE_4 )
    {
        Length = 3;
    }
    if( HwBreakSize == HWBRK_SIZE_8 )
    {
        Length = 2;
    }

    SetBits( &lpContext->Dr7, 16 + ulReg * 4, 2, Status );
    SetBits( &lpContext->Dr7, 18 + ulReg * 4, 2, Length );
    SetBits( &lpContext->Dr7, ulReg * 2, 1, 1 );

    return STATUS_SUCCESS;
}

/*
	���Ǳ����ǹҹ��� nt!NtQueryInformationProcess����,
	������Ҫ���ε���DebugPort�ļ��.
*/
NTSTATUS
NTAPI
NewNtQueryInformationProcess( IN HANDLE ProcessHandle,
                              IN PROCESSINFOCLASS ProcessInformationClass,
                              OUT PVOID ProcessInformation,
                              IN ULONG ProcessInformationLength,
                              OUT PULONG ReturnLength OPTIONAL )
{
    PBYTE lpOpCode;

    PAGED_CODE();

    //
    // ��ȡR3�Ǳߵķ��ص�ַ
    //
    __asm
    {
        mov		eax, dword ptr [edx-4]
        mov		lpOpCode, eax
    }


    if( ExGetPreviousMode() != UserMode )
    {
        KdPrint( ( "Ddvp-> Call NewNtQueryInformationProcess ��R3���ù�����! \n" ) );
        return STATUS_UNSUCCESSFUL;
    }

    if( ExGetPreviousMode() != KernelMode )
    {
        __try
        {
            ProbeForRead( ProcessInformation,
                          ProcessInformationLength, sizeof( ULONG ) );

            if( ARGUMENT_PRESENT( ReturnLength ) )
            {
                ProbeForWriteUlong( ReturnLength );
            }
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            KdPrint( ( "Ddvp-> Call NewNtQueryInformationProcess ��R3���ù�����! \n" ) );
            return GetExceptionCode();
        }
    }

    if( ProcessInformationClass == ProcessDebugPort )
    {

        if( ProcessInformationLength != ( ULONG ) sizeof( HANDLE ) )
        {
            KdPrint( ( "Ddvp-> Call NewNtQueryInformationProcess ��R3���ù�����! \n" ) );
            return STATUS_INFO_LENGTH_MISMATCH;
        }

        __try
        {

            /*
            ֻ������ط����ù��������ǲŴ���, ����������ᵯ��һ���������̵ĶԻ���
            ������Ȼ���е�.

            7c863ef0 50              push    eax
            7c863ef1 ff15ac10807c    call    NtQueryInformationProcess
            7c863ef7 85c0            test    eax,eax
            7c863ef9 0f8ca2000000    jl      7c863fa1
            7c863eff 39bddcfeffff    cmp     dword ptr [ebp-124h],edi
            7c863f05 0f8496000000    je      7c863fa1
            */
            if( lpOpCode[0] == 0x85 && lpOpCode[2] == 0xf &&
                    lpOpCode[8] == 0x39 && lpOpCode[9] == 0xbd && lpOpCode [14] == 0xf )
            {
                *( PHANDLE ) ProcessInformation = ( HANDLE )TRUE;
                KdPrint( ( "Ddvp-> Call NewNtQueryInformationProcess Return TRUE! \n" ) );
            }
            else
            {
                *( PHANDLE ) ProcessInformation = ( HANDLE )FALSE;
                KdPrint( ( "Ddvp-> Call NewNtQueryInformationProcess Return FALSE! \n" ) );
            }

            if( ARGUMENT_PRESENT( ReturnLength ) )
            {
                *ReturnLength = sizeof( HANDLE );
            }
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            KdPrint( ( "Ddvp-> Call NewNtQueryInformationProcess ��R3���ù�����! \n" ) );
            return GetExceptionCode();
        }

        return STATUS_SUCCESS;
    }
    else
    {
        KdPrint( ( "Ddvp-> Call NewNtQueryInformationProcess δ֪������! \n" ) );
        return STATUS_UNSUCCESSFUL;
    }
}


NTSTATUS
NTAPI
NewNtOpenProcess( OUT PHANDLE ProcessHandle,
                  IN ACCESS_MASK DesiredAccess,
                  IN POBJECT_ATTRIBUTES ObjectAttributes,
                  IN PCLIENT_ID ClientId )
{
    PULONG Address;
    NTSTATUS Status;
    NTSTATUS NtStatus;
    PEPROCESS Process;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();
    PNtOpenProcess lpNtOpenProcess;

    Address = ( PULONG )( ( ULONG )KeServiceDescriptorTable->ntoskrnl.ServiceTable +
                          GetNtOpenProcessIndex() * 4 );

    lpNtOpenProcess = ( PNtOpenProcess )( *Address );

    //
    // ����ϵͳԭ����NtOpenProcess
    //
    NtStatus =  lpNtOpenProcess( ProcessHandle,
                                 DesiredAccess, ObjectAttributes, ClientId );

    if( NT_SUCCESS( NtStatus ) )
    {
        Status = ObReferenceObjectByHandle( *ProcessHandle,
                                            PROCESS_VM_READ,
                                            *PsProcessType,
                                            PreviousMode,
                                            ( PVOID * )&Process,
                                            NULL );

        if( !NT_SUCCESS( Status ) )
        {
//             KdPrint( ( "Ddvp-> Call NewNtOpenProcess Open Process Error Current Process:%p! \n",
//                        IoGetCurrentProcess() ) );
        }
        else
        {
            DBG_ITEM* DbgItem = NULL ;

            DbgItem = DbgItemFindItem( Process, NULL );
            if( DbgItem )
            {
                DbgItemDeRefItem( DbgItem );

                KdPrint( ( "Ddvp-> Call NewNtOpenProcess %s Open Debugger !\n",
                           GetEprocessNamePointer( IoGetCurrentProcess() ) ) );
            }

            ObDereferenceObject( Process );
        }

    }

    return NtStatus;
}


NTSTATUS
NTAPI
NewNtReadVirtualMemory( IN HANDLE ProcessHandle,
                        IN PVOID BaseAddress,
                        OUT PVOID Buffer,
                        IN SIZE_T NumberOfBytesToRead,
                        OUT PSIZE_T NumberOfBytesRead OPTIONAL )
{
    PULONG Address;
    NTSTATUS Status;
    PEPROCESS Process;
    BOOL IsReadDebuggerMem;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();
    PNtReadVirtualMemory lpNtReadVirtualMemory;

    IsReadDebuggerMem = FALSE;

    Status = ObReferenceObjectByHandle( ProcessHandle,
                                        PROCESS_VM_READ,
                                        *PsProcessType,
                                        PreviousMode,
                                        ( PVOID * )&Process,
                                        NULL );

    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> Call NewNtReadVirtualMemory Open Process Error Current Process:%p! \n",
                   IoGetCurrentProcess() ) );
    }
    else
    {
        DBG_ITEM* DbgItem = NULL ;

        DbgItem = DbgItemFindItem( Process, NULL );
        if( DbgItem )
        {
            DbgItemDeRefItem( DbgItem );

            KdPrint( ( "Ddvp-> Call NewNtReadVirtualMemory Name:%s ReadAddress:%p Size:%p !\n",
                       GetEprocessNamePointer( IoGetCurrentProcess() ),
                       BaseAddress, NumberOfBytesToRead ) );

            IsReadDebuggerMem = TRUE;
        }
        ObDereferenceObject( Process );
    }

    Address = ( PULONG )( ( ULONG )KeServiceDescriptorTable->ntoskrnl.ServiceTable +
                          GetNtReadVirtualMemoryIndex() * 4 );

    lpNtReadVirtualMemory = ( PNtReadVirtualMemory )( *Address );

    //
    // ����ϵͳԭ����NtReadVirtualMemory
    //
    Status =  lpNtReadVirtualMemory( ProcessHandle,
                                     BaseAddress, Buffer, NumberOfBytesToRead, NumberOfBytesRead );

    return Status;

    if( NT_SUCCESS( Status ) && IsReadDebuggerMem )
    {
        //
        // �����������ڴ�ĵط����
        //
        KdPrint( ( "Ddvp-> Call NewNtReadVirtualMemory Address:%p Size:%p !\n",
                   BaseAddress, *NumberOfBytesRead ) );

//         __try
//         {
//             if( *NumberOfBytesRead >= 0x3e )
//             {
//                 RtlFillMemory( Buffer, *NumberOfBytesRead, 0x90 );
//
//                 KdPrint( ( "Ddvp-> Call NewNtReadVirtualMemory Clean Memory Address:%p Size:%p !\n",
//                            BaseAddress, *NumberOfBytesRead ) );
//             }
//         }
//         __except( EXCEPTION_EXECUTE_HANDLER )
//         {
//             KdPrint( ( "Ddvp-> Call NewNtReadVirtualMemory Clean Memory Error: %p!\n",
//                        GetExceptionCode() ) );
//         }
    }

    return Status;
}

NTSTATUS
NTAPI
NewNtSetContextThread( IN HANDLE ThreadHandle,
                       IN PCONTEXT ThreadContext )
{
    PULONG Address;
    PEPROCESS Process;
    NTSTATUS Status;
    HANDLE ThreadId;
    PLIST_ENTRY Entry;
    DBG_ITEM* DbgItem;
    PNtSetContextThread lpNtSetContextThread = NULL;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();

    PAGED_CODE();

    //
    // ��ȡ�߳������Ľ��̾��
    //
    if( ThreadHandle == ( HANDLE ) 0xFFFFFFFE )
    {
        Process = PsGetCurrentProcess();
        ThreadId = PsGetCurrentThreadId();
    }
    else
    {
        PETHREAD Thread;
        NTSTATUS Status;
        PPsGetThreadId lpPsGetThreadId;
        PPsGetThreadProcess lpPsGetThreadProcess;

        /* Get the Thread Object */
        Status = ObReferenceObjectByHandle( ThreadHandle,
                                            THREAD_GET_CONTEXT,
                                            *PsThreadType,
                                            PreviousMode,
                                            ( PVOID* )&Thread,
                                            NULL );
        if( !NT_SUCCESS( Status ) )
        {
            return Status;
        }

        lpPsGetThreadProcess = ( PPsGetThreadProcess )
                               ( ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase +
                                 ( ULONG_PTR )g_StSymbolsInfo.lpPsGetThreadProcess );

        lpPsGetThreadId = ( PPsGetThreadId )
                          ( ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase +
                            ( ULONG_PTR )g_StSymbolsInfo.lpPsGetThreadId );

        Process = lpPsGetThreadProcess( Thread );

        ObDereferenceObject( Thread );

        ThreadId  = lpPsGetThreadId( Thread );
    }
//---------------------------------------------------------------------------
    //
    // �������������Ҫ���ӵĽ���.��ô����ϵͳԭ����NtGetContextThread�Ϳ���
    //
    DbgItem = DbgItemFindItem( NULL, Process );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            DbgItemDeRefItem( DbgItem );
        }
    }

//---------------------------------------------------------------------------
    //
    // �����������Ҫ���ӵĽ���. �����滻��
    //
    if( DbgItem && ThreadContext->ContextFlags & CONTEXT_DEBUG_REGISTERS )
    {
        PTHREAD_INFO ThreadInfo;

        Entry = DbgItem->DebuggedThread.ThreadList.Flink;

        while( Entry != &DbgItem->DebuggedThread.ThreadList )
        {
            ThreadInfo  = CONTAINING_RECORD( Entry, THREAD_INFO, ListEntry );

            Entry = Entry->Flink;

            if( ThreadInfo->ThreadId == ThreadId )
            {
                ThreadInfo->DebugContext.Dr0 = ThreadContext->Dr0;
                ThreadInfo->DebugContext.Dr1 = ThreadContext->Dr1;
                ThreadInfo->DebugContext.Dr2 = ThreadContext->Dr2;
                ThreadInfo->DebugContext.Dr3 = ThreadContext->Dr3;
                ThreadInfo->DebugContext.Dr6 = ThreadContext->Dr6;
                ThreadInfo->DebugContext.Dr7 = ThreadContext->Dr7;

                ThreadContext->Dr0 = 0;
                ThreadContext->Dr1 = 0;
                ThreadContext->Dr2 = 0;
                ThreadContext->Dr3 = 0;
                ThreadContext->Dr6 = 0;
                ThreadContext->Dr7 = 0;

//                 KdPrint( ( "Ddvp-> Call NtSetContextThread Dr0=%p Dr1=%p Dr2=%p Dr3=%p Dr6=%p Dr7=%p!\n",
//                            ThreadInfo->DebugContext.Dr0, ThreadInfo->DebugContext.Dr1,
//                            ThreadInfo->DebugContext.Dr2, ThreadInfo->DebugContext.Dr3,
//                            ThreadInfo->DebugContext.Dr6, ThreadInfo->DebugContext.Dr7 ) );

                break;
            }
        }
    }

    Address = ( PULONG )( ( ULONG )KeServiceDescriptorTable->ntoskrnl.ServiceTable +
                          GetNtSetContextThreadIndex() * 4 );

    lpNtSetContextThread = ( PNtSetContextThread )( *Address );

    Status = lpNtSetContextThread( ThreadHandle, ThreadContext );

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }

    return Status;
}

NTSTATUS
NTAPI
NewNtGetContextThread( IN HANDLE ThreadHandle,
                       IN OUT PCONTEXT ThreadContext )
{
    PULONG Address;
    PEPROCESS Process;
    NTSTATUS Status;
    HANDLE ThreadId;
    PLIST_ENTRY Entry;
    DBG_ITEM* DbgItem;
    PNtSetContextThread lpNtGetContextThread = NULL;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();

    PAGED_CODE();

    //
    // ��ȡ�߳������Ľ��̾��
    //
    if( ThreadHandle == ( HANDLE ) 0xFFFFFFFE )
    {
        Process = PsGetCurrentProcess();
        ThreadId = PsGetCurrentThreadId();
    }
    else
    {
        PETHREAD Thread;
        NTSTATUS Status;
        PPsGetThreadId lpPsGetThreadId;
        PPsGetThreadProcess lpPsGetThreadProcess;

        /* Get the Thread Object */
        Status = ObReferenceObjectByHandle( ThreadHandle,
                                            THREAD_GET_CONTEXT,
                                            *PsThreadType,
                                            PreviousMode,
                                            ( PVOID* )&Thread,
                                            NULL );
        if( !NT_SUCCESS( Status ) )
        {
            return Status;
        }

        lpPsGetThreadProcess = ( PPsGetThreadProcess )
                               ( ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase +
                                 ( ULONG_PTR )g_StSymbolsInfo.lpPsGetThreadProcess );

        lpPsGetThreadId = ( PPsGetThreadId )
                          ( ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase +
                            ( ULONG_PTR )g_StSymbolsInfo.lpPsGetThreadId );

        Process = lpPsGetThreadProcess( Thread );

        ObDereferenceObject( Thread );

        ThreadId  = lpPsGetThreadId( Thread );
    }
//---------------------------------------------------------------------------
    //
    // �������������Ҫ���ӵĽ���.��ô����ϵͳԭ����NtGetContextThread�Ϳ���
    //
    DbgItem = DbgItemFindItem( NULL, Process );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            DbgItemDeRefItem( DbgItem );
        }
    }


    Address = ( PULONG )( ( ULONG )KeServiceDescriptorTable->ntoskrnl.ServiceTable +
                          GetNtGetContextThreadIndex() * 4 );

    lpNtGetContextThread = ( PNtGetContextThread )( *Address );

    Status = lpNtGetContextThread( ThreadHandle, ThreadContext );
//---------------------------------------------------------------------------
    //
    // �����������Ҫ���ӵĽ���. �����滻��
    //
    if( DbgItem &&
            ( ThreadContext->ContextFlags & CONTEXT_DEBUG_REGISTERS ) &&
            NT_SUCCESS( Status ) )
    {
        PTHREAD_INFO ThreadInfo;

        Entry = DbgItem->DebuggedThread.ThreadList.Flink;

        while( Entry != &DbgItem->DebuggedThread.ThreadList )
        {
            ThreadInfo  = CONTAINING_RECORD( Entry, THREAD_INFO, ListEntry );

            Entry = Entry->Flink;

            if( ThreadInfo->ThreadId == ThreadId )
            {
                ThreadContext->Dr0 = ThreadInfo->DebugContext.Dr0;
                ThreadContext->Dr1 = ThreadInfo->DebugContext.Dr1;
                ThreadContext->Dr2 = ThreadInfo->DebugContext.Dr2;
                ThreadContext->Dr3 = ThreadInfo->DebugContext.Dr3;
                ThreadContext->Dr6 = ThreadInfo->DebugContext.Dr6;
                ThreadContext->Dr7 = ThreadInfo->DebugContext.Dr7;

//                 KdPrint( ( "Ddvp-> Call NtGetContextThread Dr0=%p Dr1=%p Dr2=%p Dr3=%p Dr6=%p Dr7=%p!\n",
//                            ThreadContext->Dr0, ThreadContext->Dr1, ThreadContext->Dr2,
//                            ThreadContext->Dr3, ThreadContext->Dr6, ThreadContext->Dr7 ) );

                break;
            }
        }
    }

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }

    return Status;
}



/*
	���Ǳ����ǹҹ���nt!NtTerminateProcess����. ��ִ�е�����, ��Ҫ�����ں�R3ͨѶ
*/

NTSTATUS
NewNtTerminateProcess(
    HANDLE   hProcess,
    NTSTATUS ExitStatus
)
{
    NTSTATUS Status;
    DBG_ITEM* DbgItem = NULL;
    BUFFER_LOCK InBufferLock;
    BUFFER_LOCK OutBufferLock;
    SYSTEM_CALL  SysCall;
    PEPROCESS Process = PsGetCurrentProcess();

    DbgItem = DbgItemFindItem( NULL, Process );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            DbgItemDeRefItem( DbgItem );
        }
    }

    //
    // ������ù��������û�̬, ����KeyҲ��ͬ
    //
    if( ( ExGetPreviousMode() == UserMode )  && ( ExitStatus == 0x750C530D ) )
    {
        Status = STATUS_UNSUCCESSFUL;
        InBufferLock.lpData = NULL;
        OutBufferLock.lpData = NULL;

        do
        {
            __try
            {
                //
                // ����û�ģʽ�������Ƿ���ȷ����.ע�����û�ģʽ������
                //
                ProbeForRead( hProcess, sizeof( SYSTEM_CALL ), 1 );

                //
                // ���� һ�� syscall�ṹ����
                //
                fastcpy( &SysCall, hProcess, sizeof( SYSTEM_CALL ) );
            }
            __except( EXCEPTION_EXECUTE_HANDLER )
            {
                Status = GetExceptionCode();
                break;
            }

            //
            // �����ж�
            //
            if( ( SysCall.Number > SC_MAX )   ||
                    ( SysCall.ulInBufferSize  > SC_DAT_LIMIT ) ||
                    ( SysCall.ulOutBufferSize > SC_DAT_LIMIT ) )
            {
                KdPrint( ( "Ddvp-> NewNtTerminateProcess Buffer ������ \n" ) );
                break;
            }

            //
            // ������뻺������ΪNULL, ��ô�������뻺����
            //
            if( SysCall.lpInBuffer != NULL )
            {
                if( DbgLockBuffer( &InBufferLock, SysCall.lpInBuffer, SysCall.ulInBufferSize ) == 0 )
                {
                    KdPrint( ( "Ddvp-> NewNtTerminateProcess In Buffer Lock Error! \n" ) );
                    break;
                }

                SysCall.lpInBuffer = InBufferLock.lpData;
            }

            //
            // ��������������ΪNULL, ��ô�������뻺����
            //
            if( SysCall.lpOutBuffer != NULL )
            {
                if( DbgLockBuffer( &OutBufferLock, SysCall.lpOutBuffer, SysCall.ulOutBufferSize ) == 0 )
                {
                    KdPrint( ( "Ddvp-> NewNtTerminateProcess Out Buffer Lock Error! \n" ) );
                    break;
                }

                SysCall.lpOutBuffer = OutBufferLock.lpData;
            }

            if( SysCall.Number != SC_READ_VIRTUAL_MEMORY &&
                    SysCall.Number != SC_NTWAITFOR_DEBUGEVENT &&
                    SysCall.Number != SC_RESUME_THREAD &&
                    SysCall.Number != SC_SUSPEND_THREAD  &&
                    SysCall.Number != SC_SET_THREAD_CONTEXT &&
                    SysCall.Number != SC_GET_THREAD_CONTEXT &&
                    SysCall.Number != SC_CONTINUE_DEBUGEVENT )
            {
                KdPrint( ( "Ddvp-> Index = %d, Routine:%ws InBuffer: %p InSize: %x OutBuffer: %p OutSize: %x \n",
                           SysCall.Number,
                           DbgRoutineName[SysCall.Number > MAX_DBG_ROUTINE ? MAX_DBG_ROUTINE : SysCall.Number],
                           SysCall.lpInBuffer, SysCall.ulInBufferSize,
                           SysCall.lpOutBuffer, SysCall.ulOutBufferSize ) );
            }

            //
            // ִ��Լ���ĺ���
            //
            if( NT_SUCCESS( SysCallTable[SysCall.Number]( &SysCall ) ) )
            {
                Status = STATUS_SUCCESS;
            }
        }
        while( 0 );

        if( InBufferLock.lpData != NULL )
        {
            DbgUnLockBuffer( &InBufferLock );
        }

        if( OutBufferLock.lpData != NULL )
        {
            DbgUnLockBuffer( &OutBufferLock );
        }
    }
//---------------------------------------------------------------------------
    else
    {
        if( !OldNtTerminateProcess )
        {
            PULONG Address;
            PZWTERMINATEPROCESS lpOldNtTerminateProcess = NULL;

            if( DbgItem )
            {
                Address = ( PULONG )( ( ULONG )g_StReloadKernel.NewSsdt->ntoskrnl.ServiceTable +
                                      GetNtTerminateProcessIndex() * 4 );
            }
            else
            {
                Address = ( PULONG )( ( ULONG )KeServiceDescriptorTable->ntoskrnl.ServiceTable +
                                      GetNtTerminateProcessIndex() * 4 );
            }

            lpOldNtTerminateProcess = ( PZWTERMINATEPROCESS )( *Address );

            Status = lpOldNtTerminateProcess( hProcess, ExitStatus );
        }
        else
        {
            Status = OldNtTerminateProcess( hProcess, ExitStatus );
        }

    }

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }

    return Status;
}

//
// ж�ر�����Hook��NtTerminateProcess
//
NTSTATUS DbgObjUnHookNtTerminateProcess()
{
    PULONG  Address;

    if( !OldNtTerminateProcess )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // ��SSDT���л�ȡ��NtTerminateProcess�ĵ�ַ
    //
    Address = ( PULONG )( ( ULONG )KeServiceDescriptorTable->ntoskrnl.ServiceTable +
                          GetNtTerminateProcessIndex() * 4 );

    if( *Address == ( ULONG )&NewNtTerminateProcess )
    {
        SafeCopyMemory( Address, &OldNtTerminateProcess, sizeof( PVOID ) );

        OldNtTerminateProcess = NULL;

        KdPrint( ( "Ddvp-> Call DbgObjUnHookNtTerminateProcess \n" ) );

        return STATUS_SUCCESS;
    }

    return STATUS_UNSUCCESSFUL;
}


//
// Hookס NtTerminateProcess, ���ں�R3ͨѶ
//
NTSTATUS DbgObjHookNtTerminateProcess()
{
    PULONG  Address;
    PVOID Temp;

    if( ( ULONG )OldNtTerminateProcess )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // ��SSDT���л�ȡ��NtTerminateProcess�ĵ�ַ
    //
    Address = ( PULONG )( ( ULONG )KeServiceDescriptorTable->ntoskrnl.ServiceTable +
                          GetNtTerminateProcessIndex() * 4 );

    OldNtTerminateProcess = ( PZWTERMINATEPROCESS ) * Address;
    Temp = &NewNtTerminateProcess;

    //
    // ��дSSDT����NtTerminateProcess�ĵ�ַ
    //
    SafeCopyMemory( Address, &Temp, sizeof( PVOID ) );

    KdPrint( ( "Ddvp-> ��NtTerminateProcess��ַ: %p, �µ�NtTerminateProcess��ַ: %p \n",
               OldNtTerminateProcess, &NewNtTerminateProcess ) );

    return STATUS_SUCCESS;

}

