#pragma once
#include "CCmdTarget.h"
#include "CWnd.h"

class CWinThread :
    public CCmdTarget
{
public:
  virtual BOOL InitInstance();
  virtual int ExitInstance();
  virtual int Run();
public:
  CWnd* m_pMainWnd;
};

