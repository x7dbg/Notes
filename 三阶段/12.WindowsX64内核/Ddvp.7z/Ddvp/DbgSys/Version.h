typedef enum WIN_VER_DETAIL {
	WINDOWS_VERSION_NONE,       //  0
	WINDOWS_VERSION_2K,
	WINDOWS_VERSION_XP,
	WINDOWS_VERSION_2K3,
	WINDOWS_VERSION_2K3_SP1_SP2,
	WINDOWS_VERSION_VISTA_2008,
	WINDOWS_VERSION_7
} WIN_VER_DETAIL;



typedef NTSTATUS (NTAPI * PFN_RtlGetVersion)(OUT PRTL_OSVERSIONINFOW lpVersionInformation);

WIN_VER_DETAIL GetWindowsVersion();
PVOID GetEprocessSectionBaseAddress(PVOID p );
PVOID GetEprocessSectionObject(PVOID p );
PVOID GetThreadCid(PVOID p);
ULONG GetNtTerminateProcessIndex();
PVOID GetEProcessPeb(PVOID p);
ULONG GetNtQueryInformationProcessIndex();
PVOID GetEprocessRundownProtect( PVOID p);
PVOID GetEThreadRundownProtect( PVOID p);
PVOID GetEThreadSystemThread( PVOID p);
PVOID GetPebLdr(PVOID p);
PVOID GetEprocessPcbPointer(PVOID p);
PVOID GetEThreadStartAddress( PVOID p);
PVOID GetObjectTypeTypeInfoGenericMapping( PVOID p );
PVOID GetEprocessNamePointer( PVOID p );
ULONG GetNtSetContextThreadIndex();
ULONG GetNtGetContextThreadIndex();
PVOID GetEprocessCr3( PVOID p );
ULONG GetNtCreateThreadIndex();
ULONG GetNtTerminateThreadIndex();
ULONG GetNtMapViewOfSectionIndex();
ULONG GetNtUnMapViewOfSectionIndex();
ULONG GetNtRaiseExceptionIndex();
ULONG GetNtReadVirtualMemoryIndex();
PVOID GetEprocessActiveProcessLinks(PVOID p);
ULONG GetNtUserFindWindowExIndex();
ULONG GetNtUserGetForegroundWindowIndex();
ULONG GetNtUserBuildHwndListIndex();
ULONG GetNtUserWindowFromPointIndex();
PVOID GetEProcessVAD(PVOID p);
PVOID GetEprocessUniqueProcessId( PVOID p );
PVOID GetActiveProcessLinksEprocess(PVOID p);
PVOID GetEprocessObjectTable( PVOID p );
ULONG GetNtOpenProcessIndex();
PVOID GetEThreadTcbPoint( PVOID p);
PVOID GetEThreadTcbTerminatedBit( PVOID p );
ULONG GetNtCloseIndex();