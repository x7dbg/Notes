#pragma once
#include "CFrameWnd.h"

class CTestFrame :public CFrameWnd
{
    DECLARE_DYNAMIC(CTestFrame);
};

