#include "CTestDoc.h"

IMPLEMENT_DYNAMIC(CTestDoc, CDocument)