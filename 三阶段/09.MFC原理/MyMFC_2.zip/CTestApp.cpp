#include "CTestApp.h"
#include "CSingleDocTemplate.h"

IMPLEMENT_DYNAMIC(CTestApp, CWinApp)

BOOL CTestApp::InitInstance()
{
  CSingleDocTemplate* pDocTemplate = NULL;
  pDocTemplate = new CSingleDocTemplate();
  if (!pDocTemplate)
    return FALSE;

  AddDocTemplate(pDocTemplate);

  CWinApp::OnFileNew();

  m_pMainWnd->ShowWindow(SW_SHOW);
  m_pMainWnd->UpdateWindow();

  return TRUE;
}

int CTestApp::ExitInstance()
{
  return -1;
}
