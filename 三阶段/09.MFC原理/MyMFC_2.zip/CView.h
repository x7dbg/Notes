#pragma once
#include "CWnd.h"
class CView :public CWnd
{
    DECLARE_DYNAMIC(CView);
};

