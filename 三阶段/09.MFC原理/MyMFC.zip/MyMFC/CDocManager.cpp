#include "CDocManager.h"
#include "CDocTemplate.h"

void CDocManager::OnFileNew()
{
  if (m_templateList.empty())
  {
    printf("Error: no document templates registered with CWinApp.\n");
    return;
  }

  CDocTemplate* pTemplate = (CDocTemplate*)m_templateList.front();
  pTemplate->OpenDocumentFile(NULL);
}

void CDocManager::AddDocTemplate(CDocTemplate* pTemplate)
{
  m_templateList.push_back(pTemplate);
}
