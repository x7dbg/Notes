﻿// CImgBtn.cpp: 实现文件
//

#include "pch.h"
#include "PlantDLL.h"
#include "CImgBtn.h"


// CImgBtn

IMPLEMENT_DYNAMIC(CImgBtn, CStatic)

CImgBtn::CImgBtn()
{

}

CImgBtn::~CImgBtn()
{
}


BEGIN_MESSAGE_MAP(CImgBtn, CStatic)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
END_MESSAGE_MAP()



// CImgBtn 消息处理程序

void CImgBtn::OnLButtonDown(UINT nFlags, CPoint point)
{
	SetCapture();
	CStatic::OnLButtonDown(nFlags, point);
}

void CImgBtn::OnLButtonUp(UINT nFlags, CPoint point)
{
	ReleaseCapture();

	HWND hWnd = ::FindWindowA(NULL, "植物大战僵尸中文版");
	if (hWnd != NULL) {
		POINT pos = { 0 };
		GetCursorPos(&pos);
		HWND hCurWnd = ::WindowFromPoint(pos);
		if (hCurWnd == hWnd) {
			RECT rect = { 0 };
			::ScreenToClient(hWnd, &pos);
			int hang = pos.y / 80 - 1;
			if (hang >= 0 && hang <= 5) {
				PutZombies(hang, m_emZombiesType);
			}
		}
	}
	CStatic::OnLButtonUp(nFlags, point);
}
