#include "Drv.h"

typedef struct _SYSTEM_HANDLE_TABLE_ENTRY_INFO {
  USHORT UniqueProcessId;
  USHORT CreatorBackTraceIndex;
  UCHAR ObjectTypeIndex;
  UCHAR HandleAttributes;
  USHORT HandleValue;
  PVOID Object;
  ULONG GrantedAccess;
} SYSTEM_HANDLE_TABLE_ENTRY_INFO, * PSYSTEM_HANDLE_TABLE_ENTRY_INFO;

typedef struct _SYSTEM_HANDLE_INFORMATION {
  ULONG NumberOfHandles;
  SYSTEM_HANDLE_TABLE_ENTRY_INFO Handles[1];
} SYSTEM_HANDLE_INFORMATION, * PSYSTEM_HANDLE_INFORMATION;

typedef enum _SYSTEM_INFORMATION_CLASS {
  SystemBasicInformation,
  SystemProcessorInformation,             // obsolete...delete
  SystemPerformanceInformation,
  SystemTimeOfDayInformation,
  SystemPathInformation,
  SystemProcessInformation,
  SystemCallCountInformation,
  SystemDeviceInformation,
  SystemProcessorPerformanceInformation,
  SystemFlagsInformation,
  SystemCallTimeInformation,
  SystemModuleInformation,
  SystemLocksInformation,
  SystemStackTraceInformation,
  SystemPagedPoolInformation,
  SystemNonPagedPoolInformation,
  SystemHandleInformation,
  SystemObjectInformation,
  SystemPageFileInformation,
  SystemVdmInstemulInformation,
  SystemVdmBopInformation,
  SystemFileCacheInformation,
  SystemPoolTagInformation,
  SystemInterruptInformation,
  SystemDpcBehaviorInformation,
  SystemFullMemoryInformation,
  SystemLoadGdiDriverInformation,
  SystemUnloadGdiDriverInformation,
  SystemTimeAdjustmentInformation,
  SystemSummaryMemoryInformation,
  SystemMirrorMemoryInformation,
  SystemPerformanceTraceInformation,
  SystemObsolete0,
  SystemExceptionInformation,
  SystemCrashDumpStateInformation,
  SystemKernelDebuggerInformation,
  SystemContextSwitchInformation,
  SystemRegistryQuotaInformation,
  SystemExtendServiceTableInformation,
  SystemPrioritySeperation,
  SystemVerifierAddDriverInformation,
  SystemVerifierRemoveDriverInformation,
  SystemProcessorIdleInformation,
  SystemLegacyDriverInformation,
  SystemCurrentTimeZoneInformation,
  SystemLookasideInformation,
  SystemTimeSlipNotification,
  SystemSessionCreate,
  SystemSessionDetach,
  SystemSessionInformation,
  SystemRangeStartInformation,
  SystemVerifierInformation,
  SystemVerifierThunkExtend,
  SystemSessionProcessInformation,
  SystemLoadGdiDriverInSystemSpace,
  SystemNumaProcessorMap,
  SystemPrefetcherInformation,
  SystemExtendedProcessInformation,
  SystemRecommendedSharedDataAlignment,
  SystemComPlusPackage,
  SystemNumaAvailableMemory,
  SystemProcessorPowerInformation,
  SystemEmulationBasicInformation,
  SystemEmulationProcessorInformation,
  SystemExtendedHandleInformation,
  SystemLostDelayedWriteInformation,
  SystemBigPoolInformation,
  SystemSessionPoolTagInformation,
  SystemSessionMappedViewInformation,
  SystemHotpatchInformation,
  SystemObjectSecurityMode,
  SystemWatchdogTimerHandler,
  SystemWatchdogTimerInformation,
  SystemLogicalProcessorInformation,
  SystemWow64SharedInformation,
  SystemRegisterFirmwareTableInformationHandler,
  SystemFirmwareTableInformation,
  SystemModuleInformationEx,
  SystemVerifierTriageInformation,
  SystemSuperfetchInformation,
  SystemMemoryListInformation,
  SystemFileCacheInformationEx,
  MaxSystemInfoClass  // MaxSystemInfoClass should always be the last enum
} SYSTEM_INFORMATION_CLASS;

NTSTATUS
NTAPI
ZwQuerySystemInformation(
  __in SYSTEM_INFORMATION_CLASS SystemInformationClass,
  __out_bcount_opt(SystemInformationLength) PVOID SystemInformation,
  __in ULONG SystemInformationLength,
  __out_opt PULONG ReturnLength
);

typedef NTSTATUS (NTAPI * FUNTYPE)(IN PETHREAD Thread,
  IN NTSTATUS ExitStatus,
  IN BOOLEAN bSelf);

FUNTYPE PspTerminateThreadByPointer = NULL;

void MyExitProcess(HANDLE pid) {
  UNREFERENCED_PARAMETER(pid);

  UCHAR *pCode = (UCHAR*)&PsTerminateSystemThread;
  while(*pCode != 0xe8) {
    pCode++;
  }

  PspTerminateThreadByPointer = (FUNTYPE)(pCode + *(int*)(pCode + 1) + 5);
  DbgPrint("[51asm] PspTerminateThreadByPointer:%p\n", PspTerminateThreadByPointer);

  PEPROCESS Process = NULL;
  NTSTATUS Status;

  Status = PsLookupProcessByProcessId(pid, &Process);
  DbgPrint("[51asm] Process:%p\n", Process);

  if (NT_SUCCESS(Status)) {
 
    //�����߳�
    PETHREAD Thread = NULL;
    for (int i = 0; i < 65536; i+=4) {
      Status = PsLookupThreadByThreadId((HANDLE)i, &Thread);
      if (NT_SUCCESS(Status)) {
        if (IoThreadToProcess(Thread) == Process) {
          DbgPrint("[51asm] exit Thread:%p\n", Thread);
          Status = PspTerminateThreadByPointer(Thread, 0, TRUE);
          if (NT_SUCCESS(Status)) {
            DbgPrint("[51asm] exit Thread:%p OK\n", Thread);
          }
        }
        ObDereferenceObject(Thread);
      }
    }

    ObDereferenceObject(Process);
  }
}

NTSTATUS UnlockFile() {
  NTSTATUS Status;
  SYSTEM_HANDLE_INFORMATION *           Handles = NULL;
  PVOID Buffer;
  ULONG BufferSize = 4096;
  ULONG ReturnLength;
  POBJECT_NAME_INFORMATION NameInfo = NULL;

  //KdBreakPoint();

  NameInfo = ExAllocatePoolWithTag(NonPagedPool, 4096, '1234');
  if (!NameInfo) 
    return STATUS_NO_MEMORY;

retry:
  Buffer = ExAllocatePoolWithTag(NonPagedPool, BufferSize, '1234');

  if (!Buffer) {
    return STATUS_NO_MEMORY;
  }
  Status = ZwQuerySystemInformation(SystemHandleInformation,
    Buffer,
    BufferSize,
    &ReturnLength
  );

  if (Status == STATUS_INFO_LENGTH_MISMATCH) {
    ExFreePool(Buffer);
    BufferSize = ReturnLength;
    goto retry;
  }

  if (NT_SUCCESS(Status)) {
    Handles = (SYSTEM_HANDLE_INFORMATION*)Buffer;

   
    for (ULONG i = 0; i < Handles->NumberOfHandles; i++) {
      if (MmIsAddressValid(Handles->Handles[i].Object)) {
        Status = ObReferenceObjectByPointer(Handles->Handles[i].Object, 0, *IoFileObjectType, KernelMode);
        if (NT_SUCCESS(Status)) {
            //      //��ȡ�ļ���������
            Status = ObQueryNameString(Handles->Handles[i].Object,
              NameInfo,
              4096,
              &ReturnLength);
            if (NT_SUCCESS(Status)) {
              if (wcsstr(NameInfo->Name.Buffer, L"1.txt") != NULL) {
                DbgPrint("[51asm] Name:%wZ\n", &NameInfo->Name);

                PEPROCESS Process = NULL;
                Status = PsLookupProcessByProcessId((HANDLE)Handles->Handles[i].UniqueProcessId, &Process);
                DbgPrint("[51asm] Process:%p\n", Process);


                if (NT_SUCCESS(Status)) {
                  KAPC_STATE KS;
                  KeStackAttachProcess(Process, &KS);
                  ZwClose((HANDLE)Handles->Handles[i].HandleValue);
                  KeUnstackDetachProcess(&KS);
                  DbgPrint("[51asm] unlock ok Process:%p\n", Process);
                  ObDereferenceObject(Process);
                }
              }
              
            }

          ObDereferenceObject(Handles->Handles[i].Object);
        }
      }
    }
    DbgPrint("[51asm] NumberOfHandles:%d\n", Handles->NumberOfHandles);
    //for (i = 0, HandleInfo = &(Handles->Handles[0]);
    //  i < Handles->NumberOfHandles;
    //  i++, HandleInfo++) {
 
	   // if (MmIsAddressValid(HandleInfo->Object)) {
    //    //�����ļ�����
    //    Status = ObReferenceObjectByPointer(HandleInfo->Object,0, *IoFileObjectType, KernelMode);
    //    if (NT_SUCCESS(Status)) {

    //      //��ȡ�ļ���������
    //      Status = ObQueryNameString(HandleInfo->Object,
    //        NameInfo,
    //        4096,
    //        NULL);
    //      if (NT_SUCCESS(Status)) {
    //        //DbgPrint("[51asm] Name:%wZ\n", &NameInfo->Name);
    //        /*  if (wcsstr(NameInfo->Name.Buffer, L"1.txt") != NULL) {


    //            PEPROCESS Process = NULL;
    //            Status = PsLookupProcessByProcessId((HANDLE)HandleInfo->UniqueProcessId, &Process);
    //            DbgPrint("[51asm] Process:%p\n", Process);


    //            if (NT_SUCCESS(Status)) {
    //              KAPC_STATE KS;
    //              KeStackAttachProcess(Process, &KS);
    //              ZwClose((HANDLE)HandleInfo->HandleValue);
    //              KeUnstackDetachProcess(&KS);
    //              DbgPrint("[51asm] unlock ok Process:%p\n", Process);
    //              ObDereferenceObject(Process);
    //            }
    //          }*/
    //        ObDereferenceObject(HandleInfo->Object);
    //      }
    //    }
    //  }
    //}
  }


  ExFreePool(Buffer);
  ExFreePool(NameInfo);
  return Status;
}

/*����ж�غ��� clean_up*/
VOID Unload(__in struct _DRIVER_OBJECT* DriverObject)
{
  DbgPrint("[51asm] Unload! DriverObject:%p\n", DriverObject);
}


/*1.������ں���*/
 NTSTATUS DriverEntry(
  __in struct _DRIVER_OBJECT* DriverObject,
  __in PUNICODE_STRING  RegistryPath)
{
  UNREFERENCED_PARAMETER(DriverObject);
  UNREFERENCED_PARAMETER(RegistryPath);

  //4.ע��ж�غ���
  DriverObject->DriverUnload = Unload;

  DbgPrint("[51asm] DriverEntry DriverObject:%p\n", DriverObject);

  UnlockFile();
  //MyExitProcess((HANDLE)4);
  return STATUS_SUCCESS;
}
