//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ���ǹ������û�̬ʹ�õ�API�����ӿ�, ģ��󲿷ֺ͵����йصĺ���.
 *
 */
//===========================================================================

#include <tchar.h>
#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <psapi.h>
#include <DbgHelp.h>
#include <shlwapi.h>
#include "ntdll.h"
#include "DbgObj.h"
#include "IoControlCode.h"
#include "DbgObjMisc.h"
#include "resource.h"


//---------------------------------------------------------------------------
SYMBOLS_INFO	StSymbolsInfo;
DWORD64			BaseOfDll;
static HMODULE	hDllInst;
static PVOID	lpDbgBreadkPoint;
//---------------------------------------------------------------------------

// vs2008 ��һ��Bug.
#if _MSC_FULL_VER == 150030729
#define _DO_NOT_DECLARE_INTERLOCKED_INTRINSICS_IN_MEMORY
#endif

//===========================================================================


//===========================================================================


/*
 * ����������, �߱���ʽ����OutputDebugString
 */
int __cdecl DbgObjPrint( char* _Format, ... )
{
    int iRet;
    va_list list;
    char SzBuf[8192] = {0};

    va_start( list, _Format );

    iRet = vsprintf_s( SzBuf, sizeof( SzBuf ),  _Format, list );

    OutputDebugStringA( SzBuf );

    va_end( list );

    return iRet;
}

/*
 * ��ȡDbgObj���Կ�ܵİ汾.
 *
 * Return: �ɹ����ذ汾��, ���򷵻�0
 */

BOOL
WINAPI
DbgObjGetVersion( PDICHLORVOS_VERISON Version )
{
    if( !Version )
    {
        return FALSE;
    }

    RtlZeroMemory( Version, sizeof( DICHLORVOS_VERISON ) );

    if( !DbgObjCall( SC_GET_VERSION, NULL, 0, Version, sizeof( DICHLORVOS_VERISON ) ) )
    {
        return FALSE;
    }

    KdPrint( ( "DbgObj-> Version %d.%d Build Time : %s \n",
               Version->ulMainVersion, Version->ulChildVersion, Version->SzBuildTime ) );

    return TRUE;
}

/*
 * ����BIOS�Ƿ���VT����.
 *
 * Return: ���Կ�������TRUE, ���򷵻�FALSE
 */

BOOL
WINAPI
DbgObjCheckBiosIsEnabled()
{
    if( !DbgObjCall( SC_CHECKBIOS_ISENABLED, NULL, 0, NULL, 0 ) )
    {
        return FALSE;
    }
    return TRUE;
}

//
// ���豸, ������CreateFile
// SzDeviceName �豸����
//
BOOL
WINAPI
DbgObjCreateDevice( wchar_t* SzDeviceName )
{
    HWND hWnd;
    DWORD dwProcessID = 0;
    CREATE_DEVICE StBuildParam = {0};

    RtlMoveMemory( &StBuildParam.StSymbols, &StSymbolsInfo, sizeof( SYMBOLS_INFO ) );

    //
    // ������Explorer �Ľ���ID
    //
    hWnd = FindWindow( _T( "Progman" ), _T( "Program Manager" ) );
    if( !hWnd )
    {
        return FALSE;
    }

    GetWindowThreadProcessId( hWnd, &dwProcessID );
    if( dwProcessID == 0 )
    {
        return FALSE;
    }

    StBuildParam.dwProcessID = dwProcessID;


    //
    // ��R3������pdb�ļ���Ϣ���ݵ�R0
    //
    return DbgObjCall( SC_IRP_CREATE, &StBuildParam,
                       sizeof( CREATE_DEVICE ), &lpDbgBreadkPoint, sizeof( PVOID ) );
}

//
// �ر��豸, ������CloseHanle, ����FALSE�Ļ�, ����ж������
//

BOOL
WINAPI
DbgObjCloseHanle( wchar_t* SzDeviceName )
{
    BOOL bRet;
    ULONG ulClient;

    bRet =  DbgObjCall( SC_IRP_CLOSE, &ulClient, sizeof( ulClient ), NULL, 0 );

    if( bRet == 0 )
    {
        return FALSE;
    }

    //
    // ֻ�е��ͻ���ֻ��1����ʱ��, ��ж��.
    //
    if( !ulClient )
    {
        DbgObjUnInstallService( SzDeviceName );
    }
    return TRUE;
}

/*
 * ����ϵͳ��ʼ��, ��ʹ�õ���ϵͳ���еĺ���֮ǰ����
 * ����֮ǰ�����ȵ��� DbgObjEnumSymbols(). ��Ȼ��ʧ��.
 *
 * SzDriverPath	: DbgObj���Զ������ɵ�����·��.
 * SzDriverName : DbgObj���Զ����������������
 *
 * return       : �ɹ�����TRUE, ���򷵻�FALSE
 */

BOOL
WINAPI
DbgObjInitialize( wchar_t* SzDriverPath,
                  wchar_t* SzDriverName )
{
    HRSRC hResc;
    DWORD dwImageSize;
    PVOID pMemory;
    HANDLE hFile;
    DWORD dwByteWrite;
    HGLOBAL	hResourecImage;
    DICHLORVOS_VERISON StVersion = {0};

    //
    // ��ȡDbgObj�İ汾, �ܹ���ȡ���汾˵������װ�ɹ���
    //
    if( DbgObjGetVersion( &StVersion ) != 0 )
    {
        return TRUE;
    }

    //
    // �޷���ȡ���汾, �������ϴ�����δ֪����, ��������ж��
    // ���ɾ�, ����ж��һ��.
    //
    DbgObjUnInstallService( SzDriverName );

    //
    // ���Զ�����Դ���ͷų�sys
    //
    hResc = FindResource( hDllInst, MAKEINTRESOURCE( ID_DBGSYS ), RT_RCDATA );
    if( hResc == NULL )
    {
        return FALSE;
    }

    dwImageSize = SizeofResource( hDllInst, hResc );

    hResourecImage = LoadResource( hDllInst, hResc );
    if( hResourecImage == NULL )
    {
        return FALSE;
    }
    pMemory = LockResource( hResourecImage );
    if( pMemory == NULL )
    {
        return FALSE;
    }

    hFile = CreateFile( SzDriverPath, GENERIC_WRITE, FILE_SHARE_READ,
                        NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL );
    if( hFile == INVALID_HANDLE_VALUE )
    {
        return FALSE;
    }

    if( !WriteFile( hFile, pMemory, dwImageSize, &dwByteWrite, NULL ) )
    {
        CloseHandle( hFile );
        return FALSE;
    }

    if( dwByteWrite != dwImageSize )
    {
        CloseHandle( hFile );
        return FALSE;
    }

    CloseHandle( hFile );

    //
    // ��װ����
    //
    if( !DbgObjInstallService( SzDriverPath, SzDriverName ) )
    {
        return FALSE;
    }

    DeleteFile( SzDriverPath );

    return TRUE;
}

/*
 * Windowsϵͳ����CreateProcess�ķ�װ, ��Ϊ������Ҫ�ռ�һ����Ϣ.
 * ���Բ���ʹ��Windows�ĺ���.
 *
 * ������ο�Windows MSDN��CreateProcess.
 * lpExeName	: Ҫ���е�exe����. ���� c:\windows\system32\calc.exe ��ô����calc.exe
 *
 * return       : �ɹ�����TRUE, ���򷵻�FALSE
 */

BOOL
WINAPI
DbgObjCreateProcess(
    __in_opt    LPCWSTR lpApplicationName,
    __inout_opt LPWSTR lpCommandLine,
    __in		LPCWSTR lpExeName,
    __in_opt    LPSECURITY_ATTRIBUTES lpProcessAttributes,
    __in_opt    LPSECURITY_ATTRIBUTES lpThreadAttributes,
    __in        BOOL bInheritHandles,
    __in        DWORD dwCreationFlags,
    __in_opt    LPVOID lpEnvironment,
    __in_opt    LPCWSTR lpCurrentDirectory,
    __in        LPSTARTUPINFOW lpStartupInfo,
    __out       LPPROCESS_INFORMATION lpProcessInformation
)
{
    BOOL bRet;
    wchar_t SzExeName[MAX_PATH] = {0};

    //
    // �������λ
    //
    if( dwCreationFlags & ( DEBUG_PROCESS | DEBUG_ONLY_THIS_PROCESS ) )
    {
        dwCreationFlags &=  !( DEBUG_PROCESS | DEBUG_ONLY_THIS_PROCESS );
    }

    wcscpy_s( SzExeName, sizeof( SzExeName ) / sizeof( wchar_t ), lpExeName );
    StrTrim( SzExeName, L" " );

    bRet = DbgObjCall( SC_CREATE_PROCESS_BEFORE,
                       ( PVOID )SzExeName,
                       wcslen( SzExeName ) * 2 + 1, NULL, 0 );
    if( !bRet )
    {
        BaseSetLastNTError( STATUS_UNSUCCESSFUL );
        return FALSE;
    }

    bRet = CreateProcessW( lpApplicationName,
                           lpCommandLine,
                           lpProcessAttributes,
                           lpThreadAttributes,
                           bInheritHandles,
                           dwCreationFlags,
                           lpEnvironment,
                           lpCurrentDirectory,
                           lpStartupInfo,
                           lpProcessInformation );

    if( !bRet )
    {
        DbgObjCall( SC_CREATE_PROCESS_CLEAN, NULL, 0, NULL, 0 );
        return bRet;
    }

    CloseHandle( lpProcessInformation->hThread );
    CloseHandle( lpProcessInformation->hProcess );

    //
    // ������Ϣ�������������ں�, ���̽�������
    //
    bRet = DbgObjCall( SC_CREATE_PROCESS_AFTER,
                       &lpProcessInformation->dwProcessId,
                       sizeof( DWORD ), NULL, 0 );

    if( !bRet )
    {
        BaseSetLastNTError( STATUS_UNSUCCESSFUL );
        return FALSE;
    }

    return bRet;
}

/*
 * ģ��Windows��WaitForDebugEvent����
 */

BOOL
WINAPI
DbgObjWaitForDebugEvent( IN LPDEBUG_EVENT lpDebugEvent,
                         IN DWORD dwMilliseconds )
{
    LARGE_INTEGER WaitTime;
    PLARGE_INTEGER TimeOut;
    NT_DEBUG_EVENT NtDbgEvt;
    NTSTATUS Status;
    BOOL bRet;
    WAITFOR_DEBUGEVENT StWaitForDebugEvent = {0};

    /* Convert to NT Timeout */
    TimeOut = BaseFormatTimeOut( &WaitTime, dwMilliseconds );

    /* Loop while we keep getting interrupted */
    do
    {

        RtlZeroMemory( lpDebugEvent, sizeof( DEBUG_EVENT ) );

        StWaitForDebugEvent.TimeOut = TimeOut;

        /* Call the native API */
        bRet = DbgObjCall( SC_NTWAITFOR_DEBUGEVENT, &StWaitForDebugEvent,
                           sizeof( WAITFOR_DEBUGEVENT ), &Status, sizeof( NTSTATUS ) );

        if( !bRet || !NT_SUCCESS( Status ) )
        {
            /* Set the error code and quit */
            BaseSetLastNTError( Status );
            return FALSE;
        }

        RtlMoveMemory( &NtDbgEvt, &StWaitForDebugEvent.DebugEvent, sizeof( NT_DEBUG_EVENT ) );

    }
    while( ( Status == STATUS_ALERTED ) || ( Status == STATUS_USER_APC ) );

    /* Check if the wait failed */
    if( !( NT_SUCCESS( Status ) ) || ( Status == DBG_UNABLE_TO_PROVIDE_HANDLE ) )
    {
        /* Set the error code and quit */
        BaseSetLastNTError( Status );
        return FALSE;
    }

    /* Check if we timed out */
    if( Status == STATUS_TIMEOUT )
    {
        /* Fail with a timeout error */
        SetLastError( ERROR_SEM_TIMEOUT );
        return FALSE;
    }

    /* Convert the structure */
    Status = DbgObjUiConvertStateChangeStructure( &NtDbgEvt, lpDebugEvent );

    if( !NT_SUCCESS( Status ) )
    {
        /* Set the error code and quit */
        BaseSetLastNTError( Status );
        return FALSE;
    }

    /* Return success */
    return TRUE;
}


/*
 * ȥ΢������վ�����ص��Է���, ��������п��ܾܺòŷ���,
 * SzSymbolsPath: ����·��
 */
BOOL
WINAPI
DbgObjEnumSymbols( wchar_t* SzSymbolsPath )
{
    DWORD dwRet;
    HANDLE hProcess;
    DWORD  Options;
    BOOL bRet = TRUE;
    wchar_t SzEnvVar[512] = {0};
    wchar_t SzOldEnvVar[512] = {0};
    wchar_t SzSymName[512] = {0};
    char SzImageName[MAX_PATH] = {0};
    PIMAGEHLP_SYMBOL pSymbol = NULL;
    SYSTEM_MODULE StSysModuleInfo;


    dwRet = GetEnvironmentVariable( _T( "_NT_SYMBOL_PATH" ), SzOldEnvVar,
                                    sizeof( SzOldEnvVar ) / sizeof( wchar_t ) );

    swprintf_s( SzSymName,
                sizeof( SzSymName ) / sizeof( wchar_t ),
                _T( "srv*%s*http://msdl.microsoft.com/download/symbols" ), SzSymbolsPath );

    if( !SetEnvironmentVariable( _T( "_NT_SYMBOL_PATH" ), SzSymName ) )
    {
        return FALSE;
    }

    GetEnvironmentVariable( _T( "_NT_SYMBOL_PATH" ), SzEnvVar,
                            sizeof( SzEnvVar ) / sizeof( wchar_t ) );
//---------------------------------------------------------------------------
    //
    // 1.����ϵͳ�ں�ģ��. ����ntkrnlpa.exe����ntoskrnl.exe, ����֮һ
    //
    bRet = DbgObjGetSysModuleInfo( &StSysModuleInfo );
    if( !bRet )
    {
        return bRet;
    }

    GetSystemDirectoryA( SzImageName, sizeof( SzImageName ) );

    strcat_s( SzImageName,
              sizeof( SzImageName ),
              &StSysModuleInfo.ImageName[StSysModuleInfo.ModuleNameOffset - 1] );
//---------------------------------------------------------------------------
    //
    // ���÷���ѡ��
    //
    Options = SymGetOptions();

    Options = Options | SYMOPT_DEBUG;
    SymSetOptions( Options );

    hProcess = GetCurrentProcess();
    bRet = SymInitialize( hProcess, 0, FALSE );

    if( !bRet )
    {
        return FALSE;
    }

    __try
    {

        //
        // ����Ҫ���صķ�������, ��������ھͻ�ȥ΢���Ǳ�����,
        //
        BaseOfDll = SymLoadModule64( hProcess, NULL, SzImageName, NULL, 0, 0 );

        if( BaseOfDll == 0 )
        {
            return FALSE;
        }

        //
        // ö�ٷ���
        //
        SymEnumSymbols( hProcess, BaseOfDll, 0, EnumSymCallBack, 0 );

        for( ;; Sleep( 10 ) )
        {
            if( StSymbolsInfo.lpDbgkCreateThread &&
                    StSymbolsInfo.lpKiFastCallEntry &&
                    StSymbolsInfo.ulPsNtDllPathName &&
                    StSymbolsInfo.lpKeFreezeAllThreads )
            {
                break;
            }
        }

        //
        // ���������ntdll.dll�е�. ���ڴ������̵��״ζϵ�
        //
        StSymbolsInfo.lpLdrInitializeThunk =
            GetProcAddress( LoadLibrary( _T( "ntdll.dll" ) ), "LdrInitializeThunk" );

        StSymbolsInfo.lpDbgBreakPoint =
            GetProcAddress( LoadLibrary( _T( "ntdll.dll" ) ), "DbgBreakPoint" );

		StSymbolsInfo.lpExitThread = 
			GetProcAddress( LoadLibrary( _T( "kernel32.dll" ) ), "ExitThread" );

        Sleep( 500 );

        SymUnloadModule64( hProcess, BaseOfDll );

        SymCleanup( hProcess );

        bRet = TRUE;

    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {

        bRet = FALSE;

    }

    if( dwRet )
    {
        SetEnvironmentVariable( _T( "_NT_SYMBOL_PATH" ), SzOldEnvVar );
    }

    return bRet;
}

/*
 * ��ȡϵͳģ����Ϣ.
 * ��������ɹ�����TRUE, SysModInfo����ϵͳģ����Ϣ,����FALSE
 *
 */

BOOL
WINAPI
DbgObjGetSysModuleInfo(
    PSYSTEM_MODULE SysModInfo )
{
    ULONG ulInfoLen;
    NTSTATUS Status;
    SYSTEM_MODULE_INFORMATION* pStLoaderInfo = NULL;
    _QuerySystemInformation NtQuerySystemInforamtion = 0;

    if( SysModInfo == NULL )
    {
        return FALSE;
    }

    //
    //  ��ȡNtQuerySystemInformation�ĵ�ַ
    //
    if( NULL == NtQuerySystemInforamtion )
    {

        NtQuerySystemInforamtion = ( _QuerySystemInformation )
                                   GetProcAddress( LoadLibrary( L"ntdll.dll" ),
                                           "NtQuerySystemInformation" );

        if( !NtQuerySystemInforamtion )
        {
            return FALSE;
        }
    }

    //
    // ��ߵ���NtQuerySystemInforamtion��ȡϵͳģ����Ϣ, ע����. �����
    // ���ε���, �״λ�ȡģ����Ϣ����. �ٴε��ò��������Ļ�ȡ��Ϣ
    //
    NtQuerySystemInforamtion( SystemModuleInformation, NULL, 0, &ulInfoLen );

    if( !ulInfoLen )
    {
        return STATUS_UNSUCCESSFUL;
    }

    pStLoaderInfo = ( SYSTEM_MODULE_INFORMATION* )malloc( ulInfoLen + sizeof( ULONG ) );

    if( pStLoaderInfo->aSM == NULL )
    {
        return STATUS_UNSUCCESSFUL;
    }

    Status = NtQuerySystemInforamtion( SystemModuleInformation, ( PVOID )pStLoaderInfo,
                                       ulInfoLen, &ulInfoLen );

    if( !NT_SUCCESS( Status ) )
    {
        if( pStLoaderInfo )
        {
            free( pStLoaderInfo );
        }

        return Status;
    }

    RtlMoveMemory( SysModInfo, &pStLoaderInfo->aSM[0], sizeof( SYSTEM_MODULE ) );

    if( pStLoaderInfo )
    {
        free( pStLoaderInfo );
    }

    return TRUE;
}

/*
 * ģ��Windows��ContinueDebugEvent����
 */

BOOL
WINAPI
DbgObjContinueDebugEvent( IN DWORD dwProcessId,
                          IN DWORD dwThreadId,
                          IN DWORD dwContinueStatus )
{
    BOOL bRet;
    NTSTATUS Status;
    CONTINUE_DEBUGEVENT StContinueDebug = {0};

    StContinueDebug.dwProcessId      = ( HANDLE )dwProcessId;
    StContinueDebug.dwThreadId       = ( HANDLE )dwThreadId;
    StContinueDebug.dwContinueStatus = dwContinueStatus;

    /* Call the native API */
    bRet = DbgObjCall( SC_CONTINUE_DEBUGEVENT, &StContinueDebug,
                       sizeof( CONTINUE_DEBUGEVENT ), &Status, sizeof( NTSTATUS ) );

    if( !bRet )
    {
        /* Set the error code and quit */
        BaseSetLastNTError( Status );
        return FALSE;
    }

    /* Success */
    return TRUE;
}

NTSTATUS
NTAPI
DbgObjNtProtectVirtualMemory(IN HANDLE ProcessHandle,
					   IN OUT PVOID *UnsafeBaseAddress,
					   IN OUT SIZE_T *UnsafeNumberOfBytesToProtect,
					   IN ULONG NewAccessProtection,
					   OUT PULONG UnsafeOldAccessProtection)
{
	BOOL bRet;
	NTSTATUS Status;
	NT_PROTECT_VIRTUALMEMORY StProtect;

	StProtect.ProcessHandle                = ProcessHandle;
	StProtect.UnsafeBaseAddress            = UnsafeBaseAddress;
	StProtect.NewAccessProtection          = NewAccessProtection;
	StProtect.UnsafeOldAccessProtection    = UnsafeOldAccessProtection;
	StProtect.UnsafeNumberOfBytesToProtect = UnsafeNumberOfBytesToProtect;

	/* Call the native API */
	bRet = DbgObjCall( SC_NTPROTECTVIRTUALMEMORY, &StProtect,
		sizeof( NT_PROTECT_VIRTUALMEMORY ), &Status, sizeof( NTSTATUS ) );
	if (!bRet)
	{
		return STATUS_UNSUCCESSFUL;
	}

	return Status;
}

BOOL
WINAPI
DbgObjDebugActiveProcess(
    __in DWORD dwProcessId
)
{
    BOOL bRet;
    NTSTATUS Status;
    HANDLE Process;
    HANDLE hThread;
    CLIENT_ID ClientId;
    DEBUG_ACTIVE_PROCESS DebugActive;

    DebugActive.dwProcessId = ( HANDLE )dwProcessId;

    Process = ProcessIdToHandle( dwProcessId );

    /* Call the native API */
    bRet = DbgObjCall( SC_DEBUGACTIVEPROCESS, &DebugActive,
                       sizeof( DEBUG_ACTIVE_PROCESS ), &Status, sizeof( NTSTATUS ) );

    if( !bRet || !NT_SUCCESS( Status ) )
    {
        /* Set the error code and quit */
        BaseSetLastNTError( Status );
        return FALSE;
    }

    if( !lpDbgBreadkPoint )
    {
        return FALSE;
    }

    /* Create the thread that will do the breakin */
    Status = RtlCreateUserThread( Process,
                                  NULL,
                                  FALSE,
                                  0,
                                  0,
                                  PAGE_SIZE,
                                  lpDbgBreadkPoint,
                                  NULL,
                                  &hThread,
                                  &ClientId );

    /* Close the handle on success */
    if( NT_SUCCESS( Status ) )
    {
        NtClose( hThread );
        return TRUE;
    }

    return FALSE;
}

/* ָ���������˳�ʱ, �Ƿ��˳������Խ���*/
BOOL
WINAPI
DbgObjDebugSetProcessKillOnExit(
    __in BOOL KillOnExit
)
{

    return FALSE;

}

/* ������ԻỰ*/
BOOL
WINAPI
DbgObjDebugActiveProcessStop(
    __in DWORD dwProcessId
)
{
    return FALSE;
}

BOOL
WINAPI
DbgObjReadProcessMemory( IN HANDLE hProcess,
                         IN LPCVOID lpBaseAddress,
                         IN LPVOID lpBuffer,
                         IN SIZE_T nSize,
                         OUT SIZE_T* lpNumberOfBytesRead )
{
    BOOL bRet;
    NTSTATUS Status;
    READ_MEMORY ReadMemory;

    ReadMemory.hProcess            = hProcess;
    ReadMemory.BaseAddress         = ( PVOID )lpBaseAddress;
    ReadMemory.Buffer              = lpBuffer;
    ReadMemory.NumberOfBytesToRead = nSize;
    ReadMemory.NumberOfBytesRead   = lpNumberOfBytesRead;

    /* Call the native API */
    bRet = DbgObjCall( SC_READ_VIRTUAL_MEMORY, &ReadMemory,
                       sizeof( READ_MEMORY ), &Status, sizeof( NTSTATUS ) );

    if( !bRet || !NT_SUCCESS( Status ) )
    {
        /* Set the error code and quit */
        BaseSetLastNTError( Status );
        return FALSE;
    }

    /* Return success */
    return TRUE;

}

BOOL
WINAPI
DbgObjWriteProcessMemory( IN HANDLE hProcess,
                          IN LPVOID lpBaseAddress,
                          IN LPCVOID lpBuffer,
                          IN SIZE_T nSize,
                          OUT SIZE_T *lpNumberOfBytesWritten )
{
    BOOL bRet;
    PVOID Base;
    NTSTATUS Status;
    ULONG OldValue;
    SIZE_T RegionSize;
    BOOLEAN UnProtect;
    WRITE_MEMORY WriteMemory;

    /* Set parameters for protect call */
    RegionSize = nSize;
    Base = lpBaseAddress;

    /* Check the current status */
    Status = DbgObjNtProtectVirtualMemory( hProcess,
                                     &Base,
                                     &RegionSize,
                                     PAGE_EXECUTE_READWRITE,
                                     &OldValue );
    if( NT_SUCCESS( Status ) )
    {
        /* Check if we are unprotecting */
        UnProtect = OldValue & ( PAGE_READWRITE |
                                 PAGE_WRITECOPY |
                                 PAGE_EXECUTE_READWRITE |
                                 PAGE_EXECUTE_WRITECOPY ) ? FALSE : TRUE;
        if( !UnProtect )
        {
            /* Set the new protection */
            Status = DbgObjNtProtectVirtualMemory( hProcess,
                                             &Base,
                                             &RegionSize,
                                             OldValue,
                                             &OldValue );

            WriteMemory.hProcess            = hProcess;
            WriteMemory.BaseAddress         = lpBaseAddress;
            WriteMemory.Buffer              = ( PVOID )lpBuffer;
            WriteMemory.NumberOfBytesToWrite = nSize;
            WriteMemory.NumberOfBytesWritten   = lpNumberOfBytesWritten;

            /* Call the native API */
            bRet = DbgObjCall( SC_WRITE_VIRTUAL_MEMORY, &WriteMemory,
                               sizeof( READ_MEMORY ), &Status, sizeof( NTSTATUS ) );
            if( !NT_SUCCESS( Status ) || !bRet )
            {
                /* We failed */
                BaseSetLastNTError( Status );
                return FALSE;
            }

            /* Flush the ITLB */
            NtFlushInstructionCache( hProcess, lpBaseAddress, nSize );
            return TRUE;
        }
        else
        {
            /* Check if we were read only */
            if( ( OldValue & PAGE_NOACCESS ) || ( OldValue & PAGE_READONLY ) )
            {
                /* Restore protection and fail */
                DbgObjNtProtectVirtualMemory( hProcess,
                                        &Base,
                                        &RegionSize,
                                        OldValue,
                                        &OldValue );
                BaseSetLastNTError( STATUS_ACCESS_VIOLATION );
                return FALSE;
            }

            WriteMemory.hProcess            = hProcess;
            WriteMemory.BaseAddress         = lpBaseAddress;
            WriteMemory.Buffer              = ( PVOID )lpBuffer;
            WriteMemory.NumberOfBytesToWrite = nSize;
            WriteMemory.NumberOfBytesWritten   = lpNumberOfBytesWritten;

            /* Call the native API */
            bRet = DbgObjCall( SC_WRITE_VIRTUAL_MEMORY, &WriteMemory,
                               sizeof( READ_MEMORY ), &Status, sizeof( NTSTATUS ) );

            /* And restore the protection */
            DbgObjNtProtectVirtualMemory( hProcess,
                                    &Base,
                                    &RegionSize,
                                    OldValue,
                                    &OldValue );
            if( !NT_SUCCESS( Status ) || !bRet )
            {
                /* We failed */
                BaseSetLastNTError( STATUS_ACCESS_VIOLATION );
                return FALSE;
            }

            /* Flush the ITLB */
            NtFlushInstructionCache( hProcess, lpBaseAddress, nSize );
            return TRUE;
        }
    }
    else
    {
        /* We failed */
        BaseSetLastNTError( Status );
        return FALSE;
    }
}

HANDLE
WINAPI
DbgObjOpenProcess( DWORD dwDesiredAccess,
                   BOOL bInheritHandle,
                   DWORD dwProcessId )
{
    BOOL bRet;
    NTSTATUS Status;
    HANDLE ProcessHandle;
    OBJECT_ATTRIBUTES ObjectAttributes;
    CLIENT_ID ClientId;
    OPEN_PROCESS StOpenProcess;

    ClientId.UniqueProcess = UlongToHandle( dwProcessId );
    ClientId.UniqueThread = 0;

    InitializeObjectAttributes( &ObjectAttributes,
                                NULL,
                                ( bInheritHandle ? OBJ_INHERIT : 0 ),
                                NULL,
                                NULL );

    StOpenProcess.ClientId         = &ClientId;
    StOpenProcess.ObjectAttributes = &ObjectAttributes;
    StOpenProcess.ProcessHandle    = &ProcessHandle;
    StOpenProcess.DesiredAccess    = dwDesiredAccess;

    /* Call the native API */
    bRet = DbgObjCall( SC_OPEN_PROCESS, &StOpenProcess,
                       sizeof( OPEN_PROCESS ), &Status, sizeof( NTSTATUS ) );
    if( !NT_SUCCESS( Status ) || !bRet )
    {
        /* We failed */
        BaseSetLastNTError( Status );
        return FALSE;
    }

    return ProcessHandle;

}

BOOL
WINAPI
DbgObjGetThreadContext( HANDLE hThread,
                        LPCONTEXT lpContext )
{
    BOOL bRet;
    NTSTATUS Status;
    GET_THREAD_CONTEXT GetContext;

    GetContext.hThread = hThread;
    GetContext.lpContext = lpContext;

    /* Call the native API */
    bRet = DbgObjCall( SC_GET_THREAD_CONTEXT, &GetContext,
                       sizeof( GET_THREAD_CONTEXT ), &Status, sizeof( NTSTATUS ) );
    if( !NT_SUCCESS( Status ) || !bRet )
    {
        /* We failed */
        BaseSetLastNTError( Status );
        return FALSE;
    }

    return TRUE;
}

BOOL
WINAPI
DbgObjSetThreadContext( HANDLE hThread,
                        LPCONTEXT lpContext )
{
    BOOL bRet;
    NTSTATUS Status;
    SET_THREAD_CONTEXT SetContext;

    SetContext.hThread = hThread;
    SetContext.lpContext = lpContext;

    /* Call the native API */
    bRet = DbgObjCall( SC_SET_THREAD_CONTEXT, &SetContext,
                       sizeof( GET_THREAD_CONTEXT ), &Status, sizeof( NTSTATUS ) );
    if( !NT_SUCCESS( Status ) || !bRet )
    {
        /* We failed */
        BaseSetLastNTError( Status );
        return FALSE;
    }

    return TRUE;
}

DWORD
WINAPI
DbgObjSuspendThread( HANDLE hThread )
{
    BOOL bRet;
    NTSTATUS Status;
    SUSPEND_THREAD StSuspendThread;
    ULONG PreviousSuspendCount;


    StSuspendThread.hThread = hThread;
    StSuspendThread.lpPreviousSuspendCount = &PreviousSuspendCount;

    /* Call the native API */
    bRet = DbgObjCall( SC_SUSPEND_THREAD, &StSuspendThread,
                       sizeof( SUSPEND_THREAD ), &Status, sizeof( NTSTATUS ) );
    if( !NT_SUCCESS( Status ) || !bRet )
    {
        /* We failed */
        BaseSetLastNTError( Status );
        return -1;
    }

    return PreviousSuspendCount;

}


// ���߳�
NTSTATUS
WINAPI
DbgObjNtOpenThread( OUT PHANDLE ThreadHandle,
                    IN ACCESS_MASK DesiredAccess,
                    IN POBJECT_ATTRIBUTES ObjectAttributes,
                    IN PCLIENT_ID ClientId OPTIONAL )
{

    BOOL bRet;
    NTSTATUS Status;
    OPEN_THREAD StOpenThread;

    StOpenThread.ThreadHandle     = ThreadHandle;
    StOpenThread.DesiredAccess    = DesiredAccess;
    StOpenThread.ObjectAttributes = ObjectAttributes;
    StOpenThread.ClientId         = ClientId;

    // Call the native API
    bRet = DbgObjCall( SC_OPEN_THREAD, &StOpenThread,
                       sizeof( OPEN_THREAD ), &Status, sizeof( NTSTATUS ) );
    if( !NT_SUCCESS( Status ) || !bRet )
    {
        // We failed
        BaseSetLastNTError( Status );
    }

    return Status;
}


DWORD
WINAPI
DbgObjResumeThread( HANDLE hThread )
{
    BOOL bRet;
    NTSTATUS Status;
    RESUME_THREAD StResumeThread;
    ULONG PreviousResumeCount;

    StResumeThread.hThread = hThread;
    StResumeThread.lpPreviousSuspendCount = &PreviousResumeCount;

    /* Call the native API */
    bRet = DbgObjCall( SC_RESUME_THREAD, &StResumeThread,
                       sizeof( RESUME_THREAD ), &Status, sizeof( NTSTATUS ) );
    if( !NT_SUCCESS( Status ) || !bRet )
    {
        /* We failed */
        BaseSetLastNTError( Status );
        return -1;
    }

    return PreviousResumeCount;
}


BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch( ul_reason_for_call )
    {
    case DLL_PROCESS_ATTACH:
        hDllInst = hModule;

        EnableDebugPrivilegies();

        EnableLoadDriverPrivilegies();
        break;

    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }

    return TRUE;
}

