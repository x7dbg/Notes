#pragma once
#include "CView.h"
class CTestView :
    public CView
{
    DECLARE_DYNAMIC(CTestView);
};

