#ifndef _MISC_
#define _MISC_




enum HWBRK_TYPE
{
    HWBRK_TYPE_CODE,
    HWBRK_TYPE_READWRITE,
    HWBRK_TYPE_WRITE,
};

enum HWBRK_SIZE
{
    HWBRK_SIZE_1,
    HWBRK_SIZE_2,
    HWBRK_SIZE_4,
    HWBRK_SIZE_8,
};


typedef struct Buffer_Lock
{
    PMDL mdl;
    PVOID *lpData;
} BUFFER_LOCK;


typedef struct
{
    USHORT Offset0_15;
    USHORT Segment;
    UCHAR  attr0;
    UCHAR  attr1;
    USHORT Offset_47_63;
} GATE_DESCRIPTOR, *PGATE_DESCRIPTOR;


#define LA_ACCESSED		0x01
#define LA_READABLE		0x02    // for code segments
#define LA_WRITABLE		0x02    // for data segments
#define LA_CONFORMING	0x04    // for code segments
#define LA_EXPANDDOWN	0x04    // for data segments
#define LA_CODE			0x08
#define LA_STANDARD		0x10
#define LA_DPL_0		0x00
#define LA_DPL_1		0x20
#define LA_DPL_2		0x40
#define LA_DPL_3		0x60
#define LA_PRESENT		0x80

#define LA_LDT64		0x02
#define LA_ATSS64		0x09
#define LA_BTSS64		0x0b
#define LA_CALLGATE64	0x0c
#define LA_INTGATE64	0x0e
#define LA_TRAPGATE64	0x0f

#define HA_AVAILABLE	0x01
#define HA_LONG			0x02
#define HA_DB			0x04
#define HA_GRANULARITY	0x08


void *DbgObjGetKernelBase();

NTSTATUS SetHardwareBreakPoint(
    PCONTEXT lpContext,
    ULONG HwBreakType,
    ULONG HwBreakSize,
    PVOID Address );

NTSTATUS __stdcall RemoveHardwareBreakPoint(
    PCONTEXT lpContext,
    ULONG Address );

BOOL SafeCopyMemory(
    PVOID pDest,
    PVOID pSrc,
    ULONG dwSize );

BOOL _Jump(
    PVOID pAddress,
    PVOID pFunction,
    ULONG ulNop );

int DbgLockBuffer(
    BUFFER_LOCK
    *lpStBufferLock,
    void *Buffer,
    ULONG ulSize );
void DbgUnLockBuffer(
    BUFFER_LOCK *lpStBufferLock );


NTSTATUS DbgObjHookNtTerminateProcess();
NTSTATUS DbgObjUnHookNtTerminateProcess();

NTSTATUS NewNtTerminateProcess(
    HANDLE hProcess,
    NTSTATUS ExitStatus );

NTSTATUS NTAPI NewNtQueryInformationProcess(
    IN HANDLE ProcessHandle,
    IN PROCESSINFOCLASS ProcessInformationClass,
    OUT PVOID ProcessInformation,
    IN ULONG ProcessInformationLength,
    OUT PULONG ReturnLength OPTIONAL );

VOID SetCreateProcessName( wchar_t* lpExeName );

VOID CleanCreateProcessName( );

VOID _Sleep( ULONG ulMilliseconds );

BOOL CompareProcessName( PEPROCESS Process );

BOOL _Call( PVOID pAddress, PVOID pFunction, ULONG ulNop );

NTSTATUS NTAPI NewNtSetContextThread(
    IN HANDLE ThreadHandle,
    IN PCONTEXT ThreadContext );

NTSTATUS NTAPI NewNtGetContextThread(
    IN HANDLE ThreadHandle,
    IN OUT PCONTEXT ThreadContext );

NTSTATUS NTAPI NewNtReadVirtualMemory(IN HANDLE ProcessHandle, IN PVOID BaseAddress, OUT PVOID Buffer, IN SIZE_T NumberOfBytesToRead, OUT PSIZE_T NumberOfBytesRead OPTIONAL);
NTSTATUS NTAPI NewNtOpenProcess(OUT PHANDLE ProcessHandle, IN ACCESS_MASK DesiredAccess, IN POBJECT_ATTRIBUTES ObjectAttributes, IN PCLIENT_ID ClientId);
#endif