#pragma once
#include <Windows.h>

void ReadVirual(DWORD pDest, void* buf, int nLen);
void WriteVirtual(DWORD pDest, void* buf, int nLen);

template<typename T>
T ReadMem(DWORD pDest) {
	T data = { };
	ReadVirual(pDest, &data, sizeof(data));
	return data;
}

template<typename T>
void WriteMem(DWORD pDest, T data) {
	WriteVirtual(pDest, &data, sizeof(pDest));
}


#define Game_Offset_Base				0x002A9EC0
#define Game_Offset_GetSun				0x0003158F
#define Game_Offset_PutPlant			0x00010A9C
#define Game_Offset_AutoZombies			0x00013055
#define Game_Offset_PutZombies			0x0000DDC0

enum PlantType {

};

enum ZombiesType {
	Zombies_Normal = 0,					//	��ͨ
	Zombies_Flags = 1,					//	����
	Zombies_Hat = 2,					//	ñ��
	Zombies_Jump = 3,					//	����
	Zombies_Trash = 4,					//	����Ͱ
	Zombies_Paper = 5,					//	��ֽ
};


//	�޸�����ֵ
void ChangeSun(int nNum);
//	�Զ�ʰȡ����
void AutoGetSun(BOOL isAuto);
//	���ý�ʬ
void PutZombies(int hang, ZombiesType emZombiesType);
//	�ر��Զ����ɽ�ʬ
void CloseAutoZombies();