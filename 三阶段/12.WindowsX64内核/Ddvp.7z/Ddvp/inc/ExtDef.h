#ifndef _EXTDEF_
#define _EXTDEF_

typedef
NTSTATUS ( *PZWTERMINATEPROCESS )(
    IN HANDLE   ProcessHandle,
    IN NTSTATUS ExitStatus
);


typedef struct _AUX_ACCESS_DATA
{
    PPRIVILEGE_SET PrivilegeSet;
    GENERIC_MAPPING GenericMapping;
    ULONG Reserved;
} AUX_ACCESS_DATA, *PAUX_ACCESS_DATA;

typedef int ( *PZWCREATETHREAD )(
    PHANDLE            ThreadHandle,
    ACCESS_MASK        DesiredAccess,
    POBJECT_ATTRIBUTES ObjectAttributes,
    HANDLE             ProcessHandle,
    PCLIENT_ID         ClientId,
    PCONTEXT           ThreadContext,
    PVOID              UserStack,
    BOOLEAN            CreateSuspended
);

typedef struct _SYSTEM_DLL {
	PVOID Section;
	PVOID DllBase;
	PKNORMAL_ROUTINE LoaderInitRoutine;
	ULONG_PTR DllLock;
} SYSTEM_DLL, *PSYSTEM_DLL;

NTSTATUS
NTAPI
ObOpenObjectByName( IN POBJECT_ATTRIBUTES ObjectAttributes,
                    IN POBJECT_TYPE ObjectType,
                    IN KPROCESSOR_MODE AccessMode,
                    IN PACCESS_STATE PassedAccessState,
                    IN ACCESS_MASK DesiredAccess,
                    IN OUT PVOID ParseContext,
                    OUT PHANDLE Handle );

NTSTATUS
NTAPI
PsLookupProcessThreadByCid( IN PCLIENT_ID Cid,
                            OUT PEPROCESS *Process OPTIONAL,
                            OUT PETHREAD *Thread );

VOID
NTAPI
SeDeleteAccessState( IN PACCESS_STATE AccessState );


NTSYSAPI
NTSTATUS
NTAPI
ZwFlushInstructionCache(
    IN HANDLE ProcessHandle,
    IN PVOID BaseAddress,
    IN ULONG NumberOfBytesToFlush
);
typedef NTSTATUS
( NTAPI* PGetFileNameForSection )( IN PVOID Section,
                                   OUT POBJECT_NAME_INFORMATION *ModuleName );

typedef KAFFINITY
(NTAPI* PKeSetAffinityThread)(IN PKTHREAD Thread,
					IN KAFFINITY Affinity);

typedef PETHREAD
( NTAPI* PPsGetNextProcessThread )( IN PEPROCESS Process,
                                    IN PETHREAD Thread OPTIONAL );


typedef NTSTATUS
( NTAPI* PPsResumeThread )( IN PETHREAD Thread,
                            OUT PULONG PreviousCount OPTIONAL );

typedef NTSTATUS
( NTAPI* PMmCopyVirtualMemory )( IN PEPROCESS SourceProcess,
                                 IN PVOID SourceAddress,
                                 IN PEPROCESS TargetProcess,
                                 OUT PVOID TargetAddress,
                                 IN SIZE_T BufferSize,
                                 IN KPROCESSOR_MODE PreviousMode,
                                 OUT PSIZE_T ReturnSize );

typedef NTSTATUS
( NTAPI* PObDuplicateObject )( IN PEPROCESS SourceProcess,
                               IN HANDLE SourceHandle,
                               IN PEPROCESS TargetProcess OPTIONAL,
                               IN PHANDLE TargetHandle OPTIONAL,
                               IN ACCESS_MASK DesiredAccess,
                               IN ULONG HandleAttributes,
                               IN ULONG Options,
                               IN KPROCESSOR_MODE PreviousMode );

typedef NTSTATUS ( *PZWRESUMETHREAD )(
    IN  HANDLE ThreadHandle,
    OUT PULONG PreviousSuspendCount
);

typedef
NTSTATUS (NTAPI* PMiProtectVirtualMemory)(IN PEPROCESS Process,
					   IN OUT PVOID *BaseAddress,
					   IN OUT PSIZE_T NumberOfBytesToProtect,
					   IN ULONG NewAccessProtection,
					   OUT PULONG OldAccessProtection  OPTIONAL);

typedef
PEPROCESS
(NTAPI*
PPsGetThreadProcess)(IN PETHREAD Thread);

typedef
HANDLE
(NTAPI* PPsGetThreadId)(IN PETHREAD Thread);

typedef NTSTATUS ( *PZWTERMINATETHREAD )(
    IN HANDLE   ThreadHandle,
    IN NTSTATUS ExitStatus
);

typedef VOID
( NTAPI* PKeFreezeAllThreads )( VOID );

typedef VOID
( NTAPI* PKeThawAllThreads )( VOID );

typedef
NTSTATUS
( NTAPI* PNtSetContextThread )(
							   IN HANDLE	ThreadHandle,
							   IN PCONTEXT	Context
							   );

typedef
NTSTATUS
( NTAPI* PNtGetContextThread )(
							   IN HANDLE	ThreadHandle,
							   IN PCONTEXT	Context
							   );

typedef
NTSTATUS
(NTAPI* PNtReadVirtualMemory)(IN HANDLE ProcessHandle,
					IN PVOID BaseAddress,
					OUT PVOID Buffer,
					IN SIZE_T NumberOfBytesToRead,
					OUT PSIZE_T NumberOfBytesRead OPTIONAL);


typedef
NTSTATUS
(NTAPI* PNtOpenProcess)(OUT PHANDLE ProcessHandle,
				 IN ACCESS_MASK DesiredAccess,
				 IN POBJECT_ATTRIBUTES ObjectAttributes,
				 IN PCLIENT_ID ClientId);

typedef NTSTATUS
( NTAPI* PObpCloseHandle )( IN HANDLE Handle,
                            IN KPROCESSOR_MODE AccessMode );

typedef NTSTATUS
( NTAPI* PMmGetFileNameForAddress )( IN PVOID Address,
                                     OUT PUNICODE_STRING ModuleName );

NTSYSAPI
NTSTATUS
NTAPI ZwQuerySystemInformation(
    IN ULONG SystemInformationClass,
    IN PVOID SystemInformation,
    IN ULONG SystemInformationLength,
    OUT PULONG ReturnLength
);

NTSYSAPI
NTSTATUS
NTAPI
ZwQueryInformationProcess(
    IN HANDLE ProcessHandle,
    IN PROCESSINFOCLASS ProcessInformationClass,
    OUT PVOID ProcessInformation,
    IN ULONG ProcessInformationLength,
    OUT PULONG ReturnLength OPTIONAL
);

NTSTATUS
NTAPI
SeCreateAccessState( IN OUT PACCESS_STATE AccessState,
                     IN PAUX_ACCESS_DATA AuxData,
                     IN ACCESS_MASK Access,
					 IN PGENERIC_MAPPING GenericMapping );


NTSTATUS
NTAPI
PsGetContextThread(IN PETHREAD Thread,
				   IN OUT PCONTEXT ThreadContext,
				   IN KPROCESSOR_MODE PreviousMode);

typedef
ULONG
(NTAPI* PKeSuspendThread)(PKTHREAD Thread);

typedef
ULONG
(NTAPI* PKeForceResumeThread) (
					 __inout PKTHREAD Thread
					 );

typedef NTSTATUS
( NTAPI* PPsGetContextThread )( IN PETHREAD Thread,
							  IN OUT PCONTEXT ThreadContext,
							  IN KPROCESSOR_MODE PreviousMode );

NTSTATUS
NTAPI
PsSetContextThread(IN PETHREAD Thread,
				   IN OUT PCONTEXT ThreadContext,
				   IN KPROCESSOR_MODE PreviousMode);

typedef NTSTATUS
( NTAPI* PPsSetContextThread )( IN PETHREAD Thread,
							  IN OUT PCONTEXT ThreadContext,
							  IN KPROCESSOR_MODE PreviousMode );

NTSYSAPI
NTSTATUS
NTAPI
ZwQueryInformationThread(
    IN HANDLE          ThreadHandle,
    IN THREADINFOCLASS ThreadInformationClass,
    OUT PVOID          ThreadInformation,
    IN ULONG           ThreadInformationLength,
    OUT PULONG         ReturnLength
);

NTSYSAPI
HANDLE PsGetThreadId( PETHREAD thread );

#pragma pack (push, 1)

typedef struct _SYSTEM_MODULE_INFORMATION   // Information Class 11
{
    ULONG Reserved[2];
    PVOID Base;
    ULONG Size;
    ULONG Flags;
    USHORT Index;
    USHORT Unknown;
    USHORT LoadCount;
    USHORT ModuleNameOffset;
    CHAR ImageName[256];
} SYSTEM_MODULE_INFORMATION, *PSYSTEM_MODULE_INFORMATION;

typedef struct _SYSTEM_MODULE_INFORMATION_EX
{
    ULONG ModulesCount;
    SYSTEM_MODULE_INFORMATION Modules[0];
} SYSTEM_MODULE_INFORMATION_EX, *PSYSTEM_MODULE_INFORMATION_EX;

typedef struct _THREAD_BASIC_INFORMATION
{
    NTSTATUS ExitStatus;
    PNT_TIB   TebBaseAddress;
    CLIENT_ID ClientId;
    KAFFINITY AffinityMask;
    KPRIORITY Priority;
    KPRIORITY BasePriority;
} THREAD_BASIC_INFORMATION, *PTHREAD_BASIC_INFORMATION;

typedef struct _SYSTEM_SERVICE_TABLE
{
    PVOID  *ServiceTable;
    PULONG	CounterTable;
    ULONG	ServiceLimit;
    PUCHAR	ArgumentTable;
} SYSTEM_SERVICE_TABLE, *PSYSTEM_SERVICE_TABLE;


typedef struct _SERVICE_DESCRIPTOR_TABLE
{
    SYSTEM_SERVICE_TABLE ntoskrnl;
    SYSTEM_SERVICE_TABLE win32k;
    SYSTEM_SERVICE_TABLE iis;
    SYSTEM_SERVICE_TABLE unused;
} SERVICE_DESCRIPTOR_TABLE, *PSERVICE_DESCRIPTOR_TABLE;

typedef struct _PEB_LDR_DATA
{
    ULONG		Length;
    ULONG		Initialized;
    PVOID		SsHandle;
    LIST_ENTRY	InLoadOrderModuleList; // ref. to PLDR_DATA_TABLE_ENTRY->InLoadOrderModuleList
    LIST_ENTRY	InMemoryOrderModuleList; // ref. to PLDR_DATA_TABLE_ENTRY->InMemoryOrderModuleList
    LIST_ENTRY	InInitializationOrderModuleList; // ref. to PLDR_DATA_TABLE_ENTRY->InInitializationOrderModuleList
} PEB_LDR_DATA, *PPEB_LDR_DATA;

typedef struct _LDR_DATA_TABLE_ENTRY
{
    LIST_ENTRY		InLoadOrderLinks;
    LIST_ENTRY		InMemoryOrderLinks;
    LIST_ENTRY		InInitializationOrderLinks;
    PVOID			DllBase;
    PVOID			EntryPoint;
    ULONG			SizeOfImage;	// in bytes
    UNICODE_STRING	FullDllName;
    UNICODE_STRING	BaseDllName;
    ULONG			Flags;			// LDR_*
    USHORT			LoadCount;
    USHORT			TlsIndex;
    LIST_ENTRY		HashLinks;
    PVOID			SectionPointer;
    ULONG			CheckSum;
    ULONG			TimeDateStamp;
    //    PVOID			LoadedImports;					// seems they are exist only on XP !!!
    //    PVOID			EntryPointActivationContext;	// -same-
} LDR_DATA_TABLE_ENTRY, *PLDR_DATA_TABLE_ENTRY;

typedef struct _PEB
{
    UCHAR				InheritedAddressSpace;				// 0
    UCHAR				ReadImageFileExecOptions;			// 1
    UCHAR				BeingDebugged;						// 2
    BYTE				b003;								// 3
    PVOID				Mutant;								// 4
    PVOID				ImageBaseAddress;					// 8
} PEB, *PPEB;


//
// i386 Feature bit definitions
//
// N.B. The no execute feature flags must be identical on all platforms.

#define KF_V86_VIS          0x00000001
#define KF_RDTSC            0x00000002
#define KF_CR4              0x00000004
#define KF_CMOV             0x00000008
#define KF_GLOBAL_PAGE      0x00000010
#define KF_LARGE_PAGE       0x00000020
#define KF_MTRR             0x00000040
#define KF_CMPXCHG8B        0x00000080
#define KF_MMX              0x00000100
#define KF_WORKING_PTE      0x00000200
#define KF_PAT              0x00000400
#define KF_FXSR             0x00000800
#define KF_FAST_SYSCALL     0x00001000
#define KF_XMMI             0x00002000
#define KF_3DNOW            0x00004000
#define KF_AMDK6MTRR        0x00008000
#define KF_XMMI64           0x00010000
#define KF_DTS              0x00020000
#define KF_NOEXECUTE        0x20000000
#define KF_GLOBAL_32BIT_EXECUTE 0x40000000
#define KF_GLOBAL_32BIT_NOEXECUTE 0x80000000

#define try _try
#define except _except





// begin_ntsrv


// end_ntsrv
#define DBGKD_MAXSTREAM 16

// typedef struct _DBGKD_CONTROL_REPORT {
//     ULONG   Dr6;
//     ULONG   Dr7;
//     USHORT  InstructionCount;
//     USHORT  ReportFlags;
//     UCHAR   InstructionStream[DBGKD_MAXSTREAM];
//     USHORT  SegCs;
//     USHORT  SegDs;
//     USHORT  SegEs;
//     USHORT  SegFs;
//     ULONG   EFlags;
// } DBGKD_CONTROL_REPORT, *PDBGKD_CONTROL_REPORT;


#define REPORT_INCLUDES_SEGS    0x0001  // this is for backward compatibility

//
// DBGKD_CONTROL_SET
//
// This structure control value the debugger wants to set on every
// continue, and thus sets here to avoid packet traffic.
//

// typedef struct _DBGKD_CONTROL_SET {
//     ULONG   TraceFlag;                  // WARNING: This must NOT be a BOOLEAN,
// 	//     or host and target will end
// 	//     up with different alignments!
//     ULONG   Dr7;
//     ULONG   CurrentSymbolStart;         // Range in which to trace locally
//     ULONG   CurrentSymbolEnd;
// } DBGKD_CONTROL_SET, *PDBGKD_CONTROL_SET;

// begin_windbgkd


#define KI_EXCEPTION_INTERNAL               0x10000000
#define KI_EXCEPTION_GP_FAULT               (KI_EXCEPTION_INTERNAL | 0x1)
#define KI_EXCEPTION_INVALID_OP             (KI_EXCEPTION_INTERNAL | 0x2)
#define KI_EXCEPTION_INTEGER_DIVIDE_BY_ZERO (KI_EXCEPTION_INTERNAL | 0x3)
#define KI_EXCEPTION_ACCESS_VIOLATION       (KI_EXCEPTION_INTERNAL | 0x4)

#define EFLAGS_CF_MASK        0x00000001L
#define EFLAGS_PF_MASK        0x00000004L
#define EFLAGS_AF_MASK        0x00000010L
#define EFLAGS_ZF_MASK        0x00000040L
#define EFLAGS_SF_MASK        0x00000080L
#define EFLAGS_TF             0x00000100L
#define EFLAGS_INTERRUPT_MASK 0x00000200L
#define EFLAGS_DF_MASK        0x00000400L
#define EFLAGS_OF_MASK        0x00000800L
#define EFLAGS_IOPL_MASK      0x00003000L
#define EFLAGS_NT             0x00004000L
#define EFLAGS_RF             0x00010000L
#define EFLAGS_V86_MASK       0x00020000L
#define EFLAGS_ALIGN_CHECK    0x00040000L
#define EFLAGS_VIF            0x00080000L
#define EFLAGS_VIP            0x00100000L
#define EFLAGS_ID_MASK        0x00200000L

#define EFLAGS_USER_SANITIZE  0x003f4dd7L


#define RPL_MASK                                0x0003
#define MODE_MASK                               0x0001
#define KGDT_R0_CODE                            0x8
#define KGDT_R0_DATA                            0x10
#define KGDT_R3_CODE                            0x18
#define KGDT_R3_DATA                            0x20
#define KGDT_TSS                                0x28
#define KGDT_R0_PCR                             0x30
#define KGDT_R3_TEB                             0x38
#define KGDT_LDT                                0x48
#define KGDT_DF_TSS                             0x50
#define KGDT_NMI_TSS                            0x58
#define EXCEPTION_EXECUTE_FAULT					0x8


#define CONTEXT_LENGTH  (sizeof(CONTEXT))
#define CONTEXT_ALIGN   (sizeof(ULONG))
#define CONTEXT_ROUND   (CONTEXT_ALIGN - 1)
#define CONTEXT_ALIGNED_SIZE ((sizeof(CONTEXT) + CONTEXT_ROUND) & ~CONTEXT_ROUND)

#define SANITIZE_SEG(segCS, mode) (\
	((mode) == KernelMode ? \
	((0x00000000L) | ((segCS) & 0xfffc)) : \
	((0x00000003L) | ((segCS) & 0xffff))))

typedef struct _DESCRIPTOR // 3 elements, 0x8 bytes (sizeof)
{
    /*0x000*/     UINT16       Pad;
    /*0x002*/
    UINT16       Limit;
    /*0x004*/
    ULONG32      Base;
} DESCRIPTOR, *PDESCRIPTOR;

typedef struct _KSPECIAL_REGISTERS // 15 elements, 0x54 bytes (sizeof)
{
    /*0x000*/     ULONG32      Cr0;
    /*0x004*/
    ULONG32      Cr2;
    /*0x008*/
    ULONG32      Cr3;
    /*0x00C*/
    ULONG32      Cr4;
    /*0x010*/
    ULONG32      KernelDr0;
    /*0x014*/
    ULONG32      KernelDr1;
    /*0x018*/
    ULONG32      KernelDr2;
    /*0x01C*/
    ULONG32      KernelDr3;
    /*0x020*/
    ULONG32      KernelDr6;
    /*0x024*/
    ULONG32      KernelDr7;
    /*0x028*/
    struct _DESCRIPTOR Gdtr;       // 3 elements, 0x8 bytes (sizeof)
    /*0x030*/
    struct _DESCRIPTOR Idtr;       // 3 elements, 0x8 bytes (sizeof)
    /*0x038*/
    UINT16       Tr;
    /*0x03A*/
    UINT16       Ldtr;
    /*0x03C*/
    ULONG32      Reserved[6];
} KSPECIAL_REGISTERS, *PKSPECIAL_REGISTERS;

typedef struct _KPROCESSOR_STATE                 // 2 elements, 0x320 bytes (sizeof)
{
    /*0x000*/     struct _CONTEXT ContextFrame;                // 25 elements, 0x2CC bytes (sizeof)
    /*0x2CC*/
    struct _KSPECIAL_REGISTERS SpecialRegisters; // 15 elements, 0x54 bytes (sizeof)
} KPROCESSOR_STATE, *PKPROCESSOR_STATE;


typedef struct _PP_LOOKASIDE_LIST // 2 elements, 0x8 bytes (sizeof)
{
    /*0x000*/     struct _GENERAL_LOOKASIDE* P;
    /*0x004*/
    struct _GENERAL_LOOKASIDE* L;
} PP_LOOKASIDE_LIST, *PPP_LOOKASIDE_LIST;


typedef struct _FNSAVE_FORMAT      // 8 elements, 0x6C bytes (sizeof)
{
    /*0x000*/     ULONG32      ControlWord;
    /*0x004*/
    ULONG32      StatusWord;
    /*0x008*/
    ULONG32      TagWord;
    /*0x00C*/
    ULONG32      ErrorOffset;
    /*0x010*/
    ULONG32      ErrorSelector;
    /*0x014*/
    ULONG32      DataOffset;
    /*0x018*/
    ULONG32      DataSelector;
    /*0x01C*/
    UINT8        RegisterArea[80];
} FNSAVE_FORMAT, *PFNSAVE_FORMAT;

typedef struct _FXSAVE_FORMAT       // 14 elements, 0x208 bytes (sizeof)
{
    /*0x000*/     UINT16       ControlWord;
    /*0x002*/
    UINT16       StatusWord;
    /*0x004*/
    UINT16       TagWord;
    /*0x006*/
    UINT16       ErrorOpcode;
    /*0x008*/
    ULONG32      ErrorOffset;
    /*0x00C*/
    ULONG32      ErrorSelector;
    /*0x010*/
    ULONG32      DataOffset;
    /*0x014*/
    ULONG32      DataSelector;
    /*0x018*/
    ULONG32      MXCsr;
    /*0x01C*/
    ULONG32      MXCsrMask;
    /*0x020*/
    UINT8        RegisterArea[128];
    /*0x0A0*/
    UINT8        Reserved3[128];
    /*0x120*/
    UINT8        Reserved4[224];
    /*0x200*/
    UINT8        Align16Byte[8];
} FXSAVE_FORMAT, *PFXSAVE_FORMAT;

typedef struct _FX_SAVE_AREA          // 3 elements, 0x210 bytes (sizeof)
{
    union                             // 2 elements, 0x208 bytes (sizeof)
    {
        /*0x000*/         struct _FNSAVE_FORMAT FnArea; // 8 elements, 0x6C bytes (sizeof)
        /*0x000*/
        struct _FXSAVE_FORMAT FxArea; // 14 elements, 0x208 bytes (sizeof)
    } U;
    /*0x208*/
    ULONG32      NpxSavedCpu;
    /*0x20C*/
    ULONG32      Cr0NpxState;
} FX_SAVE_AREA, *PFX_SAVE_AREA;


typedef struct _PROCESSOR_IDLE_TIMES     // 3 elements, 0x20 bytes (sizeof)
{
    /*0x000*/     UINT64       StartTime;
    /*0x008*/
    UINT64       EndTime;
    /*0x010*/
    ULONG32      IdleHandlerReserved[4];
} PROCESSOR_IDLE_TIMES, *PPROCESSOR_IDLE_TIMES;

typedef struct _PROCESSOR_POWER_STATE          // 45 elements, 0x120 bytes (sizeof)
{
    /*0x000*/     PVOID IdleFunction;
    /*0x004*/
    ULONG32      Idle0KernelTimeLimit;
    /*0x008*/
    ULONG32      Idle0LastTime;
    /*0x00C*/
    VOID*        IdleHandlers;
    /*0x010*/
    VOID*        IdleState;
    /*0x014*/
    ULONG32      IdleHandlersCount;
    /*0x018*/
    UINT64       LastCheck;
    /*0x020*/
    struct _PROCESSOR_IDLE_TIMES IdleTimes;    // 3 elements, 0x20 bytes (sizeof)
    /*0x040*/
    ULONG32      IdleTime1;
    /*0x044*/
    ULONG32      PromotionCheck;
    /*0x048*/
    ULONG32      IdleTime2;
    /*0x04C*/
    UINT8        CurrentThrottle;
    /*0x04D*/
    UINT8        ThermalThrottleLimit;
    /*0x04E*/
    UINT8        CurrentThrottleIndex;
    /*0x04F*/
    UINT8        ThermalThrottleIndex;
    /*0x050*/
    ULONG32      LastKernelUserTime;
    /*0x054*/
    ULONG32      LastIdleThreadKernelTime;
    /*0x058*/
    ULONG32      PackageIdleStartTime;
    /*0x05C*/
    ULONG32      PackageIdleTime;
    /*0x060*/
    ULONG32      DebugCount;
    /*0x064*/
    ULONG32      LastSysTime;
    /*0x068*/
    UINT64       TotalIdleStateTime[3];
    /*0x080*/
    ULONG32      TotalIdleTransitions[3];
    /*0x08C*/
    UINT8        _PADDING0_[0x4];
    /*0x090*/
    UINT64       PreviousC3StateTime;
    /*0x098*/
    UINT8        KneeThrottleIndex;
    /*0x099*/
    UINT8        ThrottleLimitIndex;
    /*0x09A*/
    UINT8        PerfStatesCount;
    /*0x09B*/
    UINT8        ProcessorMinThrottle;
    /*0x09C*/
    UINT8        ProcessorMaxThrottle;
    /*0x09D*/
    UINT8        EnableIdleAccounting;
    /*0x09E*/
    UINT8        LastC3Percentage;
    /*0x09F*/
    UINT8        LastAdjustedBusyPercentage;
    /*0x0A0*/
    ULONG32      PromotionCount;
    /*0x0A4*/
    ULONG32      DemotionCount;
    /*0x0A8*/
    ULONG32      ErrorCount;
    /*0x0AC*/
    ULONG32      RetryCount;
    /*0x0B0*/
    ULONG32      Flags;
    /*0x0B4*/
    UINT8        _PADDING1_[0x4];
    /*0x0B8*/
    union _LARGE_INTEGER PerfCounterFrequency; // 4 elements, 0x8 bytes (sizeof)
    /*0x0C0*/
    ULONG32      PerfTickCount;
    /*0x0C4*/
    UINT8        _PADDING2_[0x4];
    /*0x0C8*/
    struct _KTIMER PerfTimer;                  // 5 elements, 0x28 bytes (sizeof)
    /*0x0F0*/
    struct _KDPC PerfDpc;                      // 9 elements, 0x20 bytes (sizeof)
    /*0x110*/
    PVOID PerfStates;
    /*0x114*/
    PVOID PerfSetThrottle;
    /*0x118*/
    ULONG32      LastC3KernelUserTime;
    /*0x11C*/
    ULONG32      LastPackageIdleTime;
} PROCESSOR_POWER_STATE, *PPROCESSOR_POWER_STATE;
//
typedef struct _KPRCB                                    // 91 elements, 0xC50 bytes (sizeof)
{
    /*0x000*/     UINT16       MinorVersion;
    /*0x002*/
    UINT16       MajorVersion;
    /*0x004*/
    struct _KTHREAD* CurrentThread;
    /*0x008*/
    struct _KTHREAD* NextThread;
    /*0x00C*/
    struct _KTHREAD* IdleThread;
    /*0x010*/
    CHAR         Number;
    /*0x011*/
    CHAR         Reserved;
    /*0x012*/
    UINT16       BuildType;
    /*0x014*/
    ULONG32      SetMember;
    /*0x018*/
    CHAR         CpuType;
    /*0x019*/
    CHAR         CpuID;
    /*0x01A*/
    UINT16       CpuStep;
    /*0x01C*/
    struct _KPROCESSOR_STATE ProcessorState;             // 2 elements, 0x320 bytes (sizeof)
    /*0x33C*/
    ULONG32      KernelReserved[16];
    /*0x37C*/
    ULONG32      HalReserved[16];
    /*0x3BC*/
    UINT8        PrcbPad0[92];
    /*0x418*/
    struct _KSPIN_LOCK_QUEUE LockQueue[16];
    /*0x498*/
    UINT8        PrcbPad1[8];
    /*0x4A0*/
    struct _KTHREAD* NpxThread;
    /*0x4A4*/
    ULONG32      InterruptCount;
    /*0x4A8*/
    ULONG32      KernelTime;
    /*0x4AC*/
    ULONG32      UserTime;
    /*0x4B0*/
    ULONG32      DpcTime;
    /*0x4B4*/
    ULONG32      DebugDpcTime;
    /*0x4B8*/
    ULONG32      InterruptTime;
    /*0x4BC*/
    ULONG32      AdjustDpcThreshold;
    /*0x4C0*/
    ULONG32      PageColor;
    /*0x4C4*/
    ULONG32      SkipTick;
    /*0x4C8*/
    UINT8        MultiThreadSetBusy;
    /*0x4C9*/
    UINT8        Spare2[3];
    /*0x4CC*/
    PVOID ParentNode;
    /*0x4D0*/
    ULONG32      MultiThreadProcessorSet;
    /*0x4D4*/
    struct _KPRCB* MultiThreadSetMaster;
    /*0x4D8*/
    ULONG32      ThreadStartCount[2];
    /*0x4E0*/
    ULONG32      CcFastReadNoWait;
    /*0x4E4*/
    ULONG32      CcFastReadWait;
    /*0x4E8*/
    ULONG32      CcFastReadNotPossible;
    /*0x4EC*/
    ULONG32      CcCopyReadNoWait;
    /*0x4F0*/
    ULONG32      CcCopyReadWait;
    /*0x4F4*/
    ULONG32      CcCopyReadNoWaitMiss;
    /*0x4F8*/
    ULONG32      KeAlignmentFixupCount;
    /*0x4FC*/
    ULONG32      KeContextSwitches;
    /*0x500*/
    ULONG32      KeDcacheFlushCount;
    /*0x504*/
    ULONG32      KeExceptionDispatchCount;
    /*0x508*/
    ULONG32      KeFirstLevelTbFills;
    /*0x50C*/
    ULONG32      KeFloatingEmulationCount;
    /*0x510*/
    ULONG32      KeIcacheFlushCount;
    /*0x514*/
    ULONG32      KeSecondLevelTbFills;
    /*0x518*/
    ULONG32      KeSystemCalls;
    /*0x51C*/
    ULONG32      SpareCounter0[1];
    /*0x520*/
    struct _PP_LOOKASIDE_LIST PPLookasideList[16];
    /*0x5A0*/
    struct _PP_LOOKASIDE_LIST PPNPagedLookasideList[32];
    /*0x6A0*/
    struct _PP_LOOKASIDE_LIST PPPagedLookasideList[32];
    /*0x7A0*/
    ULONG32      PacketBarrier;
    /*0x7A4*/
    ULONG32      ReverseStall;
    /*0x7A8*/
    VOID*        IpiFrame;
    /*0x7AC*/
    UINT8        PrcbPad2[52];
    /*0x7E0*/
    VOID*        CurrentPacket[3];
    /*0x7EC*/
    ULONG32      TargetSet;
    /*0x7F0*/
    PVOID WorkerRoutine;
    /*0x7F4*/
    ULONG32      IpiFrozen;
    /*0x7F8*/
    UINT8        PrcbPad3[40];
    /*0x820*/
    ULONG32      RequestSummary;
    /*0x824*/
    struct _KPRCB* SignalDone;
    /*0x828*/
    UINT8        PrcbPad4[56];
    /*0x860*/
    struct _LIST_ENTRY DpcListHead;                      // 2 elements, 0x8 bytes (sizeof)
    /*0x868*/
    VOID*        DpcStack;
    /*0x86C*/
    ULONG32      DpcCount;
    /*0x870*/
    ULONG32      DpcQueueDepth;
    /*0x874*/
    ULONG32      DpcRoutineActive;
    /*0x878*/
    ULONG32      DpcInterruptRequested;
    /*0x87C*/
    ULONG32      DpcLastCount;
    /*0x880*/
    ULONG32      DpcRequestRate;
    /*0x884*/
    ULONG32      MaximumDpcQueueDepth;
    /*0x888*/
    ULONG32      MinimumDpcRate;
    /*0x88C*/
    ULONG32      QuantumEnd;
    /*0x890*/
    UINT8        PrcbPad5[16];
    /*0x8A0*/
    ULONG32      DpcLock;
    /*0x8A4*/
    UINT8        PrcbPad6[28];
    /*0x8C0*/
    struct _KDPC CallDpc;                                // 9 elements, 0x20 bytes (sizeof)
    /*0x8E0*/
    VOID*        ChainedInterruptList;
    /*0x8E4*/
    LONG32       LookasideIrpFloat;
    /*0x8E8*/
    ULONG32      SpareFields0[6];
    /*0x900*/
    UINT8        VendorString[13];
    /*0x90D*/
    UINT8        InitialApicId;
    /*0x90E*/
    UINT8        LogicalProcessorsPerPhysicalProcessor;
    /*0x90F*/
    UINT8        _PADDING0_[0x1];
    /*0x910*/
    ULONG32      MHz;
    /*0x914*/
    ULONG32      FeatureBits;
    /*0x918*/
    union _LARGE_INTEGER UpdateSignature;                // 4 elements, 0x8 bytes (sizeof)
    /*0x920*/
    struct _FX_SAVE_AREA NpxSaveArea;                    // 3 elements, 0x210 bytes (sizeof)
    /*0xB30*/
    struct _PROCESSOR_POWER_STATE PowerState;            // 45 elements, 0x120 bytes (sizeof)
} KPRCB, *PKPRCB;

typedef struct _KTRAP_FRAME
{


//
//  Following 4 values are only used and defined for DBG systems,
//  but are always allocated to make switching from DBG to non-DBG
//  and back quicker.  They are not DEVL because they have a non-0
//  performance impact.
//

    ULONG   DbgEbp;         // Copy of User EBP set up so KB will work.
    ULONG   DbgEip;         // EIP of caller to system call, again, for KB.
    ULONG   DbgArgMark;     // Marker to show no args here.
    ULONG   DbgArgPointer;  // Pointer to the actual args

//
//  Temporary values used when frames are edited.
//
//
//  NOTE:   Any code that want's ESP must materialize it, since it
//          is not stored in the frame for kernel mode callers.
//
//          And code that sets ESP in a KERNEL mode frame, must put
//          the new value in TempEsp, make sure that TempSegCs holds
//          the real SegCs value, and put a special marker value into SegCs.
//

    ULONG   TempSegCs;
    ULONG   TempEsp;

//
//  Debug registers.
//

    ULONG   Dr0;
    ULONG   Dr1;
    ULONG   Dr2;
    ULONG   Dr3;
    ULONG   Dr6;
    ULONG   Dr7;

//
//  Segment registers
//

    ULONG   SegGs;
    ULONG   SegEs;
    ULONG   SegDs;

//
//  Volatile registers
//

    ULONG   Edx;
    ULONG   Ecx;
    ULONG   Eax;

//
//  Nesting state, not part of context record
//

    ULONG   PreviousPreviousMode;

    struct _EXCEPTION_REGISTRATION_RECORD *ExceptionList;
    // Trash if caller was user mode.
    // Saved exception list if caller
    // was kernel mode or we're in
    // an interrupt.

//
//  FS is TIB/PCR pointer, is here to make save sequence easy
//

    ULONG   SegFs;

//
//  Non-volatile registers
//

    ULONG   Edi;
    ULONG   Esi;
    ULONG   Ebx;
    ULONG   Ebp;

//
//  Control registers
//

    ULONG   ErrCode;
    ULONG   Eip;
    ULONG   SegCs;
    ULONG   EFlags;

    ULONG   HardwareEsp;    // WARNING - segSS:esp are only here for stacks
    ULONG   HardwareSegSs;  // that involve a ring transition.

    ULONG   V86Es;          // these will be present for all transitions from
    ULONG   V86Ds;          // V86 mode
    ULONG   V86Fs;
    ULONG   V86Gs;
} KTRAP_FRAME;


typedef KTRAP_FRAME *PKTRAP_FRAME;
typedef KTRAP_FRAME *PKEXCEPTION_FRAME;

#pragma pack (pop)

typedef VOID ( *PKIDISPATCHEXCEPTION )(
    IN PEXCEPTION_RECORD ExceptionRecord,
    IN PKEXCEPTION_FRAME ExceptionFrame,
    IN PKTRAP_FRAME      TrapFrame,
    IN KPROCESSOR_MODE   PreviousMode,
    IN BOOLEAN           FirstChance
);

typedef enum _SYSTEM_INFORMATION_CLASS
{
    SystemBasicInformation, // 0 Y N
    SystemProcessorInformation, // 1 Y N
    SystemPerformanceInformation, // 2 Y N
    SystemTimeOfDayInformation, // 3 Y N
    SystemNotImplemented1, // 4 Y N
    SystemProcessesAndThreadsInformation, // 5 Y N
    SystemCallCounts, // 6 Y N
    SystemConfigurationInformation, // 7 Y N
    SystemProcessorTimes, // 8 Y N
    SystemGlobalFlag, // 9 Y Y
    SystemNotImplemented2, // 10 Y N
    SystemModuleInformation, // 11 Y N
    SystemLockInformation, // 12 Y N
    SystemNotImplemented3, // 13 Y N
    SystemNotImplemented4, // 14 Y N
    SystemNotImplemented5, // 15 Y N
    SystemHandleInformation, // 16 Y N
    SystemObjectInformation, // 17 Y N
    SystemPagefileInformation, // 18 Y N
    SystemInstructionEmulationCounts, // 19 Y N
    SystemInvalidInfoClass1, // 20
    SystemCacheInformation, // 21 Y Y
    SystemPoolTagInformation, // 22 Y N
    SystemProcessorStatistics, // 23 Y N
    SystemDpcInformation, // 24 Y Y
    SystemNotImplemented6, // 25 Y N
    SystemLoadImage, // 26 N Y
    SystemUnloadImage, // 27 N Y
    SystemTimeAdjustment, // 28 Y Y
    SystemNotImplemented7, // 29 Y N
    SystemNotImplemented8, // 30 Y N
    SystemNotImplemented9, // 31 Y N
    SystemCrashDumpInformation, // 32 Y N
    SystemExceptionInformation, // 33 Y N
    SystemCrashDumpStateInformation, // 34 Y Y/N
    SystemKernelDebuggerInformation, // 35 Y N
    SystemContextSwitchInformation, // 36 Y N
    SystemRegistryQuotaInformation, // 37 Y Y
    SystemLoadAndCallImage, // 38 N Y
    SystemPrioritySeparation, // 39 N Y
    SystemNotImplemented10, // 40 Y N
    SystemNotImplemented11, // 41 Y N
    SystemInvalidInfoClass2, // 42
    SystemInvalidInfoClass3, // 43
    SystemTimeZoneInformation, // 44 Y N
    SystemLookasideInformation, // 45 Y N
    SystemSetTimeSlipEvent, // 46 N Y
    SystemCreateSession, // 47 N Y
    SystemDeleteSession, // 48 N Y
    SystemInvalidInfoClass4, // 49
    SystemRangeStartInformation, // 50 Y N
    SystemVerifierInformation, // 51 Y Y
    SystemAddVerifier, // 52 N Y
    SystemSessionProcessesInformation // 53 Y N
} SYSTEM_INFORMATION_CLASS;

typedef VOID ( *PKeContextFromKframes )
(	  __in PKTRAP_FRAME TrapFrame,
      __in PKEXCEPTION_FRAME ExceptionFrame,
      __inout PCONTEXT ContextFrame
);

typedef BOOLEAN( * PKiCheckForAtlThunk )
(
    IN PEXCEPTION_RECORD ExceptionRecord,
    IN PCONTEXT Context
);

typedef BOOLEAN( * PRtlDispatchException )
(
    IN PEXCEPTION_RECORD ExceptionRecord,
    IN PCONTEXT ContextRecord
);

typedef VOID( * PRtlRaiseException )
(
    IN PEXCEPTION_RECORD ExceptionRecord
);

typedef VOID( * PKiSegSsToTrapFrame )
(
    IN PKTRAP_FRAME TrapFrame,
    IN ULONG SegSs
);

typedef VOID( *PKiEspToTrapFrame )
(
    IN PKTRAP_FRAME TrapFrame,
    IN ULONG Esp
);

typedef VOID( *PKeContextToKframes )
(
    __inout PKTRAP_FRAME TrapFrame,
    __inout PKEXCEPTION_FRAME ExceptionFrame,
    __in PCONTEXT ContextFrame,
    __in ULONG ContextFlags,
    __in KPROCESSOR_MODE PreviousMode
);
typedef
BOOLEAN
( *PKDEBUG_ROUTINE ) (
    IN PKTRAP_FRAME TrapFrame,
    IN PKEXCEPTION_FRAME ExceptionFrame,
    IN PEXCEPTION_RECORD ExceptionRecord,
    IN PCONTEXT ContextRecord,
    IN KPROCESSOR_MODE PreviousMode,
    IN BOOLEAN SecondChance
);

extern
PSERVICE_DESCRIPTOR_TABLE KeServiceDescriptorTable;

#define SYSCALL(function) KeServiceDescriptorTable->ntoskrnl.ServiceTable[function]


#endif