﻿#pragma once
#include "afxdialogex.h"


// CRegedit 对话框

class CRegedit : public CDialogEx
{
	DECLARE_DYNAMIC(CRegedit)

public:
	CRegedit(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CRegedit();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_REGEDIT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持
	HTREEITEM m_hItemHead;
	DECLARE_MESSAGE_MAP()
public:
	CTreeCtrl m_Tree;
	CListCtrl m_ListCtrl;
//	afx_msg void OnSelchangedTreeReg(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClickTreeReg(NMHDR* pNMHDR, LRESULT* pResult);
	virtual BOOL OnInitDialog();
	CImageList m_imgIcon;
};
