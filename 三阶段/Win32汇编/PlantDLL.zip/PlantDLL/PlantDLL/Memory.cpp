#include "Memory.h"

BYTE pOldAutoZombies[9] = { 0 };


//	�޸�����ֵ
void ChangeSun(int nNum) {
	DWORD GameBase = (DWORD)GetModuleHandleA(NULL);
	DWORD addr_Sun = ReadMem<DWORD>(GameBase + Game_Offset_Base);
	addr_Sun = ReadMem<DWORD>(addr_Sun + 0x768);
	WriteMem <int>(addr_Sun + 0x5560, nNum);
}

//	�Զ�ʰȡ����
void AutoGetSun(BOOL isAuto) {
	DWORD GameBase = (DWORD)GetModuleHandleA(NULL);
	if (isAuto) {
		WriteMem<BYTE>(GameBase + Game_Offset_GetSun, 0x74);
	}
	else {
		WriteMem<BYTE>(GameBase + Game_Offset_GetSun, 0x75);
	}
}

DWORD g_PutZombiesTime = 0;

//	���ý�ʬ
void PutZombies(int hang, ZombiesType emZombiesType) {
	if (GetTickCount() - g_PutZombiesTime <= 3000) {
		return;
	}
	g_PutZombiesTime = GetTickCount();

	DWORD GameBase = (DWORD)GetModuleHandleA(NULL);
	DWORD addr_This = ReadMem<DWORD>(GameBase + Game_Offset_Base);
	addr_This = ReadMem<DWORD>(addr_This + 0x768);
	if (addr_This == NULL) {
		return;
	}
	DWORD call_PutZombies = GameBase + Game_Offset_PutZombies;

	__asm {
		push hang
		push emZombiesType
		mov eax, addr_This
		call call_PutZombies
	}
}

//	�ر��Զ����ɽ�ʬ
void CloseAutoZombies() {
	DWORD GameBase = (DWORD)GetModuleHandleA(NULL);
	DWORD AutoZombies = GameBase + Game_Offset_AutoZombies;
	BYTE NopArr[9] = { };
	memset(NopArr, 0x90, sizeof(NopArr));
	WriteVirtual(AutoZombies, NopArr, sizeof(NopArr));
}





void ReadVirual(DWORD pDest, void* buf, int nLen) {
	if (buf == NULL || nLen <= 0) {
		return;
	}
	memset(buf, 0, nLen);
	ReadProcessMemory(GetCurrentProcess(), (void*)pDest, buf, nLen, NULL);
}

void WriteVirtual(DWORD pDest, void* buf, int nLen) {
	if (buf == NULL || nLen <= 0) {
		return;
	}
	DWORD dwOldProtect = 0;
	VirtualProtectEx(GetCurrentProcess(), (void*)pDest, nLen, PAGE_EXECUTE_READWRITE, &dwOldProtect);
	WriteProcessMemory(GetCurrentProcess(), (void*)pDest, buf, nLen, NULL);
	VirtualProtectEx(GetCurrentProcess(), (void*)pDest, nLen, dwOldProtect, &dwOldProtect);
}