#pragma once
#include "CObject.h"
#include <list>
#include "CDocument.h"
#include "CDocTemplate.h"

class CDocManager :public CObject
{
public:
  void OnFileNew();
  void AddDocTemplate(CDocTemplate* pTemplate);
public:
  std::list<CDocTemplate*> m_templateList;
};

