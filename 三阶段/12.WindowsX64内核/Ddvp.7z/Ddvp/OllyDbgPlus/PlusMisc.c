//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ����OllyDbg�Ĳ������.�ĸ�������.
 */
//===========================================================================
#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <commctrl.h>
#include <strsafe.h>
#include <Richedit.h>
#include "Dichlorvos.h"
#include "PlusMisc.h"

LPFN_ISWOW64PROCESS fnIsWow64Process;

/* �����ļ�*/
BOOL FindFile( wchar_t* SzFileName, wchar_t* SzSysModName )
{
    int i;
    HANDLE hFile;
    WIN32_FIND_DATA FindData;
    wchar_t SzPath[MAX_PATH] = {0};
    wchar_t SzSearch[MAX_PATH] = {0};
    wchar_t SzFindFile[MAX_PATH] = {0};


    wcscpy_s( SzPath, SizeOf( SzPath ), SzFileName );

    i = wcslen( SzPath );

    while ( SzPath[i] != L'\\' )
    {
        i--;
    }

    SzPath[i+1] = L'\0';

    wcscpy_s( SzSearch, SizeOf( SzSearch ), SzPath );

    wcscat_s( SzSearch, SizeOf( SzSearch ), _T( "*.*" ) );

    hFile = FindFirstFile( SzSearch, &FindData );
    if ( hFile == INVALID_HANDLE_VALUE )
    {
        return FALSE;
    }

    do
    {
        if ( FindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
        {
            if ( FindData.cFileName[0] != L'.' )
            {
				wcscpy_s( SzFindFile, SizeOf( SzFindFile ), SzPath );
				wcscat_s( SzFindFile, SizeOf( SzFindFile ), FindData.cFileName );

                FindFile( SzFindFile, SzSysModName );
            }
        }
        else
        {
            if ( wcsstr( FindData.cFileName, SzSysModName ) )
            {
                return TRUE;
            }
        }

    }
    while ( FindNextFile( hFile, &FindData ) );

    FindClose( hFile );

    return FALSE;
}

//===========================================================================
//	��߷�װһ����ȫ�����ڴ�ĺ���, ���Ƕ�ϵͳRtlCopyMemory�ķ�װ
//����ֵ:	���ִ�гɹ�, ����TRUE, ���򷵻�FALSE
//===========================================================================
BOOL SafeCopyMemory( PVOID pDest, PVOID pSrc, DWORD dwSize ) {
	BOOL bRet;
	DWORD dwOldProtect;


	__try {

		bRet = VirtualProtectEx( GetCurrentProcess(), pDest, dwSize,
			PAGE_EXECUTE_READWRITE, &dwOldProtect );
		if ( bRet == FALSE ) {
			
			return FALSE;
		}

		_asm {
			mov	edi, pDest
				mov	esi, pSrc
				mov	ecx, dwSize
				rep	movsb
		}

		bRet = VirtualProtectEx( GetCurrentProcess(), pDest, dwSize, dwOldProtect,
			&dwOldProtect );
		if ( bRet == FALSE ) {
			
			return FALSE;
		}

		bRet = TRUE;
	} __except( EXCEPTION_EXECUTE_HANDLER ) {
		bRet = FALSE;
	}
	return bRet;

}

//===========================================================================
//	��ȫ��д��һ��jmp��ַ
//pAddress	:Ҫд��ĵ�ַ
//pFunction	:д��Ҫ��ת���ĵ�ַ
//����ֵ	:�ɹ�����TRUE, ���򷵻�FALSE
//===========================================================================
BOOL _Jump( PVOID pAddress, PVOID pFunction, ULONG dwNop ) {
	ULONG i;
	DWORD dwOldProtect1 = 0;

	__try {

		VirtualProtectEx( GetCurrentProcess(), ( LPVOID )pAddress, 1,
			PAGE_EXECUTE_READWRITE, &dwOldProtect1 );

		*( PBYTE )pAddress = 0xE9;

		*( PDWORD )( ( ( PBYTE )pAddress ) + 1 ) = _jmp( pAddress, pFunction );

		for( i = 0; i < dwNop; i++ )
		{
			*( ( ( PBYTE )pAddress ) + 5 + i ) = 0x90;
		}

		VirtualProtectEx( GetCurrentProcess(), ( LPVOID )pAddress, 1,
			dwOldProtect1, &dwOldProtect1 );
		return TRUE;

	} __except ( EXCEPTION_EXECUTE_HANDLER ) {
		return FALSE;
	}
}

//===========================================================================
// ��ListView������һ����
// ����:
//	dwColumn = ���ӵ��б��
//	dwWidth	 = �еĿ���
//	pStr	 = �еı����ַ���
//===========================================================================
VOID ListViewInsertColumn( HWND hListView, DWORD dwColumn, DWORD dwWidth, _TCHAR* pStr )
{
    LV_COLUMN StLvColumn = {0};

    StLvColumn.mask       = LVCF_TEXT | LVCF_WIDTH | LVCF_FMT;
    StLvColumn.fmt        = LVCFMT_LEFT;
    StLvColumn.pszText    = pStr;
    StLvColumn.cx         = dwWidth;
    StLvColumn.cchTextMax = lstrlen( pStr );
    SendMessage( hListView, LVM_INSERTCOLUMN, dwColumn, ( LPARAM )&StLvColumn );
}


//===========================================================================
// ��ListView������һ�У����޸�һ����ĳ���ֶε�����
// ���룺_dwItem = Ҫ�޸ĵ��еı��
//	_dwSubItem = Ҫ�޸ĵ��ֶεı�ţ�-1��ʾ�����µ��У�>=1��ʾ�ֶεı��
//����ֵ	:�ɹ����ش���1, ��ʾ�µ��к�, ���򷵻�0
//===========================================================================
LRESULT ListViewSetItem( HWND hListView, DWORD dwItem, DWORD dwSubItem, TCHAR* pStr )
{
    LV_ITEM StLvi = {0};

    StLvi.cchTextMax = lstrlen( pStr );
    StLvi.pszText    = pStr;
    StLvi.mask       = LVIF_TEXT;
    StLvi.iItem      = dwItem;
    StLvi.iSubItem   = dwSubItem;

    if ( dwSubItem == -1 )
    {
        StLvi.iItem = SendMessage( hListView, LVM_GETITEMCOUNT, 0, 0 );
        StLvi.iSubItem = 0;
        return SendMessage( hListView, LVM_INSERTITEM, 0, ( LPARAM )&StLvi );
    }
    else
    {
        return SendMessage( hListView, LVM_SETITEM, 0, ( LPARAM )&StLvi  );
    }
}

BOOLEAN IsBitSet( ULONG64 v, UCHAR bitNo )
{
    ULONG64 mask = ( ULONG64 ) 1 << bitNo;
    return ( BOOLEAN ) ( ( v & mask ) != 0 );
}

// ���Cpu�Ƿ�֧��VT
BOOL CheckForVirtualizationSupport()
{
    ULONG eax, ebx, ecx, edx;
	
	return TRUE;

    //
    // ���Cpu�Ƿ�֧��Cpuidָ��
    //
    CpuId( 0, &eax, &ebx, &ecx, &edx );
    if ( eax < 1 )
    {

        return FALSE;
    }

    /* Intel Genuine */
    if ( !( ebx == 0x756e6547 && ecx == 0x6c65746e && edx == 0x49656e69 ) )
    {

        return FALSE;
    }

    //
    // ���Cpu�Ƿ�֧��VT����
    //
    CpuId( 0x1, &eax, &ebx, &ecx, &edx );
    if ( !IsBitSet( ecx, 5 ) )
    {
        return FALSE;
    }
    return TRUE;
}

/*	��hEdit�в���һ����־��Ϣ*/
VOID AppendTextToEdit( HWND hEdit, TCHAR* pStr )
{
    CHARRANGE StCharrange;

    StCharrange.cpMax = StCharrange.cpMin = GetWindowTextLength( hEdit );
    SendMessage( hEdit, EM_SETSEL, StCharrange.cpMin, ( LPARAM )StCharrange.cpMax );
    SendMessage( hEdit, EM_REPLACESEL, FALSE, ( LPARAM )pStr  );
    SendMessage( hEdit, WM_VSCROLL, SB_BOTTOM, 0 );
}

CPU_TYPE GetCpuType()
{
    ULONG eax, ebx, ecx, edx;

    //
    // ���Cpu�Ƿ�֧��Cpuidָ��
    //
    CpuId( 0, &eax, &ebx, &ecx, &edx );
    if ( eax < 1 )
    {

        return Cpu_Other;
    }

    /* Intel Genuine */
    if ( !( ebx == 0x756e6547 && ecx == 0x6c65746e && edx == 0x49656e69 ) )
    {

        return Cpu_Other;
    }

    return Cpu_Intel;
}

/*
 * ����������, �߱���ʽ����OutputDebugString
 */
int __cdecl DbgPrint( char* _Format, ... )
{
    int iRet;
    va_list list;
    char SzBuf[8192] = {0};

    va_start( list, _Format );

    iRet = vsprintf_s( SzBuf, sizeof( SzBuf ),  _Format, list );

    OutputDebugStringA( SzBuf );

    va_end( list );

    return iRet;
}

/* ��ȡģ�����ڵľ���·��*/
BOOL _GetModuleFilePath( wchar_t* SzPath, size_t Size  )
{
    int i;

    //
    // ��ȡ���������·��
    //
    i = GetModuleFileName( NULL, SzPath, Size );

    while( SzPath[i] != L'\\' )
    {
        i--;
    }

    SzPath[i+1] = L'\0';

    return i;
}

BOOL IsWow64()
{
    BOOL bIsWow64 = FALSE;

    // IsWow64Process is not available on all supported versions of Windows.
    // Use GetModuleHandle to get a handle to the DLL that contains the function
    // and GetProcAddress to get a pointer to the function if available.

    fnIsWow64Process = ( LPFN_ISWOW64PROCESS ) GetProcAddress(
                           GetModuleHandle( _T( "kernel32" ) ),"IsWow64Process" );

    if( NULL != fnIsWow64Process )
    {
        if ( !fnIsWow64Process( GetCurrentProcess(),&bIsWow64 ) )
        {
            //handle error
        }
    }
    return bIsWow64;
}


/* ��IAT����ͨ������IAT����, ������λ��, �ɹ�������IAT�е�λ��, ʧ�ܷ���NULL*/
PVOID FindProcForIAT( char* SzProcName )
{
    DWORD dwImageBase;
    PIMAGE_DOS_HEADER lpDosHead;
    PIMAGE_NT_HEADERS lpNtHead;
    PDWORD lpOriginalFirstThunk;
    PDWORD lpFirstThunk;
    int j,i;
    PIMAGE_IMPORT_DESCRIPTOR lpImageImport;

    // ��ȡDosͷλ��
    lpDosHead = ( PIMAGE_DOS_HEADER )GetModuleHandle( NULL );
    if ( !lpDosHead )
    {
        return NULL;
    }

    // ��ȡNTͷλ��
    lpNtHead = ( PIMAGE_NT_HEADERS )( ( ( DWORD )lpDosHead ) + lpDosHead->e_lfanew );

    // ����װ�ص�ַ
    dwImageBase = lpNtHead->OptionalHeader.ImageBase;

    // �����λ�õ�ַ.
    lpImageImport = ( PIMAGE_IMPORT_DESCRIPTOR )
                    lpNtHead->OptionalHeader.DataDirectory[2].VirtualAddress;

    //
    // ���������������ÿ��DLL
    //
    for( j = 0; ; j++ )
    {

        if ( ( !lpImageImport[j].Characteristics ) &&
                ( !lpImageImport[j].FirstThunk ) &&
                ( !lpImageImport[j].ForwarderChain ) &&
                ( !lpImageImport[j].Name ) &&
                ( !lpImageImport[j].OriginalFirstThunk ) &&
                ( !lpImageImport[j].TimeDateStamp ) )
        {
            break;
        }

        // ��ȡIAT��ַ
        lpFirstThunk = ( PDWORD )( ( dwImageBase ) + lpImageImport[j].FirstThunk );

        // ��ȡINT��ַ
        lpOriginalFirstThunk = ( PDWORD )( ( dwImageBase ) +
                                           lpImageImport[j].OriginalFirstThunk );

        //
        // ��������DLL, ������û�иú���.
        //
        for(  i = 0; lpOriginalFirstThunk[i]; i++ )
        {
            PIMAGE_IMPORT_BY_NAME lpImageImportName = ( PIMAGE_IMPORT_BY_NAME )
                    ( ( PDWORD )( lpOriginalFirstThunk[i] + dwImageBase ) );

            // ������λΪ1, ��ô���ǰ�����ŵ����, ��Ȼ������.
            if ( lpImageImportName->Hint & 0x8000 )
            {
                continue;
            }

            // �Ƚ��Ƿ���Ҫ�¹��ӵĺ���..
            if ( !strcmp( ( char* ) & ( lpImageImportName->Name ), SzProcName ) )
            {
                // ���ز��ҵ��ĵ�ַ.
                return ( PVOID ) * ( PDWORD )( lpFirstThunk[i] + dwImageBase );
            }
        }
    }
    return NULL;
}

VOID  CpuId( ULONG fn,
              OUT PULONG ret_eax,
              OUT PULONG ret_ebx,
              OUT PULONG ret_ecx,
              OUT PULONG ret_edx )
{

    __asm
    {
        pushad
        mov		eax, fn
        cpuid
        mov		esi, ret_eax
        mov		dword ptr [esi], eax
        mov		esi, ret_ebx
        mov		dword ptr [esi], ebx
        mov		esi, ret_ecx
        mov		dword ptr [esi], ecx
        mov		esi, ret_edx
        mov		dword ptr [esi], edx
        popad
    }
}