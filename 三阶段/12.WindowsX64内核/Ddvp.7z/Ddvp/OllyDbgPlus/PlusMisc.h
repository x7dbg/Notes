

// ����jmp��ַ
#define _jmp(frm, to) (int)(((int)to - (int)frm) - 5)

int __cdecl DbgPrint( char* _Format, ... );

#undef  KdPrint
#ifdef _DEBUG
#define KdPrint( _x_ ) DbgPrint _x_
#else
#define KdPrint( _x_ )
#endif

typedef enum _CPU_TYPE
{
    Cpu_Intel,
    Cpu_AMD,
    Cpu_Other
} CPU_TYPE;


typedef BOOL ( WINAPI *LPFN_ISWOW64PROCESS ) ( HANDLE, PBOOL );

BOOL _GetModuleFilePath( wchar_t* SzPath, size_t Size );
BOOL IsWow64();
BOOL FindFile( wchar_t* SzFileName, wchar_t* SzSysModName );
VOID ListViewInsertColumn( HWND hListView, DWORD dwColumn, DWORD dwWidth, _TCHAR* pStr );
LRESULT ListViewSetItem( HWND hListView, DWORD dwItem, DWORD dwSubItem, TCHAR* pStr );
CPU_TYPE GetCpuType();
VOID CpuId( ULONG fn, OUT PULONG ret_eax, OUT PULONG ret_ebx, OUT PULONG ret_ecx, OUT PULONG ret_edx );
VOID AppendTextToEdit( HWND hEdit, TCHAR* pStr );
BOOL CheckForVirtualizationSupport();
BOOL _Jump( PVOID pAddress, PVOID pFunction, ULONG dwNop );
BOOL SafeCopyMemory( PVOID pDest, PVOID pSrc, DWORD dwSize );