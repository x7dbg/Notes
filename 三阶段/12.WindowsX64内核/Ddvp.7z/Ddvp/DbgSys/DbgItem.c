//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ������֯���������̵����������ļ�.
 */
//===========================================================================
#include <ntifs.h>
#include "defines.h"
#include "DbgItem.h"

static LIST_ENTRY DbgItemList;
static KSPIN_LOCK DbgItemLock;

//
// ����ĳ�������Ƿ����ڵ���������
//
DBG_ITEM* DbgItemFindItem( PEPROCESS Debugger, PEPROCESS Debugged )
{
    PLIST_ENTRY Entry;
    DBG_ITEM *DbgItem = NULL;
    DBG_ITEM* DbgFind = NULL;
    KIRQL OldIrql;

    KeAcquireSpinLock( &DbgItemLock, &OldIrql );

    Entry = DbgItemList.Flink;

    while( Entry != &DbgItemList )
    {
        DbgItem  = CONTAINING_RECORD( Entry, DBG_ITEM, ListEntry );

        Entry = Entry->Flink;

        //
        // �����ǰ�����Ѿ����б���.
        //
        if( ( Debugger == NULL || DbgItem->Debugger == Debugger ) &&
                ( Debugged  == NULL || DbgItem->Debugged == Debugged ) )
        {
            InterlockedIncrement( &DbgItem->RefCount );

 			// KdPrint( ( "Ddvp-> Call DbgItemFindItem  Ref:%3d Debugger: %p Debugged: %p \n",
            //            DbgItem->RefCount, Debugger, Debugged ) );

            DbgFind = DbgItem;
            break;
        }
    }

    KeReleaseSpinLock( &DbgItemLock, OldIrql );

    return DbgFind;
}

//
// ����ĳ�������Ƿ����ڵ���������
//
DBG_ITEM* DbgItemCr3FindItem( ULONG_PTR DebuggerCr3, ULONG_PTR DebuggedCr3 )
{
	PLIST_ENTRY Entry;
	DBG_ITEM *DbgItem = NULL;
	DBG_ITEM* DbgFind = NULL;
	KIRQL OldIrql;

	KeAcquireSpinLock( &DbgItemLock, &OldIrql );

	Entry = DbgItemList.Flink;

	while( Entry != &DbgItemList )
	{
		DbgItem  = CONTAINING_RECORD( Entry, DBG_ITEM, ListEntry );

		Entry = Entry->Flink;

		//
		// �����ǰ�����Ѿ����б���.
		//
		if( ( DebuggerCr3 == 0 || DbgItem->DebuggerCr3 == DebuggerCr3 ) &&
			( DebuggedCr3  == 0 || DbgItem->DebuggedCr3 == DebuggedCr3 ) )
		{
			InterlockedIncrement( &DbgItem->RefCount );

			// KdPrint( ( "Ddvp-> Call DbgItemFindItem  Ref:%3d DebuggerCr3: %p DebuggedCr3: %p \n",
			//           DbgItem->RefCount, DebuggerCr3, DebuggedCr3 ) );

			DbgFind = DbgItem;
			break;
		}
	}

	KeReleaseSpinLock( &DbgItemLock, OldIrql );

	return DbgFind;
}

//
// ��ĳ�����̵�DbgItem������һ��
//
VOID DbgItemDeRefItem( DBG_ITEM *DbgItem )
{

    if( InterlockedDecrement( &DbgItem->RefCount ) == 0 )
    {
        RemoveEntryList( &DbgItem->ListEntry );

        if( DbgItem->Debugged )
        {
            ObDereferenceObject( DbgItem->Debugged );
        }

        if( DbgItem->Debugger )
        {
            ObDereferenceObject( DbgItem->Debugger );
        }

        ExFreePool( DbgItem );
    }

    // KdPrint( ( "Ddvp-> Call DbgItemDeRefItem Ref:%3d Debugger: %p Debugged: %p \n",
    //            DbgItem->RefCount, DbgItem->Debugger, DbgItem->Debugged ) );
    return;
}

//
// ɾ��������Item
//
VOID DbgItemDeleteItem( DBG_ITEM* DbgItem )
{
    DbgItem->Active = FALSE;

    // channel_release( item->chan );

    DbgItemDeRefItem( DbgItem );
}

//
// �½�һ��������Item
//
PDBG_ITEM DbgItemNewDbgItem( PEPROCESS Debugger, ULONG_PTR DebuggerCr3 )
{

    PDBG_ITEM DbgItem = NULL;

    DbgItem = ExAllocatePoolWithTag( NonPagedPool, sizeof( DBG_ITEM ), 'Joen' );

    if( !DbgItem )
    {
        return NULL;
    }

    RtlZeroMemory( DbgItem, sizeof( DBG_ITEM ) );

    //
    // ���Խ���
    //
    DbgItem->Debugger = Debugger;

    DbgItem->DebuggerCr3 = DebuggerCr3;
    //
    // �����Խ���
    //
    DbgItem->Debugged = NULL;

    //
    // ��ʼ������2
    //
    DbgItem->RefCount = 2;

    // ��ʼ�����̱��Ϊ0
    DbgItem->ProcessFlags = 0;

    //
    // ������Խ����б�
    //
    ExInterlockedInsertTailList( &DbgItemList, &DbgItem->ListEntry, &DbgItemLock );

    KdPrint( ( "Ddvp-> Create New Debugger :%p \n", DbgItem->Debugger ) );

    ObReferenceObject( DbgItem->Debugger );

    return DbgItem;
}

//
// ��ʼ��ϵͳ�����������б�
//
NTSTATUS DbgItemInitDbgItem( )
{
    InitializeListHead( &DbgItemList );

    KeInitializeSpinLock( &DbgItemLock );

    return STATUS_SUCCESS;
}

//
// ��������ʱ, Ҫ��ʼ��һЩ��Ϣ
//
VOID DbgItemNewProcess( DBG_ITEM* DbgItem, PEPROCESS Debugged, ULONG_PTR DebuggedCr3 )
{
    KIRQL OldIrql;

    KeAcquireSpinLock( &DbgItemLock, &OldIrql );

    //
    // ����Item
    //
    DbgItem->Active = TRUE;

    //
    // �����Զ���
    //
    DbgItem->Debugged = Debugged;
    DbgItem->DebuggedCr3 = DebuggedCr3;

    /* Set the Flags */
    DbgItem->DebugObject.Flags = 0;

    KeReleaseSpinLock( &DbgItemLock, OldIrql );
}


//
// �˳���������ʱҲҪ��ʼ��һЩ��Ϣ
//

VOID DbgItemExitProcess( DBG_ITEM* DbgItem )
{
    KIRQL OldIrql;

    KeAcquireSpinLock( &DbgItemLock, &OldIrql );

    DbgItem->ProcessFlags = 0;

    /* Initialize the Debug Object's Fast Mutex */
    ExReleaseFastMutex( &DbgItem->DebugObject.Mutex );
	
	ExReleaseFastMutex( &DbgItem->DebuggedThread.Mutex );

    /* Initialize the Debug Object's Wait Event */
    KeClearEvent( &DbgItem->DebugObject.EventRecv );

    KeClearEvent( &DbgItem->DebugObject.EventSend );

    KeReleaseSpinLock( &DbgItemLock, OldIrql );
}

// �󶨽���.
VOID DbgItemAttachProcess(
    DBG_ITEM* DbgItem,
    PEPROCESS Debugged,
    ULONG_PTR DebuggedCr3 )
{
    KIRQL OldIrql;

    KeAcquireSpinLock( &DbgItemLock, &OldIrql );

    //
    // ����Item
    //
    DbgItem->Active = TRUE;

    //
    // �����Զ���
    //
    DbgItem->Debugged = Debugged;
    DbgItem->DebuggedCr3 = DebuggedCr3;

    /* Set the Flags */
    DbgItem->DebugObject.Flags = 0;

    KeReleaseSpinLock( &DbgItemLock, OldIrql );
}