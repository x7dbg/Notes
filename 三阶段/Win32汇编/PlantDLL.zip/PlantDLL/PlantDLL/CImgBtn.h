#pragma once
#include "Memory.h"

// CImgBtn

class CImgBtn : public CStatic
{
	DECLARE_DYNAMIC(CImgBtn)

public:
	CImgBtn();
	virtual ~CImgBtn();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);

public:
	ZombiesType m_emZombiesType = Zombies_Normal;
};


