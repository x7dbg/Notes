#include "CSingleDocTemplate.h"
#include "CTestDoc.h"
#include "CTestFrame.h"
#include "resource.h"
#include "CWinApp.h"

IMPLEMENT_DYNAMIC(CSingleDocTemplate, CDocTemplate)

CDocument* CSingleDocTemplate::OpenDocumentFile(LPCTSTR lpszPathName, BOOL bMakeVisible)
{
  return OpenDocumentFile(lpszPathName, TRUE, bMakeVisible);
}

CDocument* CSingleDocTemplate::OpenDocumentFile(LPCTSTR lpszPathName, BOOL bAddToMRU, BOOL bMakeVisible)
{
  CDocument* pDocument = NULL;
  CFrameWnd* pFrame = NULL;
  BOOL bCreated = FALSE;      // => doc and frame created
  BOOL bWasModified = FALSE;

  
  pDocument = new CTestDoc();
  bCreated = TRUE;


  pFrame = new CTestFrame();
  if (pFrame == NULL)
  {
    delete pDocument;       // explicit delete on error
    return NULL;
  }

  AfxGetApp()->m_pMainWnd = pFrame;

  CCreateContext context;
  context.m_pCurrentFrame = pFrame;
  context.m_pCurrentDoc = pDocument;
  //context.m_pNewViewClass = m_pViewClass;
  context.m_pNewDocTemplate = this;

  m_nIDResource = IDR_MENU1;
  if (!pFrame->LoadFrame(m_nIDResource,
    WS_OVERLAPPEDWINDOW,   // default frame styles
    NULL, &context))
  {
    return NULL;
  }

  return pDocument;
}