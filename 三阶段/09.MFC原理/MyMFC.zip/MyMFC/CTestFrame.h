#pragma once
#include "CFrameWnd.h"

class CTestFrame :public CFrameWnd
{
};

