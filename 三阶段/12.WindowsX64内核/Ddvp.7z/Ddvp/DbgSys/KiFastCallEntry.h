NTSTATUS DbgObjHookKiFastCallEntry();
NTSTATUS DbgUnHookKiFastCallEntry();
NTSTATUS InitKiFastCallEntry();
BOOL __stdcall DbgObjForwardCr3( ULONG_PTR Cr3, ULONG Index );
NTSTATUS HookLdrInitializeThunk(PVOID* lpDbgBreadkPoint );