//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ����OllyDbg�Ĳ������.
 */
//===========================================================================

#include <tchar.h>
#include <windows.h>
#include <stdio.h>
#include <commctrl.h>
#include <windowsx.h>
#include <strsafe.h>
#include <assert.h>
#include "Plugin.h"
#include "ntdll.h"
#include "resource.h"
#include "IoControlCode.h"
#include "DbgObj.h"
#include "Dichlorvos.h"
#include "PlusMisc.h"
#include "HookRoutine.h"


//---------------------------------------------------------------------------
#pragma comment( lib, "DdvpOD.lib" )

// vs2008 ��һ��Bug.
#if _MSC_FULL_VER == 150030729
#define _DO_NOT_DECLARE_INTERLOCKED_INTRINSICS_IN_MEMORY
#endif
#define Plugin_Name				"Dichlorvos"
#define Device_Name				"DbgSys"
//---------------------------------------------------------------------------

HANDLE		hDllInst;
HWND		hWndOllyDbg;
HBRUSH		hBrush;
BOOL		g_bHookFlags;
wchar_t*	g_SzTitle = _T( Plugin_Name );
static PDbgObjGetSysModuleInfo	lpDbgObjGetSysModuleInfo;
static PDbgObjGetVersion		lpDbgObjGetVersion;
static PDbgObjEnumSymbols		lpDbgObjEnumSymbols;
static PDbgObjInitialize		lpDbgObjInitialize;
static PDbgObjCreateDevice		lpDbgObjCreateDevice;
static PDbgObjCloseHanle		lpDbgObjCloseHanle;

PDbgObjCreateProcess			lpDbgObjCreateProcess;
PDbgObjWaitForDebugEvent		lpDbgObjWaitForDebugEvent;
PDbgObjContinueDebugEvent		lpDbgObjContinueDebugEvent;
PDebugActiveProcess				lpDbgObjDebugActiveProcess;
PDbgObjWriteProcessMemory		lpDbgObjWriteProcessMemory;
PDbgObjReadProcessMemory		lpDbgObjReadProcessMemory;
PDbgObjOpenProcess				lpDbgObjOpenProcess;
PDbgObjResumeThread				lpDbgObjResumeThread;
PDbgObjSuspendThread			lpDbgObjSuspendThread;
PDbgObjSetThreadContext			lpDbgObjSetThreadContext;
PDbgObjGetThreadContext			lpDbgObjGetThreadContext;
PDbgObjCheckBiosIsEnabled		lpDbgObjCheckBiosIsEnabled;
PDbgObjNtOpenThread				lpDbgObjNtOpenThread;
//---------------------------------------------------------------------------



BOOL Main_OnInitDialog( HWND hWnd, HWND hwndFocus, LPARAM lParam )
{
    HWND hEdit;
    BOOL bFlags = FALSE;
    HWND hList;
    HMODULE hDbgObj;
    SYSTEM_MODULE SymMod;
    wchar_t SzCurrentDir[MAX_PATH] = {0};
    wchar_t SzTempCurDir[MAX_PATH] = {0};
    wchar_t SzTempDllName[MAX_PATH] = {0};
    wchar_t SzSymbolsName[MAX_PATH] = {0};
    wchar_t SzTemp[MAX_PATH] = {0};
    DICHLORVOS_VERISON StDichlorovs = {0};

    hList = GetDlgItem( hWnd, IDC_LIST );

    //
    // ����һ�����ڻ�ˢ
    //
    hBrush = CreateSolidBrush( 0xffffe0 );

    // ���ô���ͼ��
    SendMessage( hWnd, WM_SETICON, ICON_BIG,
                 ( LPARAM )LoadIcon( GetModuleHandle( NULL ),
                                     MAKEINTRESOURCE( IDI_ICON1 ) ) );

    swprintf_s( SzTemp, SizeOf( SzTemp ), _T( "Dicholrvs %d.%d" ),
                MAIN_VERSION, CHILD_VERSION );

    SendMessage( hWnd, WM_SETTEXT, 0, ( LPARAM )SzTemp );

    hEdit = GetDlgItem( hWnd, IDC_EDIT_LOG );

    SendMessage( GetDlgItem( hWnd, IDC_EDIT_BIOS_SUPER ),
                 WM_SETTEXT, 0, ( LPARAM )_T( "BIOS VT�Ƿ��δ֪" ) );

    SendMessage( GetDlgItem( hWnd, IDC_EDIT_VT_SUPER ),
                 WM_SETTEXT, 0, ( LPARAM )_T( "CPU VT֧��δ֪" ) );

    EnableWindow( GetDlgItem( hWnd, IDCANCEL ), FALSE );
    EnableWindow( GetDlgItem( hWnd, IDOK ), FALSE );
//---------------------------------------------------------------------------
    //
    // ��OllyDbg��Ŀ¼���潨��һ��������Ƶ�Ŀ¼, ����ǲ���ĵ�ǰĿ¼��.
    //
    _GetModuleFilePath( SzCurrentDir, SizeOf( SzCurrentDir ) );

    //
    // �������Ҫ���ص�DbgObj.dll dbghelp.dll symsrv.dll�Ƿ����
    // Ollydbg��Щ����������3��DLL��λ��, �������³�ʼ��һ��.
    //
    wcscpy_s( SzTempCurDir, SizeOf( SzTempCurDir ), SzCurrentDir );
//---------------------------------------------------------------------------
    wcscpy_s( SzTempDllName, SizeOf( SzTempDllName ), SzTempCurDir );
    wcscat_s( SzTempDllName, SizeOf( SzTempDllName ), _T( "\\dbghelp.dll" ) );

    hDbgObj = LoadLibrary( SzTempDllName );
    if ( !hDbgObj )
    {
        MessageBox( hWnd, _T( "�޷�����dbghelp.dll, ����!" ),
                    g_SzTitle, MB_OK | MB_ICONWARNING );
        EndDialog( hWnd, 0 );
        return FALSE;
    }
//---------------------------------------------------------------------------
    wcscpy_s( SzTempDllName, SizeOf( SzTempDllName ), SzTempCurDir );
    wcscat_s( SzTempDllName, SizeOf( SzTempDllName ), _T( "\\symsrv.dll" ) );

    hDbgObj = LoadLibrary( SzTempDllName );
    if ( !hDbgObj )
    {
        MessageBox( hWnd, _T( "�޷�����symsrv.dll, ����!" ),
                    g_SzTitle, MB_OK | MB_ICONWARNING );
        EndDialog( hWnd, 0 );
        return FALSE;
    }
//---------------------------------------------------------------------------
    wcscpy_s( SzTempDllName, SizeOf( SzTempDllName ), SzTempCurDir );
    wcscat_s( SzTempDllName, SizeOf( SzTempDllName ), _T( "\\DbgObj.dll" ) );

    hDbgObj = LoadLibrary( SzTempDllName );
    if ( !hDbgObj )
    {
        MessageBox( hWnd, _T( "�޷�����DbgObj.dll, ����!" ),
                    g_SzTitle, MB_OK | MB_ICONWARNING );
        EndDialog( hWnd, 0 );
        return FALSE;
    }
//---------------------------------------------------------------------------
    lpDbgObjGetSysModuleInfo = ( PDbgObjGetSysModuleInfo )
                               GetProcAddress( hDbgObj, "DbgObjGetSysModuleInfo" );

    lpDbgObjGetVersion = ( PDbgObjGetVersion )
                         GetProcAddress( hDbgObj, "DbgObjGetVersion" );

    lpDbgObjEnumSymbols = ( PDbgObjEnumSymbols )
                          GetProcAddress( hDbgObj, "DbgObjEnumSymbols" );

    lpDbgObjInitialize = ( PDbgObjInitialize )
                         GetProcAddress( hDbgObj, "DbgObjInitialize" );

    lpDbgObjCreateProcess = ( PDbgObjCreateProcess )
                            GetProcAddress( hDbgObj, "DbgObjCreateProcess" );

    lpDbgObjWaitForDebugEvent = ( PDbgObjWaitForDebugEvent )
                                GetProcAddress( hDbgObj, "DbgObjWaitForDebugEvent" );

    lpDbgObjContinueDebugEvent = ( PDbgObjContinueDebugEvent )
                                 GetProcAddress( hDbgObj, "DbgObjContinueDebugEvent" );

    lpDbgObjCreateDevice = ( PDbgObjCreateDevice )
                           GetProcAddress( hDbgObj, "DbgObjCreateDevice" );

    lpDbgObjCloseHanle =  ( PDbgObjCloseHanle )
                          GetProcAddress( hDbgObj, "DbgObjCloseHanle" );

    lpDbgObjDebugActiveProcess = ( PDbgObjDebugActiveProcess )
                                 GetProcAddress( hDbgObj, "DbgObjDebugActiveProcess" );

    lpDbgObjWriteProcessMemory = ( PDbgObjWriteProcessMemory )
                                 GetProcAddress( hDbgObj, "DbgObjWriteProcessMemory" );

    lpDbgObjReadProcessMemory = ( PDbgObjReadProcessMemory )
                                GetProcAddress( hDbgObj, "DbgObjReadProcessMemory" );

    lpDbgObjOpenProcess = ( PDbgObjOpenProcess )
                          GetProcAddress( hDbgObj, "DbgObjOpenProcess" );

    lpDbgObjResumeThread = ( PDbgObjResumeThread )
                           GetProcAddress( hDbgObj, "DbgObjResumeThread" );

    lpDbgObjSuspendThread = ( PDbgObjSuspendThread )
                            GetProcAddress( hDbgObj, "DbgObjSuspendThread" );

    lpDbgObjSetThreadContext = ( PDbgObjSetThreadContext )
                               GetProcAddress( hDbgObj, "DbgObjSetThreadContext" );

    lpDbgObjGetThreadContext = ( PDbgObjGetThreadContext )
                               GetProcAddress( hDbgObj, "DbgObjGetThreadContext" );

    lpDbgObjCheckBiosIsEnabled = ( PDbgObjCheckBiosIsEnabled )
                                 GetProcAddress( hDbgObj, "DbgObjCheckBiosIsEnabled" );
	
	lpDbgObjNtOpenThread = ( PDbgObjNtOpenThread )
		GetProcAddress( hDbgObj, "DbgObjNtOpenThread" );
	
	assert( lpDbgObjNtOpenThread );
    assert( lpDbgObjCheckBiosIsEnabled );
    assert( lpDbgObjResumeThread );
    assert( lpDbgObjSetThreadContext );
    assert( lpDbgObjGetThreadContext );
    assert( lpDbgObjSuspendThread );
    assert( lpDbgObjOpenProcess );
    assert( lpDbgObjWaitForDebugEvent );
    assert( lpDbgObjWriteProcessMemory );
    assert( lpDbgObjReadProcessMemory );
    assert( lpDbgObjContinueDebugEvent );
    assert( lpDbgObjCreateDevice );
    assert( lpDbgObjCreateProcess );
    assert( lpDbgObjInitialize );
    assert( lpDbgObjEnumSymbols );
    assert( lpDbgObjGetSysModuleInfo );
    assert( lpDbgObjGetVersion );
    assert( lpDbgObjDebugActiveProcess );
//---------------------------------------------------------------------------
    if ( !lpDbgObjGetSysModuleInfo( &SymMod ) )
    {
        MessageBox( hWnd, _T( "��ѯϵͳģ��ʧ��!" ), g_SzTitle, MB_OK | MB_ICONWARNING );
        EndDialog( hWnd, 0 );
        return FALSE;
    }

    SendMessageA( hList, LB_ADDSTRING, 0, ( LPARAM )SymMod.ImageName );

    //
    // ����ܹ���ȡ�����Կ�ܵİ汾, ��ô���Կ���Ѿ�����
    // ����ֻ��ҪHook ��R3�ĺ����ʹ����豸�Ϳ���...
    //
    if ( lpDbgObjGetVersion( &StDichlorovs ) )
    {
        swprintf_s( SzTemp, SizeOf( SzTemp ),
                    _T( "���Կ�ܰ汾: %d.%d ��������:%S !\r\n" ),
                    StDichlorovs.ulMainVersion, StDichlorovs.ulChildVersion,
                    StDichlorovs.SzBuildTime  );

        AppendTextToEdit( hEdit, SzTemp );

        if ( StDichlorovs.ulMainVersion == MAIN_VERSION &&
                StDichlorovs.ulChildVersion == CHILD_VERSION )
        {

            if ( !g_bHookFlags )
            {
                //
                // ���豸.
                //
                if ( !lpDbgObjCreateDevice( _T( Device_Name ) ) )
                {
                    MessageBox( hWnd, _T( "�豸��ʧ��!" ),
                                g_SzTitle, MB_OK | MB_ICONWARNING );
                }
                else
                {
                    AppendTextToEdit(
                        GetDlgItem( hWnd, IDC_EDIT_LOG ), _T( "��������򿪳ɹ�!\r\n" ) );
                }

                if ( !HookDebugRoutine() )
                {
                    MessageBox( hWnd, _T( "��������Hookʧ��!" ),
                                g_SzTitle, MB_OK | MB_ICONWARNING );

                    lpDbgObjCloseHanle( _T( Device_Name ) );
                    return TRUE;
                }
                else
                {
                    g_bHookFlags = TRUE;
                    AppendTextToEdit(
                        GetDlgItem( hWnd, IDC_EDIT_LOG ), _T( "��������Hook�ɹ�!\r\n" ) );
                }
            }
            EnableWindow( GetDlgItem( hWnd, IDCANCEL ), TRUE );
            EnableWindow( GetDlgItem( hWnd, IDOK ), FALSE );
            return TRUE;
        }
        else
        {
            MessageBox( hWnd, _T( "�����汾�����, ����!" ),
                        _T( "Information" ), MB_OK | MB_ICONWARNING );

            EnableWindow( GetDlgItem( hWnd, IDCANCEL ), FALSE );
            EnableWindow( GetDlgItem( hWnd, IDOK ), FALSE );
            return TRUE;
        }
    }
//---------------------------------------------------------------------------
    do
    {
        //
        // ���CPU����, Ŀǰֻ֧��Intel
        //
        if ( Cpu_Intel != GetCpuType() )
        {
            AppendTextToEdit( hEdit, _T( "Ŀǰֻ֧��IntelCpu�����⻯!\r\n" ) );
            break;
        }

        //
        // ���Cpu�Ƿ���Կ������⻯
        //
        if ( !CheckForVirtualizationSupport() )
        {
            AppendTextToEdit( hEdit, _T( "���Cpu��֧�����⻯����!\r\n" ) );

            SendMessage( GetDlgItem( hWnd, IDC_EDIT_VT_SUPER ),
                         WM_SETTEXT, 0, ( LPARAM )_T( "CPU ��֧��VT" ) );
            break;
        }
        else
        {
            AppendTextToEdit( hEdit, _T( "Cpu֧�����⻯����!\r\n" ) );

            SendMessage( GetDlgItem( hWnd, IDC_EDIT_VT_SUPER ),
                         WM_SETTEXT, 0, ( LPARAM )_T( "CPU ֧��VT" ) );
        }

        bFlags = TRUE;
    }
    while ( 0 );

    if ( bFlags )
    {
        EnableWindow( GetDlgItem( hWnd, IDOK ), TRUE );
    }

    return TRUE;
}


HBRUSH
Main_OnCtlColor(
    HWND hwnd,
    HDC hdc,
    HWND hwndChild,
    int type )
{
    //
    // ������ǽ����ڵ���ɫС����
    //
    SetTextColor( hdc, 0 );
    SetBkColor( hdc, 0xffffe0 );
    return hBrush;
}



void Main_OnClose( HWND hWnd )
{
    EndDialog( hWnd, 0 );
}


/* ������������*/
VOID StartDebugEngine( HWND hWnd )
{
    BOOL bRet;
    wchar_t SzDriverPath[MAX_PATH] = {0};
    wchar_t SzTemp[512] = {0};
    DICHLORVOS_VERISON StDichlorovs = {0};

    //
    // �ж��Ƿ�����������
    //
    if ( lpDbgObjGetVersion( &StDichlorovs ) )
    {
        swprintf_s( SzTemp, SizeOf( SzTemp ), _T( "���Կ�ܰ汾:%d.%d ��������: %S!\r\n" ),
                    StDichlorovs.ulMainVersion, StDichlorovs.ulChildVersion,
                    StDichlorovs.SzBuildTime );

        AppendTextToEdit( GetDlgItem( hWnd, IDC_EDIT_LOG ), SzTemp );

        if ( StDichlorovs.ulMainVersion == MAIN_VERSION &&
                StDichlorovs.ulChildVersion == CHILD_VERSION )
        {
            AppendTextToEdit( GetDlgItem( hWnd, IDC_EDIT_LOG ), _T( "���������Ѿ�����!" ) );

            if ( !g_bHookFlags )
            {
                if ( !HookDebugRoutine() )
                {
                    MessageBox( hWnd, _T( "��������Hookʧ��!" ),
                                g_SzTitle, MB_OK | MB_ICONWARNING );
                    return;
                }
                else
                {
                    g_bHookFlags = TRUE;
                    AppendTextToEdit(
                        GetDlgItem( hWnd, IDC_EDIT_LOG ), _T( "��������Hook�ɹ�!\r\n" ) );
                }
            }

            EnableWindow( GetDlgItem( hWnd, IDOK ), FALSE );
            EnableWindow( GetDlgItem( hWnd, IDCANCEL ), TRUE );
            return;
        }
    }

    //
    // ö�ٷ���
    //
    bRet = DialogBoxParam( hDllInst,
                           MAKEINTRESOURCE( IDD_DIALOG_PROGRESS ),
                           hWnd, &SymbolsProc, 0 );

    if ( !bRet )
    {
        MessageBox( hWnd, _T( "����ö��ʧ��, ����!" ),
                    g_SzTitle, MB_OK | MB_ICONWARNING );
        return;
    }
    else
    {
        AppendTextToEdit(
            GetDlgItem( hWnd, IDC_EDIT_LOG ), _T( "����ö�����!\r\n" ) );
    }

    //
    // ��ʼ��, ��װ����.
    //
    _GetModuleFilePath( SzDriverPath, SizeOf( SzDriverPath ) );
    wcscat_s( SzDriverPath, SizeOf( SzDriverPath ), _T( Device_Name ) );
    wcscat_s( SzDriverPath, SizeOf( SzDriverPath ), _T( ".sys" ) );

    bRet = lpDbgObjInitialize( SzDriverPath, _T( Device_Name ) );
    if ( !bRet )
    {
        MessageBox( hWnd, _T( "������װʧ��!" ),
                    g_SzTitle, MB_OK | MB_ICONWARNING );
        return;

    }
    else
    {
        AppendTextToEdit(
            GetDlgItem( hWnd, IDC_EDIT_LOG ), _T( "�������سɹ�!\r\n" ) );
    }
//---------------------------------------------------------------------------
    //
    // ���BIOS�Ƿ�֧�ֿ������⻯����
    //
    if ( !lpDbgObjCheckBiosIsEnabled() )
    {
        AppendTextToEdit( GetDlgItem( hWnd, IDC_EDIT_LOG ),
                          _T( "BIOSû�п���VT֧��, ����BIOS�д�!\r\n" ) );

        SendMessage( GetDlgItem( hWnd, IDC_EDIT_BIOS_SUPER ),
                     WM_SETTEXT, 0, ( LPARAM )_T( "BIOSû�п���VT֧��" ) );

        lpDbgObjCloseHanle( _T( Device_Name ) );

        EnableWindow( GetDlgItem( hWnd, IDCANCEL ), FALSE );
        EnableWindow( GetDlgItem( hWnd, IDOK ), TRUE );

        g_bHookFlags = FALSE;

        return ;
    }
    else
    {
		AppendTextToEdit( GetDlgItem( hWnd, IDC_EDIT_LOG ),
			_T( "BIOS�Ѿ�����VT֧��!\r\n" ) );

        SendMessage( GetDlgItem( hWnd, IDC_EDIT_BIOS_SUPER ),
                     WM_SETTEXT, 0, ( LPARAM )_T( "BIOS�Ѿ�����VT֧��" ) );
    }
//---------------------------------------------------------------------------
    //
    // ���豸.
    //
    if ( !lpDbgObjCreateDevice( _T( Device_Name ) ) )
    {
        MessageBox( hWnd, _T( "�豸��ʧ��, ���Ƿ�����VT��������!" ),
                    g_SzTitle, MB_OK | MB_ICONWARNING );
		return;
    }
    else
    {
        AppendTextToEdit(
            GetDlgItem( hWnd, IDC_EDIT_LOG ), _T( "��������򿪳ɹ�!\r\n" ) );
    }
//---------------------------------------------------------------------------
    //
    // Hook R3��������
    //
    if ( !HookDebugRoutine() )
    {
        MessageBox( hWnd, _T( "��������Hookʧ��!" ),
                    g_SzTitle, MB_OK | MB_ICONWARNING );
        return;
    }
    else
    {
        g_bHookFlags = TRUE;
        AppendTextToEdit(
            GetDlgItem( hWnd, IDC_EDIT_LOG ), _T( "��������Hook�ɹ�!\r\n" ) );
    }
//---------------------------------------------------------------------------
    //
    // ��ӡ�汾
    //
    lpDbgObjGetVersion( &StDichlorovs );

    swprintf_s( SzTemp, SizeOf( SzTemp ), _T( "���Կ�ܰ汾:%d.%d ��������:%S \r\n" ),
                StDichlorovs.ulMainVersion, StDichlorovs.ulChildVersion,
                StDichlorovs.SzBuildTime );

    AppendTextToEdit( GetDlgItem( hWnd, IDC_EDIT_LOG ), SzTemp );

    AppendTextToEdit(  GetDlgItem( hWnd, IDC_EDIT_LOG ),
                       _T( "�����ڿ��Թرմ��ڲ����е�����!\r\n" ) );

    EnableWindow( GetDlgItem( hWnd, IDCANCEL ), TRUE );
    EnableWindow( GetDlgItem( hWnd, IDOK ), FALSE );
}

/* ֹͣ��������*/
VOID StopDebugEngine( HWND hWnd )
{

    UnHookDebugRoutine();

    if ( g_bHookFlags )
    {
        lpDbgObjCloseHanle( _T( Device_Name ) );

        EnableWindow( GetDlgItem( hWnd, IDCANCEL ), FALSE );
        EnableWindow( GetDlgItem( hWnd, IDOK ), TRUE );

        g_bHookFlags = FALSE;
    }

    AppendTextToEdit(  GetDlgItem( hWnd, IDC_EDIT_LOG ),
                       _T( "�رյ�������ɹ�!\r\n" ) );
}

void Main_OnCommand( HWND hWnd, int id, HWND hwndCtl, UINT codeNotify )
{

    if ( id == IDOK )
    {
        StartDebugEngine( hWnd );
    }
    else if ( id == IDCANCEL )
    {
        StopDebugEngine( hWnd );
    }
}

VOID _ExitProcess()
{
    if ( g_bHookFlags )
    {
        lpDbgObjCloseHanle( _T( Device_Name ) );

        g_bHookFlags = FALSE;
    }
}

BOOL
WINAPI
MainProc (
    HWND hWnd,
    UINT uMsg,
    WPARAM wParam,
    LPARAM lParam )
{

    switch( uMsg )
    {
        HANDLE_MSG( hWnd, WM_CTLCOLORDLG, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLORMSGBOX, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLORSTATIC, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLORSCROLLBAR, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLORLISTBOX, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLORBTN, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLOREDIT, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_INITDIALOG, Main_OnInitDialog );
        HANDLE_MSG( hWnd, WM_CLOSE, Main_OnClose );
        HANDLE_MSG( hWnd, WM_COMMAND, Main_OnCommand );
    default:
        return FALSE;
    }

    return TRUE;
}


/* ö�ٷ����߳�*/
DWORD __stdcall EnumSymbolsThread( LPVOID lpParameter )
{
    BOOL bRet;
    HWND hWnd = ( HWND )lpParameter;
    wchar_t SzSymbolsPath[MAX_PATH] = {0};

    //
    // ö��ϵͳģ�����
    //
    _GetModuleFilePath( SzSymbolsPath, SizeOf( SzSymbolsPath ) );
    wcscat_s( SzSymbolsPath, SizeOf( SzSymbolsPath ), _T( "\\Symbols" ) );

    bRet = lpDbgObjEnumSymbols( SzSymbolsPath );

    KillTimer( hWnd, 1000 );
    EndDialog( hWnd, bRet );

    return 0;
}



BOOL Symbols_OnInitDialog( HWND hWnd, HWND hwndFocus, LPARAM lParam )
{
    HANDLE hThread;
    DWORD dwThreadId;
    HWND hProgress;
    PBRANGE StRange;


    hProgress = GetDlgItem( hWnd, IDC_PROGRESS );

    SendMessage( hProgress, PBM_SETRANGE, 0, ( LPARAM ) MAKELPARAM ( 0, 10 ) );

    SendMessage( hProgress, PBM_GETRANGE, ( WPARAM )FALSE, ( LPARAM )&StRange );

	SetWindowText( GetDlgItem( hWnd, IDC_EDIT1 ), _T( "ʱ��̫��, ˵����ʱ��, ���´򿪳���!" ) );

    SetTimer( hWnd, 1000, 500, NULL );

    hThread = CreateThread( NULL, 0, &EnumSymbolsThread,
                            ( PVOID )hWnd, 0, &dwThreadId );

    if ( hThread )
    {
        CloseHandle( hThread );
    }
    else
    {
        assert( 1 );
    }

    return TRUE;
}

void SymbolsProc_OnTimer( HWND hWnd, UINT id )
{
    HWND hProgress;
    ULONG ulPos;

    hProgress = GetDlgItem( hWnd, IDC_PROGRESS );

    ulPos = SendMessage( hProgress, PBM_GETPOS, ( WPARAM )0, ( LPARAM )0 );

    if ( ulPos >= 10 )
    {
        SendMessage( hProgress, PBM_SETPOS, 0, 0 );
    }
    else
    {
        SendMessage( hProgress, PBM_SETPOS, ulPos + 2, 0 );
    }
}

BOOL
WINAPI
SymbolsProc (
    HWND hWnd,
    UINT uMsg,
    WPARAM wParam,
    LPARAM lParam )
{

    switch( uMsg )
    {
        HANDLE_MSG( hWnd, WM_CTLCOLORDLG, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLORMSGBOX, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLORSTATIC, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLORSCROLLBAR, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLORLISTBOX, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLORBTN, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_CTLCOLOREDIT, Main_OnCtlColor );
        HANDLE_MSG( hWnd, WM_INITDIALOG, Symbols_OnInitDialog );
        HANDLE_MSG( hWnd, WM_TIMER, SymbolsProc_OnTimer );
    default:
        return FALSE;
    }
    return TRUE;
}

/* ���ز������*/
extc
int
_export
cdecl
ODBG_Plugindata( char* shortname )
{
    strcpy_s( shortname, 32, Plugin_Name );

    return PLUGIN_VERSION;
}


/* �����ʼ���ص�*/
extc int _export
cdecl
ODBG_Plugininit(
    int ollydbgversion,
    HWND hw,
    ulong *features )
{

    //
    // �汾�Ƿ���������Ҫ��.
    //
    if ( ollydbgversion < PLUGIN_VERSION )
    {
        return -1;
    }

    //
    // ����Ƿ���64λ
    //
    if ( IsWow64() )
    {
        MessageBox( hw, _T( "�����޷�������x64ϵͳ��!" ),
                    _T( Plugin_Name ), MB_OK | MB_ICONWARNING );
        return -1;
    }

    //
    // ����OD���ھ��
    //
    hWndOllyDbg = hw;

    //
    // ��ӡ������־
    //
    Addtolist( 0, 0, "%s v%d.%02d", Plugin_Name, MAIN_VERSION, CHILD_VERSION );
    Addtolist( 0, -1, "  ����    :Joen    Email:Joen@JoenChen.com" );
    Addtolist( 0, -1, "  �������: " __DATE__ ", " __TIME__ );

    return 0;
}


/* ���Ӳ˵� VAL_REFERENCES */
extc
int _export
cdecl
ODBG_Pluginmenu(
    int origin,
    char data[4096],
    void *item )
{
    if ( origin == PM_MAIN )
    {
        //
        // �����ڲ˵��Ĳ�����Ʋ˵�������
        //
        strcpy_s( data, 4096, "0 �������Կ��...\tAlt+Q|1 ���� Joen" );
        return 1;
    }
    return 0;
}


/* ��ݲ˵�����*/
extc
int _export
cdecl
ODBG_Pluginshortcut(
    int origin,
    int ctrl,
    int alt,
    int shift,
    int key,
    void *item )
{

    if ( ctrl == 0 && alt == 1 && shift == 0 && key == 'Q' )
    {
        DialogBoxParam( hDllInst, MAKEINTRESOURCE( IDD_DIALOG1 ),
                        hWndOllyDbg, &MainProc, 0 );
        return 1;
    }
    return 0;
}

/* �˵����� */
extc
void _export
cdecl
ODBG_Pluginaction(
    int origin,
    int action,
    void *item )
{

    if ( origin == PM_MAIN && 0 == action  )
    {

        DialogBoxParam( hDllInst, MAKEINTRESOURCE( IDD_DIALOG1 ),
                        hWndOllyDbg, &MainProc, 0 );
    }
    else if ( origin == PM_MAIN && 1 == action )
    {
        MessageBox( 0, _T( "Dichlorvos �����Կ�� By Joen" ), _T( Plugin_Name ), MB_OK );
    }
    return ;
}


BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch( ul_reason_for_call )
    {
    case DLL_PROCESS_ATTACH:
        hDllInst = hModule;
        break;
    case DLL_PROCESS_DETACH:
		_ExitProcess();
        break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
        break;
    }

    return TRUE;
}

