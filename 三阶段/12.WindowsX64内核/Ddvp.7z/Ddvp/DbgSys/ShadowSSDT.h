#pragma once

#include <windef.h>


typedef HWND( *PNtUserFindWindowEx )(
									 IN HWND hwndParent,
									 IN HWND hwndChild,
									 IN PUNICODE_STRING pstrClassName,
									 IN PUNICODE_STRING pstrWindowName,
									 DWORD dwType );

typedef HWND( *PNtUserGetForegroundWindow)( VOID);
typedef HWND (*PNtUserWindowFromPoint)(LONG X, LONG Y);

typedef NTSTATUS (*PNtUserBuildHwndList)( IN HDESK hdesk, IN HWND hwndNext, IN BOOL fEnumChildren, IN DWORD idThread, IN UINT cHwndMax, OUT HWND *phwndFirst, OUT PUINT pcHwndNeeded);

HWND _NtUserFindWindowEx( IN HWND hwndParent, IN HWND hwndChild, IN PUNICODE_STRING pstrClassName, IN PUNICODE_STRING pstrWindowName, DWORD dwType );
HWND _NtUserGetForegroundWindow( VOID);
NTSTATUS _NtUserBuildHwndList( IN HDESK hdesk, IN HWND hwndNext, IN BOOL fEnumChildren, IN DWORD idThread, IN UINT cHwndMax, OUT HWND *phwndFirst, OUT PUINT pcHwndNeeded);
HWND _NtUserWindowFromPoint(LONG X, LONG Y);