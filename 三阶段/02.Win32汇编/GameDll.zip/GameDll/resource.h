﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 GameDll.rc 使用
//
#define BTN_AUTOPLANT                   1004
#define BTN_NEXTLEVEL                   1005
#define GameHelperBTN_OPENPICKUP        1006
#define BTN_CLOSEPPICKUP                1007
#define DLG_GAME                        1007
#define IDC_BUTTON1                     1008
#define BTN_SUNSHINE                    1009
#define ID_32771                        32771
#define ID_32773                        32773
#define ID_32774                        32774
#define MEN_UNINSERT                    32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1009
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
