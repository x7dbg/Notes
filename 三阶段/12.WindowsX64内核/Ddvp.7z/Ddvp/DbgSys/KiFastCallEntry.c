//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 *
 * ����ļ���Hook KiFastCallEntry����
 */
//===========================================================================
#include <ntddk.h>
#include "defines.h"
#include "ExtDef.h"
#include "WinBaseEx.h"
#include "IoControlCode.h"
#include "Assembly.h"
#include "SysMisc.h"
#include "Version.h"
#include "KiFastCallEntry.h"
#include "ReloadKernel.h"
#include "DbgItem.h"
#include "DbgkUtil.h"
#include "DbgItem.h"
#include "HookDbgk.h"
#include "ShadowSSDT.h"


extern KMUTEX				g_GlobleMutex;
extern SYMBOLS_INFO			g_StSymbolsInfo;
extern DBG_RELOAD_KERNEL	g_StReloadKernel;
//---------------------------------------------------------------------------

PVOID	OldKiFastCallEntry;
PVOID	lpPspUserThreadStartup;
PVOID	KiFastCallEntryMovEspEbp;
PBYTE	lpNewKiFastCallEntry;
PVOID   lpNewDbgBreakPoint;

ULONG	ulNtTerminateProcessIndex;
ULONG	ulNtQueryInformationProcess;
ULONG   ulNtCreateThreadIndex;
ULONG	ulNtTerminateThreadIndex;
ULONG	ulNtMapViewOfSectionIndex;
ULONG	ulNtUnMapViewOfSectionIndex;
ULONG	ulNtRaiseExceptionIndex;
ULONG	ulNtSetContextThreadIndex;
ULONG   ulNtGetContextThreadIndex;
ULONG	ulNtReadVirtualMemoryIndex;
ULONG	ulNtOpenProcessIndex;
ULONG	ulNtCloseIndex;

ULONG	ulNtUserFindWindowExIndex;
ULONG	ulNtUserGetForegroundWindowIndex;
ULONG	ulNtUserBuildHwndListIndex;
ULONG	ulNtUserWindowFromPointIndex;
//---------------------------------------------------------------------------

//
// �ж��Ƿ���������ҪHook�ĺ���. �����޸�DestAddressĿ�꺯����ַ.
// ����DestAddress��Ҫ��.
//

BOOL __stdcall DbgObjForwardRoutine( ULONG Index, PVOID* DestAddress )
{
    NTSTATUS Status;
    DBG_ITEM* DbgItemDebugger = NULL;
    DBG_ITEM* DbgItemDebugged = NULL;
    PEPROCESS Eprocess = NULL;

    if( ExGetPreviousMode() == KernelMode )
    {
        return FALSE;
    }

    Eprocess = IoGetCurrentProcess();

    DbgItemDebugger = DbgItemFindItem( Eprocess, NULL );
    DbgItemDebugged = DbgItemFindItem( NULL, Eprocess );

//---------------------------------------------------------------------------
    // Shadow SSDT Hook
    if( Index == ulNtUserFindWindowExIndex )
    {
        // ���н��̵�NtUserFindWindowEx
        *DestAddress = &_NtUserFindWindowEx;
        Status = STATUS_SUCCESS;

    }
    else if( Index == ulNtUserGetForegroundWindowIndex )
    {
        // ���н��̵�NtUserGetForegroundWindow
        *DestAddress = &_NtUserGetForegroundWindow;
        Status = STATUS_SUCCESS;

    }
    else if( Index == ulNtUserBuildHwndListIndex )
    {
        // ���н��̵�NtUserBuildHwndListIndex
        *DestAddress = &_NtUserGetForegroundWindow;
        Status = STATUS_SUCCESS;

    }
    else if( Index == ulNtUserWindowFromPointIndex )
    {
        // ���н��̵�NtUserWindowFromPoint
        *DestAddress = &_NtUserWindowFromPoint;
        Status = STATUS_SUCCESS;
    }

//---------------------------------------------------------------------------
    if( Index == ulNtSetContextThreadIndex )
    {
        // ���н��̵�NtSetContextThread
        *DestAddress = &NewNtSetContextThread;
        Status = STATUS_SUCCESS;
    }
    else if( Index == ulNtGetContextThreadIndex )
    {
        // ���н��̵�NtGetContextThread
        *DestAddress = &NewNtGetContextThread;
        Status = STATUS_SUCCESS;
    }
//     else if( Index == ulNtReadVirtualMemoryIndex )
//     {
//         // ���н��̵�NtReadVirtualMemory
//         *DestAddress = &NewNtReadVirtualMemory;
//         Status = STATUS_SUCCESS;
//     }
//     else if( Index == ulNtOpenProcessIndex )
//     {
//         // ���н��̵�NtOpenProcess
//         *DestAddress = &NewNtOpenProcess;
//         Status = STATUS_SUCCESS;
//     }
    else if( Index == ulNtTerminateProcessIndex )
    {
        // ���Խ��̵�NtTerminateProcess
        *DestAddress = &NewNtTerminateProcess;
        Status = STATUS_SUCCESS;

        // KdPrint( ( "Ddvp-> Eprcess %p ���� NtTerminateProcess\n", Eprocess ) );
    }
    else if( DbgItemDebugged && Index == ulNtQueryInformationProcess )
    {
        // �����Խ��̵�NtQueryInformationProcess����
        *DestAddress = &NewNtQueryInformationProcess;
        Status = STATUS_SUCCESS;

        //KdPrint( ( "Ddvp-> Eprcess %p ���� NtQueryInformationProcess\n", Eprocess ) );
    }
    else if( DbgItemDebugger && Index == ulNtCreateThreadIndex )
    {
        // ���Խ��̵�NtCreateThread
        *DestAddress = *( PVOID* )( ( ULONG_PTR )g_StReloadKernel.NewSsdt->ntoskrnl.ServiceTable +
                                    GetNtCreateThreadIndex() * 4 );
        Status = STATUS_SUCCESS;

        KdPrint( ( "Ddvp-> Eprocess %p Debugger Invoke NtCreateThread \n",
                   DbgItemDebugger->Debugger ) );

    }
	else if( DbgItemDebugger && Index == ulNtCloseIndex )
	{
		// ���Խ��̵�NtClose
		*DestAddress = *( PVOID* )( ( ULONG_PTR )g_StReloadKernel.NewSsdt->ntoskrnl.ServiceTable +
			GetNtCloseIndex() * 4 );
		Status = STATUS_SUCCESS;

// 		KdPrint( ( "Ddvp-> Eprocess %p Debugger Invoke NtClose \n",
// 			DbgItemDebugger->Debugger ) );

	}
    else if( DbgItemDebugged && Index == ulNtCreateThreadIndex )
    {
        // �����Խ��̵�NtCreateThread
        *DestAddress = *( PVOID* )( ( ULONG_PTR )g_StReloadKernel.NewSsdt->ntoskrnl.ServiceTable +
                                    GetNtCreateThreadIndex() * 4 );
        Status = STATUS_SUCCESS;

        //KdPrint( ( "Ddvp-> Cr3 %p Invoke NtCreateThread \n", DbgItemDebugged ) );

    }
    else if( DbgItemDebugged && Index == ulNtTerminateThreadIndex )
    {
        // �����Խ��̵�NtTerminateThread
        *DestAddress = *( PVOID* )( ( ULONG_PTR )g_StReloadKernel.NewSsdt->ntoskrnl.ServiceTable +
                                    GetNtTerminateThreadIndex() * 4 );
        Status = STATUS_SUCCESS;

        //KdPrint( ( "Ddvp-> Cr3 %p Invoke NtTerminateThread \n", DbgItemDebugged ) );
    }
    else if( DbgItemDebugged && Index == ulNtMapViewOfSectionIndex )
    {
        // �����Խ��̵�NtMapViewOfSection
        *DestAddress = *( PVOID* )( ( ULONG_PTR )g_StReloadKernel.NewSsdt->ntoskrnl.ServiceTable +
                                    GetNtMapViewOfSectionIndex() * 4 );

        Status = STATUS_SUCCESS;

        //KdPrint( ( "Ddvp-> Cr3 %p Invoke NtMapViewOfSectionIndex \n", DbgItemDebugged ) );
    }
    else if( DbgItemDebugged && Index == ulNtUnMapViewOfSectionIndex )
    {
        // �����Խ��̵�NtMapViewOfSection
        *DestAddress = *( PVOID* )( ( ULONG_PTR )g_StReloadKernel.NewSsdt->ntoskrnl.ServiceTable +
                                    GetNtUnMapViewOfSectionIndex() * 4 );

        Status = STATUS_SUCCESS;

        // KdPrint( ( "Ddvp-> Cr3 %p Invoke NtUnMapViewOfSection \n", DbgItemDebugged ) );

    }
    else if( DbgItemDebugged && Index == ulNtRaiseExceptionIndex )
    {
        // �����Խ��̵�NtRaiseException
        *DestAddress = *( PVOID* )( ( ULONG_PTR )g_StReloadKernel.NewSsdt->ntoskrnl.ServiceTable +
                                    GetNtRaiseExceptionIndex() * 4 );

        Status = STATUS_SUCCESS;

        //KdPrint( ( "Ddvp-> Cr3 %p Invoke NtRaiseException \n", DbgItemDebugged ) );
    }
    else
    {
        Status = STATUS_UNSUCCESSFUL;
    }

    if( DbgItemDebugger )
    {
        DbgItemDeRefItem( DbgItemDebugger );
    }

    if( DbgItemDebugged )
    {
        DbgItemDeRefItem( DbgItemDebugged );
    }

    if( !NT_SUCCESS( Status ) )
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

// ��cr3����
BOOL __stdcall DbgObjForwardCr3( ULONG_PTR Cr3, ULONG Index )
{
    PDBG_ITEM DbgItemDebuger = NULL;
    PDBG_ITEM DbgItemDebuged = NULL;
    BOOL bRet = FALSE;

    // ����Shadow SSDT Hook
    if( Index == ulNtUserFindWindowExIndex + 0x1000 ||
            Index == ulNtUserGetForegroundWindowIndex + 0x1000 ||
            Index == ulNtUserBuildHwndListIndex + 0x1000 ||
            Index == ulNtUserWindowFromPointIndex + 0x1000 )
    {
        return TRUE;
    }

    //
    // ���Խ���
    //
    DbgItemDebuger = DbgItemCr3FindItem( Cr3, 0 );
    DbgItemDebuged = DbgItemCr3FindItem( 0, Cr3 );

    if( Index == ulNtSetContextThreadIndex )
    {
        // ���н��̵�NtSetContextThread
        bRet = TRUE;

    }
//     else if( Index == ulNtReadVirtualMemoryIndex )
//     {
//         // ���н��̵�NtReadVirtualMemory
//         bRet = TRUE;
//     }
//     else if( Index == ulNtOpenProcessIndex )
//     {
//         // ���н��̵�NtOpenProcess
//         bRet = TRUE;
//     }
    else if( Index == ulNtGetContextThreadIndex )
    {
        // ���н��̵�NtGetContextThread
        bRet = TRUE;
    }
    else if( Index == ulNtTerminateProcessIndex )
    {
        // ���н��̵�NtTerminateProcess
        bRet = TRUE;

    }
    else if( DbgItemDebuger && Index == ulNtCreateThreadIndex )
    {
        // ���Խ��̵���NtCreateThread
        bRet = TRUE;
    }
	else if( DbgItemDebuger && Index == ulNtCloseIndex )
	{
		// ���Խ��̵���NtClose
		bRet = TRUE;
	}
	else if( DbgItemDebuger && Index == ulNtCloseIndex )
	{
		// ���Խ��̵���NtClose
		bRet = TRUE;
	}
    else if( DbgItemDebuged && Index == ulNtCreateThreadIndex )
    {
        // �����Խ��̵���NtCreateThread
        bRet = TRUE;
    }
    else if( DbgItemDebuged && Index == ulNtTerminateThreadIndex )
    {
        // �����Խ��̵�NtTerminateThread
        bRet = TRUE;
    }
    else if( DbgItemDebuged && Index == ulNtMapViewOfSectionIndex )
    {
        // �����Խ��̵�NtMapViewOfSection
        bRet = TRUE;
    }
    else if( DbgItemDebuged && Index == ulNtUnMapViewOfSectionIndex )
    {
        // �����Խ��̵�NtUnMapViewOfSection
        bRet = TRUE;
    }
    else if( DbgItemDebuged && Index == ulNtRaiseExceptionIndex )
    {
        // �����Խ��̵�NtRaiseException
        bRet = TRUE;
    }

    if( DbgItemDebuger )
    {
        DbgItemDeRefItem( DbgItemDebuger );
    }

    if( DbgItemDebuged )
    {
        DbgItemDeRefItem( DbgItemDebuged );
    }

    return bRet;
}

//
// �����µ�LdrInitializeThunk������ַ, �Ϳ���DbgBreakPoint�ĵ�ַ
//
NTSTATUS HookLdrInitializeThunk( PVOID* lpDbgBreadkPoint )
{
    ULONG i;
    PBYTE NtDllBase;
    ULONG ulAddress;
    ULONG_PTR Temp;
    PBYTE lpTemp;
    PSYSTEM_DLL lpSystemDll;
    BYTE byBuffer[15] = {0};
    ULONG_PTR NewLdrInitializeThunk;
    BYTE BufferDbgBreakPoint[15] = {0};
    BYTE BufferDbgBreakPoint2[] = {0xcc, 0x50, 0xe8, 0x00, 0x00, 0x00, 0x00, 0xa8, 0x47, 0xd7, 0x8d };


    lpSystemDll = ( PSYSTEM_DLL )( ( ULONG_PTR )g_StSymbolsInfo.lpPspSystemDll +
                                   ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase );

    if( lpSystemDll->LoaderInitRoutine != g_StSymbolsInfo.lpLdrInitializeThunk )
    {
        //
        // �ҵ�����ԭ����д��DbgkBreakPoint�ĵ�ַ
        //
        for( i = 0, lpTemp = g_StSymbolsInfo.lpDbgBreakPoint; i <= 0x10000; i++ )
        {

            if( lpTemp[i] == 0xa8 && lpTemp[i + 1] == 0x47 &&
                    lpTemp[i + 2] == 0xd7 && lpTemp[i + 3] == 0x8d )
            {
                KdPrint( ( "Ddvp-> NewLdrInitializeThunk Address Change :%p !\n",
                           lpSystemDll->LoaderInitRoutine ) );

                *lpDbgBreadkPoint = &lpTemp[i] - 7;

                KdPrint( ( "Ddvp-> NewDbgBreakPoint Address :%p !\n",
                           *lpDbgBreadkPoint ) );

                return STATUS_SUCCESS;
            }
        }
    }

    //
    // ��LdrInitializeThunk����, �ҵ�һ����15BYTE�Ŀյط�..
    //
    for( i = 0, ulAddress = 0, NtDllBase = g_StSymbolsInfo.lpLdrInitializeThunk; i <= 0x10000; i++ )
    {
        if( sizeof( byBuffer ) == RtlCompareMemory( &NtDllBase[i], byBuffer, sizeof( byBuffer ) ) )
        {
            ulAddress = i;
            break;
        }
    }

    if( !ulAddress )
    {
        KdPrint( ( "Ddvp-> NewLdrInitializeThunk Address Scan Error!\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

    NewLdrInitializeThunk = ( ( ULONG_PTR )g_StSymbolsInfo.lpLdrInitializeThunk ) + ulAddress;

    /*
    7c93b057 8bff            mov     edi,edi
    7c93b059 55              push    ebp
    7c93b05a 8bec            mov     ebp,esp
    7c93b05c 803d0cb2997c00  cmp     byte ptr [ntdll!SecurityCookieInitialized (7c99b20c)],0
    7c93b063 0f8484760000    je      ntdll!LdrpInitialize+0xe (7c9426ed)
    7c93b069 5d              pop     ebp
    7c93b06a e907ffffff      jmp     ntdll!_LdrpInitialize (7c93af76)
    */
    RtlCopyBytes( byBuffer, g_StSymbolsInfo.lpLdrInitializeThunk, sizeof( byBuffer ) );

    SafeCopyMemory( ( PVOID )NewLdrInitializeThunk, byBuffer, sizeof( byBuffer ) );

    for( i = 0; i <= 0x50; i++ )
    {
        if( ( ( PUCHAR )NewLdrInitializeThunk )[i] == 0xe9 )
        {

            //
            // ����������ת��ַ
            //
            Temp = *( PULONG_PTR )( ( ULONG_PTR )g_StSymbolsInfo.lpLdrInitializeThunk + i + 1 );
            Temp += ( ULONG_PTR )g_StSymbolsInfo.lpLdrInitializeThunk + i;
            Temp += 5;

            //
            // ����E9��תĿ�ĵص�ַ
            //
            _Jump( ( PVOID )( NewLdrInitializeThunk + i ), ( PVOID )Temp, 0 );

            lpSystemDll->LoaderInitRoutine = ( PKNORMAL_ROUTINE ) NewLdrInitializeThunk;

            KdPrint( ( "Ddvp-> NewLdrInitializeThunk %p!\n", NewLdrInitializeThunk ) );
            break;
        }
    }
//---------------------------------------------------------------------------
    //
    // ɨ��һ����еĵط���DbgBreakPoint
    //
    for( i = 0, lpTemp = g_StSymbolsInfo.lpDbgBreakPoint; i <= 0x10000; i++ )
    {
        if( sizeof( BufferDbgBreakPoint ) ==
                RtlCompareMemory( &lpTemp[i], BufferDbgBreakPoint, sizeof( BufferDbgBreakPoint ) ) )
        {
            *lpDbgBreadkPoint = &lpTemp[i];
            lpNewDbgBreakPoint = *lpDbgBreadkPoint;

            SafeCopyMemory( *lpDbgBreadkPoint, BufferDbgBreakPoint2, sizeof( BufferDbgBreakPoint2 ) );

            _Call( ( PBYTE )*lpDbgBreadkPoint + 2, g_StSymbolsInfo.lpExitThread, 0 );

            KdPrint( ( "Ddvp-> NewDbgBreadkPoint Address %p!\n", *lpDbgBreadkPoint ) );
            return STATUS_SUCCESS;
        }
    }

    return STATUS_UNSUCCESSFUL;
}

NTSTATUS InitKiFastCallEntry()
{
    int i;
    BYTE* p = NULL;
    BYTE byBuffer[0x20] = {0};

    if( !g_StSymbolsInfo.lpKiFastCallEntry )
    {
        return STATUS_UNSUCCESSFUL;
    }

//---------------------------------------------------------------------------
    ulNtCreateThreadIndex		= GetNtCreateThreadIndex();
    ulNtTerminateProcessIndex   = GetNtTerminateProcessIndex();
    ulNtTerminateThreadIndex    = GetNtTerminateThreadIndex();
    ulNtQueryInformationProcess = GetNtQueryInformationProcessIndex();
    ulNtMapViewOfSectionIndex   = GetNtMapViewOfSectionIndex();
    ulNtUnMapViewOfSectionIndex = GetNtUnMapViewOfSectionIndex();
    ulNtRaiseExceptionIndex     = GetNtRaiseExceptionIndex();
    ulNtSetContextThreadIndex   = GetNtSetContextThreadIndex();
    ulNtGetContextThreadIndex   = GetNtGetContextThreadIndex();
    ulNtReadVirtualMemoryIndex	= GetNtReadVirtualMemoryIndex();
    ulNtOpenProcessIndex        = GetNtOpenProcessIndex();
	ulNtCloseIndex              = GetNtCloseIndex();
//---------------------------------------------------------------------------
    ulNtUserFindWindowExIndex   = GetNtUserFindWindowExIndex();
    ulNtUserGetForegroundWindowIndex = GetNtUserGetForegroundWindowIndex();
    ulNtUserBuildHwndListIndex   = GetNtUserBuildHwndListIndex();
    ulNtUserWindowFromPointIndex = GetNtUserWindowFromPointIndex();

    lpPspUserThreadStartup = ( PVOID )( ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase +
                                        ( ULONG_PTR )g_StSymbolsInfo.lpPspUserThreadStartup );

    OldKiFastCallEntry   = ( PVOID )GetKiFastCallEntry();

    lpNewKiFastCallEntry = ( BYTE* )( ( ULONG )g_StSymbolsInfo.lpKiFastCallEntry +
                                      ( ULONG )g_StReloadKernel.NewKernelBase );

    //
    // ��KiFastCallEntry ��ɨ��������Ҫ�ҹ���λ�� ����call ebx
    //
    // 8053d62e 0f83a8010000    jae     nt!KiSystemCallExit2+0x9f (8053d7dc)
    // 8053d634 f3a5            rep		movs dword ptr es:[edi],dword ptr [esi]
    // 8053d636 ffd3            call    ebx
    // 8053d638 8be5            mov     esp,ebp
    //
    __try
    {
        for( i = 0, p = lpNewKiFastCallEntry; ; i++, p++ )
        {
            if( *p == 0xff && *( p + 1 ) == 0xd3 )
            {
                break;
            }
            else if( i > 0x1000 )
            {
                KdPrint( ( "Ddvp-> Hook KiFastCallEntry ������������������\n" ) );
                return STATUS_UNSUCCESSFUL;
            }
        }

    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {
        KdPrint( ( "Ddvp-> Hook KiFastCallEntry �����������쳣\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

    // 8053d636 ffd3            call    ebx {nt!NtClose (805b1c3a)}
    // 8053d638 8be5            mov     esp,ebp
    // 8053d63a 8b0d24f1dfff    mov     ecx,dword ptr ds:[0FFDFF124h]
    KiFastCallEntryMovEspEbp = p - ( BYTE* )g_StReloadKernel.NewKernelBase +
                               ( BYTE* )g_StReloadKernel.OriginalKernelBase + 2;

    //
    // ��ס���������ں˵� call ebx
    //
    _Jump( p, NewKiFastCallEntryCallEbx, 5 );

    KdPrint( ( "Ddvp-> call ebx: %p , mov esp, ebp: %p \n",
               p, KiFastCallEntryMovEspEbp ) );

    return STATUS_SUCCESS;
}

//---------------------------------------------------------------------------
//
// Hookϵͳ��KiFastCallEntry����,�ҵİ취��Hook MSR 176�ĵ�ַ
//
NTSTATUS DbgObjHookKiFastCallEntry()
{
    int i;
    BYTE* p = NULL;
    KIRQL OldIrql;
    NTSTATUS Status;
    ULONG_PTR ulKiFastCallEntry;
    ULONG_PTR ulTempKiFastCallEntry;
    PVOID lpKiDispatchException = NULL;


    KdPrint( ( "Ddvp-> Call DbgObjHookKiFastCallEntry \n" ) );

    if( !g_StSymbolsInfo.lpKiFastCallEntry )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // Hook ϵͳ�� KiDispatchException����
    //
    lpKiDispatchException = ( PVOID )( ( ULONG )g_StReloadKernel.OriginalKernelBase +
                                       ( ULONG )g_StSymbolsInfo.lpKiDispatchException );
    Status = HookKiDispatchException( lpKiDispatchException );
    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> Hook HookKiDispatchException ʧ�� \n" ) );
        return Status;
    }
//---------------------------------------------------------------------------
    //
    // ���ÿ�������е�KiFastCallEntry�Ƿ�һ��
    //
    ulKiFastCallEntry = GetKiFastCallEntry();

    for( i = 0; i < KeNumberProcessors; i++ )
    {
        KeSetSystemAffinityThread( ( KAFFINITY )( 1 << i ) );
        OldIrql = KeRaiseIrqlToDpcLevel();

        ulTempKiFastCallEntry = GetKiFastCallEntry();

        KdPrint( ( "Ddvp-> Cpu Number %d KiFastCallEntry Address :%p\n",
                   i, ulTempKiFastCallEntry ) );

        if( ulKiFastCallEntry != ulTempKiFastCallEntry )
        {
            KdPrint( ( "Ddvp-> Cpu Number %d KiFastCallEntry :%p  not equal %p\n",
                       i, ulTempKiFastCallEntry, ulKiFastCallEntry ) );

            KeLowerIrql( OldIrql );

            return STATUS_UNSUCCESSFUL;
        }

        KeLowerIrql( OldIrql );
    }

//---------------------------------------------------------------------------
    //
    // �ȴ�������, ��֤ÿ��ʱ��ֻ��һ��Hook KiFastCallEntry����
    //
    KeWaitForSingleObject( &g_GlobleMutex, Executive, KernelMode, FALSE, NULL );

    //
    // ��ÿһ��Process����ִ��һ��Hook KiFastCallEntry����,
    // ��˵Ҫ��KeQueryActiveProcessors(), ������Ͳ�����.
    //
    for( i = 0; i < KeNumberProcessors; i++ )
    {

        KeSetSystemAffinityThread( ( KAFFINITY )( 1 << i ) );

        OldIrql = KeRaiseIrqlToDpcLevel();

        //
        // ��סϵͳ��sysenter��ַ, �����������ص��ں���
        //
        HookKiFastCallEntry( &OldKiFastCallEntry, NewKiFastCallEntry );

        KeLowerIrql( OldIrql );

        KdPrint( ( "Ddvp-> Cpu Index:%d OldKiFastCallEntry: %p , NewKiFastCallEntry: %p \n",
                   i, OldKiFastCallEntry, NewKiFastCallEntry ) );
    }

    KeReleaseMutex( &g_GlobleMutex, FALSE );

    return STATUS_SUCCESS;
}

NTSTATUS DbgUnHookKiFastCallEntry()
{
    int i;
    PVOID Temp;
    KIRQL OldIrql;
    ULONG_PTR ulKiFastCallEntry;
    ULONG_PTR ulTempKiFastCallEntry;

    if( !OldKiFastCallEntry )
    {
        return STATUS_UNSUCCESSFUL;
    }

    UnHookKiDispatchException();
//---------------------------------------------------------------------------
    //
    // ���ÿ�������е�KiFastCallEntry�Ƿ�һ��
    //
    ulKiFastCallEntry = GetKiFastCallEntry();

    for( i = 0; i < KeNumberProcessors; i++ )
    {
        KeSetSystemAffinityThread( ( KAFFINITY )( 1 << i ) );
        OldIrql = KeRaiseIrqlToDpcLevel();

        ulTempKiFastCallEntry = GetKiFastCallEntry();

        KdPrint( ( "Ddvp-> Cpu Number %d KiFastCallEntry Address :%p !\n",
                   i, ulTempKiFastCallEntry ) );

        if( ulKiFastCallEntry != ulTempKiFastCallEntry )
        {
            KdPrint( ( "Ddvp-> Cpu Number %d KiFastCallEntry :%p  not equal %p !\n",
                       i, ulTempKiFastCallEntry, ulKiFastCallEntry ) );

            KeLowerIrql( OldIrql );

            return STATUS_UNSUCCESSFUL;
        }

        KeLowerIrql( OldIrql );
    }

//---------------------------------------------------------------------------
    //
    // �ȴ�������, ��֤ÿ��ʱ��ֻ��һ��Hook KiFastCallEntry����
    //
    KeWaitForSingleObject( &g_GlobleMutex, Executive, KernelMode, FALSE, NULL );

    //
    // ��ÿһ��Process����ִ��һ��Hook KiFastCallEntry����,
    // ��˵Ҫ��KeQueryActiveProcessors(), ������Ͳ�����.
    //
    for( i = 0; i < KeNumberProcessors; i++ )
    {
        KeSetSystemAffinityThread( ( KAFFINITY )( 1 << i ) );
        OldIrql = KeRaiseIrqlToDpcLevel();

        //
        // ��ԭsysenter��ַ.
        //
        HookKiFastCallEntry( &Temp, OldKiFastCallEntry );

        KeLowerIrql( OldIrql );

        KdPrint( ( "Ddvp-> Cpu Index: %d OldKiFastCallEntry: %p , NewKiFastCallEntry: %p \n",
                   i, Temp, OldKiFastCallEntry ) );
    }

    KeReleaseMutex( &g_GlobleMutex, FALSE );

    return STATUS_SUCCESS;
}