//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Dichlorvos.rc
//
#define IDD_DIALOG1                     101
#define IDI_ICON1                       103
#define IDD_DIALOG_PROGRESS             104
#define IDC_EDIT_BIOS_SUPER             1002
#define IDC_EDIT_VT_SUPER               1003
#define IDC_PROGRESS                    1003
#define IDC_EDIT_LOG                    1004
#define IDC_LIST1                       1005
#define IDC_LIST                        1005
#define IDC_EDIT1                       1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
