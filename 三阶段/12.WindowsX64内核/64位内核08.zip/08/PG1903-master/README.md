# PG1903

Disable PatchGuard in real time for Win10 1903.

Based on setting context pages NX method.

# References

Shark, https://github.com/9176324/Shark

DisableWin10PatchguardPoc, https://github.com/killvxk/DisableWin10PatchguardPoc

PgResarch, https://github.com/tandasat/PgResarch
