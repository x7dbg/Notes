#include "CWinApp.h"

IMPLEMENT_DYNAMIC(CWinApp, CObject);

void CWinApp::OnFileNew()
{
  if (m_pDocManager != NULL)
    m_pDocManager->OnFileNew();
}

CWinApp::CWinApp()
{
}

void CWinApp::AddDocTemplate(CDocTemplate* pTemplate)
{
  if (m_pDocManager == NULL)
    m_pDocManager = new CDocManager;
  m_pDocManager->AddDocTemplate(pTemplate);
}