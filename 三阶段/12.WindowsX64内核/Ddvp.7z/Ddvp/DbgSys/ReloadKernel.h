#pragma once

#define RVATOVA(base,offset)(((ULONG)(base)+(ULONG)(offset)))

typedef struct _LOADED_KERNEL_INFO
{
    PVOID OriginalKernelBase;
    PVOID NewKernelBase;
    PSERVICE_DESCRIPTOR_TABLE NewSsdt;
    PKEVENT NotifyEvent;
    LONG LoadedStatus;
} DBG_RELOAD_KERNEL, *PDBG_RELOAD_KERNEL;



NTSTATUS DbgObjOverLoadKernel( PDBG_RELOAD_KERNEL pStLoaderInfo );



typedef struct _LOADED_MOD_INFO
{
    ULONG ulCount;
    SYSTEM_MODULE_INFORMATION StSysModuleInfo[];
} LOADED_MOD_INFO;

typedef NTSTATUS ( NTAPI* _QuerySystemInformation )( IN SYSTEM_INFORMATION_CLASS SystemInformationClass,
        IN OUT PVOID SystemInformation,	IN ULONG SystemInformationLength, OUT PULONG ReturnLength OPTIONAL );

PVOID
RtlImageDirectoryEntryToData (
							  IN PVOID Base,
							  IN BOOLEAN MappedAsImage,
							  IN USHORT DirectoryEntry,
							  OUT PULONG Size
							  );


BOOLEAN InitFilterSystem ();
BOOLEAN VerifyCaller ( ULONG ulPid );
BOOLEAN VerifyCallIndex ( ULONG ulIndex );
void AddProcVerify ( ULONG ulPid );
void DeleteProcVerify ( ULONG ulPid );
void UninitVerify ();
void UnloadKernel();
NTSTATUS DbgObjFreeKernel(PDBG_RELOAD_KERNEL pStLoaderInfo);
NTSTATUS DbgObjInitGlobalVariable( PDBG_RELOAD_KERNEL lpReloadKernel, PSYMBOLS_INFO lpSymbols );
#define _min(a,b) (a<=b? a:b)


