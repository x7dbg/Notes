#pragma once
#include "CWinApp.h"
class CTestApp :
    public CWinApp
{
    DECLARE_DYNAMIC(CTestApp);
public:
  virtual BOOL InitInstance();
  virtual int ExitInstance();
};

