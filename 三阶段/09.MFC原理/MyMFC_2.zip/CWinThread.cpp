#include "CWinThread.h"

IMPLEMENT_DYNAMIC(CWinThread, CCmdTarget);

BOOL CWinThread::InitInstance()
{
  //ע�ᴰ����

  //��������

  //��ʾ���´���
  return FALSE;
}

int CWinThread::ExitInstance()
{
  return 0;
}

int CWinThread::Run()
{
  BOOL bRet;
  MSG msg;
  while ((bRet = GetMessage(&msg, NULL, 0, 0)) != 0)
  {
    if (bRet == -1)
    {
      break;
    }
    else
    {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
  }
  return msg.wParam;
}
