// -*- mode: C++; tab-width: 4; indent-tabs-mode: nil -*- (for GNU Emacs)
//
// $Id: packet.h,v 1.1 2003/05/14 16:33:34 dev Exp $

#ifndef _packet_h_
#define _packet_h_

NTSTATUS	init_packet(void);
void		free_packet(void);

#endif
