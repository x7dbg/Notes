#pragma once

#include <ntifs.h>
#include <Ntddk.h>
#include <stddef.h>


NTSTATUS DriverEntry(__in struct _DRIVER_OBJECT* DriverObject,
  __in PUNICODE_STRING  RegistryPath);


VOID Unload(__in struct _DRIVER_OBJECT* DriverObject);



#pragma alloc_text( "INIT", DriverEntry)
#pragma alloc_text( "PAGE", Unload)