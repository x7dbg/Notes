#pragma once

#include <ntifs.h>
//�����ļ�
ULONG TraverseDocument(PVOID pOutputBuffer, ULONG ulBufferSize, PVOID pDirectoryName);


//��ȡ�ļ�����
HANDLE GetFileHandle(PUNICODE_STRING pStrFile);



BOOLEAN GetDirectoryInfo(HANDLE hFile, ULONG ulLen, PFILE_BOTH_DIR_INFORMATION pDirectory, ULONG ulFileLen, PFILE_BOTH_DIR_INFORMATION pFirstFile);


BOOLEAN GetNextFileInfo(PFILE_BOTH_DIR_INFORMATION pDirList, PFILE_BOTH_DIR_INFORMATION pFileInfo, LONG* nOffset);


//��ȡ�ļ���С
LONGLONG GetFileSize(PUNICODE_STRING pFileStr);



ULONG ThroughRegistry(PVOID pOutputBuffer, ULONG ulBufferSize, PVOID pRegisterName);