#include "CFrameWnd.h"
#include "CView.h"



LRESULT MainWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

  if (uMsg == WM_DESTROY) {
    ::PostQuitMessage(0);
  }

  return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}

BOOL CFrameWnd::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle,
  CWnd* pParentWnd, CCreateContext* pContext)
{

  const char* lpszClass = "MainWindowClass";
  const char* lpszTitle = "51asm";
  RECT rectDefault = {0, 0, CW_USEDEFAULT, CW_USEDEFAULT};
  WNDCLASS wc;

  // Register the main window class. 
  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = (WNDPROC)MainWndProc;
  wc.cbClsExtra = 0;
  wc.cbWndExtra = 0;
  wc.hInstance = ::GetModuleHandle(NULL);
  wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
  wc.lpszMenuName = NULL;
  wc.lpszClassName = lpszClass;

  if (!RegisterClass(&wc))
    return FALSE;

  if (!Create(lpszClass, lpszTitle, dwDefaultStyle, rectDefault,
    pParentWnd, MAKEINTRESOURCE(nIDResource), 0L, pContext))
  {
    return FALSE;   
  }

  return TRUE;
}

BOOL CFrameWnd::Create(LPCTSTR lpszClassName,
  LPCTSTR lpszWindowName,
  DWORD dwStyle,
  const RECT& rect,
  CWnd* pParentWnd,
  LPCTSTR lpszMenuName,
  DWORD dwExStyle,
  CCreateContext* pContext)
{
  HMENU hMenu = NULL;
  if (lpszMenuName != NULL)
  {
    if ((hMenu = ::LoadMenu(::GetModuleHandle(NULL), lpszMenuName)) == NULL)
    {
      return FALSE;
    }
  }
 
  if (!CreateEx(dwExStyle, lpszClassName, lpszWindowName, dwStyle,
    rect.left, rect.top, 
    rect.right - rect.left, 
    rect.bottom - rect.top,
    pParentWnd->GetSafeHwnd(),
    hMenu, 
    (LPVOID)pContext))
  {
    if (hMenu != NULL)
      ::DestroyMenu(hMenu);
    return FALSE;
  }

  return TRUE;
}
