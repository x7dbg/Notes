﻿// CGameDlg.cpp: 实现文件
//

#include "pch.h"
#include "GameDll.h"
#include "CGameDlg.h"
#include "afxdialogex.h"


// CGameDlg 对话框

IMPLEMENT_DYNAMIC(CGameDlg, CDialogEx)

CGameDlg::CGameDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(DLG_GAME, pParent)
{

}

CGameDlg::~CGameDlg()
{
}

void CGameDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CGameDlg, CDialogEx)
	ON_BN_CLICKED(GameHelperBTN_OPENPICKUP, &CGameDlg::OnBnClickedOpenpickup)
	ON_BN_CLICKED(BTN_CLOSEPPICKUP, &CGameDlg::OnBnClickedCloseppickup)
	ON_BN_CLICKED(BTN_AUTOPLANT, &CGameDlg::OnBnClickedAutoplant)
	ON_BN_CLICKED(BTN_NEXTLEVEL, &CGameDlg::OnBnClickedNextlevel)
    ON_BN_CLICKED(IDC_BUTTON1, &CGameDlg::OnBnClickedButton1)
    ON_BN_CLICKED(BTN_SUNSHINE, &CGameDlg::OnBnClickedSunshine)
END_MESSAGE_MAP()


// CGameDlg 消息处理程序

//自动捡阳光
void CGameDlg::OnBnClickedOpenpickup()
{
	// TODO: 在此添加控件通知处理程序代码
    DWORD dwPid = 0;
    HWND hGame1 = ::FindWindow(NULL, "植物大战僵尸中文版");
    GetWindowThreadProcessId(hGame1, &dwPid);
    HANDLE hGame = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);

    BYTE btBuf = 0xeb;
    BOOL bRet = WriteProcessMemory(hGame, (LPVOID)0x0043158f, &btBuf, sizeof(btBuf), NULL);
}

//关闭自动捡阳光
void CGameDlg::OnBnClickedCloseppickup()
{
	// TODO: 在此添加控件通知处理程序代码
    DWORD dwPid = 0;
    HWND hGame1 = ::FindWindow(NULL, "植物大战僵尸中文版");
    GetWindowThreadProcessId(hGame1, &dwPid);
    HANDLE hGame = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);

    BYTE btBuf = 0x75;
    BOOL bRet = WriteProcessMemory(hGame, (LPVOID)0x0043158f, &btBuf, sizeof(btBuf), NULL);
}

//自动种植物
void CGameDlg::OnBnClickedAutoplant()
{
	// TODO: 在此添加控件通知处理程序代码
    DWORD pAddr = 0x0040D120;
    //DWORD pThis = GetBaseAddress();
  
    int ntype = 0;
    
    for (int i = 0; i < 9; i++)
    {
        if (i <= 1)
        {
            ntype = 18;
        }
        else  if (i == 2)
        {
            ntype = 40;
        }
        else  if (i == 3)
        {
            ntype = 22;
        }
        else  if (i == 4)
        {
            ntype = 5;
        }
        else  if (i <= 5)
        {
            //ntype = 29;
            ntype = 43;
        }
        else  if (i <= 6)
        {
            ntype = 42;
        }
        else  if (i <= 7)
        {
            ntype = 23;
        }
        else
        {
            ntype = 46;
        }


        for (int j = 0; j < 6; j++)
        {

            __asm {

                pushad
                push - 1
                push ntype//植物类型
                mov eax, j//Y坐标
                push i//x坐标
                mov ebx, dword ptr ds : [0x06a9ec0]
                mov ebx, dword ptr ds : [ebx + 0x768]
                push ebx
                call pAddr //call的地址  dwz = 0x040d120;
                popad

            }
        }
    }
    

}

int GetBaseAddress() {

    HMODULE hMoudle = GetModuleHandle(NULL);

    int dAddr = (int)hMoudle;
    int dwpAddre = dAddr + 0x2A9EC0;

    int dwBaseAddre = *((int*)dwpAddre);
    int dwAddre = *((int*)(dwBaseAddre+ 0x768));
    return dwAddre;
}

//下一关
void CGameDlg::OnBnClickedNextlevel()
{
	// TODO: 在此添加控件通知处理程序代码

    DWORD dwPid = 0;
    HWND hGame1 = ::FindWindow(NULL, "植物大战僵尸中文版");
    GetWindowThreadProcessId(hGame1, &dwPid);
    HANDLE hGame = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);
    int pAddr = GetBaseAddress();
    pAddr = pAddr + 0x5550;

#if 0

    CString  Str;
    Str.Format("%08x", pAddr);
    MessageBox(NULL, Str, MB_OK);

#endif // 0

    DWORD dwLevel = *((int*)pAddr);
    dwLevel += 1;
    BOOL bRet = WriteProcessMemory(hGame, (LPVOID)pAddr, &dwLevel, sizeof(dwLevel), NULL);
}

//直接过关
void CGameDlg::OnBnClickedButton1()
{
    // TODO: 在此添加控件通知处理程序代码
    DWORD dwPid = 0;
    HWND hGame1 = ::FindWindow(NULL, "植物大战僵尸中文版");
    GetWindowThreadProcessId(hGame1, &dwPid);
    HANDLE hGame = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);

    int pAddr = GetBaseAddress();
    pAddr = pAddr + 0x55FC;
    BYTE btBuf = 0x01;
    BOOL bRet = WriteProcessMemory(hGame, (LPVOID)pAddr, &btBuf, sizeof(btBuf), NULL);
}

//改阳光
void CGameDlg::OnBnClickedSunshine()
{
    // TODO: 在此添加控件通知处理程序代码
    DWORD dwPid = 0;
    HWND hGame1 = ::FindWindow(NULL, "植物大战僵尸中文版");
    GetWindowThreadProcessId(hGame1, &dwPid);
    HANDLE hGame = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);
    int pAddr = GetBaseAddress();
    pAddr = pAddr + 0x5560;
    DWORD dwLevel = 9000;
    BOOL bRet = WriteProcessMemory(hGame, (LPVOID)pAddr, &dwLevel, sizeof(dwLevel), NULL);
}
