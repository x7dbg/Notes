#include "CDocument.h"

IMPLEMENT_DYNAMIC(CDocument, CCmdTarget)