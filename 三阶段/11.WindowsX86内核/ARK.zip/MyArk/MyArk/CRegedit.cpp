﻿// CRegedit.cpp: 实现文件
//

#include "pch.h"
#include "MyArk.h"
#include "afxdialogex.h"
#include "CRegedit.h"
#include "Data.h"

// CRegedit 对话框

IMPLEMENT_DYNAMIC(CRegedit, CDialogEx)

CRegedit::CRegedit(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_REGEDIT, pParent)
{

}

CRegedit::~CRegedit()
{
}

void CRegedit::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, TREE_REG, m_Tree);
	DDX_Control(pDX, LST_REG, m_ListCtrl);
}


BEGIN_MESSAGE_MAP(CRegedit, CDialogEx)
//	ON_NOTIFY(TVN_SELCHANGED, TREE_REG, &CRegedit::OnSelchangedTreeReg)
ON_NOTIFY(NM_CLICK, TREE_REG, &CRegedit::OnClickTreeReg)
END_MESSAGE_MAP()



void CRegedit::OnClickTreeReg(NMHDR* pNMHDR, LRESULT* pResult)
{
	DWORD dwChild = 0;
	tagREGISTER Temp;
	DWORD dwSize = 0;
	WCHAR wRegPath[256] = { 0 };

	HTREEITEM hItem = m_Tree.GetSelectedItem();
	// 判断是否有值
	if (!hItem)
		return;
	HTREEITEM hChild = m_Tree.GetNextItem(hItem, TVGN_CHILD);
	// 判断是否有子节点
	if (hChild)
		dwChild = 1;
	CString strRegPath = (wchar_t*)m_Tree.GetItemData(hItem);
	if (strRegPath.IsEmpty())
		return;
	m_ListCtrl.DeleteAllItems();
	
	// 获取所需空间
	wcscpy_s(wRegPath, strRegPath.GetLength() * 2, strRegPath.GetBuffer());
	int len = wcslen(wRegPath) * 2 + 2;
	DeviceIoControl(g_hDevice, IOCTL_REGEDIT, wRegPath, len, &Temp, sizeof(tagREGISTER), &dwSize, NULL);
	tagREGISTER *pReg = new tagREGISTER[dwSize]();
	DeviceIoControl(g_hDevice, IOCTL_REGEDIT, wRegPath, len, pReg, dwSize, &dwSize, NULL);
	int nCount = dwSize / sizeof(tagREGISTER);
	int nIndex = 0;
	for (int i = 0; i < nCount; i++)
	{
		// 判断类型
		if (pReg[i].m_uType == 0 && !dwChild) // 子项
		{
			CString strTemp = pReg[i].m_wzKeyName;
			CString strRegFullPath;
			strRegFullPath.Format(L"%s\\%s", strRegPath, strTemp); 
			wchar_t* sz = _wcsdup(strRegFullPath.GetString());		 //申请空间拷贝字符串
			m_Tree.SetItemData(m_Tree.InsertItem(strTemp, ICON_FOLDER, ICON_FOLDER,hItem), (DWORD_PTR)sz);
		}
		else if (pReg[i].m_uType == 1) // 键
		{
			CString strValue;
			CString strVauleName = pReg[i].m_wzValueName;
			m_ListCtrl.InsertItem(nIndex, _T(""),ICON_FILE);
			m_ListCtrl.SetItemText(nIndex, 0, strVauleName);
			if (pReg[i].m_dwValueType == REG_SZ)
			{
				strVauleName = L"REG_SZ";
				strValue.Format(L"%s", pReg[i].m_uValue);
			}
			else if (pReg[i].m_dwValueType == REG_MULTI_SZ)
			{
				strVauleName = L"REG_MULTI_SZ";
				strValue.Format(L"%s", pReg[i].m_uValue);
			}
			else if (pReg[i].m_dwValueType == REG_DWORD)
			{
				strVauleName = L"REG_DWORD";
				strValue.Format(L"0x%08x", pReg[i].m_uValue);
			}
			else if (pReg[i].m_dwValueType == REG_BINARY)
			{
				strVauleName = L"REG_BINARY";
				int nSize = strlen((char*)pReg[i].m_uValue);
				strValue = L"";
				CString temp;
				for (int j = 0; j < nSize; ++j)
				{
					strValue += L" ";
					temp.Format(L"%02X", (unsigned char)pReg[i].m_uValue[j]);
					strValue += temp;
				}
			}
			m_ListCtrl.SetItemText(nIndex, 1, strVauleName);		
			m_ListCtrl.SetItemText(nIndex, 2, strValue);
			nIndex++;
		}
	}
	*pResult = 0;
}


BOOL CRegedit::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	
	HICON hIconComputer;
	HICON hIconFolder;//文件夹图标
	HICON hIconDisk;
	HICON hIconFile;
	hIconComputer = theApp.LoadIcon(IDI_COMPUTER);
	hIconFolder = theApp.LoadIcon(IDI_EXP);//文件夹图标
	hIconDisk = theApp.LoadIcon(IDI_DISK);
	hIconFile = theApp.LoadIcon(IDI_FILE);
	m_imgIcon.Create(24, 24, ILC_COLOR24 | ILC_MASK, 1, 1); //创建图像
	m_imgIcon.Add(hIconComputer); //添加计算机icon
	m_imgIcon.Add(hIconFolder); //添加文件夹icon
	m_imgIcon.Add(hIconDisk);
	m_imgIcon.Add(hIconFile);

	m_Tree.SetImageList(&m_imgIcon, LVSIL_NORMAL); //设置根节点图标
	m_ListCtrl.SetImageList(&m_imgIcon, LVSIL_SMALL);


	m_hItemHead = m_Tree.InsertItem(L"计算机", ICON_COMPUTER, ICON_COMPUTER);
	LONG lStyle;
	lStyle = GetWindowLong(m_ListCtrl.m_hWnd, GWL_STYLE);//获取当前窗口style
	lStyle &= ~LVS_TYPEMASK; //清除显示方式位
	lStyle |= LVS_REPORT; //设置style
	SetWindowLong(m_ListCtrl.m_hWnd, GWL_STYLE, lStyle);//设置style
	DWORD dwStyle = m_ListCtrl.GetExtendedStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;//选中某行使整行高亮
	dwStyle |= LVS_EX_GRIDLINES;//网格线
	dwStyle |= LVS_EX_DOUBLEBUFFER | LVS_EX_SUBITEMIMAGES;
	m_ListCtrl.SetExtendedStyle(dwStyle);
	CRect cRect;
	m_ListCtrl.GetClientRect(cRect);
	m_ListCtrl.InsertColumn(0, L"名称", 0, cRect.Width() / 3);
	m_ListCtrl.InsertColumn(1, L"类型", 0, cRect.Width() / 3);
	m_ListCtrl.InsertColumn(2, L"数据", 0, cRect.Width() / 3);
	WCHAR Buffer[256] = {};
	memset(Buffer, 0, 256);
	CString Root = L"\\Registry";
	memcpy(Buffer, Root, Root.GetLength() * 2);
	DWORD dwSize = 0;
	DeviceIoControl(g_hDevice, IOCTL_REGEDIT, Buffer, wcslen(Root.GetBuffer()) * 2 + 2, NULL, NULL, &dwSize, NULL);
	int nCount = dwSize / sizeof(tagREGISTER);
	tagREGISTER *pReg = new tagREGISTER[nCount]();
	DeviceIoControl(g_hDevice, IOCTL_REGEDIT, Buffer, wcslen(Root.GetBuffer()) * 2 + 2, pReg, dwSize, &dwSize, NULL);
	for (int i = 0; i < nCount; ++i)
	{
		// 根据TYPE来给空间分配
		if (pReg[i].m_uType == 0) // 子项
		{
			CString buff = pReg[i].m_wzKeyName;
			CString Path;
			if (buff == L"MACHINE")
			{
				Path = L"\\Registry\\Machine";
				buff = L"HKEY_LOCAL_MACHINE";
			}
			else if (buff == L"USER")
			{
				Path = L"\\Registry\\user";
				buff = L"HKEY_USERS";
			}
            
            //其他有问题
			//将所有注册表项设置到树中
			HTREEITEM hItem = m_Tree.InsertItem(buff,ICON_FOLDER,ICON_FOLDER, m_hItemHead);
			wchar_t* pBuff = _wcsdup(Path.GetBuffer());
			m_Tree.SetItemData(hItem, (DWORD_PTR)pBuff);
		}
	}


	return TRUE;  // return TRUE unless you set the focus to a control
	// 异常: OCX 属性页应返回 FALSE
}
