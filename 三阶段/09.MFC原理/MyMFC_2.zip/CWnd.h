#pragma once
#include "CCmdTarget.h"


class CDocument;
class CDocTemplate;
class CFrameWnd;

struct CCreateContext   
{
  CDocument* m_pCurrentDoc;
  CDocTemplate* m_pNewDocTemplate;
  //CView* m_pLastView;
  CFrameWnd* m_pCurrentFrame;

};

class CWnd :
    public CCmdTarget
{
    DECLARE_DYNAMIC(CWnd);
public:
  virtual BOOL DestroyWindow();
  BOOL ShowWindow(int nCmdShow);
  void UpdateWindow();
  HWND GetSafeHwnd() const;
  BOOL CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName,
    LPCTSTR lpszWindowName, DWORD dwStyle,
    int x, int y, int nWidth, int nHeight,
    HWND hWndParent, HMENU nIDorHMenu, LPVOID lpParam);
public:
  HWND m_hWnd;
};

