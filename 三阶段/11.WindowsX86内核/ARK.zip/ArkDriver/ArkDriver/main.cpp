#include "main.h"


//����ж�غ���
VOID Unload(__in struct _DRIVER_OBJECT* DriverObject)
{
    ////DbgPrint("[De1ta] Unload WDK! DriverObject:%p \n", DriverObject);


    //ɾ����������
    UNICODE_STRING DosDeviceName;
    RtlInitUnicodeString(&DosDeviceName, SYMBOL_NAME);
    NTSTATUS ntRet = IoDeleteSymbolicLink(&DosDeviceName);
    if (!NT_SUCCESS(ntRet))
    {
        //DbgPrint("[De1ta] IoDeleteSymbolicLink Error status:%d \n", ntRet);
        return;
    }


    //ɾ���豸
    if (DriverObject->DeviceObject != nullptr)
    {
        IoDeleteDevice(DriverObject->DeviceObject);
        //DbgPrint("[De1ta] IoDeleteDevice \n");
    }
   
}



//1.������ں���
NTSTATUS DriverEntry(__in struct _DRIVER_OBJECT* DriverObject, __in PUNICODE_STRING  RegistryPath)
{
    //DbgPrint("[De1ta] hello WDK! DriverObject:%p RegistryPath:%wZ \n", DriverObject, RegistryPath);
    UNREFERENCED_PARAMETER(RegistryPath);

    //2.�����豸
    UNICODE_STRING ustrDevName;
    RtlInitUnicodeString(&ustrDevName,DEVICE_NAME);
    PDEVICE_OBJECT pDevObj = nullptr;//�豸����
    NTSTATUS ntRet = IoCreateDevice(DriverObject,               //��������
                                    0,                          //��չ��С
                                    &ustrDevName,               //�豸����
                                    FILE_DEVICE_UNKNOWN,        //�豸����
                                    FILE_DEVICE_SECURE_OPEN,    //�豸����
                                    FALSE,                      //�Ƿ��ռ
                                    &pDevObj);                  //�����豸����

    if (!NT_SUCCESS(ntRet))
    {
        //�����豸ʧ��
        //DbgPrint("[De1ta] IoCreateDevice Error Status:%d\n", ntRet);
        return ntRet;
    }
    ////DbgPrint("[De1ta] IoCreateDevice Success Status:%d\n", ntRet);
    
    
    //�����豸�Ļ�����ͨѶ��ʽ
    pDevObj->Flags |= DO_DIRECT_IO;   //������ͨѶ��ʽ


    UNICODE_STRING DosDeviceName;
    RtlInitUnicodeString(&DosDeviceName, SYMBOL_NAME);
    ntRet = IoCreateSymbolicLink(&DosDeviceName, &ustrDevName); //�󶨷��ź��豸
    if (!NT_SUCCESS(ntRet)) {
        ////DbgPrint("[De1ta] IoCreateSymbolicLink Error Status:%d\n", ntRet);
        //ɾ���豸
        if (pDevObj != nullptr)
        {
            IoDeleteDevice(pDevObj);
            ////DbgPrint("[De1ta] IoDeleteDevice \n");
        }
        return ntRet;
    }

    //3.��ǲ(�ص�)����
    DriverObject->MajorFunction[IRP_MJ_CREATE] = &DispatchCreate;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = &DispatchClose;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = &DispatchControl;


    //4.����ж��
    DriverObject->DriverUnload = Unload;

    return STATUS_SUCCESS;
}



NTSTATUS DispatchCreate(_In_ struct _DEVICE_OBJECT* DeviceObject, _Inout_ struct _IRP* Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject); //��ʱûʹ�ô˲���
    //DbgPrint("[De1ta] DispatchCreate\n");

    //DbgPrint("[De1ta] PID:%d \n", PsGetCurrentProcessId());


    //�������
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0; //�ɹ��������ֽ���
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}
NTSTATUS DispatchClose(_In_ struct _DEVICE_OBJECT* DeviceObject, _Inout_ struct _IRP* Irp)
{
    UNREFERENCED_PARAMETER(DeviceObject); //��ʱûʹ�ô˲���
    //DbgPrint("[De1ta] DispatchClose\n");

    //�������
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0; //�ɹ��������ֽ���
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}
NTSTATUS DispatchControl(_In_ struct _DEVICE_OBJECT* DeviceObject, _Inout_ struct _IRP* Irp)
{
    //DbgPrint("[De1ta] DispatchControl\n");

    UNREFERENCED_PARAMETER(DeviceObject); //��ʱûʹ�ô˲���
    //��ȡ��ǰIRP��ջ
    PIO_STACK_LOCATION pIrpStack = IoGetCurrentIrpStackLocation(Irp);
    ULONG nIoControlCode = pIrpStack->Parameters.DeviceIoControl.IoControlCode;

    //��ȡ�û��Ļ�����
    PVOID pInputBuffer = Irp->AssociatedIrp.SystemBuffer;
    PVOID pOutputBuffer = NULL;
    if (Irp->MdlAddress && METHOD_FROM_CTL_CODE(nIoControlCode) & METHOD_OUT_DIRECT)
        pOutputBuffer = MmGetSystemAddressForMdlSafe(Irp->MdlAddress, 0);
    //��ȡ��С
    ULONG ulBuffSize = pIrpStack->Parameters.DeviceIoControl.OutputBufferLength;

    ULONG ulRetSize = 0;

    switch (nIoControlCode)
    {
     // �����ļ�
    case IOCTL_FILE:
    {
        //DbgPrint("[De1ta] IOCTL_FILE\n");
        ulRetSize = TraverseDocument(pOutputBuffer, ulBuffSize, pInputBuffer);
        break;
    }
    // ����ע���
    case IOCTL_REGEDIT:
    {
        //DbgPrint("[De1ta] IOCTL_REGEDIT\n");
        ulRetSize = ThroughRegistry(pOutputBuffer, ulBuffSize, pInputBuffer);
        break;
    }
    default:
        break;
    }

    //�������
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = ulRetSize; //�ɹ��������ֽ���
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}