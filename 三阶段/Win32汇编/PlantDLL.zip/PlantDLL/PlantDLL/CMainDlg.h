﻿#pragma once
#include "CImgBtn.h"

// CMainDlg 对话框

class CMainDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CMainDlg)

public:
	CMainDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CMainDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	CImgBtn m_Btn1;
	CImgBtn m_Btn2;
	CImgBtn m_Btn3;
	CImgBtn m_Btn4;
	CImgBtn m_Btn5;
	CImgBtn m_Btn6;
};
