#ifndef DBGOBJ_MISC
#define DBGOBJ_MISC

#define PAGE_SIZE	4096

int __cdecl DbgObjPrint( char* _Format, ... );

#undef  KdPrint
#ifdef _DEBUG
#define KdPrint( _x_ ) DbgObjPrint _x_
#else
#define KdPrint( _x_ )
#endif

typedef struct _INITIAL_TEB {
	PVOID StackBase;
	PVOID StackLimit;
	PVOID StackCommit;
	PVOID StackCommitMax;
	PVOID StackReserved;
} INITIAL_TEB, *PINITIAL_TEB;

NTSTATUS
NtFlushInstructionCache (
						 __in HANDLE ProcessHandle,
						 __in_opt PVOID BaseAddress,
						 __in SIZE_T Length
						 );

typedef  NTSTATUS ( NTAPI*_QuerySystemInformation )( IN enum _SYSTEMINFOCLASS SystemInformationClass,
													IN OUT PVOID SystemInformation,
													IN ULONG SystemInformationLength,
													OUT PULONG ReturnLength OPTIONAL  );

BOOL DbgObjCall( int number, PVOID lpInBuffer, ULONG ulInBufferSize, PVOID lpOutBuffer, ULONG ulOutBufferSize );
BOOL DbgObjEnumSymbols( );
BOOL DbgObjInstallService( const wchar_t *SzPath, const wchar_t *SzName );
void EnableDebugPrivilegies();
BOOL DbgObjUnInstallService( wchar_t* SzServiceName );
PLARGE_INTEGER WINAPI BaseFormatTimeOut(OUT PLARGE_INTEGER Timeout, IN DWORD dwMilliseconds);
VOID WINAPI BaseSetLastNTError(IN NTSTATUS Status);
NTSTATUS NTAPI DbgObjUiConvertStateChangeStructure( IN LPNT_DEBUG_EVENT NtDbgEvt, IN OUT LPDEBUG_EVENT DbgEvt );
void EnableLoadDriverPrivilegies();
BOOL CALLBACK EnumSymCallBack( PSYMBOL_INFO pSymInfo, ULONG SymbolSize, PVOID UserContext );
NTSTATUS NTAPI DbgUiIssueRemoteBreakin(IN HANDLE Process);
HANDLE WINAPI ProcessIdToHandle( IN DWORD dwProcessId );

NTSTATUS
NTAPI
RtlCreateUserThread( IN HANDLE ProcessHandle,
					IN PSECURITY_DESCRIPTOR SecurityDescriptor OPTIONAL,
					IN BOOLEAN CreateSuspended,
					IN ULONG StackZeroBits OPTIONAL,
					IN SIZE_T StackReserve OPTIONAL,
					IN SIZE_T StackCommit OPTIONAL,
					IN PTHREAD_START_ROUTINE StartAddress,
					IN PVOID Parameter OPTIONAL,
					OUT PHANDLE ThreadHandle OPTIONAL,
					OUT PCLIENT_ID ClientId OPTIONAL );





#endif