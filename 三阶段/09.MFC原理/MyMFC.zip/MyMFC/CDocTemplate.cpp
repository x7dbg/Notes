#include "CDocTemplate.h"

CDocument* CDocTemplate::OpenDocumentFile(LPCTSTR lpszPathName, BOOL bMakeVisible)
{
    return nullptr;
}
