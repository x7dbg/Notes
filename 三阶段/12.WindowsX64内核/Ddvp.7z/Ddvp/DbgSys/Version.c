//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * д�������Ǻܶ�;���ϵͳ�汾�йصĶ���.
 * ����ļ���ȡ����Ͱ汾�йص���Ϣ
 */
//===========================================================================
#include <ntddk.h>
#include "Version.h"

WIN_VER_DETAIL GetWindowsVersion()
{
    static WIN_VER_DETAIL WinVersion;
    UNICODE_STRING ustrFuncName = { 0 };
    RTL_OSVERSIONINFOEXW osverinfo = { sizeof( osverinfo ) };
    PFN_RtlGetVersion pfnRtlGetVersion = NULL;

    if( WinVersion )
    {
        return WinVersion;
    }

    RtlInitUnicodeString( &ustrFuncName, L"RtlGetVersion" );
    pfnRtlGetVersion = MmGetSystemRoutineAddress( &ustrFuncName );

    if( pfnRtlGetVersion )
    {
        pfnRtlGetVersion( ( PRTL_OSVERSIONINFOW )&osverinfo );
    }
    else
    {
        PsGetVersion( &osverinfo.dwMajorVersion, &osverinfo.dwMinorVersion, &osverinfo.dwBuildNumber, NULL );
    }

    // 	KdPrint(("[xxxxxxxx] OSVersion NT %d.%d:%d sp%d.%d\n",
    // 		osverinfo.dwMajorVersion, osverinfo.dwMinorVersion, osverinfo.dwBuildNumber,
    // 		osverinfo.wServicePackMajor, osverinfo.wServicePackMinor));

    if( osverinfo.dwMajorVersion == 5 && osverinfo.dwMinorVersion == 0 )
    {
        WinVersion = WINDOWS_VERSION_2K;
    }
    else if( osverinfo.dwMajorVersion == 5 && osverinfo.dwMinorVersion == 1 )
    {
        WinVersion = WINDOWS_VERSION_XP;
    }
    else if( osverinfo.dwMajorVersion == 5 && osverinfo.dwMinorVersion == 2 )
    {
        if( osverinfo.wServicePackMajor == 0 )
        {
            WinVersion = WINDOWS_VERSION_2K3;
        }
        else
        {
            WinVersion = WINDOWS_VERSION_2K3_SP1_SP2;
        }
    }
    else if( osverinfo.dwMajorVersion == 6 && osverinfo.dwMinorVersion == 0 )
    {
        WinVersion = WINDOWS_VERSION_2K3_SP1_SP2;
    }
    else if( osverinfo.dwMajorVersion == 6 && osverinfo.dwMinorVersion == 1 )
    {
        WinVersion = WINDOWS_VERSION_7;
    }

    return WinVersion;
}

PVOID GetEprocessSectionObject( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( *( ULONG_PTR* )( ( ( char* )p ) + 0x138 ) );
    }

    return NULL;
}

PVOID GetEprocessCr3( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( *( ULONG_PTR* )( ( ( char* )p ) + 0x18 ) );
    }

    return NULL;
}


PVOID GetEprocessSectionBaseAddress( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( *( ULONG_PTR* )( ( ( char* )p ) + 0x13c ) );
    }

    return NULL;
}

PVOID GetEProcessPeb( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( *( ULONG_PTR* )( ( ( char* )p ) + 0x1B0 ) );
    }

    return NULL;
}

PVOID GetEProcessVAD( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( *( ULONG_PTR* )( ( ( char* )p ) + 0x11c ) );
    }

    return NULL;
}

PVOID GetPebLdr( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( *( ULONG_PTR* )( ( ( char* )p ) + 0x00c ) );
    }

    return NULL;
}

PVOID GetEprocessPcbPointer( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )p;
    }

    return NULL;
}

PVOID GetEprocessActiveProcessLinks( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( char* )p + 0x88;
    }

    return NULL;
}

PVOID GetActiveProcessLinksEprocess( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( char* )p - 0x88;
    }

    return NULL;
}

PVOID GetEprocessNamePointer( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( ( ( char* )p ) + 0x174 );
    }
    return NULL;
}



PVOID GetEprocessObjectTable( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( *( ULONG_PTR* )( ( ( char* )p ) + 0xc4 ) );
    }
    return NULL;
}

PVOID GetEprocessUniqueProcessId( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( *( ULONG_PTR* )( ( ( char* )p ) + 0x84 ) );
    }
    return NULL;
}


ULONG GetNtTerminateProcessIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	257;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;

}

ULONG GetNtRaiseExceptionIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	181;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;

}


ULONG GetNtTerminateThreadIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	258;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;
}

ULONG GetNtUserFindWindowExIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	0x17A;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;
}

ULONG GetNtUserGetForegroundWindowIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	0x194;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;
}

ULONG GetNtUserBuildHwndListIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	0x138;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;
}

ULONG GetNtUserWindowFromPointIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	592;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;
}


ULONG GetNtMapViewOfSectionIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	108;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;

}

ULONG GetNtUnMapViewOfSectionIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	267;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;

}

ULONG GetNtReadVirtualMemoryIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	186;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;

}
ULONG GetNtCloseIndex()
{

	ULONG ulVersion;

	ulVersion = GetWindowsVersion();

	if( ulVersion == WINDOWS_VERSION_XP )
	{
		return 	25;

	}
	else if( ulVersion == WINDOWS_VERSION_2K3 )
	{
		ASSERT( 1 );

	}
	else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
	{
		ASSERT( 1 );
	}

	return 0;

}


ULONG GetNtOpenProcessIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	122;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;

}


ULONG GetNtCreateThreadIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	53;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        ASSERT( 1 );
    }

    return 0;
}


ULONG GetNtQueryInformationProcessIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	154;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;

}


ULONG GetNtSetContextThreadIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	213;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;

}

ULONG GetNtGetContextThreadIndex()
{

    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return 	85;

    }
    else if( ulVersion == WINDOWS_VERSION_2K3 )
    {
        ASSERT( 1 );

    }
    else if( ulVersion == WINDOWS_VERSION_2K3_SP1_SP2 )
    {
        return 266;
    }

    return 0;

}


PVOID GetThreadCid( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( ( ( char* )p ) + 0x1ec );
    }

    return NULL;
}

PVOID GetEprocessRundownProtect( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( ( ( char* )p ) + 0x80 );
    }

    return NULL;
}



PVOID GetEThreadRundownProtect( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( ( ( char* )p ) + 0x234 );
    }

    return NULL;
}

PVOID GetEThreadTcbPoint( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )p;
    }

    return NULL;
}

PVOID GetEThreadTcbTerminatedBit( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( ( *( ULONG_PTR* )( ( char* )p + 0x248 ) ) & 0x1 );
    }

    return NULL;
}



PVOID GetEThreadSystemThread( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( ( *( ULONG* )( ( ( char* )p ) + 0x248 ) ) & 0x10 );
    }

    return NULL;
}

PVOID GetEThreadGrantedAccess( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( ( ( char* )p ) + 0x244 );
    }

    return NULL;
}

PVOID GetEThreadStartAddress( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID ) * ( ULONG* )( ( ( char* )p ) + 0x224 );
    }

    return NULL;
}


PVOID GetObjectTypeTypeInfoGenericMapping( PVOID p )
{
    ULONG ulVersion;

    ulVersion = GetWindowsVersion();

    if( ulVersion == WINDOWS_VERSION_XP )
    {
        return ( PVOID )( ( ( char* )p ) + 0x68 );
    }

    return NULL;
}
