typedef VOID
(NTAPI* PKiDispatchException )(IN PEXCEPTION_RECORD ExceptionRecord,
					IN PKEXCEPTION_FRAME ExceptionFrame,
					IN PKTRAP_FRAME TrapFrame,
					IN KPROCESSOR_MODE PreviousMode,
					IN BOOLEAN FirstChance);

typedef VOID  ( NTAPI *PDbgkCreateThread)(IN PETHREAD Thread, IN PVOID StartAddress);

typedef VOID (NTAPI* PDbgkExitProcess)(IN NTSTATUS ExitStatus);

typedef 
VOID
(NTAPI* PKiAttachProcess)(IN PKTHREAD Thread,
				IN PKPROCESS Process,
				IN PKLOCK_QUEUE_HANDLE ApcLock,
				IN PVOID SavedApcState);

VOID
NTAPI
PspUserThreadStartup(IN PKSTART_ROUTINE StartRoutine,
					 IN PVOID StartContext);

typedef VOID
(NTAPI* PPspUserThreadStartup)(IN PKSTART_ROUTINE StartRoutine,
					 IN PVOID StartContext);


typedef VOID
(NTAPI*PDbgkExitThread)(IN NTSTATUS ExitStatus);

typedef VOID
( NTAPI* PDbgkMapViewOfSection )(IN PVOID Section,
					 IN PVOID BaseAddress,
					 IN ULONG SectionOffset,
					 IN ULONG_PTR ViewSize);

typedef VOID
(NTAPI* PDbgkUnMapViewOfSection )(IN PVOID BaseAddress);

typedef BOOLEAN
(NTAPI* PDbgkForwardException)(IN PEXCEPTION_RECORD ExceptionRecord,
					 IN BOOLEAN DebugPort,
					 IN BOOLEAN SecondChance);
NTSTATUS HookKiDispatchException( PKiDispatchException lpKiDispatchException );
VOID UnHookKiDispatchException( );
NTSTATUS HookKiAttachProcess( PKiAttachProcess lpKiAttachProcess, PKiAttachProcess lpNewKiAttachProcess );
VOID UnHookKiAttachProcess( );