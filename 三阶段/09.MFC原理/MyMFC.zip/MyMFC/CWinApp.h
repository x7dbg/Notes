#pragma once
#include "CWinThread.h"
#include "CDocManager.h"

class CWinApp : public CWinThread
{
  DECLARE_DYNAMIC(CWinApp);
public:
  CWinApp();
  void OnFileNew();

  void AddDocTemplate(CDocTemplate* pTemplate);

  CDocManager* m_pDocManager;

  HINSTANCE m_hInstance;
  CWnd *m_pMainWnd;
};

