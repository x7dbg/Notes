#include "CCmdTarget.h"
IMPLEMENT_DYNAMIC(CCmdTarget, CObject);