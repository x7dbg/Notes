#pragma once
#include "CCmdTarget.h"
#include "CDocument.h"

class CDocTemplate : public CCmdTarget
{
public:
 virtual CDocument* OpenDocumentFile(LPCTSTR lpszPathName, BOOL bMakeVisible = TRUE);
};

