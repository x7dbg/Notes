#include "CTestView.h"

IMPLEMENT_DYNAMIC(CTestView, CView)