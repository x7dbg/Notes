#pragma once
#include "CObject.h"
class CCmdTarget :
    public CObject
{
    DECLARE_DYNAMIC(CCmdTarget);
};

