#pragma once
#include "CView.h"
class CTestView :
    public CView
{
};

