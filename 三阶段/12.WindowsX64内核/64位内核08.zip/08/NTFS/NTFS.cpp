﻿// NTFS.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h>
#include <stdlib.h>

/*
扇区 512字节

FAT16  FAT32  NTFS(卷2T)  MGR

7C00(MBR)   16位汇编
引导扇区 => winload => memory  ->  jmp  memory ->  ntoskel.exe

MBR  xxxxx  [MFT]    [DATA]     [MBR bak]

事务
数据恢复工具

*/


int main()
{
  HANDLE hFile  = INVALID_HANDLE_VALUE;
  hFile = CreateFile("\\\\.\\c:", GENERIC_READ | GENERIC_WRITE,
    FILE_SHARE_READ | FILE_SHARE_WRITE, 
    NULL, OPEN_EXISTING, 0, NULL);
  printf("hFile=%p\n", hFile);

  SetFilePointer(hFile, 0 * 512, NULL, FILE_BEGIN);

  unsigned char Buffer[512] = {0};
  DWORD dwBytes = 0;
  ReadFile(hFile, Buffer, sizeof(Buffer), &dwBytes, NULL);

  for (int i = 0; i < sizeof(Buffer); i++) {
    printf("%02X ", Buffer[i]);
  }
  FILE *fp = fopen("mbr.bin", "w");
  fwrite(Buffer, 1, sizeof(Buffer), fp);
  fclose(fp);


  CloseHandle(hFile);


  return 0;
}