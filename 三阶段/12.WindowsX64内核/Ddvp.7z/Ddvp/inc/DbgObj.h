#ifndef DBGAPI_H__
#define DBGAPI_H__

#define DBGAPI_API  __declspec(dllexport)

#pragma pack (push, 1)

typedef struct tagVerison
{
    ULONG ulMainVersion;
    ULONG ulChildVersion;
    char SzBuildTime[128];

} DICHLORVOS_VERISON, *PDICHLORVOS_VERISON;

#pragma pack( pop )

#pragma warning(disable: 4200)

#ifdef __cplusplus
extern "C" {
#endif


BOOL
WINAPI
DbgObjInitialize(  wchar_t* SzDriverPath,
                   wchar_t* SzDriverName );

typedef
BOOL
( WINAPI* PDbgObjInitialize )(  wchar_t* SzDriverPath,
                                wchar_t* SzDriverName );

BOOL
WINAPI
DbgObjGetVersion(
    PDICHLORVOS_VERISON Version );

typedef
BOOL
( WINAPI* PDbgObjGetVersion )(
    PDICHLORVOS_VERISON Version );


BOOL
WINAPI
DbgObjCreateDevice( wchar_t* SzDeviceName );

typedef
BOOL
( WINAPI* PDbgObjCreateDevice )( wchar_t* SzDeviceName );


BOOL
WINAPI
DbgObjCloseHanle( wchar_t* SzDeviceName );

typedef
BOOL
( WINAPI* PDbgObjCloseHanle )
( wchar_t* SzDeviceName );

BOOL
WINAPI
DbgObjCreateProcess(
    __in_opt LPCWSTR lpApplicationName,
    __inout_opt LPWSTR lpCommandLine,
    __in LPCWSTR lpExeName,
    __in_opt LPSECURITY_ATTRIBUTES lpProcessAttributes,
    __in_opt LPSECURITY_ATTRIBUTES lpThreadAttributes,
    __in BOOL bInheritHandles, __in DWORD dwCreationFlags,
    __in_opt LPVOID lpEnvironment,
    __in_opt LPCWSTR lpCurrentDirectory,
    __in LPSTARTUPINFOW lpStartupInfo,
    __out LPPROCESS_INFORMATION lpProcessInformation );

typedef
BOOL
( WINAPI* PDbgObjCreateProcess )(
    __in_opt LPCWSTR lpApplicationName,
    __inout_opt LPWSTR lpCommandLine,
    __in LPCWSTR lpExeName,
    __in_opt LPSECURITY_ATTRIBUTES lpProcessAttributes,
    __in_opt LPSECURITY_ATTRIBUTES lpThreadAttributes,
    __in BOOL bInheritHandles, __in DWORD dwCreationFlags,
    __in_opt LPVOID lpEnvironment,
    __in_opt LPCWSTR lpCurrentDirectory,
    __in LPSTARTUPINFOW lpStartupInfo,
    __out LPPROCESS_INFORMATION lpProcessInformation );

BOOL
WINAPI
DbgObjWaitForDebugEvent(
    IN LPDEBUG_EVENT lpDebugEvent,
    IN DWORD dwMilliseconds );

typedef
BOOL
( WINAPI* PDbgObjWaitForDebugEvent )(
    IN LPDEBUG_EVENT lpDebugEvent,
    IN DWORD dwMilliseconds );


BOOL
WINAPI
DbgObjContinueDebugEvent(
    IN DWORD dwProcessId,
    IN DWORD dwThreadId,
    IN DWORD dwContinueStatus );

typedef
BOOL
( WINAPI* PDbgObjContinueDebugEvent )(
    IN DWORD dwProcessId,
    IN DWORD dwThreadId,
    IN DWORD dwContinueStatus );

typedef
BOOL
( WINAPI* PDebugActiveProcess )( IN DWORD dwProcessId );

BOOL
WINAPI
DbgObjGetSysModuleInfo(
    PSYSTEM_MODULE SysModInfo );


typedef
BOOL
( WINAPI * PDbgObjGetSysModuleInfo )(
    PSYSTEM_MODULE SysModInfo );

BOOL WINAPI DbgObjEnumSymbols( wchar_t* SzSymbolsPath );

typedef
BOOL
( WINAPI* PDbgObjEnumSymbols )( wchar_t* SzSymbolsPath );


BOOL WINAPI DbgObjDebugActiveProcess(
    __in DWORD dwProcessId );

typedef
BOOL
( WINAPI* PDbgObjDebugActiveProcess )(
    __in DWORD dwProcessId );


BOOL WINAPI DbgObjDebugSetProcessKillOnExit(
    __in BOOL KillOnExit );

BOOL WINAPI DbgObjDebugActiveProcessStop(
    __in DWORD dwProcessId );

BOOL WINAPI DbgObjReadProcessMemory(
    IN HANDLE hProcess,
    IN LPCVOID lpBaseAddress,
    IN LPVOID lpBuffer,
    IN SIZE_T nSize,
    OUT SIZE_T* lpNumberOfBytesRead );

typedef
BOOL ( WINAPI* PDbgObjReadProcessMemory )(
    IN HANDLE hProcess,
    IN LPCVOID lpBaseAddress,
    IN LPVOID lpBuffer,
    IN SIZE_T nSize,
    OUT SIZE_T* lpNumberOfBytesRead );

BOOL WINAPI DbgObjWriteProcessMemory(
    IN HANDLE hProcess,
    IN LPVOID lpBaseAddress,
    IN LPCVOID lpBuffer,
    IN SIZE_T nSize,
    OUT SIZE_T *lpNumberOfBytesWritten );

typedef
BOOL ( WINAPI* PDbgObjWriteProcessMemory )(
    IN HANDLE hProcess,
    IN LPVOID lpBaseAddress,
    IN LPCVOID lpBuffer,
    IN SIZE_T nSize,
    OUT SIZE_T *lpNumberOfBytesWritten );

HANDLE WINAPI DbgObjOpenProcess(
    DWORD dwDesiredAccess,
    BOOL bInheritHandle,
    DWORD dwProcessId );

typedef
HANDLE ( WINAPI* PDbgObjOpenProcess )(
    DWORD dwDesiredAccess,
    BOOL bInheritHandle,
    DWORD dwProcessId );

BOOL WINAPI DbgObjGetThreadContext(
    HANDLE hThread,
    LPCONTEXT lpContext );

typedef
BOOL ( WINAPI* PDbgObjGetThreadContext )
( HANDLE hThread,
  LPCONTEXT lpContext );

BOOL WINAPI DbgObjSetThreadContext(
    HANDLE hThread,
    LPCONTEXT lpContext );

typedef
BOOL ( WINAPI* PDbgObjSetThreadContext )(
    HANDLE hThread,
    LPCONTEXT lpContext );

DWORD WINAPI DbgObjSuspendThread( HANDLE hThread );

typedef
DWORD ( WINAPI* PDbgObjSuspendThread )(
    HANDLE hThread );

DWORD WINAPI DbgObjResumeThread( HANDLE hThread );

typedef
DWORD ( WINAPI* PDbgObjResumeThread )( HANDLE hThread );

BOOL WINAPI DbgObjCheckBiosIsEnabled();

typedef
BOOL ( WINAPI* PDbgObjCheckBiosIsEnabled )( );

NTSTATUS WINAPI DbgObjNtOpenThread(
    OUT PHANDLE ThreadHandle,
    IN ACCESS_MASK DesiredAccess,
    IN POBJECT_ATTRIBUTES ObjectAttributes,
    IN PCLIENT_ID ClientId OPTIONAL );

typedef
NTSTATUS ( WINAPI* PDbgObjNtOpenThread )(
    OUT PHANDLE ThreadHandle,
    IN ACCESS_MASK DesiredAccess,
    IN POBJECT_ATTRIBUTES ObjectAttributes,
    IN PCLIENT_ID ClientId OPTIONAL );

#ifdef __cplusplus
}
#endif

#endif // DBGAPI_H__
