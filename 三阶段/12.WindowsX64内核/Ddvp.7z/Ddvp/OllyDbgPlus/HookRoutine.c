//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ����OllyDbg�Ĳ�����ֵ�Hook����, HookסOllydbgһϵ�к���. ����֮����
 * û��Hook Ollydbg��IAT��, �����Ժ�Ollydbg��ӿ�, �Զ����������.
 */
//===========================================================================
#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <assert.h>
#include <shlwapi.h>
#include "ntdll.h"
#include "PlusMisc.h"
#include "Dichlorvos.h"
#include "DbgObj.h"



//---------------------------------------------------------------------------
extern	PDbgObjCreateProcess			lpDbgObjCreateProcess;
extern	PDbgObjWaitForDebugEvent		lpDbgObjWaitForDebugEvent;
extern	PDbgObjContinueDebugEvent		lpDbgObjContinueDebugEvent;
extern	PDebugActiveProcess				lpDbgObjDebugActiveProcess;
extern	PDbgObjWriteProcessMemory		lpDbgObjWriteProcessMemory;
extern	PDbgObjReadProcessMemory		lpDbgObjReadProcessMemory;
extern	PDbgObjOpenProcess				lpDbgObjOpenProcess;
extern  PDbgObjResumeThread				lpDbgObjResumeThread;
extern	PDbgObjSuspendThread			lpDbgObjSuspendThread;
extern	PDbgObjSetThreadContext			lpDbgObjSetThreadContext;
extern	PDbgObjGetThreadContext			lpDbgObjGetThreadContext;

extern	PDbgObjNtOpenThread				lpDbgObjNtOpenThread;
//---------------------------------------------------------------------------
PVOID	lpCreateProcess;
BYTE	BufferCreateProcess[5];
BYTE	NewBufferCreateProcess[5];

PVOID	lpWaitForDebugEvent;
BYTE	BufferWaitForDebugEvent[5];
BYTE	NewBufferWaitForDebugEvent[5];

PVOID	lpContinueDebugEvent;
BYTE	BufferContinueDebugEvent[5];
BYTE	NewBufferContinueDebugEvent[5];

PVOID	lpDebugActiveProcess;
BYTE	BufferDebugActiveProcess[5];
BYTE	NewBufferDebugActiveProcess[5];

PVOID	lpWriteProcessMemory;
BYTE	BufferWriteProcessMemory[5];
BYTE	NewBufferWriteProcessMemory[5];

PVOID	lpReadProcessMemory;
BYTE	BufferReadProcessMemory[5];
BYTE	NewBufferReadProcessMemory[5];

PVOID	lpOpenProcess;
BYTE	BufferOpenProcess[5];
BYTE	NewBufferOpenProcess[5];

PVOID	lpNtOpenThread;
BYTE	BufferNtOpenThread[5];
BYTE	NewBufferNtOpenThread[5];

PVOID	lpResumeThread;
BYTE	BufferResumeThread[5];
BYTE	NewBufferResumeThread[5];

PVOID	lpSuspendThread;
BYTE	BufferSuspendThread[5];
BYTE	NewBufferSuspendThread[5];


PVOID	lpSetThreadContext;
BYTE	BufferSetThreadContext[5];
BYTE	NewBufferSetThreadContext[5];

PVOID	lpGetThreadContext;
BYTE	BufferGetThreadContext[5];
BYTE	NewBufferGetThreadContext[5];

PVOID	lpExitProcess;
BYTE	BufferExitProcess[5];
BYTE	NewBufferExitProcess[5];
//---------------------------------------------------------------------------


BOOL
WINAPI
Naked_CreateProcessA(
    __in_opt    LPCSTR lpApplicationName,
    __inout_opt LPSTR lpCommandLine,
    __in_opt    LPSECURITY_ATTRIBUTES lpProcessAttributes,
    __in_opt    LPSECURITY_ATTRIBUTES lpThreadAttributes,
    __in        BOOL bInheritHandles,
    __in        DWORD dwCreationFlags,
    __in_opt    LPVOID lpEnvironment,
    __in_opt    LPCSTR lpCurrentDirectory,
    __in        LPSTARTUPINFOA lpStartupInfo,
    __out       LPPROCESS_INFORMATION lpProcessInformation
)
{
    int iRet;
    BOOL bRet;
    int i;
    wchar_t* lpSzExeName = NULL;
    wchar_t SzExeName[MAX_PATH] = {0};
    wchar_t SzApplicationName[MAX_PATH] = {0};
    wchar_t* lpSzApplicationName = SzApplicationName;
    wchar_t SzCommandLine[MAX_PATH] = {0};
    wchar_t* lpSzCommandLine = SzCommandLine;
    wchar_t SzCurrentDirectory[MAX_PATH] = {0};
    wchar_t* lpSzCurrentDirectory = SzCurrentDirectory;
    wchar_t SzReserved[MAX_PATH] = {0};
    wchar_t SzDesktop[MAX_PATH] = {0};
    wchar_t SzTitle[MAX_PATH] = {0};
    STARTUPINFOW StartUpInfo;

    if ( !lpStartupInfo )
    {
        return FALSE;
    }

    RtlMoveMemory( &StartUpInfo, lpStartupInfo, sizeof( *lpStartupInfo ) );

    StartUpInfo.lpDesktop = NULL;
    StartUpInfo.lpReserved = NULL;
    StartUpInfo.lpTitle = NULL;

    /* Now convert Startup Strings */
    if ( lpStartupInfo->lpReserved )
    {
        iRet = MultiByteToWideChar( CP_ACP, 0, lpStartupInfo->lpReserved,
                                    strlen( lpStartupInfo->lpReserved ),
                                    SzReserved,
                                    SizeOf( SzReserved ) );
        if ( iRet == 0 )
        {
            return FALSE;
        }
        StartUpInfo.lpReserved = SzReserved;
    }

    if ( lpStartupInfo->lpDesktop )
    {
        iRet = MultiByteToWideChar( CP_ACP, 0, lpStartupInfo->lpDesktop,
                                    strlen( lpStartupInfo->lpDesktop ),
                                    SzDesktop,
                                    SizeOf( SzDesktop ) );
        if ( iRet == 0 )
        {
            return FALSE;
        }
        StartUpInfo.lpDesktop = SzDesktop;
    }

    if ( lpStartupInfo->lpTitle )
    {
        iRet = MultiByteToWideChar( CP_ACP, 0, lpStartupInfo->lpTitle,
                                    strlen( lpStartupInfo->lpTitle ),
                                    SzTitle,
                                    SizeOf( SzTitle ) );
        if ( iRet == 0 )
        {
            return FALSE;
        }
        StartUpInfo.lpTitle = SzTitle;
    }

    if ( lpApplicationName )
    {
        iRet = MultiByteToWideChar( CP_ACP, 0, lpApplicationName,
                                    strlen( lpApplicationName ),
                                    SzApplicationName,
                                    SizeOf( SzApplicationName ) );
        if ( iRet == 0 )
        {
            return FALSE;
        }
    }
    else
    {
        lpSzApplicationName = NULL;
    }

    if ( lpCommandLine )
    {
        iRet = MultiByteToWideChar( CP_ACP, 0, lpCommandLine,
                                    strlen( lpCommandLine ),
                                    SzCommandLine,
                                    SizeOf( SzCommandLine ) );
        if ( iRet == 0 )
        {
            return FALSE;
        }
    }
    else
    {
        lpSzCommandLine = NULL;
    }

    if ( lpCurrentDirectory )
    {
        iRet = MultiByteToWideChar( CP_ACP, 0, lpCurrentDirectory,
                                    strlen( lpCurrentDirectory ),
                                    SzCurrentDirectory,
                                    SizeOf( SzCurrentDirectory ) );
        if ( iRet == 0 )
        {
            return FALSE;
        }
    }
    else
    {
        lpSzCurrentDirectory = NULL;
    }

    lpSzExeName = lpSzApplicationName;
    if ( !lpSzApplicationName )
    {
        lpSzExeName = lpSzCommandLine;

    }

    for( i = wcslen( lpSzExeName ), bRet = FALSE; i > 0; i-- )
    {
        if ( lpSzExeName[i] == L'\\' )
        {
            bRet = TRUE;
            break;
        }
    }

    if ( !bRet )
    {
        KdPrint( ( "Plus--> CreateProcess ������ȡʧ��\t\t%ws \n", lpSzExeName ) );
        return FALSE;
    }

    wcscpy_s( SzExeName, SizeOf( SzExeName ), &lpSzExeName[i + 1] );
    StrTrim( SzExeName, L" " );
    StrTrim ( SzExeName, L"\"" );

    KdPrint( ( "Plus--> CreateProcess ApplicationName\t\t%ws \n", lpSzApplicationName ) );
    KdPrint( ( "Plus--> CreateProcess SzCommandLine\t\t%ws \n", lpSzCommandLine ) );
    KdPrint( ( "Plus--> CreateProcess SzExeName\t\t%ws \n", SzExeName ) );

    return lpDbgObjCreateProcess( lpSzApplicationName,
                                  lpSzCommandLine,
                                  SzExeName,
                                  lpProcessAttributes,
                                  lpThreadAttributes,
                                  bInheritHandles,
                                  dwCreationFlags,
                                  lpEnvironment,
                                  lpSzCurrentDirectory,
                                  &StartUpInfo,
                                  lpProcessInformation );
}

#define MAX_DBG_EVENT 9

LPTSTR DbgEventName[ MAX_DBG_EVENT + 1] =
{
    L"EXCEPTION_DEBUG_EVENT",
    L"CREATE_THREAD_DEBUG_EVENT",
    L"CREATE_PROCESS_DEBUG_EVENT",
    L"EXIT_THREAD_DEBUG_EVENT",
    L"EXIT_PROCESS_DEBUG_EVENT",
    L"LOAD_DLL_DEBUG_EVENT",
    L"UNLOAD_DLL_DEBUG_EVENT",
    L"OUTPUT_DEBUG_STRING_EVENT",
    L"RIP_EVENT",
    L"Unknown Debug Event"
};

BOOL
WINAPI
Naked_WaitForDebugEvent(
    __in LPDEBUG_EVENT lpDebugEvent,
    __in DWORD dwMilliseconds
)
{
    BOOL bRet;
    CREATE_PROCESS_DEBUG_INFO CreateProcessInfo;
    LOAD_DLL_DEBUG_INFO LoadDllInfo;
    CREATE_THREAD_DEBUG_INFO CreateThreadInfo;
    // EXCEPTION_RECORD ExceptionRecord;
    // EXIT_PROCESS_DEBUG_INFO ExitProcessInfo;
    // EXCEPTION_DEBUG_INFO ExceptionInfo;
    // EXIT_THREAD_DEBUG_INFO ExitThreadInfo;
    // UNLOAD_DLL_DEBUG_INFO UnLoadDllInfo;
    // OUTPUT_DEBUG_STRING_INFO StDebugStringInfo;

    bRet = lpDbgObjWaitForDebugEvent(
               lpDebugEvent, dwMilliseconds );
    if ( bRet )
    {
        //
        // Process the debugging event code.
//         //
//         KdPrint( ( "Plus--> Debug event received from process %d thread %d: %ws \n",
//                    lpDebugEvent->dwProcessId, lpDebugEvent->dwThreadId,
//                    DbgEventName[lpDebugEvent->dwDebugEventCode > MAX_DBG_EVENT
//                                 ? MAX_DBG_EVENT :
//                                 lpDebugEvent->dwDebugEventCode - 1] ) );

        if ( lpDebugEvent->dwDebugEventCode == CREATE_THREAD_DEBUG_EVENT )
        {
            CreateThreadInfo = lpDebugEvent->u.CreateThread;

//             KdPrint( ( "Plus--> \tThread TLS data address 0x%p, Start address 0x%p \n",
//                        CreateThreadInfo.lpThreadLocalBase,
//                        CreateThreadInfo.lpStartAddress ) );
// 
//             KdPrint( ( "Plus--> Info \n\tDbgEvt.dwDebugEventCode\t\t %d \n", lpDebugEvent->dwDebugEventCode ) );
//             KdPrint( ( "Plus--> \tDbgEvt.dwProcessId\t\t %d \n", lpDebugEvent->dwProcessId ) );
//             KdPrint( ( "Plus--> \tDbgEvt.dwThreadId\t\t %d \n", lpDebugEvent->dwThreadId ) );
// 
//             KdPrint( ( "Plus--> \tCreateThreadInfo.hThread\t\t %d \n", CreateThreadInfo.hThread ) );
//             KdPrint( ( "Plus--> \tCreateThreadInfo.lpStartAddress\t\t %p \n", CreateThreadInfo.lpStartAddress ) );
//             KdPrint( ( "Plus--> \tCreateThreadInfo.lpThreadLocalBase \t\t %p \n", CreateThreadInfo.lpThreadLocalBase ) );

        }
        else if ( lpDebugEvent->dwDebugEventCode == CREATE_PROCESS_DEBUG_EVENT )
        {
            CreateProcessInfo = lpDebugEvent->u.CreateProcessInfo;

//             KdPrint( ( "Info \n\tDbgEvt.dwDebugEventCode\t\t %d \n", lpDebugEvent->dwDebugEventCode ) );
//             KdPrint( ( "\tDbgEvt.dwProcessId\t\t %d \n", lpDebugEvent->dwProcessId ) );
//             KdPrint( ( "\tDbgEvt.dwThreadId\t\t %d \n", lpDebugEvent->dwThreadId ) );
// 
//             KdPrint( ( "\tCreateProcessInfo.hProcess\t\t %d \n",
//                        CreateProcessInfo.hProcess ) );
//             KdPrint( ( "\tCreateProcessInfo.hThread\t\t %d \n",
//                        CreateProcessInfo.hThread ) );
//             KdPrint( ( "\tCreateProcessInfo.hFile \t\t %d \n",
//                        CreateProcessInfo.hFile ) );
//             KdPrint( ( "\tCreateProcessInfo.lpBaseOfImage \t\t %p \n",
//                        CreateProcessInfo.lpBaseOfImage ) );
// 
//             KdPrint( ( "\tCreateProcessInfo.dwDebugInfoFileOffset\t\t %p \n",
//                        CreateProcessInfo.dwDebugInfoFileOffset ) );
//             KdPrint( ( "\tCreateProcessInfo.nDebugInfoSize\t\t %p \n",
//                        CreateProcessInfo.nDebugInfoSize ) );
//             KdPrint( ( "\tCreateProcessInfo.lpThreadLocalBase\t\t %p \n",
//                        CreateProcessInfo.lpThreadLocalBase ) );
//             KdPrint( ( "\tCreateProcessInfo.lpStartAddress\t\t %p \n",
//                        CreateProcessInfo.lpStartAddress ) );
//             KdPrint( ( "\tCreateProcessInfo.lpImageName\t\t %d \n",
//                        CreateProcessInfo.lpImageName ) );
//             KdPrint( ( "\tCreateProcessInfo.fUnicode\t\t %d \n",
//                        CreateProcessInfo.fUnicode ) );

        }
        else if ( lpDebugEvent->dwDebugEventCode == LOAD_DLL_DEBUG_EVENT )
        {
            LoadDllInfo = lpDebugEvent->u.LoadDll;

//             KdPrint( ( "Info \n\tDbgEvt.dwDebugEventCode\t\t %d \n",
//                        lpDebugEvent->dwDebugEventCode ) );
//             KdPrint( ( "\tDbgEvt.dwProcessId\t\t %d \n", lpDebugEvent->dwProcessId ) );
//             KdPrint( ( "\tDbgEvt.dwThreadId\t\t %d \n", lpDebugEvent->dwThreadId ) );
// 
//             KdPrint( ( "\tLoadDllInfo.dwDebugInfoFileOffset\t\t %d \n",
//                        LoadDllInfo.dwDebugInfoFileOffset ) );
//             KdPrint( ( "\tLoadDllInfo.fUnicode\t\t %d \n",
//                        LoadDllInfo.fUnicode ) );
//             KdPrint( ( "\tLoadDllInfo.hFile \t\t %d \n",
//                        LoadDllInfo.hFile ) );
//             KdPrint( ( "\tLoadDllInfo.lpBaseOfDll \t\t %p \n",
//                        LoadDllInfo.lpBaseOfDll ) );
//             KdPrint( ( "\tLoadDllInfo.lpImageName\t\t %p \n",
//                        LoadDllInfo.lpImageName ) );
//             KdPrint( ( "\tCreateProcessInfo.nDebugInfoSize\t\t %p \n",
//                        LoadDllInfo.nDebugInfoSize ) );
        }
    }

    return bRet;
}

BOOL
WINAPI
Naked_ContinueDebugEvent(
    __in DWORD dwProcessId,
    __in DWORD dwThreadId,
    __in DWORD dwContinueStatus
)
{
    return lpDbgObjContinueDebugEvent(
               dwProcessId, dwThreadId, dwContinueStatus );
}

BOOL
WINAPI
Naked_DebugActiveProcess( IN DWORD dwProcessId )
{
    return lpDbgObjDebugActiveProcess( dwProcessId );
}



BOOL
NTAPI
Naked_WriteProcessMemory( IN HANDLE hProcess,
                          IN LPVOID lpBaseAddress,
                          IN LPCVOID lpBuffer,
                          IN SIZE_T nSize,
                          OUT SIZE_T *lpNumberOfBytesWritten )
{

    return lpDbgObjWriteProcessMemory( hProcess,
                                       lpBaseAddress,
                                       lpBuffer, nSize,
                                       lpNumberOfBytesWritten );

}

BOOL
NTAPI
Naked_ReadProcessMemory( IN HANDLE hProcess,
                         IN LPCVOID lpBaseAddress,
                         IN LPVOID lpBuffer,
                         IN SIZE_T nSize,
                         OUT SIZE_T* lpNumberOfBytesRead )
{

    return lpDbgObjReadProcessMemory( hProcess,
                                      lpBaseAddress,
                                      lpBuffer, nSize,
                                      lpNumberOfBytesRead );

}

HANDLE
WINAPI
Naked_OpenProcess( DWORD dwDesiredAccess,
                   BOOL bInheritHandle,
                   DWORD dwProcessId )
{

    return lpDbgObjOpenProcess( dwDesiredAccess, bInheritHandle, dwProcessId );

}

DWORD
WINAPI
Naked_ResumeThread( HANDLE hThread )
{
    return lpDbgObjResumeThread( hThread );
}

DWORD
WINAPI
Naked_SuspendThread( HANDLE hThread )
{
    return lpDbgObjSuspendThread( hThread );
}

BOOL
WINAPI
Naked_SetThreadContext( HANDLE hThread,
                        CONTEXT *lpContext )

{
    return lpDbgObjSetThreadContext( hThread, lpContext );
}

BOOL
WINAPI
Naked_GetThreadContext( HANDLE hThread,
                        LPCONTEXT lpContext )
{
    return lpDbgObjGetThreadContext( hThread, lpContext );
}

NTSTATUS
NTAPI
Naked_NtOpenThread(OUT PHANDLE ThreadHandle,
			 IN ACCESS_MASK DesiredAccess,
			 IN POBJECT_ATTRIBUTES ObjectAttributes,
			 IN PCLIENT_ID ClientId OPTIONAL)
{

	return lpDbgObjNtOpenThread( ThreadHandle, DesiredAccess, ObjectAttributes, ClientId );
}

VOID
WINAPI
Naked_ExitProcess(UINT uExitCode)
{

	_ExitProcess();

	__asm
	{
		mov		eax, lpExitProcess
		add		eax, 5
		jmp		eax
	}

}


BOOL HookDebugRoutine()
{
    HMODULE hModule;

    //
    // Hook R3����
    //
    hModule = LoadLibrary( _T( "kernel32.dll" ) );
    lpCreateProcess = ( PVOID )GetProcAddress( hModule, "CreateProcessA" );
    lpWaitForDebugEvent = ( PVOID )GetProcAddress( hModule, "WaitForDebugEvent" );
    lpContinueDebugEvent = ( PVOID )GetProcAddress( hModule, "ContinueDebugEvent" );
    lpDebugActiveProcess = ( PVOID )GetProcAddress( hModule, "DebugActiveProcess" );
    lpReadProcessMemory = ( PVOID )GetProcAddress( hModule, "ReadProcessMemory" );
    lpWriteProcessMemory = ( PVOID )GetProcAddress( hModule, "WriteProcessMemory" );
    lpOpenProcess = ( PVOID )GetProcAddress( hModule, "OpenProcess" );
    lpResumeThread = ( PVOID )GetProcAddress( hModule, "ResumeThread" );
    lpSuspendThread = ( PVOID )GetProcAddress( hModule, "SuspendThread" );
    lpSetThreadContext = ( PVOID )GetProcAddress( hModule, "SetThreadContext" );
    lpGetThreadContext = ( PVOID )GetProcAddress( hModule, "GetThreadContext" );
    lpExitProcess = ( PVOID )GetProcAddress( hModule, "ExitProcess" );

	hModule = LoadLibrary( _T( "ntdll.dll" ) );
	
	lpNtOpenThread = ( PVOID )GetProcAddress( hModule, "NtOpenThread" );
	
	assert( lpNtOpenThread );
    assert( lpOpenProcess );
    assert( lpGetThreadContext );
    assert( lpSetThreadContext );
    assert( lpSuspendThread );
    assert( lpResumeThread );
    assert( lpWaitForDebugEvent );
    assert( lpCreateProcess );
    assert( lpContinueDebugEvent );
    assert( lpDebugActiveProcess );
    assert( lpWriteProcessMemory );
    assert( lpReadProcessMemory );
	assert( lpExitProcess );
	
//---------------------------------------------------------------------------
    SafeCopyMemory( BufferCreateProcess, lpCreateProcess,
                    sizeof( BufferCreateProcess ) );

    _Jump( lpCreateProcess, Naked_CreateProcessA, 0 );

    SafeCopyMemory( NewBufferCreateProcess, lpCreateProcess,
                    sizeof( NewBufferCreateProcess ) );
//---------------------------------------------------------------------------
    SafeCopyMemory( BufferWaitForDebugEvent, lpWaitForDebugEvent,
                    sizeof( BufferWaitForDebugEvent ) );

    _Jump( lpWaitForDebugEvent, Naked_WaitForDebugEvent, 0 );

    SafeCopyMemory( NewBufferWaitForDebugEvent, lpWaitForDebugEvent,
                    sizeof( NewBufferWaitForDebugEvent ) );
//---------------------------------------------------------------------------
    SafeCopyMemory( BufferContinueDebugEvent, lpContinueDebugEvent,
                    sizeof( BufferContinueDebugEvent ) );

    _Jump( lpContinueDebugEvent, Naked_ContinueDebugEvent, 0 );

    SafeCopyMemory( NewBufferContinueDebugEvent, lpContinueDebugEvent,
                    sizeof( NewBufferContinueDebugEvent ) );
//---------------------------------------------------------------------------
    SafeCopyMemory( BufferDebugActiveProcess, lpDebugActiveProcess,
                    sizeof( BufferDebugActiveProcess ) );

    _Jump( lpDebugActiveProcess, Naked_DebugActiveProcess, 0 );

    SafeCopyMemory( NewBufferDebugActiveProcess, lpDebugActiveProcess,
                    sizeof( NewBufferDebugActiveProcess ) );
//---------------------------------------------------------------------------
    SafeCopyMemory( BufferOpenProcess, lpOpenProcess,
                    sizeof( BufferOpenProcess ) );

    _Jump( lpOpenProcess, Naked_OpenProcess, 0 );

    SafeCopyMemory( NewBufferOpenProcess, lpOpenProcess,
                    sizeof( NewBufferOpenProcess ) );
//---------------------------------------------------------------------------
    SafeCopyMemory( BufferWriteProcessMemory, lpWriteProcessMemory,
                    sizeof( BufferWriteProcessMemory ) );

    _Jump( lpWriteProcessMemory, Naked_WriteProcessMemory, 0 );

    SafeCopyMemory( NewBufferWriteProcessMemory, lpWriteProcessMemory,
                    sizeof( NewBufferWriteProcessMemory ) );
//---------------------------------------------------------------------------
    SafeCopyMemory( BufferReadProcessMemory, lpReadProcessMemory,
                    sizeof( BufferReadProcessMemory ) );

    _Jump( lpReadProcessMemory, Naked_ReadProcessMemory, 0 );

    SafeCopyMemory( NewBufferReadProcessMemory, lpReadProcessMemory,
                    sizeof( NewBufferReadProcessMemory ) );

//---------------------------------------------------------------------------
    SafeCopyMemory( BufferResumeThread, lpResumeThread,
                    sizeof( BufferResumeThread ) );

    _Jump( lpResumeThread, Naked_ResumeThread, 0 );

    SafeCopyMemory( NewBufferResumeThread, lpResumeThread,
                    sizeof( NewBufferResumeThread ) );

//---------------------------------------------------------------------------
    SafeCopyMemory( BufferSuspendThread, lpSuspendThread,
                    sizeof( BufferSuspendThread ) );

    _Jump( lpSuspendThread, Naked_SuspendThread, 0 );

    SafeCopyMemory( NewBufferSuspendThread, lpSuspendThread,
                    sizeof( NewBufferSuspendThread ) );

//---------------------------------------------------------------------------
    SafeCopyMemory( BufferSetThreadContext, lpSetThreadContext,
                    sizeof( BufferSetThreadContext ) );

    _Jump( lpSetThreadContext, Naked_SetThreadContext, 0 );

    SafeCopyMemory( NewBufferSetThreadContext, lpSetThreadContext,
                    sizeof( NewBufferSetThreadContext ) );
//---------------------------------------------------------------------------
    SafeCopyMemory( BufferGetThreadContext, lpGetThreadContext,
                    sizeof( BufferGetThreadContext ) );

    _Jump( lpGetThreadContext, Naked_GetThreadContext, 0 );

    SafeCopyMemory( NewBufferGetThreadContext, lpGetThreadContext,
                    sizeof( NewBufferGetThreadContext ) );
//---------------------------------------------------------------------------
	SafeCopyMemory( BufferNtOpenThread, lpNtOpenThread,
		sizeof( BufferNtOpenThread ) );

	_Jump( lpNtOpenThread, Naked_NtOpenThread, 0 );

	SafeCopyMemory( NewBufferNtOpenThread, lpNtOpenThread,
		sizeof( NewBufferNtOpenThread ) );
//---------------------------------------------------------------------------
// 	SafeCopyMemory( BufferExitProcess, lpExitProcess,
// 		sizeof( BufferExitProcess ) );
// 
// 	_Jump( lpExitProcess, Naked_ExitProcess, 0 );
// 
// 	SafeCopyMemory( NewBufferExitProcess, lpExitProcess,
// 		sizeof( NewBufferExitProcess ) );
//---------------------------------------------------------------------------
    return TRUE;
}

VOID UnHookDebugRoutine()
{
    SIZE_T Ret;

    Ret = memcmp( lpCreateProcess, NewBufferCreateProcess,
                  sizeof( NewBufferCreateProcess ) );
    if ( !Ret )
    {
        SafeCopyMemory( lpCreateProcess, BufferCreateProcess,
                        sizeof( BufferCreateProcess ) );
    }
//---------------------------------------------------------------------------
    Ret = memcmp( lpWaitForDebugEvent, NewBufferWaitForDebugEvent,
                  sizeof( NewBufferWaitForDebugEvent ) );
    if ( Ret )
    {
        SafeCopyMemory( lpCreateProcess, BufferWaitForDebugEvent,
                        sizeof( BufferWaitForDebugEvent ) );
    }
//---------------------------------------------------------------------------
    Ret = memcmp( lpContinueDebugEvent, NewBufferContinueDebugEvent,
                  sizeof( NewBufferContinueDebugEvent ) );
    if ( Ret  )
    {
        SafeCopyMemory( lpCreateProcess, BufferContinueDebugEvent,
                        sizeof( BufferContinueDebugEvent ) );
    }
//---------------------------------------------------------------------------
    Ret = memcmp( lpDebugActiveProcess, NewBufferDebugActiveProcess,
                  sizeof( NewBufferDebugActiveProcess ) );
    if ( Ret  )
    {
        SafeCopyMemory( lpDebugActiveProcess, BufferDebugActiveProcess,
                        sizeof( BufferDebugActiveProcess ) );
    }
//---------------------------------------------------------------------------
    Ret = memcmp( lpReadProcessMemory, NewBufferReadProcessMemory,
                  sizeof( NewBufferReadProcessMemory ) );
    if ( Ret  )
    {
        SafeCopyMemory( lpReadProcessMemory, BufferReadProcessMemory,
                        sizeof( BufferReadProcessMemory ) );
    }
//---------------------------------------------------------------------------
    Ret = memcmp( lpWriteProcessMemory, NewBufferWriteProcessMemory,
                  sizeof( NewBufferWriteProcessMemory ) );
    if ( Ret  )
    {
        SafeCopyMemory( lpWriteProcessMemory, BufferWriteProcessMemory,
                        sizeof( BufferWriteProcessMemory ) );
    }
//---------------------------------------------------------------------------
    Ret = memcmp( lpOpenProcess, NewBufferOpenProcess,
                  sizeof( NewBufferOpenProcess ) );
    if ( Ret  )
    {
        SafeCopyMemory( lpOpenProcess, BufferOpenProcess,
                        sizeof( BufferOpenProcess ) );
    }
//---------------------------------------------------------------------------
    Ret = memcmp( lpResumeThread, NewBufferResumeThread,
                  sizeof( NewBufferResumeThread ) );
    if ( Ret  )
    {
        SafeCopyMemory( lpResumeThread, BufferResumeThread,
                        sizeof( BufferResumeThread ) );
    }
//---------------------------------------------------------------------------
    Ret = memcmp( lpSuspendThread, NewBufferSuspendThread,
                  sizeof( NewBufferSuspendThread ) );
    if ( Ret  )
    {
        SafeCopyMemory( lpSuspendThread, BufferSuspendThread,
                        sizeof( BufferSuspendThread ) );
    }
//---------------------------------------------------------------------------
    Ret = memcmp( lpSetThreadContext, NewBufferSetThreadContext,
                  sizeof( NewBufferSetThreadContext ) );
    if ( Ret  )
    {
        SafeCopyMemory( lpSetThreadContext, BufferSetThreadContext,
                        sizeof( BufferSetThreadContext ) );
    }
//---------------------------------------------------------------------------
    Ret = memcmp( lpGetThreadContext, NewBufferGetThreadContext,
                  sizeof( NewBufferGetThreadContext ) );
    if ( Ret  )
    {
        SafeCopyMemory( lpGetThreadContext, BufferGetThreadContext,
                        sizeof( BufferGetThreadContext ) );
    }
}