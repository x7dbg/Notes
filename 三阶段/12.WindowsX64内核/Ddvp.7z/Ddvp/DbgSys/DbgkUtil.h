#pragma  once
#include <ntimage.h>

#define LPC_REQUEST             1
#define LPC_REPLY               2
#define LPC_DATAGRAM            3
#define LPC_LOST_REPLY          4
#define LPC_PORT_CLOSED         5
#define LPC_CLIENT_DIED         6
#define LPC_EXCEPTION           7
#define LPC_DEBUG_EVENT         8
#define LPC_ERROR_EVENT         9
#define LPC_CONNECTION_REQUEST 10
#define PS_CROSS_THREAD_FLAGS_HIDEFROMDBG          0x00000004UL


#define ProbeForReadGenericType(Ptr, Type, Default)                            \
	(((ULONG_PTR)(Ptr) + sizeof(Type) - 1 < (ULONG_PTR)(Ptr) ||                \
	(ULONG_PTR)(Ptr) + sizeof(Type) - 1 >= (ULONG_PTR)MmUserProbeAddress) ?   \
	ExRaiseAccessViolation(), Default :                     \
	*(const volatile Type *)(Ptr))

#define ProbeForReadLargeInteger(Ptr) ProbeForReadGenericType((const LARGE_INTEGER *)(Ptr), LARGE_INTEGER, __emptyLargeInteger)

PIMAGE_NT_HEADERS
NTAPI
RtlImageNtHeader( PVOID Base );


NTSTATUS NTAPI _NtWaitForDebugEvent( PDBG_ITEM DbgItem, LPNT_DEBUG_EVENT DebugEvent, LARGE_INTEGER* TimeOut );
VOID NTAPI _DbgkCreateThread(IN PETHREAD Thread, IN PVOID StartAddress);
VOID NTAPI _DbgkExitProcess(IN NTSTATUS ExitStatus);
VOID NTAPI _DbgkExitThread(IN NTSTATUS ExitStatus);
VOID NTAPI _DbgkMapViewOfSection(IN PVOID Section, IN PVOID BaseAddress, IN ULONG SectionOffset, IN ULONG_PTR ViewSize);
VOID NTAPI _DbgkUnMapViewOfSection(IN PVOID BaseAddress);

NTSTATUS NTAPI _NtDebugContinue( IN HANDLE dwProcessId, IN HANDLE dwThreadId, IN NTSTATUS ContinueStatus );

NTSTATUS DbgkInitRoutine();
BOOL _KiDispatchException ( IN PEXCEPTION_RECORD ExceptionRecord, IN PKEXCEPTION_FRAME ExceptionFrame, IN PKTRAP_FRAME TrapFrame, IN KPROCESSOR_MODE PreviousMode, IN BOOLEAN FirstChance );

NTSTATUS NTAPI DbgkpPostFakeProcessCreateMessages( DBG_ITEM* DbgItem, OUT PETHREAD *LastThread );
NTSTATUS NTAPI DbgkNtSetContextThread(IN HANDLE ThreadHandle, IN PCONTEXT ThreadContext);
NTSTATUS NTAPI DbgkNtGetContextThread(IN HANDLE ThreadHandle, IN OUT PCONTEXT ThreadContext);
ULONG NTAPI _DbgkForwardException( IN PEXCEPTION_RECORD ExceptionRecord, IN BOOLEAN DebugPort, IN BOOLEAN SecondChance);
NTSTATUS NTAPI _PsSuspendThread( IN PETHREAD Thread, OUT PULONG PreviousCount OPTIONAL );