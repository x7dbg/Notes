#include "CDocTemplate.h"
IMPLEMENT_DYNAMIC(CDocTemplate, CCmdTarget)

CDocument* CDocTemplate::OpenDocumentFile(LPCTSTR lpszPathName, BOOL bMakeVisible)
{
    return nullptr;
}
