﻿#pragma once
#include "afxdialogex.h"
#include <vector>

// CFileManager 对话框

class CFileManager : public CDialogEx
{
	DECLARE_DYNAMIC(CFileManager)

public:
	CFileManager(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CFileManager();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_FILE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持
	DECLARE_MESSAGE_MAP()
public:
	void TravelAll(HTREEITEM ht);
	CTreeCtrl m_Tree;
	CListCtrl m_ListCtrl;
	virtual BOOL OnInitDialog();
	afx_msg void OnClickTreeFile(NMHDR* pNMHDR, LRESULT* pResult);
	virtual BOOL DestroyWindow();
	HTREEITEM m_hItemHead;
	CImageList m_imgIcon;
};
