#ifndef _DEFINES_
#define _DEFINES_

#ifdef KMDF_MAJOR_VERSION
#endif

#define far
#define near

#define WINAPI      __stdcall

//typedef unsigned
typedef unsigned __int64 ULONG64;
typedef unsigned long    ULONG;
typedef unsigned short   USHORT;
typedef unsigned char    BYTE;
typedef unsigned char*	PBYTE;
typedef int                 BOOL;
typedef unsigned long       DWORD;
typedef int                 BOOL;
typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef float               FLOAT;
typedef FLOAT               *PFLOAT;
typedef BOOL near           *PBOOL;
typedef BOOL far            *LPBOOL;
typedef BYTE near           *PBYTE;
typedef BYTE far            *LPBYTE;
typedef int near            *PINT;
typedef int far             *LPINT;
typedef WORD near           *PWORD;
typedef WORD far            *LPWORD;
typedef long far            *LPLONG;
typedef DWORD near          *PDWORD;
typedef DWORD far           *LPDWORD;
typedef void far            *LPVOID;
typedef CONST void far      *LPCVOID;

typedef int                 INT;
typedef unsigned int        UINT;
typedef unsigned int        *PUINT;
typedef const BYTE    cu8;

#if defined(_WIN64)
typedef				__int64 s3264;
typedef unsigned	__int64 u3264;
#else
typedef long			s3264;
typedef unsigned long	u3264;
#endif

#pragma pack (push, 1)

typedef struct
{
	ULONG64 a, b;
} be128;

#pragma pack (pop)

#define MAX_PATH 260
#define BE16(x) _byteswap_ushort(x)
#define BE32(x) _byteswap_ulong(x)
#define BE64(x) _byteswap_uint64(x)

#if _MSC_VER >= 1400
#define GETU32(pt)     (_byteswap_ulong(*(ULONG*)(pt)))
#define PUTU32(ct, st) (*(ULONG*)(ct) = _byteswap_ulong(st))
#define GETU64(pt)     (_byteswap_uint64(*(ULONG64*)(pt)))
#define PUTU64(ct, st) (*(ULONG64*)(ct) = _byteswap_uint64(st))
#define ROR64(x,y)     (_rotr64((x),(y)))
#define ROL64(x,y)     (_rotl64((x),(y)))
#define ROL32(x,y)     (_rotl((x), (y)))
#define ROR32(x,y)     (_rotr((x), (y)))
#define bsf(x,y)       (_BitScanForward((x),(y)))
#define bsr(x,y)       (_BitScanReverse((x),(y)))
#define ProbeForWritePointer(Ptr) ProbeForWriteGenericType(Ptr, PVOID)
#define ProbeForWriteSize_t(Ptr) ProbeForWriteGenericType(Ptr, SIZE_T)
#define ProbeForWriteHandle(Ptr) ProbeForWriteGenericType(Ptr, HANDLE)
#else
#define GETU32(pt) (((ULONG)(pt)[0] << 24) ^ ((ULONG)(pt)[1] << 16) ^ ((ULONG)(pt)[2] <<  8) ^ ((ULONG)(pt)[3]))
#define PUTU32(ct, st) { (ct)[0] = (BYTE)((st) >> 24); (ct)[1] = (BYTE)((st) >> 16); (ct)[2] = (BYTE)((st) >>  8); (ct)[3] = (BYTE)(st); }
#endif

#ifdef _M_IX86
#define ASM_CRYPTO
#endif

/*
 * NOTE: Alignment of the pointers is not verified!
 */
#define ProbeForWriteGenericType(Ptr, Type)                                    \
    do {                                                                       \
        if ((ULONG_PTR)(Ptr) + sizeof(Type) - 1 < (ULONG_PTR)(Ptr) ||          \
            (ULONG_PTR)(Ptr) + sizeof(Type) - 1 >= (ULONG_PTR)MmUserProbeAddress) { \
            ExRaiseAccessViolation();                                          \
        }                                                                      \
        *(volatile Type *)(Ptr) = *(volatile Type *)(Ptr);                     \
    } while (0)

			#define ProbeForWriteUlong(Ptr) ProbeForWriteGenericType(Ptr, ULONG);

// end_winnt

//
// Thread Specific Access Rights
//

#define THREAD_TERMINATE               (0x0001)  // winnt
// end_ntddk end_wdm end_ntifs
#define THREAD_SUSPEND_RESUME          (0x0002)  // winnt
#define THREAD_ALERT                   (0x0004)
#define THREAD_GET_CONTEXT             (0x0008)  // winnt
#define THREAD_SET_CONTEXT             (0x0010)  // winnt
// begin_ntddk begin_wdm begin_ntifs
#define THREAD_SET_INFORMATION         (0x0020)  // winnt
// end_ntddk end_wdm end_ntifs
#define THREAD_QUERY_INFORMATION       (0x0040)  // winnt
// begin_winnt
#define THREAD_SET_THREAD_TOKEN        (0x0080)
#define THREAD_IMPERSONATE             (0x0100)
#define THREAD_DIRECT_IMPERSONATION    (0x0200)
// begin_ntddk begin_wdm begin_ntifs

#define PROCESS_TERMINATE                  (0x0001)  
#define PROCESS_CREATE_THREAD              (0x0002)  
#define PROCESS_SET_SESSIONID              (0x0004)  
#define PROCESS_VM_OPERATION               (0x0008)  
#define PROCESS_VM_READ                    (0x0010)  
#define PROCESS_VM_WRITE                   (0x0020)  
#define PROCESS_DUP_HANDLE                 (0x0040)  
#define PROCESS_CREATE_PROCESS             (0x0080)  
#define PROCESS_SET_QUOTA                  (0x0100)  
#define PROCESS_SET_INFORMATION            (0x0200)  
#define PROCESS_QUERY_INFORMATION          (0x0400)  
#define PROCESS_SUSPEND_RESUME             (0x0800)  
#define PROCESS_QUERY_LIMITED_INFORMATION  (0x1000)  

#define stdcall  __stdcall
#define fastcall __fastcall
#define aligned  __declspec(align(32))

#define p8(x)  ((BYTE*)(x))
#define pcu8(x) ((cu8*)(x))
#define p16(x) ((USHORT*)(x))
#define p32(x) ((ULONG*)(x))
#define p64(x) ((ULONG64*)(x))
#define p3264(x) ((u3264*)(x))
#define pv(x)  ((void*)(x))
#define ppv(x) ((void**)(x))

#define in_reg(a,base,size) ( (a >= base) && (a < base+size)  )
#define addof(a,o)          pv(p8(a)+o)

#define put_b(p,d) { p8(p)[0]  = (BYTE)(d);  p = pv((p8(p) + 1));  }
#define put_w(p,d) { p16(p)[0] = (USHORT)(d); p = pv((p16(p) + 1)); }
#define put_d(p,d) { p32(p)[0] = (ULONG)(d); p = pv((p32(p) + 1)); }

#ifdef _M_X64

#define xor128(d,x,y) { \
	p64(d)[0] = p64(x)[0] ^ p64(y)[0], \
	p64(d)[1] = p64(x)[1] ^ p64(y)[1]; \
   }

#else

#define xor128(d,x,y) { \
	p32(d)[0] = p32(x)[0] ^ p32(y)[0], \
	p32(d)[1] = p32(x)[1] ^ p32(y)[1], \
	p32(d)[2] = p32(x)[2] ^ p32(y)[2], \
	p32(d)[3] = p32(x)[3] ^ p32(y)[3]; \
   }

#endif

#ifndef max
#define max(a,b) (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b) (((a) < (b)) ? (a) : (b))
#endif


#ifndef MAX_PATH
#define MAX_PATH 260
#endif

#define zeromem(m,s) memset(m, 0, s)
#define BYTE_ORDER LITTLE_ENDIAN

#define DBG_MSG
//#define DBG_FILE

#ifdef DBG_MSG
#ifdef DBG_FILE
#define DbgMsg debug_out
#else
#define DbgMsg DbgPrint
#endif
#else
#define DbgMsg
#endif

#ifdef NTDDI_VERSION
#define mem_alloc(x) ExAllocatePool(NonPagedPool, x)
#define mem_free(x)  ExFreePool(x)
#else
#define mem_alloc(x) malloc(x)
#define mem_free(x)  free(x)
#endif

#ifdef DBG_FILE
void debug_out( char *format, ... );
#endif

/* define memcpy for 64 bit aligned blocks */
#ifdef _M_IX86
#define fastcpy(a,b,c) __movsd(p32(a), p32(b), (size_t)(c) / 4)
#else
#define fastcpy(a,b,c) __movsq(p8(a), p8(b), (size_t)(c) / 8)
#endif

#define memcpy(a,b,c) __movsb(p8(a), pcu8(b), (size_t)(c))
#define memset(a,b,c) __stosb(p8(a),(BYTE)(b),(size_t)(c))


// ����jmp��ַ
#define Set_Jump(frm, to) (int)(((int)to - (int)frm) - 5)
#define Set_Call(frm, to) (int)(((int)to - (int)frm) - 5)

#define lock_inc(x)             ( _InterlockedIncrement(x) )
#define lock_dec(x)             ( _InterlockedDecrement(x) )
#define lock_xchg(p,v)          ( _InterlockedExchange((p),(v)) )
#define lock_cmpxchg(a,b,c)     ( _InterlockedCompareExchange((a),(b),(c)) )
#define lock_cmpxchg_ptr(a,b,c) ( pv(_InterlockedCompareExchange(pv(a),(ULONG)(b),(ULONG)(c))) )

#define plist(x) ((PLIST_ENTRY)(x))
#define init_list(a) InitializeListHead(a)
#define insert_list_tail(a,b,c) ExInterlockedInsertTailList(a,plist(b),c)
#define remove_list_head(a,b,c) ExInterlockedRemoveHeadList(a,plist(b),c)

#pragma warning(disable:4995)
#pragma warning(disable:4164)
#pragma intrinsic(memcpy,memset,memcmp)
#pragma intrinsic(strcpy,strcmp,strlen)
#pragma intrinsic(strcat)
#pragma intrinsic(_enable,_disable)
#pragma warning(default:4164)
#pragma warning(default:4995)

#endif
