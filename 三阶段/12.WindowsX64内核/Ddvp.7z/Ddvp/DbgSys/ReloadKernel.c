//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ���������ں˷���ĺ���, ��������Ŀ������.
 */
//===========================================================================
#include <ntifs.h>
#include <strsafe.h>
#include <ntimage.h>
#include "defines.h"
#include "ExtDef.h"
#include "WinBaseEx.h"
#include "IoControlCode.h"
#include "ReloadKernel.h"
#include "Assembly.h"
#include "SysMisc.h"
#include "DbgItem.h"
#include "DbgkUtil.h"
#include "Version.h"

//===========================================================================
//	��ȡϵͳĿ¼(KnownDlls)Ŀ¼���涼��һЩϵͳ�ļ�
//chBuffer	:����ϵͳĿ¼
//===========================================================================
NTSTATUS GetSystemDir( char* chBuffer )
{
    NTSTATUS Status;
    HANDLE hDir;
    HANDLE hSymbolic;
    OBJECT_ATTRIBUTES ObjDir;
    OBJECT_ATTRIBUTES ObjSymbolic;
    UNICODE_STRING usSymbolic;
    ANSI_STRING asSymbolic;
    WCHAR	wchBuffer[256] = {0};
    UNICODE_STRING usDirName = RTL_CONSTANT_STRING( L"\\KnownDlls" );
    UNICODE_STRING usSymbolicName = RTL_CONSTANT_STRING( L"KnownDllPath" );

    KdPrint( ( "Ddvp-> Call GetSystemDir Routine\n" ) );


    if( chBuffer == NULL )
    {
        return STATUS_UNSUCCESSFUL;
    }

    __try
    {
        //
        // 1. ���ں������ȡϵͳĿ¼��һ���Ƚ��鷳�����鰡.
        //
        InitializeObjectAttributes( &ObjDir, &usDirName, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE,
                                    NULL, NULL );

        Status = ZwOpenDirectoryObject( &hDir, DIRECTORY_QUERY, &ObjDir );

        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> ��Ŀ¼����ʧ��:%p \n", Status ) );
            __leave;
        }

        //
        // 2: �򿪷��Ŷ���..������Ӷ������ӵ�ϵͳĿ¼
        //
        InitializeObjectAttributes( &ObjSymbolic, &usSymbolicName, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, hDir, NULL );

        Status = ZwOpenSymbolicLinkObject( &hSymbolic, GENERIC_READ, &ObjSymbolic );

        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> �޷��򿪷��Ŷ���:%p \n", Status ) );
            __leave;
        }

        //
        // ��ѯ���Ŷ�����Ϣ
        //
        usSymbolic.Buffer        = wchBuffer;
        usSymbolic.MaximumLength = 256 * sizeof( WCHAR );
        usSymbolic.Length        = 0;

        Status = ZwQuerySymbolicLinkObject( hSymbolic, &usSymbolic, NULL );

        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp->��ѯ���Ŷ�����Ϣʧ��:%p \n", Status ) );
            __leave;
        }

        KdPrint( ( "Ddvp-> KnownDllPath: %wZ \n", &usSymbolic ) );

        //
        // ת������������Ϣ..
        //
        Status = RtlUnicodeStringToAnsiString( &asSymbolic, &usSymbolic, TRUE );

        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> ת��Unicode�ַ�����ANSI�ַ���ʧ��: %p \n", Status ) );
            __leave;
        }

        // �����ַ���
        RtlCopyMemory( chBuffer, asSymbolic.Buffer, asSymbolic.Length + 1 );

        Status = STATUS_SUCCESS;
//---------------------------------------------------------------------------
    }
    __finally
    {
        if( hDir )
        {
            ZwClose( hDir );
        }

        if( hSymbolic )
        {
            ZwClose( hSymbolic );
        }
    }

    return Status;
}

//===========================================================================
//	�ַ�������
//===========================================================================
_StrCat( char* pDest, char* pSource )
{

    for( ; *pDest != '\0'; pDest++ );

    for( ; *pSource != '\0'; pDest++, pSource++ )
    {
        *pDest = *pSource;
    }

    *pDest = '\0';
}

//===========================================================================
//	��ȡϵͳģ����Ϣ�׸�����
//pStSysModuleInfo	:����ϵͳģ����Ϣ..
//===========================================================================
NTSTATUS DbgObjGetSysModuleInfo( PSYSTEM_MODULE_INFORMATION pStSysModuleInfo )
{
    ULONG ulInfoLen;
    NTSTATUS Status;
    LOADED_MOD_INFO* pStLoaderInfo = NULL;
    UNICODE_STRING usFuncName;
    _QuerySystemInformation NtQuerySystemInforamtion = 0;


    KdPrint( ( "Ddvp-> Call GetModuleInfo Routine! \n" ) );

    if( pStSysModuleInfo == NULL )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    //  ��ȡNtQuerySystemInformation�ĵ�ַ
    //
    if( NULL == NtQuerySystemInforamtion )
    {

        RtlInitUnicodeString( &usFuncName, L"NtQuerySystemInformation" );

        NtQuerySystemInforamtion = ( _QuerySystemInformation )MmGetSystemRoutineAddress( &usFuncName );

        if( !NtQuerySystemInforamtion )
        {
            KdPrint( ( "Ddvp-> ��ȡNtQuerySystemInformation���̵�ַʧ��!\n" ) );
            return STATUS_UNSUCCESSFUL;
        }
    }

    KdPrint( ( "Ddvp-> NtQueryInfomation ��ַ[%p] \n", NtQuerySystemInforamtion ) );

    //
    // ��ߵ���NtQuerySystemInforamtion��ȡϵͳģ����Ϣ, ע����. �����
    // ���ε���, �״λ�ȡģ����Ϣ����. �ٴε��ò��������Ļ�ȡ��Ϣ
    //
    Status = NtQuerySystemInforamtion( SystemModuleInformation, NULL, 0, &ulInfoLen );

    if( !ulInfoLen )
    {
        return STATUS_UNSUCCESSFUL;
    }

    pStLoaderInfo = ( LOADED_MOD_INFO* )ExAllocatePoolWithTag( NonPagedPool,
                    ulInfoLen + sizeof( ULONG ), 'Joen' );

    if( pStLoaderInfo->StSysModuleInfo == NULL )
    {
        return STATUS_UNSUCCESSFUL;
    }

    Status = NtQuerySystemInforamtion( SystemModuleInformation, ( PVOID )pStLoaderInfo,
                                       ulInfoLen, &ulInfoLen );

    if( !NT_SUCCESS( Status ) )
    {
        if( pStLoaderInfo )
        {
            ExFreePool( pStLoaderInfo );
        }

        KdPrint( ( "Ddvp-> ��ѯϵͳģ����Ϣʧ��:%p \n", Status ) );
        return Status;
    }

    __try
    {
        RtlCopyMemory( pStSysModuleInfo, &( pStLoaderInfo->StSysModuleInfo[0] ),
                       sizeof( SYSTEM_MODULE_INFORMATION ) );
    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {
        if( pStLoaderInfo )
        {
            ExFreePool( pStLoaderInfo );
        }

        return GetExceptionCode();
    }

    if( pStLoaderInfo )
    {
        ExFreePool( pStLoaderInfo );
    }

    return STATUS_SUCCESS;
}


//===========================================================================
//	ɾ��PE�ļ���PEͷ
//===========================================================================
VOID RemovePEHeader( PVOID pBase )
{
    PIMAGE_DOS_HEADER pImgDosHeader;
    PIMAGE_NT_HEADERS pImgNtHeader;

    KdPrint( ( "Ddvp-> Calling  RemovePEHeader\n" ) );

    if( pBase == NULL )
    {
        return;
    }

    pImgDosHeader = ( PIMAGE_DOS_HEADER )pBase;
    pImgNtHeader = ( PIMAGE_NT_HEADERS )( ( ULONG )pBase + pImgDosHeader->e_lfanew );

    __try
    {
        // �������PEͷ
        RtlZeroMemory( pBase, pImgNtHeader->FileHeader.SizeOfOptionalHeader +
                       sizeof( IMAGE_FILE_HEADER ) + pImgDosHeader->e_lfanew );

    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {

        KdPrint( ( "Ddvp-> RemovePEHeader�쳣!\n" ) );
    }
}


//===========================================================================
//	��ϵͳ�ļ�ӳ�䵽�ڴ�����
//chPath	:Ҫӳ���ϵͳ�ļ�·��
//ppImageBase	:���ﷵ�ؾ���װ�ػ�ַ
//pulImageSize	:���ﷵ�ؾ����С
//===========================================================================
NTSTATUS MapFileToMem( char* chPath, PVOID* ppImageBase, PULONG pulImageSize )
{
    HANDLE hFile = 0;
    ULONG ulImageSize;
    ULONG ulSizeOfSections;
    ULONG i;
    ULONG ulRvaOfReloc;
    ULONG ulReadLen;
    PVOID pImgBufPoi;
    IO_STATUS_BLOCK StIo_StatusBlock;
    UNICODE_STRING usFilePath;
    ANSI_STRING asFilePath;
    OBJECT_ATTRIBUTES FileObjAttr;
    LARGE_INTEGER liOffset;
    IMAGE_DOS_HEADER ImgDosHeader;
    IMAGE_NT_HEADERS ImgNtHeader;
    PIMAGE_SECTION_HEADER pImgSectHeaders = NULL;
    NTSTATUS Status = STATUS_UNSUCCESSFUL;
    PVOID pNewKernelImage;

    KdPrint( ( "Ddvp-> Call MapFileMem Routine\n" ) );


    if( chPath == NULL || ppImageBase == NULL || pulImageSize == NULL )
    {
        return STATUS_UNSUCCESSFUL;
    }

    *ppImageBase = NULL;

    RtlInitAnsiString( &asFilePath, chPath );

    Status = RtlAnsiStringToUnicodeString( &usFilePath, &asFilePath, TRUE );

    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp->  �޷���UNICODE_STRINGת����ANSI_STRING %08x\n", Status ) );
        return Status;
    }

    InitializeObjectAttributes( &FileObjAttr, &usFilePath, OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE,
                                0, NULL );

    //
    // �����ϵͳ�ļ�, ֻ����..
    //
    Status = ZwCreateFile( &hFile, FILE_READ_DATA, &FileObjAttr, &StIo_StatusBlock, NULL,
                           FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ,
                           FILE_OPEN, FILE_NON_DIRECTORY_FILE | FILE_SYNCHRONOUS_IO_NONALERT, NULL, 0 );

    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> ��ϵͳ�ļ�ʧ��:%08x ", Status ) );
        return Status;
    }

    RtlZeroMemory( &liOffset, sizeof( LARGE_INTEGER ) );

//---------------------------------------------------------------------------
    __try
    {
        Status = ZwReadFile( hFile, 0, NULL, NULL, &StIo_StatusBlock, ( PVOID )&ImgDosHeader,
                             sizeof( IMAGE_DOS_HEADER ), &liOffset, NULL );

        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> �޷���ȡ, IMAGE_DOS_HEADER [0x%08x]\n", Status ) );
            __leave;
        }

        KdPrint( ( "Ddvp-> Read IMAGE_DOS_HEADER %x /%x\n", StIo_StatusBlock.Information,
                   sizeof( IMAGE_DOS_HEADER ) ) );

        // ��ȡNTͷƫ��
        liOffset.LowPart = ImgDosHeader.e_lfanew;

        Status = ZwReadFile( hFile, 0, NULL, NULL, &StIo_StatusBlock, ( PVOID )&ImgNtHeader,
                             sizeof( IMAGE_NT_HEADERS ), &liOffset, NULL );

        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> �޷���ȡNTͷ IMAGE_NT_HEADERS [0x%08x]\n", Status ) );
            __leave;
        }

        KdPrint( ( "Ddvp-> ��ȡNTͷ�ɹ� IMAGE_NT_HEADERS %x/%x\n", StIo_StatusBlock.Information,
                   sizeof( IMAGE_NT_HEADERS ) ) );


        //
        // ��ȡ�����С
        //
        ulImageSize = ImgNtHeader.OptionalHeader.SizeOfImage;

        KdPrint( ( "Ddvp-> �ں˾����С:%p \n", ulImageSize ) );

        pNewKernelImage = ExAllocatePoolWithTag( NonPagedPool, ulImageSize, 'Joen' );

        if( pNewKernelImage == NULL )
        {
            KdPrint( ( "Ddvp-> �����ڴ�ʧ��! \n" ) );
            Status = STATUS_UNSUCCESSFUL;
            __leave;
        }

        RtlZeroMemory( pNewKernelImage, ulImageSize );

        //
        // ��ȡ�����ڴ�С( �ڴ�С = ������* sizeof( IMAGE_SECTION_HEADER )
        //
        ulSizeOfSections = ImgNtHeader.FileHeader.NumberOfSections * sizeof( IMAGE_SECTION_HEADER );

        KdPrint( ( "Ddvp-> ���нھ����С: %p \n", ulSizeOfSections ) );

        pImgSectHeaders = ( PIMAGE_SECTION_HEADER )ExAllocatePoolWithTag(
                              NonPagedPool, ulSizeOfSections, 'Joen' );

        if( pImgSectHeaders == NULL )
        {
            KdPrint( ( "Ddvp-> �����ڴ�ʧ��!\n" ) );
            Status = STATUS_UNSUCCESSFUL;
            __leave;
        }

        RtlZeroMemory( pImgSectHeaders, ulSizeOfSections );

        //
        // ����ƫ�ƾ�ָ���˽ڱ���.. ����, Ȼ���ٽ������ڱ���С��ȡ����
        //
        liOffset.LowPart = ImgDosHeader.e_lfanew + sizeof( IMAGE_NT_HEADERS );

        Status = ZwReadFile( hFile, 0, NULL, NULL, &StIo_StatusBlock, ( PVOID )pImgSectHeaders,
                             ulSizeOfSections, &liOffset, NULL );

        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> �޷���ȡ�ڱ�����:[0x%08x] \n", Status ) );
            Status = STATUS_UNSUCCESSFUL;
            __leave;
        }

        KdPrint( ( "Ddvp-> ��ȡ�ڱ������С %x/%x \n", StIo_StatusBlock.Information, ulSizeOfSections ) );

        //
        // ��ȡ�ض�λ��RVA
        //
        ulRvaOfReloc = ImgNtHeader.
                       OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress;

        RtlZeroMemory( &liOffset, sizeof( LARGE_INTEGER ) );

        //
        // ѭ������ÿһ����
        //
        for( i = 0 ; i < ImgNtHeader.FileHeader.NumberOfSections ; i++ )
        {

            //
            // ���ǽ��ڴ�����������λ��
            //
            liOffset.LowPart = pImgSectHeaders[i].PointerToRawData;

            //
            // �������RVAƫ��, RVA = VA + ImageBase
            //
            ( ULONG )pImgBufPoi = ( ULONG )pNewKernelImage + pImgSectHeaders[i].VirtualAddress;

            //
            // ���ȡ���Ľ�ռ�õ��ڴ�ռ��С. �����ΪVirtualSize�п��ܻ����
            // ��������ȡС��
            //
            ulReadLen = _min( pImgSectHeaders[i].SizeOfRawData, pImgSectHeaders[i].Misc.VirtualSize );


//             KdPrint( ( "Ddvp-> ��ȡ��һ����!\n Name: %s\n  RawOffset(����������λ��): 0x%08x\n  RawSize: 0x%08x\n  Rva: 0x%08x\n  VSize: 0x%08x\n  WriteTo: 0x%08x \n",
//                        pImgSectHeaders[i].Name,
//                        pImgSectHeaders[i].PointerToRawData,
//                        pImgSectHeaders[i].SizeOfRawData,
//                        pImgSectHeaders[i].VirtualAddress,
//                        pImgSectHeaders[i].Misc.VirtualSize,
//                        pImgBufPoi ) );

            //
            // ���������в�����������������,����������д��������,������������ض�λ��
            //
//             if ( ( !( pImgSectHeaders[i].Characteristics & IMAGE_SCN_MEM_DISCARDABLE ) &&
//                     ( pImgSectHeaders[i].Characteristics & IMAGE_SCN_CNT_CODE ) ) ||
//                     pImgSectHeaders[i].VirtualAddress == ulRvaOfReloc )
//             {

            //
            // ������ڵ�����װ�ؽ���.
            //
            Status = ZwReadFile( hFile, 0, NULL, NULL, &StIo_StatusBlock,
                                 pImgBufPoi, ulReadLen, &liOffset, NULL );

            if( !NT_SUCCESS( Status ) )
            {
                KdPrint( ( "Ddvp-> ��ȡ������ʧ�� [0x%08x] \n", Status ) );
                Status = STATUS_UNSUCCESSFUL;
                __leave;
            }

//             }
//             else
//             {
//
//                 //
//                 // �����������������, ��ô���Ǿ����� int 3�Ϳ���..
//                 //
//                 RtlFillMemory( pImgBufPoi, pImgSectHeaders[i].Misc.VirtualSize, 0xcc );
//
// // 				KdPrint( ( "Ddvp-> �����һ�ε�ַ%p, ��С:%p! \n", pImgBufPoi,
// // 				           pImgSectHeaders[i].Misc.VirtualSize ) );
//             }

        }

        RtlZeroMemory( &liOffset, sizeof( LARGE_INTEGER ) );

        // ����ȡNT ͷ..
        Status = ZwReadFile( hFile, 0, NULL, NULL, &StIo_StatusBlock, pNewKernelImage,
                             ImgNtHeader.OptionalHeader.SizeOfHeaders, &liOffset, NULL );

        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> װ��NTͷʧ��![0x%08x] \n", Status ) );
            Status = STATUS_UNSUCCESSFUL;
            __leave;
        }

        KdPrint( ( "Ddvp-> װ��NTͷ�ɹ�%x/%x \n", StIo_StatusBlock.Information,
                   ImgNtHeader.OptionalHeader.SizeOfHeaders ) );

        KdPrint( ( "Ddvp-> ����ڴ�װ��, ������������������ض�λ��\n" ) );

        *ppImageBase = pNewKernelImage;
        *pulImageSize = ulImageSize;
//---------------------------------------------------------------------------
    }
    __finally
    {
        if( pImgSectHeaders )
        {
            ExFreePool( pImgSectHeaders );
        }

        if( hFile )
        {
            ZwClose( hFile );
            hFile = NULL;
        }
    }

    if( !NT_SUCCESS( Status ) )
    {
        ExFreePool( pImgSectHeaders );
        pImgSectHeaders = NULL;

    }

    return Status;
}

//===========================================================================
//	�ض�λģ��
//pModule	:ģ���ַ
//pOldModule	:�ɵ�ģ���ַ, ������������ض�λ
//===========================================================================
NTSTATUS RelocModule( PVOID pModule, PVOID pOldModule )
{
    ULONG m = 0, ulTemp;
    ULONG ulRVA, i, RelocArrayNumber;
    USHORT* RelocArray;
    ULONG ulAddrOfReloc;
    ULONG ulSizeOfReloc;
    ULONG RelocValueByNew;
    ULONG RelocValueByOld;
    PIMAGE_DOS_HEADER pImgDosHeader;
    PIMAGE_NT_HEADERS pImgNtHeader;
    PIMAGE_OPTIONAL_HEADER pImgOptHeader;
    PIMAGE_DATA_DIRECTORY pImgDataDir;
    PIMAGE_BASE_RELOCATION pImgBaseReloc;


    KdPrint( ( "Ddvp-> Calling  RelocModule Routine\n" ) );

    if( pModule == NULL )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( pOldModule == NULL )
    {
        pOldModule = pModule;
    }

    // Get Dos header
    pImgDosHeader = ( PIMAGE_DOS_HEADER )pModule;

    // get nt header
    pImgNtHeader = ( PIMAGE_NT_HEADERS )( ( ULONG )pModule + pImgDosHeader->e_lfanew );

    // get optional headers
    pImgOptHeader = &( pImgNtHeader->OptionalHeader );

    // �����µ��ض�λƫ��
    RelocValueByNew = ( ULONG )pModule - pImgOptHeader->ImageBase;

    // ����ɵ��ض�λƫ��
    RelocValueByOld = ( ULONG )pOldModule - pImgOptHeader->ImageBase;

    //get data directory
    pImgDataDir = pImgOptHeader->DataDirectory;

    //get relocation info �ض�λ����ƫ��
    pImgBaseReloc = ( PIMAGE_BASE_RELOCATION )( ( ULONG )pModule +
                    pImgDataDir[IMAGE_DIRECTORY_ENTRY_BASERELOC].VirtualAddress );

    //get size of relocation �ض�λ�����С
    ulSizeOfReloc = pImgDataDir[IMAGE_DIRECTORY_ENTRY_BASERELOC].Size;

    KdPrint( ( "Ddvp-> �ض�λ��RVA:%p, ��С:%p, ׼�������ض�λ����!\n", pImgBaseReloc, ulSizeOfReloc ) );

    do
    {
        // ��ȡ�ض�λ��ָ��
        RelocArray = ( USHORT* )( ( ULONG )pImgBaseReloc + sizeof( IMAGE_BASE_RELOCATION ) );

        // �����ض�λָ������
        RelocArrayNumber = ( pImgBaseReloc->SizeOfBlock - sizeof( IMAGE_BASE_RELOCATION ) ) / sizeof( USHORT );

        if( !RelocArrayNumber )
        {
            continue;
        }

        //KdPrint( ( "Ddvp-> ���ǵ�%d ���ض�λ��Ŀ, �����Ŀ�ܹ��� %d ����Ŀ, ��߽�һһ���� \n", ++m, RelocArrayNumber ) );

        //relocate this block
        for( i = 0 ; i < RelocArrayNumber ; i++ )
        {

            //
            // ��������ض�λָ��ĵ�ַ ˫��32λ����Ҫ����
            //
            if( RelocArray[i] && ( RelocArray[i] >> 12 ) == IMAGE_REL_BASED_HIGHLOW )
            {

                // �����ض�λ������ض�λ����ƫ��
                ulRVA = ( RelocArray[i] & 0xFFF ) + pImgBaseReloc->VirtualAddress;

                // ���������ģ���ƫ��
                ulAddrOfReloc = ulRVA + ( ULONG )pModule;

                // KdPrint(("Ddvp-> ��:%d���ض�λ, ���:%d --> RVA: %X Address: %X \n",m,i,ulRVA,ulAddrOfReloc));

                //
                // ��߻�Ҫ������ַָ����Ƿ���0xccccccccʲô��, ���������������
                // �Ͳ��ض�λ��.
                //
                ulTemp = *( ULONG* )ulAddrOfReloc;

                if( ulTemp != 0xcccccccc )
                {
                    *( ULONG* )ulAddrOfReloc = ulTemp + RelocValueByOld;
                }

            }
            else
            {
                //KdPrint( ( "Ddvp->  ����ҵ�һ����Ч���ض�λ��...�ѵ���Ҫ������?!\n" ) );
            }
        }

        // ����һ���ض�λ
        ulSizeOfReloc -= pImgBaseReloc->SizeOfBlock;

        // ָ����һ��IMAGE_BASE_RELOCATION �ṹ
        pImgBaseReloc = ( PIMAGE_BASE_RELOCATION )( ( ULONG )pImgBaseReloc + pImgBaseReloc->SizeOfBlock );

    }
    while( ulSizeOfReloc );

    return STATUS_SUCCESS;
}

//===========================================================================
//	װ���µ��ں�, ��ʵ��������Ŀǰ��SSDT��
//pOriginalImageBase	:�ɵ��ں�ģ���ַ
//pNewImageBase			:�µ��ں�ģ���ַ
//ppNewSdt				:�����µ�SSDT��
//����ֵ				:NTSTATUS
//===========================================================================
NTSTATUS FixKernelSDT( PVOID pOriginalImageBase, PVOID pNewImageBase, PSERVICE_DESCRIPTOR_TABLE* ppNewSdt )
{
    ULONG i;
    ULONG ulRVA;
    ULONG ulDist;
    PSERVICE_DESCRIPTOR_TABLE NewSsdt;

    KdPrint( ( "Ddvp-> Calling FixKernelSDT \n" ) );

    //
    // ���ֵ����SSDT�;ɵ�SSDT֮��Ĳ�
    //
    ulDist = ( ULONG )pNewImageBase - ( ULONG )pOriginalImageBase;


    NewSsdt = ( PSERVICE_DESCRIPTOR_TABLE )( ( ULONG )KeServiceDescriptorTable + ulDist );

    __try
    {

        // ��ȡSSDT����
        NewSsdt->ntoskrnl.ServiceLimit = KeServiceDescriptorTable->ntoskrnl.ServiceLimit;

        // �������SSDT������Ŀ��������
        if( KeServiceDescriptorTable->ntoskrnl.CounterTable != NULL )
        {

            // ������ϵͳ�������������Ŀǰ��ƫ��
            ulRVA = ( ULONG )( KeServiceDescriptorTable->ntoskrnl.CounterTable ) - ( ULONG )pOriginalImageBase;

            // ���ڸ�дSSTD�еĵ�ַ
            NewSsdt->ntoskrnl.CounterTable = ( PVOID )( ulRVA + ( ULONG )pNewImageBase );

            // ��д�µ�SSDT���е���Ŀ����
            * ( NewSsdt->ntoskrnl.CounterTable ) = *( KeServiceDescriptorTable->ntoskrnl.CounterTable );

        }

        // �������SSDT���еĲ�������
        if( KeServiceDescriptorTable->ntoskrnl.ArgumentTable != NULL )
        {

            //
            // ���ԭ�����������ԭ�������ƫ��
            //
            ulRVA = ( ULONG )( KeServiceDescriptorTable->ntoskrnl.ArgumentTable ) - ( ULONG )pOriginalImageBase;

            //
            // ��߾Ϳ����������ǵ�SSDT������ָ���ƫ��
            //
            NewSsdt->ntoskrnl.ArgumentTable = ( PBYTE )( ( ULONG )pNewImageBase + ulRVA );

            //
            // ��߻�ҪCOPY�������еĸ�������Ϣ
            //
            RtlCopyMemory( NewSsdt->ntoskrnl.ArgumentTable, KeServiceDescriptorTable->ntoskrnl.ArgumentTable,
                           KeServiceDescriptorTable->ntoskrnl.ServiceLimit );
        }

        //
        // ��������SSDT��ַƫ��
        //
        if( KeServiceDescriptorTable->ntoskrnl.ServiceTable != NULL )
        {

            // ���ԭ����SSDT����ھ����ƫ��
            ulRVA = ( ULONG )( KeServiceDescriptorTable->ntoskrnl.ServiceTable ) - ( ULONG )pOriginalImageBase;

            // ��߾Ϳ�������������SSDT����ƫ����
            NewSsdt->ntoskrnl.ServiceTable = ( PVOID* )( ( ULONG )pNewImageBase + ulRVA );

            // ����������е�SSDT����
            for( i = 0; i < KeServiceDescriptorTable->ntoskrnl.ServiceLimit ; i++ )
            {

                // ��������ÿһ���ƫ��
                ( ULONG )( NewSsdt->ntoskrnl.ServiceTable[i] ) += ulDist;

                // KdPrint( ( "Ddvp-> SSDT Index:%p, Old Address 0x%p, New Address 0x%p \n", i,
                //           KeServiceDescriptorTable->ntoskrnl.ServiceTable[i],
                //           NewSsdt->ntoskrnl.ServiceTable[i] ) );
            }
        }
    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {

        KdPrint( ( "Ddvp->�����µ�SSDT���е���Ŀ�쳣, �쳣��:%p\n", GetExceptionCode() ) );
        return GetExceptionCode();
    }

    *ppNewSdt = NewSsdt;
    return STATUS_SUCCESS;
}
#define NULL    ((void *)0)

PVOID
__stdcall
PeLdrFindExportedRoutineByName(
    IN PVOID DllBase,
    IN PCHAR RoutineName
)
{
    USHORT OrdinalNumber;
    PULONG NameTableBase;
    PUSHORT NameOrdinalTableBase;
    PULONG Addr;
    LONG High;
    LONG Low;
    LONG Middle;
    LONG Result;
    ULONG ExportSize;
    PVOID FunctionAddress;
    PIMAGE_EXPORT_DIRECTORY ExportDirectory;

    __try
    {
        ExportDirectory = ( PIMAGE_EXPORT_DIRECTORY ) RtlImageDirectoryEntryToData(
                              DllBase,
                              TRUE,
                              IMAGE_DIRECTORY_ENTRY_EXPORT,
                              &ExportSize );

        if( ExportDirectory == NULL )
        {
            return NULL;
        }

        NameTableBase = ( PULONG )( ( PCHAR )DllBase + ( ULONG )ExportDirectory->AddressOfNames );
        NameOrdinalTableBase = ( PUSHORT )( ( PCHAR )DllBase + ( ULONG )ExportDirectory->AddressOfNameOrdinals );

        /* Binary Search */
        Low = 0;
        Middle = 0;
        High = ExportDirectory->NumberOfNames - 1;

        while( High >= Low )
        {
            Middle = ( Low + High ) >> 1;
            Result = strcmp( RoutineName, ( PCHAR )DllBase + NameTableBase[Middle] );

            if( Result < 0 )
            {
                High = Middle - 1;
            }
            else if( Result > 0 )
            {
                Low = Middle + 1;
            }
            else
            {
                break;
            }
        }

        if( High < Low )
        {
            return NULL;
        }

        OrdinalNumber = NameOrdinalTableBase[Middle];

        if( ( ULONG )OrdinalNumber >= ExportDirectory->NumberOfFunctions )
        {
            return NULL;
        }

        Addr = ( PULONG )( ( PCHAR )DllBase + ( ULONG )ExportDirectory->AddressOfFunctions );

        FunctionAddress = ( PVOID )( ( PCHAR )DllBase + Addr[OrdinalNumber] );

        ASSERT( ( FunctionAddress <= ( PVOID )ExportDirectory ) ||
                ( FunctionAddress >= ( PVOID )( ( PCHAR )ExportDirectory + ExportSize ) ) );

        return FunctionAddress;

    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {
        KdPrint( ( "Ddvp-> PeLdrFindExportedRoutineByName raise an exception.\n" ) );
        return NULL;
    }
}

PVOID
__stdcall
PeLdrGetModuleBase(
    IN PCHAR ModuleName
)
{
    PVOID Buffer = NULL;
    PVOID ModuleBase = NULL;
    NTSTATUS Status;
    ULONG Size = 0x1000;
    ULONG RetSize = 0;
    ULONG Index = 0;
    PCHAR ImageName;
    STRING strImageName;
    STRING strModuleName;
    ULONG NameOffset = 0;
    PSYSTEM_MODULE_INFORMATION_EX InfoBuffer = NULL;

    RtlInitString( &strModuleName, ModuleName );

    do
    {
        Buffer = ExAllocatePoolWithTag( NonPagedPool, Size, 'Joen' );

        if( Buffer == NULL )
        {
            return NULL;
        }

        Status = ZwQuerySystemInformation( SystemModuleInformation, Buffer, Size, &RetSize );

        if( Status == STATUS_INFO_LENGTH_MISMATCH )
        {
            ExFreePool( Buffer );
            Size = RetSize;
        }
    }
    while( Status == STATUS_INFO_LENGTH_MISMATCH );

    InfoBuffer = ( PSYSTEM_MODULE_INFORMATION_EX )Buffer;

    for( Index = 0; Index < InfoBuffer->ModulesCount; Index++ )
    {
        ImageName = InfoBuffer->Modules[Index].ImageName;
        NameOffset = InfoBuffer->Modules[Index].ModuleNameOffset;

        RtlInitString( &strImageName, ( PCHAR )( ImageName + NameOffset ) );

        if( !RtlCompareString( &strImageName, &strModuleName, TRUE ) )
        {
            ModuleBase = ( PVOID )( InfoBuffer->Modules[Index].Base );
        }
    }

    ExFreePool( Buffer );
    return ModuleBase;
}


BOOL PeLdrProcessImportTable(
    IN PVOID BaseAddress
)
{

    PIMAGE_NT_HEADERS			pImageNtHeader = NULL;
    PIMAGE_IMPORT_DESCRIPTOR	pImportDescriptor = NULL;
    PIMAGE_IMPORT_BY_NAME 		pImageImportByName = NULL;
    PIMAGE_THUNK_DATA32 		pFirstThunkData = NULL;
    PIMAGE_THUNK_DATA32 		pOriginalThunkData = NULL;

    ULONG	ImportSize = 0;
    PVOID 	ModuleBase = NULL;
    PCHAR	ModuleName = NULL;
    CHAR    SzModuleName[256] = {0};
    PCHAR	FuncName   = NULL;
    ULONG 	FuncAddr   = 0;

    __try
    {
        pImportDescriptor = ( PIMAGE_IMPORT_DESCRIPTOR ) RtlImageDirectoryEntryToData(
                                BaseAddress,
                                TRUE,
                                IMAGE_DIRECTORY_ENTRY_IMPORT,
                                &ImportSize );

        if( pImportDescriptor == NULL )
        {
            return FALSE;
        }


        while( pImportDescriptor->Name != 0 )
        {
            ModuleName = ( PCHAR )( ( ULONG )BaseAddress + ( ULONG )pImportDescriptor->Name );

            StringCchCopy( SzModuleName, sizeof( SzModuleName ), ModuleName );

            KdPrint( ( "Ddvp-> ModuleName: %s\n", SzModuleName ) );

            ModuleBase = PeLdrGetModuleBase( SzModuleName );

            if( ModuleBase == NULL )
            {
                //
                // ������ڿ���VirtualKD�ĵ�����, ��û�����DLL��. ��Ҫ����kdbazis.dll
                //
                if( 0 == stricmp( SzModuleName, "KDCOM.DLL" ) )
                {
                    StringCchCopy( SzModuleName, sizeof( SzModuleName ), "kdbazis.dll" );

                    ModuleBase = PeLdrGetModuleBase( SzModuleName );

                    if( ModuleBase == NULL )
                    {
                        KdPrint( ( "Ddvp-> ϵͳ��ȱ��ģ��:%s \n", SzModuleName ) );
                        return FALSE;
                    }
                }
                else if( ( 0 == stricmp( SzModuleName, "hal.dll" ) ) )
                {
                    StringCchCopy( SzModuleName, sizeof( SzModuleName ), "halacpim.dll" );

                    ModuleBase = PeLdrGetModuleBase( SzModuleName );

                    if( ModuleBase == NULL )
                    {
                        StringCchCopy( SzModuleName, sizeof( SzModuleName ), "halmacpi.dll" );

                        ModuleBase = PeLdrGetModuleBase( SzModuleName );

                        if( ModuleBase == NULL )
                        {
                            StringCchCopy( SzModuleName, sizeof( SzModuleName ), "halmps.dll" );

                            ModuleBase = PeLdrGetModuleBase( SzModuleName );

                            if( ModuleBase == NULL )
                            {
                                KdPrint( ( "Ddvp-> ϵͳ��ȱ��ģ��:%s \n", SzModuleName ) );
                                return FALSE;
                            }
                        }
                    }
                }
            }

            KdPrint( ( "Ddvp-> Ҫ�����ģ���ַ0x%.8x ����: %s\n", ModuleBase, SzModuleName ) );

            pFirstThunkData = ( PIMAGE_THUNK_DATA32 )
                              ( ( ULONG )BaseAddress + ( ULONG )( pImportDescriptor->FirstThunk ) );
            pOriginalThunkData = ( PIMAGE_THUNK_DATA32 )
                                 ( ( ULONG )BaseAddress + ( ULONG )( pImportDescriptor->OriginalFirstThunk ) );

            while( pOriginalThunkData->u1.Ordinal != 0
                    &&
                    !( pOriginalThunkData->u1.Ordinal & 0x80000000 ) //Not import by ordinal num
                 )
            {
                pImageImportByName = ( PIMAGE_IMPORT_BY_NAME )
                                     RVATOVA( BaseAddress, pOriginalThunkData->u1.AddressOfData );

                FuncName = ( PCHAR )( &pImageImportByName->Name );

                FuncAddr = ( ULONG )PeLdrFindExportedRoutineByName( ModuleBase, FuncName );

                // KdPrint( ( "Ddvp-> ������ַ0x%.8x ��������: %s\n", FuncAddr, FuncName ) );

                if( FuncAddr == 0 )
                {
                    return FALSE;
                }

                *( ULONG* )pFirstThunkData = FuncAddr;

                pOriginalThunkData++;
                pFirstThunkData++;
            }

            pImportDescriptor++;
        }
    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {
        KdPrint( ( "Ddvp-> PeLdrProcessImportTable raise an excetption.\n" ) );
        return FALSE;
    }

    return TRUE;
}


//
// ��ʼ�����ں˵�ȫ�ֱ���
//
NTSTATUS
DbgObjInitGlobalVariable(
    PDBG_RELOAD_KERNEL lpReloadKernel,
    PSYMBOLS_INFO lpSymbols )
{
    int i;
    PBYTE lpKiTrap01;
    ULONG ulDebugPortHookLength;
    PBYTE PspExitThreadTemp;
    PBYTE lpPspExitThread;
    PBYTE lpNtMapViewOfSection;
    PBYTE lpMiUnmapViewOfSection;
    PBYTE lpKiDispatchException;
    ULONG_PTR OldPspUserThreadStartup;
    PBYTE NewPspCreateThread = NULL;
    BYTE byTemp[] = {0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };

    //
    // MmUserProbeAddress
    //
    *( PULONG )( ( ULONG )lpReloadKernel->NewKernelBase + lpSymbols->ulMmUserProbeAddress ) =
        *( PULONG )( lpSymbols->ulMmUserProbeAddress + ( ULONG )lpReloadKernel->OriginalKernelBase );

	//
	// MmHighestUserAddress
	//
	*( PULONG )( ( ULONG )lpReloadKernel->NewKernelBase + lpSymbols->ulMmHighestUserAddress ) =
		*( PULONG )( lpSymbols->ulMmHighestUserAddress + ( ULONG )lpReloadKernel->OriginalKernelBase );

	//
	// PsProcessType
	//
	*( PULONG )( ( ULONG )lpReloadKernel->NewKernelBase + lpSymbols->ulPsProcessType ) =
	*( PULONG )( lpSymbols->ulPsProcessType + ( ULONG )lpReloadKernel->OriginalKernelBase );

    //
    // PsInitialSystemProcess
    //
    *( PULONG )( ( ULONG )lpReloadKernel->NewKernelBase + lpSymbols->ulPsInitialSystemProcess ) =
        *( PULONG )( lpSymbols->ulPsInitialSystemProcess + ( ULONG )lpReloadKernel->OriginalKernelBase );

    //
    // ObpKernelHandleTable
    //
    *( PULONG )( ( ULONG )lpReloadKernel->NewKernelBase + lpSymbols->ulObpKernelHandleTable ) =
        *( PULONG )( lpSymbols->ulObpKernelHandleTable + ( ULONG )lpReloadKernel->OriginalKernelBase );

    //
    // KdDebuggerEnabled
    //
    *( PULONG )( ( ULONG )lpReloadKernel->NewKernelBase + lpSymbols->ulKdDebuggerEnabled ) =
        *( PULONG )( lpSymbols->ulKdDebuggerEnabled + ( ULONG )lpReloadKernel->OriginalKernelBase );

//---------------------------------------------------------------------------
    //
    // �ⲻ��, ����Ҫɨ������. �ҵ�..  ���ｫ�����ں˵�PspCreateThread����
    // PspUserThreadStartup�����޸���.. ���ǿ����������ռ�DbgkCreateThread.
    //
    OldPspUserThreadStartup = ( ( ULONG_PTR )lpReloadKernel->OriginalKernelBase +
                                ( ULONG_PTR )lpSymbols->lpPspUserThreadStartup );

    NewPspCreateThread = ( PBYTE )( ( ULONG_PTR )lpReloadKernel->NewKernelBase +
                                    ( ULONG_PTR )lpSymbols->lpPspCreateThread );

    for( i = 0; i < 0x700; i++, NewPspCreateThread++ )
    {
        if( *( ULONG_PTR* )NewPspCreateThread == OldPspUserThreadStartup )
        {
            *( ULONG_PTR* )NewPspCreateThread = ( ULONG_PTR )Naked_PspUserThreadStartup;

            KdPrint( ( "Ddvp-> New PspCreateThread PspUserThreadStartup Address:%p Value:%p !\n",
                       NewPspCreateThread, Naked_PspUserThreadStartup ) );
        }
    }

//---------------------------------------------------------------------------
    //
    // ����������PspExitThread..
    //
    lpPspExitThread = ( PBYTE )( ( ULONG_PTR )lpReloadKernel->NewKernelBase +
                                 ( ULONG_PTR )lpSymbols->lpPspExitThread );

    for( i = 0,
            PspExitThreadTemp = lpPspExitThread ;
            i <= 0x300; i++, PspExitThreadTemp++ )
    {

        // 		805c8554 399fbc000000    cmp     dword ptr [edi+0BCh],ebx
        // 		805c855a 7424            je      nt!PspExitThread+0x2b2 (805c8580)
        if( *( PspExitThreadTemp + 6 ) == 0x74 && *( PspExitThreadTemp + 8 ) == 0xf6
                && *( PspExitThreadTemp + 15 ) == 0x75  && *( PspExitThreadTemp + 17 ) == 0x80 )
        {
            //
            // ���λ�õ������뻹�е����.. ��������ʽ.
            // 805d3328 83bfbc00000000  cmp     dword ptr [edi+0BCh],0
            // 805c9554 399fbc000000    cmp     dword ptr [edi+0BCh],ebx
            // ���һ��BYTE
            //
            if( *( PspExitThreadTemp - 5 ) == 0xe8 )
            {
                ulDebugPortHookLength = 8;
                lpPspExitThread = PspExitThreadTemp;
            }
            else if( *( PspExitThreadTemp - 6 ) == 0xe8 )
            {
                ulDebugPortHookLength = 9;
                PspExitThreadTemp--;
                lpPspExitThread = PspExitThreadTemp;
            }
            else
            {
                continue;
            }

            break;
        }

    }

    if( i >= 0x300 )
    {
        KdPrint( ( "Ddvp-> Call PspExitThread ����������ʧ��!\n" ) );

        return STATUS_UNSUCCESSFUL;
    }
    else
    {
        //
        // ������ж�DebugPort��ȫ����nop
        //
        SafeCopyMemory( PspExitThreadTemp, byTemp, ulDebugPortHookLength );
    }

    for( i = 0,
            PspExitThreadTemp = lpPspExitThread ;
            i <= 0x50; i++, PspExitThreadTemp++ )
    {

        // 		805c856b ffb74c020000    push    dword ptr [edi+24Ch]
        // 		805c8571 e8541e0700      call    nt!DbgkExitProcess (8063a3ca)
        if( *( PspExitThreadTemp + 0 ) == 0xff &&  *( PspExitThreadTemp + 1 ) == 0xb7 &&
                *( PspExitThreadTemp + 2 ) == 0x4c && *( PspExitThreadTemp + 3 ) == 0x2 )
        {
            PspExitThreadTemp += 6;
            _Call( PspExitThreadTemp, _DbgkExitProcess, 0 );
            break;
        }
    }

    if( i >= 0x50 )
    {
        KdPrint( ( "Ddvp-> Call DbgkExitProcess ����������ʧ��!\n" ) );

        return STATUS_UNSUCCESSFUL;
    }

//---------------------------------------------------------------------------
    for( i = 0; i <= 0x20; i++, PspExitThreadTemp++ )
    {
        // 		805c8576 eb08            jmp     nt!PspExitThread+0x2b2 (805c8580)
        // 		805c8578 ff7508          push    dword ptr [ebp+8]
        // 		805c857b e8d01d0700      call    nt!DbgkExitThread (8063a35
        if( *( PspExitThreadTemp + 0 ) == 0xff &&
                *( PspExitThreadTemp + 1 ) == 0x75 &&
                *( PspExitThreadTemp + 2 ) == 0x08 )
        {
            PspExitThreadTemp += 3;
            _Call( PspExitThreadTemp, _DbgkExitThread, 0 );
            break;
        }
    }

    if( i >= 0x20 )
    {
        KdPrint( ( "Ddvp-> Call DbgkExitThread ����������ʧ��!\n" ) );

        return STATUS_UNSUCCESSFUL;
    }

//---------------------------------------------------------------------------
    //
    // �ҹ������ں˵�NtMapViewOfSection����
    //
    lpNtMapViewOfSection = *( PBYTE* )( ( ULONG_PTR )lpReloadKernel->NewSsdt->ntoskrnl.ServiceTable +
                                        ( ULONG_PTR )GetNtMapViewOfSectionIndex() * 4 );

    for( i = 0; i <= 0x300; i++, lpNtMapViewOfSection++ )
    {
        /*
        805b22e8 ff75e0          push    dword ptr [ebp-20h]
        805b22eb ff75b4          push    dword ptr [ebp-4Ch]
        805b22ee ff75e4          push    dword ptr [ebp-1Ch]
        805b22f1 53              push    ebx
        805b22f2 e81f160900      call    nt!DbgkMapViewOfSection (80643916)
        */
        if( *( lpNtMapViewOfSection + 0 ) == 0xff &&
                *( lpNtMapViewOfSection + 3 ) == 0xff &&
                *( lpNtMapViewOfSection + 6 ) == 0xff &&
                *( lpNtMapViewOfSection + 9 ) == 0x53 )
        {
            lpNtMapViewOfSection += 10;
            _Call( lpNtMapViewOfSection, _DbgkMapViewOfSection, 0 );
            break;
        }
    }

    if( i >= 0x300 )
    {
        KdPrint( ( "Ddvp-> Call NtMapViewOfSection ����������ʧ��!\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

    for( i = 0; i <= 0x100; i++, lpNtMapViewOfSection++ )
    {
        /*
        nt!NtMapViewOfSection+0x30b:
        805b2311 ff75e0          push    dword ptr [ebp-20h]
        805b2314 ff75b4          push    dword ptr [ebp-4Ch]
        805b2317 ff75e4          push    dword ptr [ebp-1Ch]
        805b231a 53              push    ebx
        805b231b e8f6150900      call    nt!DbgkMapViewOfSection (80643916)
        */
        if( *( lpNtMapViewOfSection + 0 ) == 0xff &&
                *( lpNtMapViewOfSection + 3 ) == 0xff &&
                *( lpNtMapViewOfSection + 6 ) == 0xff &&
                *( lpNtMapViewOfSection + 9 ) == 0x53 )
        {
            lpNtMapViewOfSection += 10;
            _Call( lpNtMapViewOfSection, _DbgkMapViewOfSection, 0 );
            break;
        }

    }

    if( i >= 0x100 )
    {
        KdPrint( ( "Ddvp-> Call NtMapViewOfSection ����������ʧ��!\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

//---------------------------------------------------------------------------
    lpMiUnmapViewOfSection = ( PBYTE )( ( ULONG_PTR )lpReloadKernel->NewKernelBase +
                                        ( ULONG_PTR )lpSymbols->lpMiUnmapViewOfSection );

    for( i = 0; i <= 0x200; i++, lpMiUnmapViewOfSection++ )
    {
        /*
        nt!MiUnmapViewOfSection+0x184:
        805b2dd2 ff75fc          push    dword ptr [ebp-4]
        805b2dd5 e8120c0900      call    nt!DbgkUnMapViewOfSection (806439ec)
        */
        if( *( lpMiUnmapViewOfSection + 0 ) == 0xff &&
                *( lpMiUnmapViewOfSection + 1 ) == 0x75 &&
                *( lpMiUnmapViewOfSection + 2 ) == 0xfc )
        {
            lpMiUnmapViewOfSection += 3;
            _Call( lpMiUnmapViewOfSection, _DbgkUnMapViewOfSection, 0 );
            break;
        }
    }

    if( i >= 0x200 )
    {
        KdPrint( ( "Ddvp-> Call NtUnMapViewOfSection ����������ʧ��!\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

//---------------------------------------------------------------------------

    lpKiDispatchException = ( PBYTE )( ( ULONG_PTR )lpReloadKernel->NewKernelBase +
                                       ( ULONG_PTR )lpSymbols->lpKiDispatchException );

    for( i = 0; i <= 0x400; i++, lpKiDispatchException++ )
    {
        /*
        804fe651 57              push    edi
        804fe652 6a01            push    1
        804fe654 56              push    esi
        804fe655 e87e4c1400      call    nt!DbgkForwardException (806432d8)
        */
        if( *( lpKiDispatchException + 0 ) == 0x57 &&
                *( lpKiDispatchException + 1 ) == 0x6a &&
                *( lpKiDispatchException + 3 ) == 0x56 )
        {
            lpKiDispatchException += 4;
            _Call( lpKiDispatchException, _DbgkForwardException, 0 );
            break;
        }
    }

    if( i >= 0x400 )
    {
        KdPrint( ( "Ddvp-> Call KiDispatchException ����������ʧ��!\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

    for( i = 0; i <= 0x200; i++, lpKiDispatchException++ )
    {
        /*
        804fe7da 6a01            push    1
        804fe7dc 6a01            push    1
        804fe7de 56              push    esi
        804fe7df e8f44a1400      call    nt!DbgkForwardException (806432d8)
        */
        if( *( lpKiDispatchException + 0 ) == 0x6a &&
                *( lpKiDispatchException + 2 ) == 0x6a &&
                *( lpKiDispatchException + 4 ) == 0x56 )
        {
            lpKiDispatchException += 5;
            _Call( lpKiDispatchException, _DbgkForwardException, 0 );
            break;
        }
    }

    if( i >= 0x200 )
    {
        KdPrint( ( "Ddvp-> Call KiDispatchException ����������ʧ��!\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

    for( i = 0; i <= 0x50; i++, lpKiDispatchException++ )
    {
        /*
        804fe7ec 6a01            push    1
        804fe7ee 57              push    edi
        804fe7ef 56              push    esi
        804fe7f0 e8e34a1400      call    nt!DbgkForwardException (806432d8)
        */
        if( *( lpKiDispatchException + 0 ) == 0x6a &&
                *( lpKiDispatchException + 2 ) == 0x57 &&
                *( lpKiDispatchException + 3 ) == 0x56 )
        {
            lpKiDispatchException += 4;
            _Call( lpKiDispatchException, _DbgkForwardException, 0 );
            break;
        }
    }

    if( i >= 0x50 )
    {
        KdPrint( ( "Ddvp-> Call KiDispatchException ����������ʧ��!\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

//---------------------------------------------------------------------------

    lpKiTrap01 = ( PBYTE )( ( ULONG_PTR )lpReloadKernel->NewKernelBase +
                            ( ULONG_PTR )lpSymbols->lpKiTrap01 );

    for( i = 0; i <= 0x100; i++, lpKiTrap01++ )
    {
        /*
        8054238b 7561            jne     nt!KiTrap01+0xd2 (805423ee)
        8054238d 8b4d68          mov     ecx,dword ptr [ebp+68h]
        80542390 81f920155480    cmp     ecx,offset nt!KiFastCallEntry (80541520)
        80542396 0f84c4feffff    je      nt!KiTrap00+0xc0 (80542260)
        */
        if( *( lpKiTrap01 + 0 ) == 0x75 &&
                *( lpKiTrap01 + 2 ) == 0x8b &&
                *( lpKiTrap01 + 5 ) == 0x81 )
        {
            lpKiTrap01 += 5;
            _Call( lpKiTrap01, _KiTrap01, 1 );
            break;
        }

    }

    return STATUS_SUCCESS;
}


//===========================================================================
//	�����ں�, �����ں�ģ����Ϣ
//===========================================================================
NTSTATUS DbgObjOverLoadKernel( PDBG_RELOAD_KERNEL pStLoaderInfo )
{
    NTSTATUS Status;
    PVOID pImageBase = NULL;
    ULONG ulImageSize;
    PBYTE chTemp = NULL;
    BYTE chSystemDir[256] = {0};
    BYTE chPath[256] = "\\DosDevices\\";
    PSERVICE_DESCRIPTOR_TABLE pNewSSDT;
    SYSTEM_MODULE_INFORMATION StSysModuleInfo = {0};

    KdPrint( ( "Ddvp-> Call LoadKernel Routine!\n" ) );

    if( pStLoaderInfo == NULL )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // 1.����ϵͳ�ں�ģ��. ����ntkrnlpa.exe����ntoskrnl.exe, ����֮һ
    //
    Status = DbgObjGetSysModuleInfo( &StSysModuleInfo );

    if( !NT_SUCCESS( Status ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // 2.��ȡϵͳ��Ŀ¼
    //
    Status = GetSystemDir( chSystemDir );

    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> ��ѯϵͳ��Ŀ¼ʧ��! \n" ) );
        return Status;
    }

    //
    //  ��ѯϵͳģ���Ƿ���ϵͳĿ¼����, �ѵ����������ֽ�?
    //
    chTemp = strstr( _strupr( StSysModuleInfo.ImageName ) , _strupr( &chSystemDir[2] ) );

    if( chTemp == NULL )
    {
        KdPrint( ( "Ddvp-> ��Ч·��! \n" ) );
        return STATUS_UNSUCCESSFUL;
    }

    _StrCat( chSystemDir, ( char* )( ( ULONG )chTemp + strlen( &chSystemDir[2] ) ) );
    _StrCat( chPath, chSystemDir );

//---------------------------------------------------------------------------
    //
    // 3:ӳ���ں��ļ�..   MapFileToMem ("C:\\windows\\system32\\ntkrpamp.exe",&pImageBase,&ulImageSize);
    //
    Status = MapFileToMem( chPath , &pImageBase , &ulImageSize );

    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> ӳ���ڴ��ļ�ʧ�� 0x%x \n", Status ) );
        return Status;
    }

    //
    // 4.�ض�λģ��
    //
    Status =  RelocModule( pImageBase, StSysModuleInfo.Base );

    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> �ض�λģ��ʧ�� 0x%x \n", Status ) );

        if( pImageBase )
        {
            ExFreePool( pImageBase );
        }

        return Status;
    }

    //
    // �޸������
    //
    if( !PeLdrProcessImportTable( pImageBase ) )
    {
        KdPrint( ( "Ddvp-> ������޸�ʧ��\n" ) );

        if( pImageBase )
        {
            ExFreePool( pImageBase );
        }

        return STATUS_UNSUCCESSFUL;
    }

    //
    // 5.�����µ��ں�SSDT��
    //
    Status = FixKernelSDT( StSysModuleInfo.Base, pImageBase, &pNewSSDT );

    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> װ���µ��ں�ʧ��!\n" ) );

        if( pImageBase )
        {
            ExFreePool( pImageBase );
        }

        return Status;
    }

    //
    // 6.ɾ�������µľ���PEͷ
    //
    RemovePEHeader( pImageBase );

    //
    // 7.����߲�����һЩ�����ݴ洢����, �µ�SSDT��, �µ��ں˻�ַ, ԭ�����ں˻�ַ
    //
    pStLoaderInfo->NewSsdt = pNewSSDT;
    pStLoaderInfo->NewKernelBase = pImageBase;
    pStLoaderInfo->OriginalKernelBase = StSysModuleInfo.Base;

    return STATUS_SUCCESS;
}

//
// �ͷ������ں��ļ�
//
NTSTATUS DbgObjFreeKernel( PDBG_RELOAD_KERNEL pStLoaderInfo )
{
    if( !pStLoaderInfo )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( pStLoaderInfo->NewKernelBase )
    {
        ExFreePool( pStLoaderInfo->NewKernelBase );

        KdPrint( ( "Ddvp-> Call DbgObjFreeKernel New Kernel Address:%p \n",
                   pStLoaderInfo->NewKernelBase ) );

        return STATUS_SUCCESS;
    }

    return STATUS_UNSUCCESSFUL;
}