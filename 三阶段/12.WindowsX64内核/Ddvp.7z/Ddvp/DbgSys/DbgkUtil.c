//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ������Ϣ�շ����ƺ���, ģ���˴󲿷�Windows�����������
 */
//===========================================================================

#include <ntifs.h>
#include "defines.h"
#include "ExtDef.h"
#include "DbgItem.h"
#include "WinBaseEx.h"
#include "IoControlCode.h"
#include "DbgkUtil.h"
#include "Version.h"
#include "Driver.h"
#include "SysMisc.h"
#include "Assembly.h"
#include "ReloadKernel.h"


//===========================================================================
static PKiSegSsToTrapFrame		lpKiSegSsToTrapFrame;
static PKeContextToKframes		lpKeContextToKframes;
static PKiEspToTrapFrame		lpKiEspToTrapFrame;
static PVOID					KeUserExceptionDispatcher;
static PGetFileNameForSection	lpMmGetFileNameForSection;
static PObDuplicateObject		lpObDuplicateObject;
static PKeFreezeAllThreads		lpKeFreezeAllThreads;
static PKeThawAllThreads		lpKeThawAllThreads;
static PObpCloseHandle			lpObpCloseHandle;
static PKeContextFromKframes	lpKeContextFromKframes;
static PKiCheckForAtlThunk		lpKiCheckForAtlThunk;
static PKDEBUG_ROUTINE			ulKiDebugRoutine;
static PRtlDispatchException	lpRtlDispatchException;
static PRtlRaiseException		lpRtlRaiseException;
static PPsGetNextProcessThread	lpPsGetNextProcessThread;
static PPsResumeThread			lpPsResumeThread;
static PMmGetFileNameForAddress	lpMmGetFileNameForAddress;

static ULONG_PTR				ulKeI386XMMIPresent;
static ULONG_PTR				ulKeFeatureBits;

extern SYMBOLS_INFO			g_StSymbolsInfo;
extern DBG_RELOAD_KERNEL	g_StReloadKernel;
static const LARGE_INTEGER __emptyLargeInteger = {{0, 0}};

//===========================================================================
#define MAX_NTDBG_EVENT 9

wchar_t* DbgEvtName[ MAX_NTDBG_EVENT + 1] =
{
    L"EXCEPTION_DEBUG_EVENT",
    L"CREATE_THREAD_DEBUG_EVENT",
    L"CREATE_PROCESS_DEBUG_EVENT",
    L"EXIT_THREAD_DEBUG_EVENT",
    L"EXIT_PROCESS_DEBUG_EVENT",
    L"LOAD_DLL_DEBUG_EVENT",
    L"UNLOAD_DLL_DEBUG_EVENT",
    L"OUTPUT_DEBUG_STRING_EVENT",
    L"RIP_EVENT",
    L"Unknown Debug Event"
};

//===========================================================================
HANDLE
NTAPI
DbgkpSectionToFileHandle( IN PVOID Section )
{
    NTSTATUS Status;
    POBJECT_NAME_INFORMATION FileName;
    OBJECT_ATTRIBUTES ObjectAttributes;
    IO_STATUS_BLOCK IoStatusBlock;
    HANDLE Handle;

    PAGED_CODE();

    ASSERT( lpMmGetFileNameForSection );

    /* Get the filename of the section */
    Status = lpMmGetFileNameForSection( Section, &FileName );

    if( !NT_SUCCESS( Status ) )
    {
        return NULL;
    }

    /* Initialize object attributes */
    InitializeObjectAttributes( &ObjectAttributes,
                                &FileName->Name,
                                OBJ_CASE_INSENSITIVE |
                                OBJ_FORCE_ACCESS_CHECK |
                                OBJ_KERNEL_HANDLE,
                                NULL,
                                NULL );

    /* Open the file */
    Status = ZwOpenFile( &Handle,
                         GENERIC_READ | SYNCHRONIZE,
                         &ObjectAttributes,
                         &IoStatusBlock,
                         FILE_SHARE_DELETE | FILE_SHARE_READ | FILE_SHARE_WRITE,
                         FILE_SYNCHRONOUS_IO_NONALERT );

    /* Free the name and return the handle if we succeeded */
    ExFreePool( FileName );

    if( !NT_SUCCESS( Status ) )
    {
        return NULL;
    }

    return Handle;
}

BOOLEAN
DbgkpSuspendProcess(
    VOID
)
{
    PAGED_CODE();

    ASSERT( lpKeFreezeAllThreads );

    lpKeFreezeAllThreads();
    return TRUE;
}




NTSTATUS
NTAPI
_PsSuspendThread( IN PETHREAD Thread,
                  OUT PULONG PreviousCount OPTIONAL )
{
    NTSTATUS Status;
    ULONG OldCount = 0;
    static PKeSuspendThread lpKeSuspendThread = NULL;
    static PKeForceResumeThread lpKeForceResumeThread = NULL;

    PAGED_CODE();

    if( !lpKeSuspendThread )
    {
        lpKeSuspendThread = ( PKeSuspendThread )
                            ( ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase +
                              ( ULONG_PTR )g_StSymbolsInfo.lpKeSuspendThread );
    }

    if( !lpKeForceResumeThread )
    {
        lpKeForceResumeThread = ( PKeForceResumeThread )
                                ( ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase +
                                  ( ULONG_PTR )g_StSymbolsInfo.lpKeForceResumeThread );
    }

    ASSERT( lpKeSuspendThread );
    ASSERT( lpKeForceResumeThread );

    /* Guard with SEH because KeSuspendThread can raise an exception */
    __try
    {
        /* Check if we're suspending ourselves */
        if( Thread == PsGetCurrentThread() )
        {
            /* Do the suspend */
            // OldCount = lpKeSuspendThread( &Thread->Tcb );
            OldCount = lpKeSuspendThread( GetEThreadTcbPoint( Thread ) );

            /* We are done */
            Status = STATUS_SUCCESS;
        }
        else
        {
            /* Acquire rundown */
            if( ExAcquireRundownProtection( GetEThreadRundownProtect( Thread ) ) )
            {
                /* Make sure the thread isn't terminating */
				if( GetEThreadTcbTerminatedBit( Thread ) )
                {
                    /* Fail */
                    Status = STATUS_THREAD_IS_TERMINATING;
                }
                else
                {
                    /* Otherwise, do the suspend */
                    OldCount = lpKeSuspendThread( GetEThreadTcbPoint( Thread ) );

                    /* Check if it terminated during the suspend */
					if( GetEThreadTcbTerminatedBit( Thread ) )				
                    {
                        /* Wake it back up and fail */
                        lpKeForceResumeThread( GetEThreadTcbPoint( Thread ) );

                        Status = STATUS_THREAD_IS_TERMINATING;
                        OldCount = 0;
                    }
                }

                /* Release rundown protection */
                ExReleaseRundownProtection( GetEThreadRundownProtect( Thread ) );

                /* We are done */
                Status = STATUS_SUCCESS;
            }
            else
            {
                /* Thread is terminating */
                Status = STATUS_THREAD_IS_TERMINATING;
            }
        }
    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {
        /* Get the exception code */
        Status = GetExceptionCode();

        /* Don't fail if we merely couldn't write the handle back */
        if( Status != STATUS_SUSPEND_COUNT_EXCEEDED )
        {
            Status = STATUS_SUCCESS;
        }
    }

    /* Write back the previous count */
    if( PreviousCount )
    {
        *PreviousCount = OldCount;
    }
    return Status;
}



VOID
NTAPI
DbgkpResumeProcess( VOID )
{
    PAGED_CODE();

    ASSERT( lpKeThawAllThreads );

    lpKeThawAllThreads();
}


NTSTATUS
NTAPI
ObCloseHandle( IN HANDLE Handle,
               IN KPROCESSOR_MODE AccessMode )
{

    ASSERT( lpObpCloseHandle );

    /* Call the internal API */
    return lpObpCloseHandle( Handle, AccessMode );
}


NTSTATUS
NTAPI
DbgkpSendApiMessage(
    IN OUT LPNT_DEBUG_EVENT KDbgEvt,
    IN PDBG_ITEM DbgItem,
    IN BOOLEAN SuspendProcess )
{
    BOOLEAN Suspended = FALSE;
    NTSTATUS Status = STATUS_UNSUCCESSFUL;

    PAGED_CODE();

    /* Suspend process if required */
    if( SuspendProcess )
    {
        Suspended = DbgkpSuspendProcess();
    }

    ExAcquireFastMutex( &DbgItem->DebugObject.Mutex );

    DbgItem->Status = STATUS_PENDING;

    ASSERT( KDbgEvt->dwDebugEventCode == UNLOAD_DLL_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == EXIT_THREAD_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == EXIT_PROCESS_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == EXCEPTION_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == STATUS_SINGLE_STEP ||
            KDbgEvt->dwDebugEventCode == STATUS_BREAKPOINT  ||
            KDbgEvt->dwDebugEventCode == CREATE_THREAD_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == CREATE_PROCESS_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == LOAD_DLL_DEBUG_EVENT );

    KdPrint( ( "Ddvp-> Call _DbgkpSendApiMessage DbgEvt: 0x%p EvtCode: %p %ws\n",
               KDbgEvt, KDbgEvt->dwDebugEventCode,
               DbgEvtName[KDbgEvt->dwDebugEventCode >
                          MAX_NTDBG_EVENT ? MAX_NTDBG_EVENT : KDbgEvt->dwDebugEventCode - 1] ) );


    //
    // �������¼��������. �ȴ�R3��ȡ
    //
    InsertTailList( &DbgItem->DebugObject.EventList, &KDbgEvt->ListEntry );

    //
    // �����־��ʾ��Ҫ�ȴ�R3���
    //
    KDbgEvt->Flags |= PSF_WAIT_FOR_EVENT;

    //
    // ֪ͨR3������ȡ��
    //
    KeSetEvent( &DbgItem->DebugObject.EventRecv, IO_NO_INCREMENT, FALSE );

    /* Release the object lock */
    ExReleaseFastMutex( &DbgItem->DebugObject.Mutex );

    //
    // �ȴ�R3�������
    //
    KeWaitForSingleObject( &DbgItem->DebugObject.EventSend,
                           Executive,
                           KernelMode,
                           FALSE,
                           NULL );

    KdPrint( ( "Ddvp-> Call  DbgkpSendApiMessage R3 ������� DbgEvtCode %p Status %p \n",
               KDbgEvt->dwDebugEventCode, DbgItem->Status ) );

    /* Flush the instruction cache */
    ZwFlushInstructionCache( NtCurrentProcess(), NULL, 0 );

    /* Resume the process if it was suspended */
    if( Suspended )
    {
        DbgkpResumeProcess();
    }

    return DbgItem->Status;
}

//
// �����쳣��������.
// DebugPort:TRUE���͸����Զ˿�, FALSE���͸��쳣�˿�
// ����ֵ����ϵͳ��DbgkForwardException����. ���ǲ����쳣�Ĳ��ǵ���
// ��ܵļ���Eprocess
//
ULONG
NTAPI
__DbgkForwardException( IN PEXCEPTION_RECORD ExceptionRecord,
                        IN BOOLEAN DebugPort,
                        IN BOOLEAN SecondChance,
                        IN DBG_ITEM* DbgItem )
{
    BOOL bRet;
    PEB* Peb;
    NTSTATUS Status;
    LPNT_DEBUG_EVENT KDbgEvt = NULL;

    PAGED_CODE();

    KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ) , 'Joen' );
    if( !KDbgEvt )
    {
        KdPrint( ( "Ddvp-> Call _DbgkForwardException.ExAllocatePool Error \n" ) );
        return FALSE;
    }
    RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

    KDbgEvt->dwProcessId = ( DWORD )PsGetCurrentProcessId();
    KDbgEvt->dwThreadId = ( DWORD )PsGetCurrentThreadId();

    if( ExceptionRecord->ExceptionCode == STATUS_BREAKPOINT )
    {
        //
        // �������д����״ζϵ�
        //
        if( g_StSymbolsInfo.lpDbgBreakPoint ==
                ExceptionRecord->ExceptionAddress )
        {
            Peb = GetEProcessPeb( DbgItem->Debugged );
            Peb->BeingDebugged = 0;

        }

        KDbgEvt->dwDebugEventCode = STATUS_BREAKPOINT;

    }
    else if( ExceptionRecord->ExceptionCode == STATUS_SINGLE_STEP )
    {
        KDbgEvt->dwDebugEventCode = STATUS_SINGLE_STEP;
    }
    else
    {
        KDbgEvt->dwDebugEventCode = EXCEPTION_DEBUG_EVENT;
    }

    KDbgEvt->u.Exception.ExceptionRecord = *ExceptionRecord;
    KDbgEvt->u.Exception.dwFirstChance = !SecondChance;

    Status = DbgkpSendApiMessage( KDbgEvt, DbgItem, DebugPort );
    if( NT_SUCCESS( Status ) )
    {
        bRet = TRUE;
    }
    else
    {
        bRet = FALSE;
    }

    return bRet;
}

//
// �����쳣��������.
// DebugPort:TRUE���͸����Զ˿�, FALSE���͸��쳣�˿�
// ����ֵ����ϵͳ��DbgkForwardException����. ���ǲ����쳣�Ĳ��ǵ���
// ��ܵļ���Eprocess
//
ULONG
NTAPI
_DbgkForwardException( IN PEXCEPTION_RECORD ExceptionRecord,
                       IN BOOLEAN DebugPort,
                       IN BOOLEAN SecondChance )
{
    BOOL bRet;
	PEB* Peb;
    NTSTATUS Status;
    DBG_ITEM* DbgItem;
    PEPROCESS Process = PsGetCurrentProcess();
    LPNT_DEBUG_EVENT KDbgEvt = NULL;

    PAGED_CODE();

    if( ( ULONG_PTR )ExceptionRecord->ExceptionAddress > 0x80000000 )
    {
        return FALSE;
    }

    DbgItem = DbgItemFindItem( NULL, Process );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            KdPrint( ( "Ddvp-> Call  _DbgkForwardException ����� Eprocess: %p \n", DbgItem->Debugged ) );
            DbgItemDeRefItem( DbgItem );
        }
        return FALSE;
    }

    KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ) , 'Joen' );
    if( !KDbgEvt )
    {
        KdPrint( ( "Ddvp-> Call _DbgkForwardException.ExAllocatePool Error \n" ) );
        return FALSE;
    }
    RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

    KDbgEvt->dwProcessId = ( DWORD )PsGetCurrentProcessId();
    KDbgEvt->dwThreadId = ( DWORD )PsGetCurrentThreadId();

    if( ExceptionRecord->ExceptionCode == STATUS_BREAKPOINT )
    {
		//
		// �������д����״ζϵ�
		//
		if ( g_StSymbolsInfo.lpDbgBreakPoint ==
			ExceptionRecord->ExceptionAddress )
		{
			Peb = GetEProcessPeb( DbgItem->Debugged );
			Peb->BeingDebugged = 0;

		}

        KDbgEvt->dwDebugEventCode = STATUS_BREAKPOINT;

    }
    else if( ExceptionRecord->ExceptionCode == STATUS_SINGLE_STEP )
    {
        KDbgEvt->dwDebugEventCode = STATUS_SINGLE_STEP;
    }
    else
    {
        KDbgEvt->dwDebugEventCode = EXCEPTION_DEBUG_EVENT;
    }

    KDbgEvt->u.Exception.ExceptionRecord = *ExceptionRecord;
    KDbgEvt->u.Exception.dwFirstChance = !SecondChance;

    Status = DbgkpSendApiMessage( KDbgEvt, DbgItem, DebugPort );
    if( NT_SUCCESS( Status ) )
    {
        bRet = TRUE;
    }
    else
    {
        bRet = FALSE;
    }

    return bRet;
}

/* DLL ж����Ϣ*/
VOID
NTAPI
_DbgkUnMapViewOfSection(
    IN PVOID BaseAddress )
{
    LPNT_DEBUG_EVENT KDbgEvt = NULL;
    PDBG_ITEM DbgItem = NULL;
    PEPROCESS Process = PsGetCurrentProcess();

    if( ( ExGetPreviousMode() == KernelMode ) )
    {
        return;
    }


    DbgItem = DbgItemFindItem( NULL, Process );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            DbgItemDeRefItem( DbgItem );
        }
        return;
    }

    // KdPrint( ( "Ddvp-> Call  _DbgkUnMapViewOfSection \n" ) );

    KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ) , 'Joen' );
    if( !KDbgEvt )
    {
        KdPrint( ( "Ddvp-> Call _DbgkUnMapViewOfSection.ExAllocatePool Error \n" ) );
        return;
    }

    RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

    KDbgEvt->dwDebugEventCode = UNLOAD_DLL_DEBUG_EVENT;
    KDbgEvt->dwProcessId = ( DWORD )PsGetCurrentProcessId();
    KDbgEvt->dwThreadId = ( DWORD )PsGetCurrentThreadId();

    KDbgEvt->u.UnloadDll.lpBaseOfDll = BaseAddress;

    DbgkpSendApiMessage( KDbgEvt, DbgItem, TRUE );

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }
}


ULONG
KiCopyInformation(
    IN OUT PEXCEPTION_RECORD ExceptionRecord1,
    IN PEXCEPTION_RECORD ExceptionRecord2
)
{

    //
    // Copy one exception record to another and return value that causes
    // an exception handler to be executed.
    //

    RtlCopyMemory( ( PVOID )ExceptionRecord1,
                   ( PVOID )ExceptionRecord2,
                   sizeof( EXCEPTION_RECORD ) );

    return EXCEPTION_EXECUTE_HANDLER;
}

/*
 * ģ��ϵͳ��KiDispatchException����, �������TRUE��ʾ�ɹ������쳣,
 * ����FALSE��ʾ�쳣û�д���, ��Ҫ����ϵͳ��KiDispatchException����
 *
 */
BOOL
_KiDispatchException(
    IN PEXCEPTION_RECORD ExceptionRecord,
    IN PKEXCEPTION_FRAME ExceptionFrame,
    IN PKTRAP_FRAME TrapFrame,
    IN KPROCESSOR_MODE PreviousMode,
    IN BOOLEAN FirstChance
)
{
    LONG Length;
    BOOL bRet = FALSE;
    ULONG UserStack1;
    DBG_ITEM* DbgItem;
    ULONG UserStack2;
    CONTEXT ContextFrame;
    PEPROCESS Process = PsGetCurrentProcess();
    EXCEPTION_RECORD ExceptionRecord1, ExceptionRecord2;

    if( PreviousMode == KernelMode )
    {
        return FALSE;
    }

    DbgItem = DbgItemFindItem( NULL, Process );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            KdPrint( ( "Ddvp-> Call  _KiDispatchException ����� Eprocess: %p \n", DbgItem->Debugged ) );
            DbgItemDeRefItem( DbgItem );
        }
        return FALSE;
    }

    ContextFrame.ContextFlags = CONTEXT_FULL | CONTEXT_DEBUG_REGISTERS;

    if( ( PreviousMode == UserMode ) || KdDebuggerEnabled )
    {
        //
        // ��������û�ģʽ, ����˵�����ں˵������������.
        // һ���Ǻ�����Ҫ��ȡ���еļĴ�����Ϣ��
        //
        ContextFrame.ContextFlags |= CONTEXT_FLOATING_POINT;
        if( ulKeI386XMMIPresent )
        {
            ContextFrame.ContextFlags |= CONTEXT_EXTENDED_REGISTERS;
        }
    }

    //
    // ��ȡ��ܼĴ�����Ϣ
    //
    lpKeContextFromKframes( TrapFrame, ExceptionFrame, &ContextFrame );

    //
    // ����������������, ����int 3 �����ݿ�ܵ�ʱ��eip++��, �����
    // ����������û�̬��
    //
    switch( ExceptionRecord->ExceptionCode )
    {
    case STATUS_BREAKPOINT:
        ContextFrame.Eip--;
        break;

    case KI_EXCEPTION_ACCESS_VIOLATION:
        ExceptionRecord->ExceptionCode = STATUS_ACCESS_VIOLATION;

        if( PreviousMode == UserMode )
        {

            if( lpKiCheckForAtlThunk( ExceptionRecord, &ContextFrame ) != FALSE )
            {
                bRet = TRUE;
                goto Handled1;
            }

            if( ( SharedUserData->ProcessorFeatures[PF_NX_ENABLED] == TRUE ) &&
                    ( ExceptionRecord->ExceptionInformation [0] == EXCEPTION_EXECUTE_FAULT ) )
            {

                __asm int 3;
                ASSERT( 1 );
//                 if ( ( ( ulKeFeatureBits & KF_GLOBAL_32BIT_EXECUTE ) != 0 ) ||
//                         ( PsGetCurrentProcess()->Pcb.Flags.ExecuteEnable != 0 ) ||
//                         ( ( ( KeFeatureBits & KF_GLOBAL_32BIT_NOEXECUTE ) == 0 ) &&
//                           ( PsGetCurrentProcess()->Pcb.Flags.ExecuteDisable == 0 ) ) )
//                 {
//                     ExceptionRecord->ExceptionInformation [0] = 0;
//                 }
            }
        }
        break;
    }

    //
    // ����ģʽ���ǷǷ���.
    //
    ASSERT( ( !( ( PreviousMode == KernelMode ) &&
                 ( ContextFrame.EFlags & EFLAGS_V86_MASK ) ) ) );


    if( FirstChance == TRUE )
    {

        //
        // ���м�һЩ�����ں˴����Ĵ�����û�м�����. ��Ȼ�ⲻ��ʲô������
        // ���������ʱ��������windbgһ��ĵ������Ļ�, ����������������쳣���̵���
        // ���Ի����. ���Բ���ʹ��windbg�������ǵ�Debugger..
        //

        //
        // ��һ�ε��� _DbgkForwardException����
        //
        if( __DbgkForwardException( ExceptionRecord, TRUE, FALSE, DbgItem ) )
        {
            bRet = TRUE;
            goto Handled2;
        }

        //
        // Transfer exception information to the user stack, transition
        // to user mode, and attempt to dispatch the exception to a frame
        // based handler.

        ExceptionRecord1.ExceptionCode = 0; // satisfy no_opt compilation

repeat:
        try
        {

            //
            // If the SS segment is not 32 bit flat, there is no point
            // to dispatch exception to frame based exception handler.
            //

            if( TrapFrame->HardwareSegSs != ( KGDT_R3_DATA | RPL_MASK ) ||
                    TrapFrame->EFlags & EFLAGS_V86_MASK )
            {
                ExceptionRecord2.ExceptionCode = STATUS_ACCESS_VIOLATION;
                ExceptionRecord2.ExceptionFlags = 0;
                ExceptionRecord2.NumberParameters = 0;

                __asm int 3;
                lpRtlRaiseException( &ExceptionRecord2 );
            }

            //
            // Compute length of context record and new aligned user stack
            // pointer.
            //

            UserStack1 = ( ContextFrame.Esp & ~CONTEXT_ROUND ) - CONTEXT_ALIGNED_SIZE;

            //
            // Probe user stack area for writability and then transfer the
            // context record to the user stack.
            //

            ProbeForWrite( ( PCHAR )UserStack1, CONTEXT_ALIGNED_SIZE, CONTEXT_ALIGN );
            RtlCopyMemory( ( PULONG )UserStack1, &ContextFrame, sizeof( CONTEXT ) );

            //
            // Compute length of exception record and new aligned stack
            // address.
            //
            Length = ( sizeof( EXCEPTION_RECORD ) - ( EXCEPTION_MAXIMUM_PARAMETERS -
                       ExceptionRecord->NumberParameters ) * sizeof( ULONG ) + 3 ) & ( ~3 );
            UserStack2 = UserStack1 - Length;

            //
            // Probe user stack area for writeability and then transfer the
            // context record to the user stack area.
            // N.B. The probing length is Length+8 because there are two
            //      arguments need to be pushed to user stack later.
            //
            ProbeForWrite( ( PCHAR )( UserStack2 - 8 ), Length + 8, sizeof( ULONG ) );
            RtlCopyMemory( ( PULONG )UserStack2, ExceptionRecord, Length );

            //
            // Push address of exception record, context record to the
            // user stack.  They are the two parameters required by
            // _KiUserExceptionDispatch.
            //
            *( PULONG )( UserStack2 - sizeof( ULONG ) ) = UserStack1;
            *( PULONG )( UserStack2 - 2 * sizeof( ULONG ) ) = UserStack2;

            //
            // Set new stack pointer to the trap frame.
            //
            lpKiSegSsToTrapFrame( TrapFrame, KGDT_R3_DATA );
            lpKiEspToTrapFrame( TrapFrame, ( UserStack2 - sizeof( ULONG ) * 2 ) );

            //
            // Force correct R3 selectors into TrapFrame.
            //
            TrapFrame->SegCs = SANITIZE_SEG( KGDT_R3_CODE, PreviousMode );
            TrapFrame->SegDs = SANITIZE_SEG( KGDT_R3_DATA, PreviousMode );
            TrapFrame->SegEs = SANITIZE_SEG( KGDT_R3_DATA, PreviousMode );
            TrapFrame->SegFs = SANITIZE_SEG( KGDT_R3_TEB, PreviousMode );
            TrapFrame->SegGs = 0;

            //
            // Set the address of the exception routine that will call the
            // exception dispatcher and then return to the trap handler.
            // The trap handler will restore the exception and trap frame
            // context and continue execution in the routine that will
            // call the exception dispatcher.
            //
            TrapFrame->Eip = ( ULONG )KeUserExceptionDispatcher;

            if( DbgItem )
            {
                DbgItemDeRefItem( DbgItem );
            }
            return TRUE;

        }
        except( KiCopyInformation( &ExceptionRecord1,
                                   ( GetExceptionInformation() )->ExceptionRecord ) )
        {

            //
            // If the exception is a stack overflow, then attempt
            // to raise the stack overflow exception. Otherwise,
            // the user's stack is not accessible, or is misaligned,
            // and second chance processing is performed.
            //
            if( ExceptionRecord1.ExceptionCode == STATUS_STACK_OVERFLOW )
            {
                ExceptionRecord1.ExceptionAddress = ExceptionRecord->ExceptionAddress;

                RtlCopyMemory( ( PVOID )ExceptionRecord,
                               &ExceptionRecord1, sizeof( EXCEPTION_RECORD ) );
                goto repeat;
            }
        }
    }

    //
    // ��2�δ���. ��߻����ȷ��͸����Զ˿�Ȼ���͸��쳣�˿�
    //
    if( __DbgkForwardException( ExceptionRecord, TRUE, TRUE, DbgItem ) )
    {
        bRet = TRUE;
        goto Handled2;
    }
    else if( __DbgkForwardException( ExceptionRecord, FALSE, TRUE, DbgItem ) )
    {
        bRet = TRUE;
        goto Handled2;
    }
    else
    {
        ZwTerminateProcess( NtCurrentProcess(), ExceptionRecord->ExceptionCode );

        KeBugCheckEx(
            KERNEL_MODE_EXCEPTION_NOT_HANDLED,
            ExceptionRecord->ExceptionCode,
            ( ULONG )ExceptionRecord->ExceptionAddress,
            ( ULONG )TrapFrame, 0 );
    }

Handled1:

    lpKeContextToKframes( TrapFrame, ExceptionFrame, &ContextFrame,
                          ContextFrame.ContextFlags, PreviousMode );
Handled2:

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }
    return bRet;
}



VOID
NTAPI
_DbgkMapViewOfSection( IN PVOID Section,
                       IN PVOID BaseAddress,
                       IN ULONG SectionOffset,
                       IN ULONG_PTR ViewSize )
{
    HANDLE FileHandle;
    NTSTATUS Status;
    ULONG_PTR ulPsSystemDllBase;
    PDBG_ITEM DbgItem = NULL;
    LPNT_DEBUG_EVENT KDbgEvt = NULL;
    PEPROCESS Process = PsGetCurrentProcess();
    PETHREAD Thread = PsGetCurrentThread();
    PIMAGE_NT_HEADERS NtHeader;
    BYTE BufferInt3[] = {0xcc, 0xcc, 0xcc};

    PAGED_CODE();

    if( ( ExGetPreviousMode() == KernelMode ) )
    {
        /* Don't notify the debugger */
        return;
    }

    DbgItem = DbgItemFindItem( NULL, Process );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            DbgItemDeRefItem( DbgItem );
        }
        return;
    }

    do
    {
        //
        // �����������ϴμ���ntdll.dll��ʱ����λ��, ���ﻹԭ�´���
        //
        if( DbgItem->ProcessFlags & PSF_LOAD_NTDLL )
        {
            __try
            {

                //
                // �ָ�����д���ntdll.dll������
                //
                ulPsSystemDllBase =
                    ( *( ULONG_PTR* )( ( ULONG_PTR ) g_StReloadKernel.OriginalKernelBase +
                                       g_StSymbolsInfo.ulPsSystemDllBase ) );

                if( !MmIsAddressValid( ( PVOID )( ulPsSystemDllBase + 4 ) ) )
                {
                    KdPrint( ( "Ddvp-> Call  _DbgkMapViewOfSection Call MmIsAddressValid Error! \n" ) );
                    return;
                }

                SafeCopyMemory(	( PVOID )( ulPsSystemDllBase + 4 ),
                                DbgItem->Buffer,
                                sizeof( PVOID ) + sizeof( L"ntdll.dll" ) + 1 );

                DbgItem->ProcessFlags &= ( ~PSF_LOAD_NTDLL );

                RtlZeroMemory( DbgItem->Buffer, sizeof( DbgItem->Buffer ) );
            }
            __except( EXCEPTION_EXECUTE_HANDLER )
            {
                Status = GetExceptionCode();
                KdPrint( ( "Ddvp-> Call  _DbgkCreateThread __try Error Status :0x%p! \n", Status ) );
                return;
            }
        }

        // KdPrint( ( "Ddvp-> Call _DbgkMapViewOfSection \n" ) );

        KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ), 'Joen' );
        if( !KDbgEvt )
        {
            KdPrint( ( "Ddvp-> Call _DbgkMapViewOfSection.ExAllocatePool Error \n" ) );
            break;
        }

        RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

        KDbgEvt->dwDebugEventCode = LOAD_DLL_DEBUG_EVENT;


        KDbgEvt->dwProcessId = ( DWORD ) PsGetCurrentProcessId();
        KDbgEvt->dwThreadId = ( DWORD ) PsGetCurrentThreadId();

        KDbgEvt->u.LoadDll.lpBaseOfDll = BaseAddress;
        KDbgEvt->u.LoadDll.dwDebugInfoFileOffset = 0;
        KDbgEvt->u.LoadDll.nDebugInfoSize = 0;

        RtlMoveMemory( &KDbgEvt->u.LoadDll.StClientID,
                       GetThreadCid( Thread ), sizeof( CLIENT_ID ) );

        FileHandle = DbgkpSectionToFileHandle( Section );

        KDbgEvt->u.LoadDll.hFile = FileHandle;

        /* Get the NT Headers */
        NtHeader = RtlImageNtHeader( BaseAddress );

        if( NtHeader )
        {
            /* Fill out debug information */
            KDbgEvt->u.LoadDll.dwDebugInfoFileOffset =
                NtHeader->FileHeader.PointerToSymbolTable;

            KDbgEvt->u.LoadDll.nDebugInfoSize =
                NtHeader->FileHeader.NumberOfSymbols;
        }

        /* Send the message */
        DbgkpSendApiMessage( KDbgEvt, DbgItem, TRUE );

        /* Close the handle */
        ObCloseHandle( FileHandle, KernelMode );


    }
    while( 0 );

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }
}


VOID
NTAPI
_DbgkCreateThread( IN PETHREAD Thread,
                   IN PVOID StartAddress )
{
    int i;
    PVOID Temp;
	PEB* Peb;
    NTSTATUS Status;
    HANDLE FileHandle;
    PDBG_ITEM DbgItem = NULL;
    ULONG_PTR ulPsSystemDllBase;
    ULONG_PTR ulPsNtDllPathName;
    PIMAGE_NT_HEADERS NtHeader;
    OBJECT_ATTRIBUTES ObjectAttributes;
    IO_STATUS_BLOCK IoStatusBlock;
    LPNT_DEBUG_EVENT KDbgEvt = NULL;
    LPNT_CREATE_PROCESS_DEBUG_INFO CreateInfo = NULL;
    LPNT_LOAD_DLL_DEBUG_INFO LoadDll = NULL;
    PEPROCESS Process = PsGetCurrentProcess();

    if( KeGetCurrentIrql() !=  PASSIVE_LEVEL )
    {
        KeLowerIrql( PASSIVE_LEVEL );
    }

    ASSERT( lpObDuplicateObject );
    PAGED_CODE();
//---------------------------------------------------------------------------
    //
    // �ڶ�˻�����, �޷��ѿ�DbgkCreateThread�ĵ���ʱ��. û�취
    // ֻ���������ֶ��ĵ�����. ͨ�رȽϽ�������..
    //
    i = 0;
    do
    {
        if( FALSE == CompareProcessName( Process ) )
        {
            break;
        }

        DbgItem = DbgItemFindItem( NULL, Process );
        if( DbgItem )
        {
            DbgItemDeRefItem( DbgItem );
            break;
        }

        KdPrint( ( "Ddvp-> Call _DbgkCreateThread Sleep 50\n" ) );

        _Sleep( 50 );
    }
    while( i <= 20 );
//---------------------------------------------------------------------------
    DbgItem = DbgItemFindItem( NULL, Process );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            KdPrint( ( "Ddvp-> Call _DbgkCreateThread Debugger:%p Debugged:%p \n",
                       DbgItem->Debugger, DbgItem->Debugged ) );

            DbgItemDeRefItem( DbgItem );
        }
        return;
    }

    //
    // �ж�Ŀǰ���͵���Ϣ�ǽ��̴��������̴߳�����Ϣ
    //
    if( DbgItem->ProcessFlags & PSF_CREATE_REPORTED_BIT )
    {

        KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ) , 'Joen' );
        if( !KDbgEvt )
        {
            KdPrint( ( "Ddvp-> Call _DbgkCreateThread.ExAllocatePool Error \n" ) );
            return;
        }

        RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

		Peb = ( PEB* )GetEProcessPeb( Process );
		Peb->BeingDebugged = TRUE;

        //
        // �ռ� CREATE_PROCESS_DEBUG_EVENT ������Ϣ
        //
        KDbgEvt->dwDebugEventCode = CREATE_PROCESS_DEBUG_EVENT;

        KDbgEvt->dwProcessId = ( DWORD )PsGetCurrentProcessId();

        KDbgEvt->dwThreadId = ( DWORD )PsGetCurrentThreadId();

        CreateInfo = &KDbgEvt->u.CreateProcessInfo;

        FileHandle = DbgkpSectionToFileHandle( GetEprocessSectionObject( Process ) );

        CreateInfo->hFile = FileHandle;

        CreateInfo->hProcess = PsGetCurrentProcess();

        CreateInfo->hThread = PsGetCurrentThread();

        CreateInfo->lpBaseOfImage =
            GetEprocessSectionBaseAddress( Process );

        CreateInfo->dwDebugInfoFileOffset = 0;
        CreateInfo->nDebugInfoSize = 0;

        /* Get the NT Header */
        NtHeader = RtlImageNtHeader( GetEprocessSectionBaseAddress( Process ) );

        if( NtHeader )
        {
            /* Fill out data from the header */
            CreateInfo->lpStartAddress =
                ( PVOID )( ( ULONG_PTR )NtHeader->OptionalHeader.ImageBase +
                           NtHeader->OptionalHeader.AddressOfEntryPoint );

            CreateInfo->dwDebugInfoFileOffset =
                NtHeader->FileHeader.PointerToSymbolTable;

            CreateInfo->nDebugInfoSize =
                NtHeader->FileHeader.NumberOfSymbols;
        }

        CreateInfo->lpImageName = NULL;
        CreateInfo->fUnicode = TRUE;

        //
        // ���߳���Ϣ�����߳��б�
        //
        {
            PTHREAD_INFO ThreadInfo = ExAllocatePoolWithTag( NonPagedPool, sizeof( THREAD_INFO ), 'Joen' );

            RtlZeroMemory( ThreadInfo, sizeof( THREAD_INFO ) );

            ThreadInfo->ThreadId = ( HANDLE )KDbgEvt->dwThreadId;

            ExAcquireFastMutex( &DbgItem->DebuggedThread.Mutex );

            InsertTailList( &DbgItem->DebuggedThread.ThreadList, &ThreadInfo->ListEntry );

            KdPrint( ( "Ddvp->_CreateProcess %p Thread Insert List!\n", ThreadInfo->ThreadId ) );

            /* Release the mutex */
            ExReleaseFastMutex( &DbgItem->DebuggedThread.Mutex );
        }

        KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Send Process Create Message! \n" ) );

        /* Send the message */
        DbgkpSendApiMessage( KDbgEvt, DbgItem, FALSE );

        KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Send Process Create Message Success! \n" ) );

        ObCloseHandle( FileHandle, KernelMode );
//---------------------------------------------------------------------------
        KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ) , 'Joen' );
        if( !KDbgEvt )
        {
            KdPrint( ( "Ddvp-> Call _DbgkCreateThread.ExAllocatePool Error \n" ) );
            return;
        }

        RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

        //
        // ntdll.dll���DLL�ļ���������DLL���ط�ʽ��һ��, ����Ҫ����ʲô
        // NtMapViewOfSection ����
        //

        KDbgEvt->dwDebugEventCode = LOAD_DLL_DEBUG_EVENT;
        KDbgEvt->dwProcessId = ( DWORD )PsGetCurrentProcessId();
        KDbgEvt->dwThreadId = ( DWORD )PsGetCurrentThreadId();

        ulPsSystemDllBase =
            ( *( ULONG_PTR* )( ( ULONG_PTR ) g_StReloadKernel.OriginalKernelBase +
                               g_StSymbolsInfo.ulPsSystemDllBase ) );

        LoadDll = &KDbgEvt->u.LoadDll;

        LoadDll->lpBaseOfDll = ( PVOID )ulPsSystemDllBase;
        LoadDll->dwDebugInfoFileOffset = 0;
        LoadDll->nDebugInfoSize = 0;
        LoadDll->lpImageName = NULL;

        /* Get the NT Headers PspSystemDllBase */
        NtHeader = RtlImageNtHeader( ( PVOID )ulPsSystemDllBase );

        if( NtHeader )
        {
            /* Fill out debug information */
            LoadDll->dwDebugInfoFileOffset = NtHeader->FileHeader.PointerToSymbolTable;

            LoadDll->nDebugInfoSize = NtHeader->FileHeader.NumberOfSymbols;
        }

        __try
        {
            //
            // �����ȡģ������, ���Ƿ���ģ���PEͷ����..����ָ��.
            //
            Temp = ( PVOID )( ulPsSystemDllBase + sizeof( PVOID ) + 4 );

            if( !MmIsAddressValid( ( PVOID )( ulPsSystemDllBase + 4 ) ) )
            {
                KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Call MmIsAddressValid Error! \n" ) );
                return;
            }

            SafeCopyMemory( DbgItem->Buffer,
                            ( PVOID )( ulPsSystemDllBase + 4 ),
                            sizeof( PVOID ) + sizeof( L"ntdll.dll" ) + 1 );

            SafeCopyMemory( ( PVOID )( ulPsSystemDllBase + 4 ), &Temp, sizeof( PVOID ) );

            SafeCopyMemory( ( PVOID )( ulPsSystemDllBase + sizeof( PVOID ) + 4 ),
                            L"ntdll.dll", sizeof( L"ntdll.dll" ) + 1 );
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            Status = GetExceptionCode();
            KdPrint( ( "Ddvp-> Call  _DbgkCreateThread __try Error Status :0x%p! \n", Status ) );
            return;
        }

        LoadDll->lpImageName = ( PVOID )( ulPsSystemDllBase + 4 );

        ulPsNtDllPathName =
            ( ( ULONG )g_StReloadKernel.OriginalKernelBase + g_StSymbolsInfo.ulPsNtDllPathName );

        /* Get a handle */
        InitializeObjectAttributes( &ObjectAttributes,
                                    ( PUNICODE_STRING )ulPsNtDllPathName,
                                    OBJ_CASE_INSENSITIVE |
                                    OBJ_KERNEL_HANDLE |
                                    OBJ_FORCE_ACCESS_CHECK,
                                    NULL,
                                    NULL );

        FileHandle = NULL;

        Status = ZwOpenFile( &FileHandle,
                             GENERIC_READ | SYNCHRONIZE,
                             &ObjectAttributes,
                             &IoStatusBlock,
                             FILE_SHARE_DELETE |
                             FILE_SHARE_READ |
                             FILE_SHARE_WRITE,
                             FILE_SYNCHRONOUS_IO_NONALERT );

        if( NT_SUCCESS( Status ) )
        {
            LoadDll->hFile = FileHandle;

            KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Send Load ntdll.dll Message! \n" ) );

            DbgkpSendApiMessage( KDbgEvt, DbgItem, TRUE );

            KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Send Load ntdll.dll Message Success! \n" ) );


            /* Close the handle */
            ObCloseHandle( FileHandle, KernelMode );
        }

        DbgItem->ProcessFlags &= ( ~PSF_CREATE_REPORTED_BIT );
        DbgItem->ProcessFlags |= PSF_LOAD_NTDLL;
    }
    else
    {
        KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ) , 'Joen' );
        if( !KDbgEvt )
        {
            KdPrint( ( "Ddvp-> Call _DbgkCreateThread.ExAllocatePool Error \n" ) );
            return;
        }

        RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

        //
        // �����̴߳�����Ϣ
        //
        KDbgEvt->dwDebugEventCode = CREATE_THREAD_DEBUG_EVENT;

        KDbgEvt->dwProcessId = ( DWORD )PsGetCurrentProcessId();
        KDbgEvt->dwThreadId = ( DWORD )PsGetCurrentThreadId();

        KDbgEvt->u.CreateThread.hThread = PsGetCurrentThread();

        KDbgEvt->u.CreateThread.lpStartAddress = ( LPTHREAD_START_ROUTINE )StartAddress;

        //
        // �ռ��߳̽��̶߳���
        //
        {
            PTHREAD_INFO ThreadInfo = ExAllocatePoolWithTag( NonPagedPool, sizeof( THREAD_INFO ), 'Joen' );

            RtlZeroMemory( ThreadInfo, sizeof( THREAD_INFO ) );

            ThreadInfo->ThreadId = ( HANDLE )KDbgEvt->dwThreadId;

            ExAcquireFastMutex( &DbgItem->DebuggedThread.Mutex );

            InsertTailList( &DbgItem->DebuggedThread.ThreadList, &ThreadInfo->ListEntry );

            /* Release the mutex */
            ExReleaseFastMutex( &DbgItem->DebuggedThread.Mutex );

            KdPrint( ( "Ddvp->_CreateThread %p Thread Insert List \n", ThreadInfo->ThreadId ) );
        }

        KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Send Thread Create Message! \n" ) );

        DbgkpSendApiMessage( KDbgEvt, DbgItem, TRUE );

        KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Send Thread Create Message Success! \n" ) );
    }

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }
}

VOID
NTAPI
_DbgkExitProcess( IN NTSTATUS ExitStatus )
{
    PDBG_ITEM DbgItem = NULL;
    PLIST_ENTRY Entry;
    LPNT_DEBUG_EVENT KDbgEvt = NULL;
    PEPROCESS Process = PsGetCurrentProcess();
    PETHREAD Thread = PsGetCurrentThread();
    PTHREAD_INFO ThreadInfo = NULL;

    PAGED_CODE();

    DbgItem = DbgItemFindItem( NULL, Process );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            DbgItemDeRefItem( DbgItem );
        }
        return;
    }

    KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ) , 'Joen' );

    if( !KDbgEvt )
    {
        KdPrint( ( "Ddvp-> Call _DbgkExitProcess.ExAllocatePool Error \n" ) );
        return;
    }

    RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

    KDbgEvt->dwDebugEventCode = EXIT_PROCESS_DEBUG_EVENT;
    KDbgEvt->dwProcessId = ( DWORD )PsGetCurrentProcessId();
    KDbgEvt->dwThreadId = ( DWORD )PsGetCurrentThreadId();

    KDbgEvt->u.ExitProcess.dwExitCode = ExitStatus;

    //
    // ��������, ��ͷ���������
    //
    while( !IsListEmpty( &DbgItem->DebuggedThread.ThreadList ) )
    {
        Entry = RemoveHeadList( &DbgItem->DebuggedThread.ThreadList );

        //
        // ��ȡ����ָ��
        //
        ThreadInfo = CONTAINING_RECORD( Entry, THREAD_INFO, ListEntry );

        KdPrint( ( "Ddvp->_ExitProcess %p Thread Exit \n", ThreadInfo->ThreadId ) );

        ExAcquireFastMutex( &DbgItem->DebuggedThread.Mutex );

        /* Release the mutex */
        ExReleaseFastMutex( &DbgItem->DebuggedThread.Mutex );

        ExFreePoolWithTag( ThreadInfo, 'Joen' );
    }

    /* Send the message */
    DbgkpSendApiMessage( KDbgEvt, DbgItem, FALSE );

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }
}

VOID
NTAPI
_DbgkExitThread( IN NTSTATUS ExitStatus )
{
    BOOLEAN Suspended;
    LPNT_DEBUG_EVENT KDbgEvt = NULL;
    PDBG_ITEM DbgItem = NULL;
    PLIST_ENTRY Entry;
    PTHREAD_INFO ThreadInfo = NULL;
    PEPROCESS Process = PsGetCurrentProcess();
    PETHREAD Thread = PsGetCurrentThread();

    PAGED_CODE();

    DbgItem = DbgItemFindItem( NULL, Process );
    if( !DbgItem || ( !DbgItem->Debugger ) )
    {
        if( DbgItem )
        {
            DbgItemDeRefItem( DbgItem );
        }
        return;
    }

    KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ) , 'Joen' );

    if( !KDbgEvt )
    {
        KdPrint( ( "Ddvp-> Call _DbgkExitProcess.ExAllocatePool Error \n" ) );
        return;
    }

    RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

    KDbgEvt->dwDebugEventCode = EXIT_THREAD_DEBUG_EVENT;
    KDbgEvt->dwProcessId = ( DWORD )PsGetCurrentProcessId();
    KDbgEvt->dwThreadId = ( DWORD )PsGetCurrentThreadId();

    KDbgEvt->u.ExitThread.dwExitCode = ExitStatus;

    /* Suspend the process */
    Suspended = DbgkpSuspendProcess();

    //
    // ��������, ��ͷ���������
    //
    Entry = DbgItem->DebuggedThread.ThreadList.Flink;

    while( Entry != &DbgItem->DebuggedThread.ThreadList )
    {
        //
        // ��ȡ����ָ��
        //
        ThreadInfo = CONTAINING_RECORD( Entry, THREAD_INFO, ListEntry );

        if( ThreadInfo->ThreadId == ( HANDLE )KDbgEvt->dwThreadId )
        {
            KdPrint( ( "Ddvp->_ExitThread %p Thread Exit \n", ThreadInfo->ThreadId ) );

            ExAcquireFastMutex( &DbgItem->DebuggedThread.Mutex );

            RemoveEntryList( &ThreadInfo->ListEntry );

            /* Release the mutex */
            ExReleaseFastMutex( &DbgItem->DebuggedThread.Mutex );

            ExFreePoolWithTag( ThreadInfo, 'Joen' );
            break;

        }
        Entry = Entry->Flink;
    }

    /* Send the message */
    DbgkpSendApiMessage( KDbgEvt, DbgItem, FALSE );

    /* Resume the process if needed */
    if( Suspended )
    {
        DbgkpResumeProcess();
    }

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }
}

VOID
NTAPI
DbgkpOpenHandles( IN LPNT_DEBUG_EVENT KDbgEvt,
                  IN PEPROCESS Process,
                  IN PETHREAD Thread )
{
    HANDLE Handle;
    PHANDLE DupHandle;
    NTSTATUS Status;

    if( KDbgEvt->dwDebugEventCode == CREATE_THREAD_DEBUG_EVENT )
    {
        /* Get handle to thread */
        Status = ObOpenObjectByPointer( KDbgEvt->u.CreateThread.hThread,
                                        0,
                                        NULL,
                                        THREAD_GET_CONTEXT | THREAD_SET_CONTEXT |
                                        THREAD_SUSPEND_RESUME |
                                        THREAD_QUERY_INFORMATION | THREAD_SET_INFORMATION |
                                        THREAD_TERMINATE |
                                        READ_CONTROL | SYNCHRONIZE,
                                        *PsThreadType,
                                        KernelMode,
                                        &Handle );

        if( NT_SUCCESS( Status ) )
        {
            ObReferenceObject( KDbgEvt->u.CreateThread.hThread );
            KDbgEvt->u.CreateThread.hThread = Handle;
        }
        else
        {
            ASSERT( 1 );
        }

        return;
    }
    else if( KDbgEvt->dwDebugEventCode == CREATE_PROCESS_DEBUG_EVENT )
    {
        /* Get handle to thread */
        Status = ObOpenObjectByPointer( KDbgEvt->u.CreateProcessInfo.hThread,
                                        0,
                                        NULL,
                                        THREAD_GET_CONTEXT | THREAD_SET_CONTEXT |
                                        THREAD_SUSPEND_RESUME |
                                        THREAD_QUERY_INFORMATION | THREAD_SET_INFORMATION |
                                        THREAD_TERMINATE |
                                        READ_CONTROL | SYNCHRONIZE,
                                        *PsThreadType,
                                        KernelMode,
                                        &Handle );

        if( NT_SUCCESS( Status ) )
        {
            ObReferenceObject( KDbgEvt->u.CreateProcessInfo.hThread );
            KDbgEvt->u.CreateProcessInfo.hThread = Handle;
        }
        else
        {
            KDbgEvt->u.CreateProcessInfo.hThread = NULL;
        }

        /* Get handle to process */
        Status = ObOpenObjectByPointer( KDbgEvt->u.CreateProcessInfo.hProcess,
                                        0,
                                        NULL,
                                        PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_VM_OPERATION |
                                        PROCESS_DUP_HANDLE | PROCESS_QUERY_INFORMATION |
                                        PROCESS_SET_INFORMATION |
                                        PROCESS_CREATE_THREAD | PROCESS_TERMINATE |
                                        READ_CONTROL | SYNCHRONIZE,
                                        *PsProcessType,
                                        KernelMode,
                                        &Handle );

        if( NT_SUCCESS( Status ) )
        {
            ObReferenceObject( KDbgEvt->u.CreateProcessInfo.hProcess );
            KDbgEvt->u.CreateProcessInfo.hProcess = Handle;
        }
        else
        {
            KDbgEvt->u.CreateProcessInfo.hProcess = NULL;
        }

        DupHandle = &KDbgEvt->u.CreateProcessInfo.hFile;
    }
    else if( KDbgEvt->dwDebugEventCode == LOAD_DLL_DEBUG_EVENT )
    {
        DupHandle = &KDbgEvt->u.LoadDll.hFile;

    }
    else if( KDbgEvt->dwDebugEventCode == UNLOAD_DLL_DEBUG_EVENT ||
             KDbgEvt->dwDebugEventCode == EXIT_THREAD_DEBUG_EVENT ||
             KDbgEvt->dwDebugEventCode == EXIT_PROCESS_DEBUG_EVENT ||
             KDbgEvt->dwDebugEventCode == EXCEPTION_DEBUG_EVENT ||
             KDbgEvt->dwDebugEventCode == STATUS_SINGLE_STEP ||
             KDbgEvt->dwDebugEventCode == STATUS_BREAKPOINT
           )
    {
        return;
    }
    else
    {
        __asm int 3;
        KdPrint( ( "Ddvp-> Call DbgkpOpenHandles Error!\n" ) );
    }

    Handle = *DupHandle;

    if( Handle )
    {
        Status = lpObDuplicateObject( PsGetCurrentProcess(),
                                      Handle,
                                      PsGetCurrentProcess(),
                                      DupHandle,
                                      0,
                                      0,
                                      DUPLICATE_SAME_ACCESS,
                                      KernelMode );

        if( !NT_SUCCESS( Status ) )
        {
            *DupHandle = NULL;
            KdPrint( ( "Ddvp-> Call DbgkpOpenHandles File Handle Translate Error!\n" ) );
        }

        /* Close the original handle */
        // ObCloseHandle( Handle, KernelMode );
    }

    if( KDbgEvt->dwDebugEventCode == CREATE_PROCESS_DEBUG_EVENT )
    {
        KDbgEvt->u.CreateProcessInfo.hFile = *DupHandle;
    }
    else if( KDbgEvt->dwDebugEventCode == LOAD_DLL_DEBUG_EVENT )
    {
        KDbgEvt->u.LoadDll.hFile = *DupHandle;
    }
}

NTSTATUS
NTAPI
_NtWaitForDebugEvent(
    PDBG_ITEM DbgItem,
    LPNT_DEBUG_EVENT DebugEvent,
    LARGE_INTEGER* TimeOut )
{
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();
    LARGE_INTEGER LocalTimeOut;
    LARGE_INTEGER StartTime;
    LPNT_DEBUG_EVENT lpKerDebugEvnet = NULL;
    NTSTATUS Status;
    PEPROCESS Eprocess = IoGetCurrentProcess();
    PLIST_ENTRY ListHead;
    PLIST_ENTRY	lpEntry;

    LocalTimeOut.QuadPart = 0;

    // KdPrint( ( "Ddvp-> Call _NtWaitForDebugEvent \n" ) );

    //
    // ���������ͱ��������Ƿ���ȷ����
    //
    if( !DbgItem->Active )
    {
        return STATUS_DEBUGGER_INACTIVE;
    }

    /* Check if we were called from user mode */
    if( PreviousMode != KernelMode )
    {
        __try
        {
            /* Check if we came with a timeout */
            if( TimeOut )
            {
                /* Probe it */
                ProbeForReadLargeInteger( TimeOut );

                /* Make a local copy */
                LocalTimeOut = *TimeOut;
                TimeOut = &LocalTimeOut;
            }
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            /* Return the exception code */
            return GetExceptionCode();
        }
    }
    else
    {
        /* Copy directly */
        if( TimeOut )
        {
            LocalTimeOut = *TimeOut;
        }
    }

    /* If we were passed a timeout, query the current time */
    if( TimeOut )
    {
        KeQuerySystemTime( &StartTime );
    }

    // KdPrint( ( "Ddvp-> Call _NtWaitForDebugEvent.KeWaitForSingleObject Wait \n" ) );

    //
    // �ȴ����������ռ�������Ϣ
    //
    Status = KeWaitForSingleObject( &DbgItem->DebugObject.EventRecv,
                                    UserRequest,
                                    PreviousMode,
                                    FALSE,
                                    TimeOut );

    if( !NT_SUCCESS( Status ) ||
            ( Status == STATUS_TIMEOUT ) ||
            ( Status == STATUS_ALERTED ) ||
            ( Status == STATUS_USER_APC ) )
    {
        return Status;
    }

    do
    {
        ExAcquireFastMutex( &DbgItem->DebugObject.Mutex );

        // KdPrint( ( "Ddvp-> Call _NtWaitForDebugEvent.KeWaitForSingleObject Return \n" ) );

        /* Loop the events */
        ListHead = &DbgItem->DebugObject.EventList;
        if( IsListEmpty( ListHead ) )
        {
            __asm int 3
        }
        else
        {
            lpEntry = RemoveHeadList( ListHead );

            //
            // �Ӷ�����ȡ��һ����¼
            //
            lpKerDebugEvnet = CONTAINING_RECORD( lpEntry, NT_DEBUG_EVENT, ListEntry );
        }

        if( !lpKerDebugEvnet )
        {
            Status = STATUS_UNSUCCESSFUL;
            break;
        }

        ASSERT( lpKerDebugEvnet->dwDebugEventCode == UNLOAD_DLL_DEBUG_EVENT ||
                lpKerDebugEvnet->dwDebugEventCode == EXIT_THREAD_DEBUG_EVENT ||
                lpKerDebugEvnet->dwDebugEventCode == EXIT_PROCESS_DEBUG_EVENT ||
                lpKerDebugEvnet->dwDebugEventCode == EXCEPTION_DEBUG_EVENT ||
                lpKerDebugEvnet->dwDebugEventCode == STATUS_SINGLE_STEP ||
                lpKerDebugEvnet->dwDebugEventCode == STATUS_BREAKPOINT  ||
                lpKerDebugEvnet->dwDebugEventCode == CREATE_THREAD_DEBUG_EVENT ||
                lpKerDebugEvnet->dwDebugEventCode == CREATE_PROCESS_DEBUG_EVENT ||
                lpKerDebugEvnet->dwDebugEventCode == LOAD_DLL_DEBUG_EVENT );

        KdPrint( ( "Ddvp-> Call _NtWaitForDebugEvent DbgEvt: 0x%p EvtCode: %p %ws\n",
                   lpKerDebugEvnet, lpKerDebugEvnet->dwDebugEventCode,
                   DbgEvtName[lpKerDebugEvnet->dwDebugEventCode > MAX_NTDBG_EVENT
                              ? MAX_NTDBG_EVENT : lpKerDebugEvnet->dwDebugEventCode - 1 ] ) );

        //
        // ����������ֻ��һ����Ϣ, ��ôȡ��Ϣͬ������λ
        //
        if( IsListEmpty( ListHead ) )
        {
            KeClearEvent( &DbgItem->DebugObject.EventRecv );
        }

        /* Release the mutex */
        ExReleaseFastMutex( &DbgItem->DebugObject.Mutex );

        Status = STATUS_SUCCESS;
    }
    while( 0 );

    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> Call _NtWaitForDebugEvent.KeWaitForSingleObject GetItem Error! \n" ) );
        __asm int 3;
    }
    else
    {
        RtlMoveMemory( DebugEvent, lpKerDebugEvnet, sizeof( NT_DEBUG_EVENT ) );

        ExAcquireFastMutex( &DbgItem->DebugObject.Mutex );

        //
        // �������Ϣ����Ҫ�ȴ�R3��, ��ô����������λ�����̱����
        //
        if( lpKerDebugEvnet->Flags & PSF_WAIT_FOR_EVENT )
        {
            DbgItem->ProcessFlags |= PSF_WAIT_FOR_EVENT;
        }

        RemoveEntryList( &lpKerDebugEvnet->ListEntry );

        /* Release the object lock */
        ExReleaseFastMutex( &DbgItem->DebugObject.Mutex );

        if( lpKerDebugEvnet )
        {
            RtlZeroMemory( lpKerDebugEvnet, sizeof( NT_DEBUG_EVENT ) );
            ExFreePoolWithTag( lpKerDebugEvnet, 'Joen' );
            lpKerDebugEvnet = NULL;
        }

        //
        // ת���¾����R3ʹ��
        //
        DbgkpOpenHandles( DebugEvent, PsGetCurrentProcess(), PsGetCurrentThread() );

    }

    return Status;
}


NTSTATUS
NTAPI
DbgkpQueueMessage( DBG_ITEM* DbgItem,
                   LPNT_DEBUG_EVENT KDbgEvt )
{
    PAGED_CODE();

    ExAcquireFastMutex( &DbgItem->DebugObject.Mutex );

    DbgItem->Status = STATUS_PENDING;

    ASSERT( KDbgEvt->dwDebugEventCode == UNLOAD_DLL_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == EXIT_THREAD_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == EXIT_PROCESS_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == EXCEPTION_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == STATUS_SINGLE_STEP ||
            KDbgEvt->dwDebugEventCode == STATUS_BREAKPOINT  ||
            KDbgEvt->dwDebugEventCode == CREATE_THREAD_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == CREATE_PROCESS_DEBUG_EVENT ||
            KDbgEvt->dwDebugEventCode == LOAD_DLL_DEBUG_EVENT );


    KdPrint( ( "Ddvp-> Call DbgkpQueueMessage DbgEvt: 0x%p EvtCode: %d %ws\n",
               KDbgEvt, KDbgEvt->dwDebugEventCode,
               DbgEvtName[KDbgEvt->dwDebugEventCode > MAX_NTDBG_EVENT
                          ? MAX_NTDBG_EVENT : KDbgEvt->dwDebugEventCode - 1] ) );

    //
    // �������¼��������. �ȴ�R3��ȡ
    //
    InsertTailList( &DbgItem->DebugObject.EventList, &KDbgEvt->ListEntry );

    //
    // ֪ͨR3������ȡ��
    //
    KeSetEvent( &DbgItem->DebugObject.EventRecv, IO_NO_INCREMENT, FALSE );

    /* Release the object lock */
    ExReleaseFastMutex( &DbgItem->DebugObject.Mutex );

    return STATUS_SUCCESS;
}



NTSTATUS
NTAPI
DbgkpPostFakeThreadMessages( IN DBG_ITEM* DbgItem,
                             IN PETHREAD StartThread,
                             OUT PETHREAD *FirstThread,
                             OUT PETHREAD *LastThread )
{
    PVOID Temp;
    HANDLE FileHandle;
    ULONG_PTR ulPsSystemDllBase;
    ULONG_PTR ulPsNtDllPathName;
    IO_STATUS_BLOCK IoStatusBlock;
    OBJECT_ATTRIBUTES ObjectAttributes;
    LPNT_DEBUG_EVENT KDbgEvt = NULL;
    NTSTATUS Status = STATUS_UNSUCCESSFUL;
    LPNT_CREATE_PROCESS_DEBUG_INFO CreateInfo = NULL;
    PIMAGE_NT_HEADERS NtHeader;
    LPNT_LOAD_DLL_DEBUG_INFO LoadDll = NULL;
    PETHREAD pFirstThread = NULL, ThisThread, OldThread = NULL, pLastThread;

    PAGED_CODE();

    ASSERT( lpPsGetNextProcessThread );
    ASSERT( lpPsResumeThread );

    /* Get the first thread ourselves */
    ThisThread = lpPsGetNextProcessThread( DbgItem->Debugged, NULL );

    /* Start thread loop */
    do
    {
        KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ) , 'Joen' );
        if( !KDbgEvt )
        {
            KdPrint( ( "Ddvp-> Call DbgkpPostFakeThreadMessages.ExAllocatePool Error \n" ) );
            return STATUS_UNSUCCESSFUL;
        }
        RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

        /* Dereference the previous thread if we had one */
        if( OldThread )
        {
            ObDereferenceObject( OldThread );
        }

        /* Set this as the last thread and lock it */
        pLastThread = ThisThread;
        ObReferenceObject( ThisThread );

        /* Check if this is the first */
        if( DbgItem->ProcessFlags & PSF_CREATE_REPORTED_BIT )
        {
//             Peb = ( PEB* )GetEProcessPeb( DbgItem->Debugged );
//             Peb->BeingDebugged = TRUE;

            //
            // �ռ� CREATE_PROCESS_DEBUG_EVENT ������Ϣ
            //
            KDbgEvt->dwDebugEventCode = CREATE_PROCESS_DEBUG_EVENT;

            KDbgEvt->dwProcessId = ( DWORD )PsGetProcessId( DbgItem->Debugged );

            KDbgEvt->dwThreadId = ( DWORD )( ( PCLIENT_ID )
                                             GetThreadCid( ThisThread ) )->UniqueThread;

            CreateInfo = &KDbgEvt->u.CreateProcessInfo;

            /* Get the file handle */
            if( GetEprocessSectionObject( DbgItem->Debugged ) )
            {
                /* Use the section object */
                FileHandle = DbgkpSectionToFileHandle(
                                 GetEprocessSectionObject( DbgItem->Debugged ) );
            }
            else
            {
                /* Don't return any handle */
                FileHandle = NULL;
            }

            CreateInfo->hFile = FileHandle;

            CreateInfo->hProcess = DbgItem->Debugged;

            CreateInfo->hThread = ThisThread;

            /* Set the base address */
            CreateInfo->lpBaseOfImage = GetEprocessSectionBaseAddress( DbgItem->Debugged );

            CreateInfo->dwDebugInfoFileOffset = 0;
            CreateInfo->nDebugInfoSize = 0;

            /* Get the NT Header */
            NtHeader = RtlImageNtHeader(
                           GetEprocessSectionBaseAddress( DbgItem->Debugged ) );
            if( NtHeader )
            {
                /* Fill out data from the header */
                CreateInfo->lpStartAddress =
                    ( PVOID )( ( ULONG_PTR )NtHeader->OptionalHeader.ImageBase +
                               NtHeader->OptionalHeader.AddressOfEntryPoint );

                CreateInfo->dwDebugInfoFileOffset =
                    NtHeader->FileHeader.PointerToSymbolTable;

                CreateInfo->nDebugInfoSize =
                    NtHeader->FileHeader.NumberOfSymbols;
            }

            CreateInfo->lpImageName = NULL;
            CreateInfo->fUnicode = TRUE;

            KdPrint( ( "Ddvp-> Call  DbgkpPostFakeThreadMessages Send Process Create Message! \n" ) );

            //
            // �ռ��߳��б�
            //
            {
                PTHREAD_INFO ThreadInfo = ExAllocatePoolWithTag( NonPagedPool, sizeof( THREAD_INFO ), 'Joen' );

                RtlZeroMemory( ThreadInfo, sizeof( THREAD_INFO ) );

                ThreadInfo->ThreadId = ( HANDLE )KDbgEvt->dwThreadId;

                ExAcquireFastMutex( &DbgItem->DebuggedThread.Mutex );

                InsertTailList( &DbgItem->DebuggedThread.ThreadList, &ThreadInfo->ListEntry );

                KdPrint( ( "Ddvp->_PostFakeCreateProcess %p Thread Insert List!\n", ThreadInfo->ThreadId ) );

                /* Release the mutex */
                ExReleaseFastMutex( &DbgItem->DebuggedThread.Mutex );
            }
//---------------------------------------------------------------------------
            Status = DbgkpQueueMessage( DbgItem, KDbgEvt );
            if( !NT_SUCCESS( Status ) )
            {
                KdPrint( ( "Ddvp-> Call  DbgkpPostFakeThreadMessages Send Process Create Message Error! \n" ) );
                return STATUS_UNSUCCESSFUL;
            }

            // ObCloseHandle( FileHandle, KernelMode );
            KDbgEvt = NULL;
            KDbgEvt = ExAllocatePoolWithTag( NonPagedPool, sizeof( NT_DEBUG_EVENT ) , 'Joen' );
            if( !KDbgEvt )
            {
                KdPrint( ( "Ddvp-> Call _DbgkCreateThread.ExAllocatePool Error \n" ) );
                return STATUS_UNSUCCESSFUL;
            }

            RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

            //
            // ntdll.dll���DLL�ļ���������DLL���ط�ʽ��һ��, ����Ҫ����ʲô
            // NtMapViewOfSection ����
            //

            KDbgEvt->dwDebugEventCode = LOAD_DLL_DEBUG_EVENT;
            KDbgEvt->dwProcessId = ( DWORD )PsGetProcessId( DbgItem->Debugged );
            KDbgEvt->dwThreadId = ( DWORD )( ( PCLIENT_ID )
                                             GetThreadCid( ThisThread ) )->UniqueThread;

            ulPsSystemDllBase =
                ( *( ULONG_PTR* )( ( ULONG_PTR ) g_StReloadKernel.OriginalKernelBase +
                                   g_StSymbolsInfo.ulPsSystemDllBase ) );

            LoadDll = &KDbgEvt->u.LoadDll;

            LoadDll->lpBaseOfDll = ( PVOID )ulPsSystemDllBase;
            LoadDll->dwDebugInfoFileOffset = 0;
            LoadDll->nDebugInfoSize = 0;
            LoadDll->lpImageName = NULL;

            /* Get the NT Headers PspSystemDllBase */
            NtHeader = RtlImageNtHeader( ( PVOID )ulPsSystemDllBase );

            if( NtHeader )
            {
                /* Fill out debug information */
                LoadDll->dwDebugInfoFileOffset = NtHeader->FileHeader.PointerToSymbolTable;

                LoadDll->nDebugInfoSize = NtHeader->FileHeader.NumberOfSymbols;
            }

            __try
            {
                //
                // �����ȡģ������, ���Ƿ���ģ���PEͷ����..����ָ��.
                //
                Temp = ( PVOID )( ulPsSystemDllBase + sizeof( PVOID ) + 4 );

                if( !MmIsAddressValid( ( PVOID )( ulPsSystemDllBase + 4 ) ) )
                {
                    KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Call MmIsAddressValid Error! \n" ) );
                    if( KDbgEvt )
                    {
                        ExFreePoolWithTag( KDbgEvt, 'Joen' );
                    }
                    return STATUS_UNSUCCESSFUL;
                }

                SafeCopyMemory( DbgItem->Buffer,
                                ( PVOID )( ulPsSystemDllBase + 4 ),
                                sizeof( PVOID ) + sizeof( L"ntdll.dll" ) + 1 );

                SafeCopyMemory( ( PVOID )( ulPsSystemDllBase + 4 ), &Temp, sizeof( PVOID ) );

                SafeCopyMemory( ( PVOID )( ulPsSystemDllBase + sizeof( PVOID ) + 4 ),
                                L"ntdll.dll", sizeof( L"ntdll.dll" ) + 1 );
            }
            __except( EXCEPTION_EXECUTE_HANDLER )
            {
                Status = GetExceptionCode();
                KdPrint( ( "Ddvp-> Call  _DbgkCreateThread __try Error Status :0x%p! \n", Status ) );

                if( KDbgEvt )
                {
                    ExFreePoolWithTag( KDbgEvt, 'Joen' );
                }
                return STATUS_UNSUCCESSFUL;
            }

            LoadDll->lpImageName = ( PVOID )( ulPsSystemDllBase + 4 );

            ulPsNtDllPathName =
                ( ( ULONG )g_StReloadKernel.OriginalKernelBase + g_StSymbolsInfo.ulPsNtDllPathName );

            /* Get a handle */
            InitializeObjectAttributes( &ObjectAttributes,
                                        ( PUNICODE_STRING )ulPsNtDllPathName,
                                        OBJ_CASE_INSENSITIVE |
                                        OBJ_KERNEL_HANDLE |
                                        OBJ_FORCE_ACCESS_CHECK,
                                        NULL,
                                        NULL );

            FileHandle = NULL;

            Status = ZwOpenFile( &FileHandle,
                                 GENERIC_READ | SYNCHRONIZE,
                                 &ObjectAttributes,
                                 &IoStatusBlock,
                                 FILE_SHARE_DELETE |
                                 FILE_SHARE_READ |
                                 FILE_SHARE_WRITE,
                                 FILE_SYNCHRONOUS_IO_NONALERT );

            if( NT_SUCCESS( Status ) )
            {
                LoadDll->hFile = FileHandle;

                KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Send Load ntdll.dll Message! \n" ) );

                Status = DbgkpQueueMessage( DbgItem, KDbgEvt );
                if( !NT_SUCCESS( Status ) )
                {
                    KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Send Load ntdll.dll Message Error! \n" ) );
                    if( KDbgEvt )
                    {
                        ExFreePoolWithTag( KDbgEvt, 'Joen' );
                    }
                    break;
                }
                else
                {
                    KdPrint( ( "Ddvp-> Call  _DbgkCreateThread Send Load ntdll.dll Message Success! \n" ) );
                }

            }

            DbgItem->ProcessFlags &= ( ~PSF_CREATE_REPORTED_BIT );
            DbgItem->ProcessFlags |= PSF_LOAD_NTDLL;

            /* Reference this thread and set it as first */
            ObReferenceObject( ThisThread );
            pFirstThread = ThisThread;
//---------------------------------------------------------------------------
        }
        else
        {
            //
            // �ռ� CREATE_THREAD_DEBUG_EVENT ������Ϣ
            //
            KDbgEvt->dwDebugEventCode = CREATE_THREAD_DEBUG_EVENT;

            KDbgEvt->dwProcessId = ( DWORD )PsGetProcessId( DbgItem->Debugged );

            KDbgEvt->dwThreadId = ( DWORD )( ( PCLIENT_ID )
                                             GetThreadCid( ThisThread ) )->UniqueThread;

            KDbgEvt->u.CreateThread.hThread = ThisThread;

            KDbgEvt->u.CreateThread.lpStartAddress = GetEThreadStartAddress( ThisThread );

            KdPrint( ( "Ddvp-> Call  DbgkpPostFakeThreadMessages Send Thread Create Message! \n" ) );

            //
            // �ռ���ǰ�߳̽������
            //
            {
                PTHREAD_INFO ThreadInfo = ExAllocatePoolWithTag( NonPagedPool, sizeof( THREAD_INFO ), 'Joen' );

                RtlZeroMemory( ThreadInfo, sizeof( THREAD_INFO ) );

                ThreadInfo->ThreadId = ( HANDLE )KDbgEvt->dwThreadId;

                ExAcquireFastMutex( &DbgItem->DebuggedThread.Mutex );

                InsertTailList( &DbgItem->DebuggedThread.ThreadList, &ThreadInfo->ListEntry );

                /* Release the mutex */
                ExReleaseFastMutex( &DbgItem->DebuggedThread.Mutex );

                KdPrint( ( "Ddvp->_CreateThread %p Thread Insert List \n", ThreadInfo->ThreadId ) );
            }

            Status = DbgkpQueueMessage( DbgItem, KDbgEvt );
        }
//---------------------------------------------------------------------------
        if( !NT_SUCCESS( Status ) )
        {

            /* Release our reference and break out */
            ObDereferenceObject( ThisThread );
            if( KDbgEvt )
            {
                ExFreePoolWithTag( KDbgEvt, 'Joen' );
                KDbgEvt = NULL;
            }
            break;
        }

        /* Get the next thread */
        ThisThread = lpPsGetNextProcessThread( DbgItem->Debugged, ThisThread );
        OldThread = pLastThread;
    }
    while( ThisThread );

    /* Check the API status */
    if( !NT_SUCCESS( Status ) )
    {
        /* Dereference and fail */
        if( pFirstThread )
        {
            ObDereferenceObject( pFirstThread );
        }

        if( pLastThread )
        {
            ObDereferenceObject( pLastThread );
        }
        return Status;
    }

    /* Make sure we have a first thread */
    if( !pFirstThread )
    {
        return STATUS_UNSUCCESSFUL;
    }

    /* Return thread pointers */
    *FirstThread = pFirstThread;
    *LastThread = pLastThread;
    return Status;
}


NTSTATUS
NTAPI
DbgkpPostFakeModuleMessages( IN DBG_ITEM* DbgItem,
                             IN PETHREAD Thread
                           )
{
    ULONG i;
    NTSTATUS Status;
    HANDLE FileHandle;
    PPEB_LDR_DATA LdrData;
    PLDR_DATA_TABLE_ENTRY LdrEntry;
    PLIST_ENTRY ListHead, NextEntry;
    LPNT_DEBUG_EVENT KDbgEvt = NULL;
    PIMAGE_NT_HEADERS NtHeader;
    UNICODE_STRING ModuleName;
    OBJECT_ATTRIBUTES ObjectAttributes;
    IO_STATUS_BLOCK IoStatusBlock;
    LPNT_LOAD_DLL_DEBUG_INFO LoadDll = NULL;
    PPEB Peb = GetEProcessPeb( DbgItem->Debugged );

    PAGED_CODE();

    /* Quit if there's no PEB */
    if( !Peb )
    {
        return STATUS_SUCCESS;
    }

    /* Get the Loader Data List */
    LdrData = GetPebLdr( Peb );
    ListHead = &LdrData->InLoadOrderModuleList;
    NextEntry = ListHead->Flink;

    /* Loop the modules */
    for( i = 0; ( NextEntry != ListHead ) && ( i < 500 );
            NextEntry = NextEntry->Flink, i++ )
    {
        /* Skip the first entry */
        if( !i )
        {
            /* Go to the next module */
            NextEntry = NextEntry->Flink;
            i++;
            continue;
        }

        /* Get the entry */
        LdrEntry = CONTAINING_RECORD( NextEntry,
                                      LDR_DATA_TABLE_ENTRY, InLoadOrderLinks );

        KDbgEvt = ExAllocatePoolWithTag( NonPagedPool,
                                         sizeof( NT_DEBUG_EVENT ) , 'Joen' );
        if( !KDbgEvt )
        {
            KdPrint( ( "Ddvp-> Call DbgkpPostFakeModuleMessages.ExAllocatePool Error \n" ) );
            return STATUS_UNSUCCESSFUL;
        }
        RtlZeroMemory( KDbgEvt, sizeof( NT_DEBUG_EVENT ) );

        /* Setup the API Message */
        KDbgEvt->dwDebugEventCode = LOAD_DLL_DEBUG_EVENT;

        KDbgEvt->dwProcessId = ( DWORD )PsGetProcessId( DbgItem->Debugged );
        KDbgEvt->dwThreadId = ( DWORD )
                              ( ( PCLIENT_ID )GetThreadCid( Thread ) )->UniqueThread;

        LoadDll = &KDbgEvt->u.LoadDll;
        //LoadDll->StClientID = *( PCLIENT_ID )GetThreadCid( Thread );

        /* Set base and clear the name */
        LoadDll->lpBaseOfDll = LdrEntry->DllBase;
        LoadDll->lpImageName = NULL;

        /* Get the NT Headers */
        NtHeader = RtlImageNtHeader( LoadDll->lpBaseOfDll );
        if( NtHeader )
        {
            /* Save debug data */
            LoadDll->dwDebugInfoFileOffset = NtHeader->FileHeader.PointerToSymbolTable;
            LoadDll->nDebugInfoSize = NtHeader->FileHeader.NumberOfSymbols;
        }

        /* Get the name of the DLL */
        Status = lpMmGetFileNameForAddress( NtHeader, &ModuleName );
        if( NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> Call DbgkpPostFakeModuleMessages Load Module Name %ws \n",
                       ModuleName.Buffer ) );

            /* Setup the object attributes */
            InitializeObjectAttributes( &ObjectAttributes,
                                        &ModuleName,
                                        OBJ_FORCE_ACCESS_CHECK |
                                        OBJ_KERNEL_HANDLE |
                                        OBJ_CASE_INSENSITIVE,
                                        NULL,
                                        NULL );

            /* Open the file to get a handle to it */
            Status = ZwOpenFile( &FileHandle ,
                                 GENERIC_READ | SYNCHRONIZE,
                                 &ObjectAttributes,
                                 &IoStatusBlock,
                                 FILE_SHARE_READ |
                                 FILE_SHARE_WRITE |
                                 FILE_SHARE_DELETE,
                                 FILE_SYNCHRONOUS_IO_NONALERT );

            if( !NT_SUCCESS( Status ) )
            {
                FileHandle = NULL;
            }

            LoadDll->hFile = FileHandle;

            /* Free the name now */
            ExFreePool( ModuleName.Buffer );
        }

        /* Send the fake module load message */
        Status = DbgkpQueueMessage( DbgItem, KDbgEvt );
        if( !NT_SUCCESS( Status ) )
        {
            /* Message send failed, close the file handle if we had one */
            if( FileHandle )
            {
                ObCloseHandle( FileHandle, KernelMode );
            }
        }
    }

    /* Return success */
    return STATUS_SUCCESS;
}


NTSTATUS
NTAPI
DbgkpPostFakeProcessCreateMessages( DBG_ITEM* DbgItem,
                                    OUT PETHREAD *LastThread )
{
    KAPC_STATE ApcState;
    NTSTATUS Status;
    PETHREAD FirstThread, FinalThread;
    PETHREAD ReturnThread = NULL;

    PAGED_CODE();

    /* Attach to the process */
    KeStackAttachProcess(
        GetEprocessPcbPointer( DbgItem->Debugged ), &ApcState );

    /* Post the fake thread messages */
    Status = DbgkpPostFakeThreadMessages( DbgItem,
                                          NULL,
                                          &FirstThread,
                                          &FinalThread );
    if( NT_SUCCESS( Status ) )
    {
        /* Send the fake module messages too */
        Status = DbgkpPostFakeModuleMessages( DbgItem, FirstThread );
        if( !NT_SUCCESS( Status ) )
        {
            /* We failed, dereference the final thread */
            ObDereferenceObject( FinalThread );
        }
        else
        {
            /* Set the final thread */
            ReturnThread = FinalThread;
        }

        /* Dereference the first thread */
        ObDereferenceObject( FirstThread );
    }

	Status = STATUS_SUCCESS;

    /* Detach from the process */
    KeUnstackDetachProcess( &ApcState );

    /* Return the last thread */
    *LastThread = ReturnThread;
    return Status;
}


NTSTATUS
NTAPI
_NtDebugContinue(
    IN HANDLE dwProcessId,
    IN HANDLE dwThreadId,
    IN NTSTATUS ContinueStatus )
{
    NTSTATUS Status;
    PEPROCESS Eprocess = NULL;
    DBG_ITEM* DbgItem = NULL;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();

    PAGED_CODE();


    // KdPrint( ( "Ddvp-> Call _NtDebugContinue \n" ) );

    /* Make sure that the status is valid */
    if( ( ContinueStatus != DBG_CONTINUE ) &&
            ( ContinueStatus != DBG_EXCEPTION_HANDLED ) &&
            ( ContinueStatus != DBG_EXCEPTION_NOT_HANDLED ) &&
            ( ContinueStatus != DBG_TERMINATE_THREAD ) &&
            ( ContinueStatus != DBG_TERMINATE_PROCESS ) )
    {
        /* Invalid status */
        return STATUS_INVALID_PARAMETER;
    }

    if( PreviousMode != UserMode )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // ��ȡ�����Խ��̵�Eprocess
    //
    Status = PsLookupProcessByProcessId( dwProcessId , &Eprocess );
    if( !NT_SUCCESS( Status ) )
    {
        return Status;
    }

    DbgItem = DbgItemFindItem( NULL, Eprocess );
    if( !DbgItem )
    {
        return STATUS_UNSUCCESSFUL;
    }

    /* Acquire the mutex */
    ExAcquireFastMutex( &DbgItem->DebugObject.Mutex );

    DbgItem->Status = ContinueStatus;

    //
    // ������PSF_WAIT_FOR_EVENT�ű�ʾ��Ҫ�ȴ�
    //
    if( DbgItem->ProcessFlags & PSF_WAIT_FOR_EVENT )
    {
        DbgItem->ProcessFlags &= ( ~PSF_WAIT_FOR_EVENT );

        KeSetEvent( &DbgItem->DebugObject.EventSend, IO_NO_INCREMENT, FALSE );
    }

    /* Release the mutex */
    ExReleaseFastMutex( &DbgItem->DebugObject.Mutex );

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }

    return STATUS_SUCCESS;
}


NTSTATUS DbgkInitRoutine()
{
    PVOID OriginalKerBase;

    OriginalKerBase = g_StReloadKernel.OriginalKernelBase;

    lpMmGetFileNameForSection = ( PGetFileNameForSection )
                                ( ( ULONG_PTR )OriginalKerBase +
                                  ( ULONG_PTR )g_StSymbolsInfo.lpMmGetFileNameForSection );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpMmGetFileNameForSection \t%p \n",
               lpMmGetFileNameForSection ) );

    lpObDuplicateObject = ( PObDuplicateObject )
                          ( ( ULONG_PTR )OriginalKerBase +
                            ( ULONG_PTR )g_StSymbolsInfo.lpObDuplicateObject );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpObDuplicateObject \t%p \n",
               lpObDuplicateObject ) );

    lpObpCloseHandle = ( PObpCloseHandle )( ( ULONG_PTR )OriginalKerBase +
                                            ( ULONG_PTR )g_StSymbolsInfo.lpObpCloseHandle );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpObpCloseHandle \t\t%p \n",
               lpObpCloseHandle ) );

    lpKeFreezeAllThreads = ( PKeFreezeAllThreads )( ( ULONG_PTR )OriginalKerBase +
                           ( ULONG_PTR )g_StSymbolsInfo.lpKeFreezeAllThreads );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpKeFreezeAllThreads \t%p \n",
               lpKeFreezeAllThreads ) );

    lpKeThawAllThreads = ( PKeThawAllThreads )( ( ULONG_PTR )OriginalKerBase +
                         ( ULONG_PTR )g_StSymbolsInfo.lpKeThawAllThreads );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpKeThawAllThreads \t\t%p \n",
               lpKeThawAllThreads ) );

    ulKeI386XMMIPresent = *( PULONG_PTR )( ( ULONG_PTR )OriginalKerBase +
                                           ( ULONG_PTR )g_StSymbolsInfo.ulKeI386XMMIPresent );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.ulKeI386XMMIPresent\t\t%p \n",
               ulKeI386XMMIPresent ) );

    ulKeFeatureBits = *( PULONG_PTR )( ( ULONG_PTR )OriginalKerBase +
                                       ( ULONG_PTR )g_StSymbolsInfo.ulKeFeatureBits );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.ulKeFeatureBits \t\t%p \n",
               ulKeFeatureBits ) );


    KeUserExceptionDispatcher = ( PVOID ) * ( PULONG_PTR )( ( ULONG_PTR )OriginalKerBase +
                                ( ULONG_PTR )g_StSymbolsInfo.KeUserExceptionDispatcher );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.KeUserExceptionDispatcher \t%p \n",
               KeUserExceptionDispatcher ) );

    ulKiDebugRoutine = ( PKDEBUG_ROUTINE ) * ( PULONG_PTR )( ( ULONG_PTR )OriginalKerBase +
                       ( ULONG_PTR )g_StSymbolsInfo.ulKiDebugRoutine );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.ulKiDebugRoutine \t\t%p \n",
               ulKiDebugRoutine ) );

    lpKeContextFromKframes = ( PKeContextFromKframes )( ( ULONG_PTR )OriginalKerBase +
                             ( ULONG_PTR )g_StSymbolsInfo.lpKeContextFromKframes );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpKeContextFromKframes \t%p \n",
               lpKeContextFromKframes ) );

    lpKiCheckForAtlThunk = ( PKiCheckForAtlThunk )( ( ULONG_PTR )OriginalKerBase +
                           ( ULONG_PTR )g_StSymbolsInfo.lpKiCheckForAtlThunk );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpKiCheckForAtlThunk \t%p \n",
               lpKiCheckForAtlThunk ) );

    lpRtlDispatchException = ( PRtlDispatchException )( ( ULONG_PTR )OriginalKerBase +
                             ( ULONG_PTR )g_StSymbolsInfo.lpRtlDispatchException );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpRtlDispatchException\t%p \n",
               lpRtlDispatchException ) );


    lpRtlRaiseException = ( PRtlRaiseException )( ( ULONG_PTR )OriginalKerBase +
                          ( ULONG_PTR )g_StSymbolsInfo.lpRtlRaiseException );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpRtlRaiseException\t\t%p \n",
               lpRtlRaiseException ) );

    lpKiSegSsToTrapFrame = ( PKiSegSsToTrapFrame )( ( ULONG_PTR )OriginalKerBase +
                           ( ULONG_PTR )g_StSymbolsInfo.lpKiSegSsToTrapFrame );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpKiSegSsToTrapFrame \t%p \n",
               lpKiSegSsToTrapFrame ) );

    lpKiEspToTrapFrame = ( PKiEspToTrapFrame )( ( ULONG_PTR )OriginalKerBase +
                         ( ULONG_PTR )g_StSymbolsInfo.lpKiEspToTrapFrame );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpKiEspToTrapFrame \t\t%p \n",
               lpKiEspToTrapFrame ) );

    lpKeContextToKframes = ( PKeContextToKframes )( ( ULONG_PTR )OriginalKerBase +
                           ( ULONG_PTR )g_StSymbolsInfo.lpKeContextToKframes );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpKeContextToKframes \t%p \n",
               lpKeContextToKframes ) );


    lpPsGetNextProcessThread = ( PPsGetNextProcessThread )( ( ULONG_PTR )OriginalKerBase +
                               ( ULONG_PTR )g_StSymbolsInfo.lpPsGetNextProcessThread );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpPsGetNextProcessThread \t%p \n",
               lpPsGetNextProcessThread ) );

    lpPsResumeThread = ( PPsResumeThread )( ( ULONG_PTR )OriginalKerBase +
                                            ( ULONG_PTR )g_StSymbolsInfo.lpPsResumeThread );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpPsResumeThread \t\t%p \n",
               lpPsResumeThread ) );

    lpMmGetFileNameForAddress = ( PMmGetFileNameForAddress )( ( ULONG_PTR )OriginalKerBase +
                                ( ULONG_PTR )g_StSymbolsInfo.lpMmGetFileNameForAddress );

    KdPrint( ( "Ddvp-> Call DbgkInitRoutine.lpMmGetFileNameForAddress \t%p \n",
               lpMmGetFileNameForAddress ) );

    return STATUS_SUCCESS;
}

