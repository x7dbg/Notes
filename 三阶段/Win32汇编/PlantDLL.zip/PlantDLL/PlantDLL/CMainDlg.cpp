﻿// CMainDlg.cpp: 实现文件
//

#include "pch.h"
#include "PlantDLL.h"
#include "CMainDlg.h"
#include "afxdialogex.h"
#include "Memory.h"

extern BYTE pOldAutoZombies[9];

// CMainDlg 对话框

IMPLEMENT_DYNAMIC(CMainDlg, CDialogEx)

CMainDlg::CMainDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
{
	DWORD GameBase = (DWORD)GetModuleHandleA(NULL);
	DWORD pCode = GameBase + Game_Offset_AutoZombies;
	ReadVirual(pCode, pOldAutoZombies, sizeof(pOldAutoZombies));

	m_Btn1.m_emZombiesType = Zombies_Normal;
	m_Btn2.m_emZombiesType = Zombies_Flags;
	m_Btn3.m_emZombiesType = Zombies_Hat;
	m_Btn4.m_emZombiesType = Zombies_Jump;
	m_Btn5.m_emZombiesType = Zombies_Trash;
	m_Btn6.m_emZombiesType = Zombies_Paper;
}

CMainDlg::~CMainDlg()
{
}

void CMainDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_1, m_Btn1);
	DDX_Control(pDX, IDC_STATIC_2, m_Btn2);
	DDX_Control(pDX, IDC_STATIC_3, m_Btn3);
	DDX_Control(pDX, IDC_STATIC_4, m_Btn4);
	DDX_Control(pDX, IDC_STATIC_5, m_Btn5);
	DDX_Control(pDX, IDC_STATIC_6, m_Btn6);
}


BEGIN_MESSAGE_MAP(CMainDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON1, &CMainDlg::OnBnClickedButton1)
END_MESSAGE_MAP()



BOOL isCloseAutoZombies = FALSE;
void CMainDlg::OnBnClickedButton1()
{
	DWORD GameBase = (DWORD)GetModuleHandleA(NULL);
	DWORD pCode = GameBase + Game_Offset_AutoZombies;

	isCloseAutoZombies = !isCloseAutoZombies;
	if (isCloseAutoZombies == TRUE) {
		BYTE NopCode[9] = { 0 };
		memset(NopCode, 0x90, sizeof(NopCode));
		WriteVirtual(pCode, NopCode, sizeof(NopCode));
		SetDlgItemTextA(IDC_BUTTON1, "开启自动僵尸");
	}
	else {
		WriteVirtual(pCode, pOldAutoZombies, sizeof(pOldAutoZombies));
		SetDlgItemTextA(IDC_BUTTON1, "关闭自动僵尸");
	}
}