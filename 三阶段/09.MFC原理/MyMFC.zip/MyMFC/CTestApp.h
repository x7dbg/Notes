#pragma once
#include "CWinApp.h"
class CTestApp :
    public CWinApp
{
public:
  virtual BOOL InitInstance();
  virtual int ExitInstance();
};

