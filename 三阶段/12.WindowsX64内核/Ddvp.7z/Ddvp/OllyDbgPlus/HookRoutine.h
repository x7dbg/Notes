BOOL HookDebugRoutine();
BOOL UnHookDebugRoutine();