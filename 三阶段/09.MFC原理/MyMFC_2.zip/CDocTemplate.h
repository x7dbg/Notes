#pragma once
#include "CCmdTarget.h"
#include "CDocument.h"

class CDocTemplate : public CCmdTarget
{
    DECLARE_DYNAMIC(CDocTemplate);
public:
 virtual CDocument* OpenDocumentFile(LPCTSTR lpszPathName, BOOL bMakeVisible = TRUE);
};

