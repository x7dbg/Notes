//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ���Ǳ�DbgObj��������һЩ��������.
 */
//===========================================================================
#include <tchar.h>
#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <DbgHelp.h>
#include "ntdll.h"
#include "IoControlCode.h"
#include "DbgObj.h"
#include "DbgObjMisc.h"
#include <strsafe.h>


//---------------------------------------------------------------------------


extern SYMBOLS_INFO StSymbolsInfo;
extern DWORD64 BaseOfDll;
//---------------------------------------------------------------------------

PLARGE_INTEGER
WINAPI
BaseFormatTimeOut( OUT PLARGE_INTEGER Timeout,
                   IN DWORD dwMilliseconds )
{
    /* Check if this is an infinite wait, which means no timeout argument */
    if( dwMilliseconds == INFINITE )
    {
        return NULL;
    }

    /* Otherwise, convert the time to NT Format */
    Timeout->QuadPart = UInt32x32To64( dwMilliseconds, -10000 );
    return Timeout;
}

/*
 * @implemented
 */
VOID
WINAPI
BaseSetLastNTError( IN NTSTATUS Status )
{
    /* Convert from NT to Win32, then set */
    SetLastError( RtlNtStatusToDosError( Status ) );
}

//
// ж�ط���
//
BOOL DbgObjUnInstallService( wchar_t* SzServiceName )
{
    BOOL bRet = FALSE;
    SC_HANDLE hServiceMgr = NULL;
    SC_HANDLE hServiceDDK = NULL;
    SERVICE_STATUS SvrSta;

    do
    {
        //
        // ��SCM������
        //
        hServiceMgr = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS );

        if( hServiceMgr == NULL )
        {
            break;
        }

        //
        // ����������Ӧ�ķ���
        //
        hServiceDDK = OpenService( hServiceMgr, SzServiceName, SERVICE_ALL_ACCESS );

        if( hServiceDDK == NULL )
        {
            break;
        }

        ControlService( hServiceDDK, SERVICE_CONTROL_STOP , &SvrSta );


        if( DeleteService( hServiceDDK ) )
        {
            bRet = TRUE;
        }

    }
    while( FALSE );

    if( hServiceDDK )
    {
        CloseServiceHandle( hServiceDDK );
    }

    if( hServiceMgr )
    {
        CloseServiceHandle( hServiceMgr );
    }

    return bRet;
}

//
// ��װ����
//
BOOL DbgObjInstallService(
    const wchar_t *SzPath,
    const wchar_t *SzName )
{
    BOOL bRet = FALSE;
	DWORD dwLastError;
    SC_HANDLE hSCManager;
    SC_HANDLE hService = NULL;

    if( hSCManager = OpenSCManager( NULL, NULL, SC_MANAGER_ALL_ACCESS ) )
    {
        hService = CreateService(
                       hSCManager, SzName,
                       SzName, SERVICE_ALL_ACCESS,
                       SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START,
                       SERVICE_ERROR_IGNORE, SzPath,
                       NULL, NULL, NULL, NULL, NULL
                   );

        if( hService == NULL )
        {
            hService = OpenService( hSCManager, SzName, SERVICE_ALL_ACCESS );

            if( !hService )
            {
                CloseServiceHandle( hSCManager );
                return FALSE;
            }

        }

        bRet = StartService( hService, 0, NULL );
		if (!bRet)
		{
			dwLastError = GetLastError();
		}
    }

    if( hService )
    {
        CloseServiceHandle( hService );
    }

    if( hSCManager )
    {
        CloseServiceHandle( hSCManager );
    }

    return bRet;
}


/*
 * �����ں��Ǳ߹�ס��NtTerminateProcess, �����������ͨ��.
 *
 * Return: �ɹ����ذ汾��, ���򷵻�0
 */
BOOL DbgObjCall(
    int number,
    PVOID lpInBuffer,
    ULONG ulInBufferSize,
    PVOID lpOutBuffer,
    ULONG ulOutBufferSize
)
{
    SYSTEM_CALL SysCall;

    SysCall.Number          = number;
    SysCall.lpInBuffer      = lpInBuffer;
    SysCall.ulInBufferSize  = ulInBufferSize;
    SysCall.lpOutBuffer     = lpOutBuffer;
    SysCall.ulOutBufferSize = ulOutBufferSize;

    return ( NtTerminateProcess( &SysCall, 0x750C530D ) == STATUS_SUCCESS );
}

//
// ��ȡ���Է��Żص�����
//
BOOL
CALLBACK
EnumSymCallBack(
    PSYMBOL_INFO pSymInfo,
    ULONG SymbolSize,
    PVOID UserContext )
{
    BOOL IsPrint = FALSE;

    if( !BaseOfDll )
    {
        return FALSE;
    }

    do
    {
        if( !wcscmp( ( pSymInfo->Name ), _T( "DbgkCreateThread" ) ) )
        {
            StSymbolsInfo.lpDbgkCreateThread = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name , _T( "KiFastCallEntry" ) ) )
        {
            StSymbolsInfo.lpKiFastCallEntry = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "DbgkExitProcess" ) ) )
        {
            StSymbolsInfo.lpDbgkExitProcess = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "DbgkForwardException" ) ) )
        {
            StSymbolsInfo.lpDbgkForwardException = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "DbgkExitThread" ) ) )
        {
            StSymbolsInfo.lpDbgkExitThread = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name , _T( "DbgkMapViewOfSection" ) ) )
        {
            StSymbolsInfo.lpDbgkMapViewOfSection = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name , _T( "DbgkUnMapViewOfSection" ) ) )
        {
            StSymbolsInfo.lpDbgkUnMapViewOfSection = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "MmGetFileNameForSection" ) ) )
        {
            StSymbolsInfo.lpMmGetFileNameForSection = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "ObDuplicateObject" ) ) )
        {
            StSymbolsInfo.lpObDuplicateObject = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "ObpCloseHandle" ) ) )
        {
            StSymbolsInfo.lpObpCloseHandle = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "KeThawAllThreads" ) ) )
        {
            StSymbolsInfo.lpKeThawAllThreads = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "KeFreezeAllThreads" ) ) )
        {
            StSymbolsInfo.lpKeFreezeAllThreads = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "PspExitThread" ) ) )
        {
            StSymbolsInfo.lpPspExitThread = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "PsGetContextThread" ) ) )
        {
            StSymbolsInfo.lpPsGetContextThread = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "PsSetContextThread" ) ) )
        {
            StSymbolsInfo.lpPsSetContextThread = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "KeContextFromKframes" ) ) )
        {
            StSymbolsInfo.lpKeContextFromKframes = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "RtlDispatchException" ) ) )
        {
            StSymbolsInfo.lpRtlDispatchException = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "RtlRaiseException" ) ) )
        {
            StSymbolsInfo.lpRtlRaiseException = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "KiSegSsToTrapFrame" ) ) )
        {
            StSymbolsInfo.lpKiSegSsToTrapFrame = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "KiEspToTrapFrame" ) ) )
        {
            StSymbolsInfo.lpKiEspToTrapFrame = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "KeContextToKframes" ) ) )
        {
            StSymbolsInfo.lpKeContextToKframes = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "KiDispatchException" ) ) )
        {
            StSymbolsInfo.lpKiDispatchException = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "KiCheckForAtlThunk" ) ) )
        {
            StSymbolsInfo.lpKiCheckForAtlThunk = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "PsGetNextProcessThread" ) ) )
        {
            StSymbolsInfo.lpPsGetNextProcessThread = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "PsResumeThread" ) ) )
        {
            StSymbolsInfo.lpPsResumeThread = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
		else if( !wcscmp( pSymInfo->Name, _T( "KeSuspendThread" ) ) )
		{
			StSymbolsInfo.lpKeSuspendThread = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "KeForceResumeThread" ) ) )
		{
			StSymbolsInfo.lpKeForceResumeThread = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "KiAttachProcess" ) ) )
		{
			StSymbolsInfo.lpKiAttachProcess = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
        else if( !wcscmp( pSymInfo->Name, _T( "MmGetFileNameForAddress" ) ) )
        {
            StSymbolsInfo.lpMmGetFileNameForAddress = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "MmCopyVirtualMemory" ) ) )
        {
            StSymbolsInfo.lpMmCopyVirtualMemory = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
		else if( !wcscmp( pSymInfo->Name, _T( "MiProtectVirtualMemory" ) ) )
		{
			StSymbolsInfo.lpMiProtectVirtualMemory = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "SeDebugPrivilege" ) ) )
		{
			StSymbolsInfo.lpSeDebugPrivilege = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "PspUserThreadStartup" ) ) )
		{
			StSymbolsInfo.lpPspUserThreadStartup = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "PspCreateThread" ) ) )
		{
			StSymbolsInfo.lpPspCreateThread = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "MiUnmapViewOfSection" ) ) )
		{
			StSymbolsInfo.lpMiUnmapViewOfSection = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "PsGetThreadProcess" ) ) )
		{
			StSymbolsInfo.lpPsGetThreadProcess = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "PsGetThreadId" ) ) )
		{
			StSymbolsInfo.lpPsGetThreadId = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "KiTrap01" ) ) )
		{
			StSymbolsInfo.lpKiTrap01 = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "KiTrap03" ) ) )
		{
			StSymbolsInfo.lpKiTrap03 = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "KiTrap0F" ) ) )
		{
			StSymbolsInfo.lpKiTrap0F = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}
		
		
		
		
	

        else if( !wcscmp( pSymInfo->Name, _T( "KeI386XMMIPresent" ) ) )
        {
            StSymbolsInfo.ulKeI386XMMIPresent = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "PsSystemDllBase" ) ) )
        {
            StSymbolsInfo.ulPsSystemDllBase = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "PsNtDllPathName" ) ) )
        {
            StSymbolsInfo.ulPsNtDllPathName = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "MmUserProbeAddress" ) ) )
        {
            StSymbolsInfo.ulMmUserProbeAddress = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
        }
		else if( !wcscmp( pSymInfo->Name, _T( "PsProcessType" ) ) )
		{
			StSymbolsInfo.ulPsProcessType = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "MmHighestUserAddress" ) ) )
		{
			StSymbolsInfo.ulMmHighestUserAddress = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "PsInitialSystemProcess" ) ) )
		{
			StSymbolsInfo.ulPsInitialSystemProcess = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "ObpKernelHandleTable" ) ) )
		{
			StSymbolsInfo.ulObpKernelHandleTable = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
		}
		else if( !wcscmp( pSymInfo->Name, _T( "KdDebuggerEnabled" ) ) )
		{
			StSymbolsInfo.ulKdDebuggerEnabled = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
		}
		
        else if( !wcscmp( pSymInfo->Name, _T( "KeFeatureBits" ) ) )
        {
            StSymbolsInfo.ulKeFeatureBits = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
        }
        else if( !wcscmp( pSymInfo->Name, _T( "KiDebugRoutine" ) ) )
        {
            StSymbolsInfo.ulKiDebugRoutine = ( ULONG_PTR )( pSymInfo->Address - BaseOfDll );
        }

        else if( !wcscmp( pSymInfo->Name, _T( "KeUserExceptionDispatcher" ) ) )
        {
            StSymbolsInfo.KeUserExceptionDispatcher = ( PVOID )( pSymInfo->Address - BaseOfDll );
        }
		else if( !wcscmp( pSymInfo->Name, _T( "PspSystemDll" ) ) )
		{
			StSymbolsInfo.lpPspSystemDll = ( PVOID )( pSymInfo->Address - BaseOfDll );
		}

        else
        {
            break;
        }

        IsPrint = TRUE;
    }
    while( 0 );

    if( IsPrint )
    {
        KdPrint( ( "DbgObj-> %-32ws %p\n", pSymInfo->Name, pSymInfo->Address - BaseOfDll ) );
    }


    return TRUE;
}


NTSTATUS
NTAPI
DbgObjUiConvertStateChangeStructure(
    IN LPNT_DEBUG_EVENT NtDbgEvt,
    IN OUT LPDEBUG_EVENT DbgEvt )
{
    NTSTATUS Status;
    OBJECT_ATTRIBUTES ObjectAttributes;
    THREAD_BASIC_INFORMATION ThreadBasicInfo;
    HANDLE ThreadHandle;

    DbgEvt->dwDebugEventCode = NtDbgEvt->dwDebugEventCode;
    DbgEvt->dwProcessId = NtDbgEvt->dwProcessId;
    DbgEvt->dwThreadId = NtDbgEvt->dwThreadId;

    if ( NtDbgEvt->dwDebugEventCode == EXCEPTION_DEBUG_EVENT ||
            NtDbgEvt->dwDebugEventCode == STATUS_SINGLE_STEP ||
            NtDbgEvt->dwDebugEventCode == STATUS_BREAKPOINT )
    {
        //
        // �����OutputDebugString �ϵ�������ϸ����.
        //
        if ( NtDbgEvt->u.Exception.ExceptionRecord.ExceptionCode == DBG_PRINTEXCEPTION_C )
        {
            /* Set the Win32 code */
            DbgEvt->dwDebugEventCode = OUTPUT_DEBUG_STRING_EVENT;

            /* Copy debug string information */
            DbgEvt->u.DebugString.lpDebugStringData =
                ( LPSTR )NtDbgEvt->u.Exception.ExceptionRecord.ExceptionInformation[1];

            DbgEvt->u.DebugString.nDebugStringLength =
                ( WORD )NtDbgEvt->u.Exception.ExceptionRecord.ExceptionInformation[0];

            DbgEvt->u.DebugString.fUnicode = FALSE;

        }
        else if ( NtDbgEvt->u.Exception.ExceptionRecord.ExceptionCode == DBG_RIPEXCEPTION )
        {
            /* Set the Win32 code */
            DbgEvt->dwDebugEventCode = RIP_EVENT;

            /* Set exception information */
            DbgEvt->u.RipInfo.dwType =
                NtDbgEvt->u.Exception.ExceptionRecord.ExceptionInformation[1];

            DbgEvt->u.RipInfo.dwError =
                NtDbgEvt->u.Exception.ExceptionRecord.ExceptionInformation[0];
        }
        else
        {
            /* Otherwise, this is a debug event, copy info over */
            DbgEvt->dwDebugEventCode = EXCEPTION_DEBUG_EVENT;
            DbgEvt->u.Exception.ExceptionRecord =
                NtDbgEvt->u.Exception.ExceptionRecord;

            DbgEvt->u.Exception.dwFirstChance =
                NtDbgEvt->u.Exception.dwFirstChance;
        }
    }
    else if( NtDbgEvt->dwDebugEventCode == CREATE_THREAD_DEBUG_EVENT )
    {
        /* Query the TEB */
        Status = NtQueryInformationThread( NtDbgEvt->u.CreateThread.hThread,
                                           ThreadBasicInformation,
                                           &ThreadBasicInfo,
                                           sizeof( ThreadBasicInfo ),
                                           NULL );

        if( !NT_SUCCESS( Status ) )
        {
            /* Failed to get PEB address */
            NtDbgEvt->u.CreateThread.lpThreadLocalBase = NULL;
        }
        else
        {
            /* Write PEB Address */
            NtDbgEvt->u.CreateThread.lpThreadLocalBase =
                ThreadBasicInfo.TebBaseAddress;
        }

        DbgEvt->u.CreateThread.hThread =
            NtDbgEvt->u.CreateThread.hThread;
        DbgEvt->u.CreateThread.lpStartAddress =
            NtDbgEvt->u.CreateThread.lpStartAddress;
        DbgEvt->u.CreateThread.lpThreadLocalBase =
            NtDbgEvt->u.CreateThread.lpThreadLocalBase;

    }
    else if( NtDbgEvt->dwDebugEventCode == CREATE_PROCESS_DEBUG_EVENT )
    {
        /* Query TEB address */
        Status = NtQueryInformationThread( NtDbgEvt->u.CreateProcessInfo.hThread,
                                           ThreadBasicInformation,
                                           &ThreadBasicInfo,
                                           sizeof( ThreadBasicInfo ),
                                           NULL );

        if( !NT_SUCCESS( Status ) )
        {
            /* Failed to get PEB address */
            NtDbgEvt->u.CreateProcessInfo.lpThreadLocalBase = NULL;
			KdPrint( ( "DbgObj-> Call DbgObjUiConvertStateChangeStructure PEB Error!\n" ) );
        }
        else
        {
            /* Write PEB Address */
            NtDbgEvt->u.CreateProcessInfo.lpThreadLocalBase = ThreadBasicInfo.TebBaseAddress;
        }

        /* Clear image name */
        NtDbgEvt->u.CreateProcessInfo.lpImageName = NULL;
        NtDbgEvt->u.CreateProcessInfo.fUnicode = TRUE;

        DbgEvt->u.CreateProcessInfo.dwDebugInfoFileOffset =
            NtDbgEvt->u.CreateProcessInfo.dwDebugInfoFileOffset;

        DbgEvt->u.CreateProcessInfo.fUnicode =
            NtDbgEvt->u.CreateProcessInfo.fUnicode;

        DbgEvt->u.CreateProcessInfo.hFile =
            NtDbgEvt->u.CreateProcessInfo.hFile;

        DbgEvt->u.CreateProcessInfo.hProcess =
            NtDbgEvt->u.CreateProcessInfo.hProcess;

        DbgEvt->u.CreateProcessInfo.hThread =
            NtDbgEvt->u.CreateProcessInfo.hThread;

        DbgEvt->u.CreateProcessInfo.lpBaseOfImage =
            NtDbgEvt->u.CreateProcessInfo.lpBaseOfImage;

        DbgEvt->u.CreateProcessInfo.lpImageName =
            NtDbgEvt->u.CreateProcessInfo.lpImageName;

        DbgEvt->u.CreateProcessInfo.lpStartAddress =
            NtDbgEvt->u.CreateProcessInfo.lpStartAddress;

        DbgEvt->u.CreateProcessInfo.lpThreadLocalBase =
            NtDbgEvt->u.CreateProcessInfo.lpThreadLocalBase;

        DbgEvt->u.CreateProcessInfo.nDebugInfoSize =
            NtDbgEvt->u.CreateProcessInfo.nDebugInfoSize;
    }
//---------------------------------------------------------------------------
    else if( NtDbgEvt->dwDebugEventCode == LOAD_DLL_DEBUG_EVENT )
    {
        if( !NtDbgEvt->u.LoadDll.lpImageName )
        {
            /* Open the thread */
            InitializeObjectAttributes( &ObjectAttributes, NULL, 0, NULL, NULL );

            Status = NtOpenThread( &ThreadHandle,
                                   THREAD_QUERY_INFORMATION,
                                   &ObjectAttributes,
                                   &NtDbgEvt->u.LoadDll.StClientID );

            if( NT_SUCCESS( Status ) )
            {
                /* Query thread information */
                Status = NtQueryInformationThread( ThreadHandle,
                                                   ThreadBasicInformation,
                                                   &ThreadBasicInfo,
                                                   sizeof( ThreadBasicInfo ),
                                                   NULL );
                NtClose( ThreadHandle );
            }else
			{
				KdPrint( ( "DbgObj-> Call DbgObjUiConvertStateChangeStructure NtOpenThread Error!\n" ) );
			}

            /* Check if we got thread information */
            if( NT_SUCCESS( Status ) )
            {
                /* Save the image name from the TIB */
                NtDbgEvt->u.LoadDll.lpImageName =
                    &( ( PTEB )ThreadBasicInfo.TebBaseAddress )->NtTib.ArbitraryUserPointer;
            }
            else
            {
                /* Otherwise, no name */
                NtDbgEvt->u.LoadDll.lpImageName = NULL;
				KdPrint( ( "DbgObj-> Call DbgObjUiConvertStateChangeStructure NtQueryInformationThread Error!\n" ) );
            }
        }
//---------------------------------------------------------------------------
        /* It's Unicode */
        NtDbgEvt->u.LoadDll.fUnicode = TRUE;

        DbgEvt->u.LoadDll.dwDebugInfoFileOffset =
            NtDbgEvt->u.LoadDll.dwDebugInfoFileOffset;

        DbgEvt->u.LoadDll.fUnicode =
            NtDbgEvt->u.LoadDll.fUnicode;

        DbgEvt->u.LoadDll.hFile =
            NtDbgEvt->u.LoadDll.hFile;

        DbgEvt->u.LoadDll.lpBaseOfDll =
            NtDbgEvt->u.LoadDll.lpBaseOfDll;

        DbgEvt->u.LoadDll.lpImageName =
            NtDbgEvt->u.LoadDll.lpImageName;

        DbgEvt->u.LoadDll.nDebugInfoSize =
            NtDbgEvt->u.LoadDll.nDebugInfoSize;
    }
    else if ( NtDbgEvt->dwDebugEventCode == UNLOAD_DLL_DEBUG_EVENT )
    {
        DbgEvt->u.UnloadDll.lpBaseOfDll = NtDbgEvt->u.UnloadDll.lpBaseOfDll;

    }
    else if ( NtDbgEvt->dwDebugEventCode == EXIT_THREAD_DEBUG_EVENT )
    {
        DbgEvt->u.ExitThread.dwExitCode =  NtDbgEvt->u.ExitThread.dwExitCode;

    }
    else if ( NtDbgEvt->dwDebugEventCode == EXIT_PROCESS_DEBUG_EVENT )
    {
        DbgEvt->u.ExitProcess.dwExitCode = NtDbgEvt->u.ExitProcess.dwExitCode;
    }
    else
    {
        return STATUS_UNSUCCESSFUL;
    }

    /* Return success */
    return STATUS_SUCCESS;
}

/* �����������ת����ǰ����ID. ��ɾ����*/
HANDLE
WINAPI
ProcessIdToHandle( IN DWORD dwProcessId )
{
    HANDLE Handle;

    /* If we don't have a PID, look it up */
    if ( dwProcessId == MAXDWORD )
    {
        // dwProcessId = (DWORD_PTR)CsrGetProcessId();
        return NULL;
    }

    Handle = DbgObjOpenProcess( PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION |
                                PROCESS_VM_WRITE | PROCESS_VM_READ |
                                PROCESS_SUSPEND_RESUME | PROCESS_QUERY_INFORMATION,
                                0, dwProcessId );
    if ( !Handle )
    {
        return 0;
    }

    return Handle;
}


//
// �򿪽��̵ĵ���Ȩ��.
//
void EnableDebugPrivilegies()
{
    HANDLE TTokenHd;
    TOKEN_PRIVILEGES TTokenPvg, rTTokenPvg;
    ULONG cbtpPrevious, pcbtpPreviousRequired;

    if( OpenProcessToken( GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &TTokenHd ) )
    {
        LookupPrivilegeValueA( NULL, "SeDebugPrivilege", &TTokenPvg.Privileges[0].Luid );

        TTokenPvg.PrivilegeCount = 1;
        TTokenPvg.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        cbtpPrevious = sizeof( rTTokenPvg );
        pcbtpPreviousRequired = 0;

        AdjustTokenPrivileges( TTokenHd, FALSE, &TTokenPvg, cbtpPrevious, &rTTokenPvg, &pcbtpPreviousRequired );
    }
}

//
// �򿪽��̵ļ�������Ȩ��.
//
void EnableLoadDriverPrivilegies()
{
    HANDLE TTokenHd;
    TOKEN_PRIVILEGES TTokenPvg, rTTokenPvg;
    ULONG cbtpPrevious, pcbtpPreviousRequired;

    if( OpenProcessToken( GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &TTokenHd ) )
    {
        LookupPrivilegeValueA( NULL, "SeLoadDriverPrivilege", &TTokenPvg.Privileges[0].Luid );

        TTokenPvg.PrivilegeCount = 1;
        TTokenPvg.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        cbtpPrevious = sizeof( rTTokenPvg );
        pcbtpPreviousRequired = 0;

        AdjustTokenPrivileges( TTokenHd, FALSE, &TTokenPvg, cbtpPrevious, &rTTokenPvg, &pcbtpPreviousRequired );
    }
}