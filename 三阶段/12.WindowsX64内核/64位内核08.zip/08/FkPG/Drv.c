#include "Drv.h"

typedef struct _SYSTEM_HANDLE_TABLE_ENTRY_INFO {
  USHORT UniqueProcessId;
  USHORT CreatorBackTraceIndex;
  UCHAR ObjectTypeIndex;
  UCHAR HandleAttributes;
  USHORT HandleValue;
  PVOID Object;
  ULONG GrantedAccess;
} SYSTEM_HANDLE_TABLE_ENTRY_INFO, * PSYSTEM_HANDLE_TABLE_ENTRY_INFO;

typedef struct _SYSTEM_HANDLE_INFORMATION {
  ULONG NumberOfHandles;
  SYSTEM_HANDLE_TABLE_ENTRY_INFO Handles[1];
} SYSTEM_HANDLE_INFORMATION, * PSYSTEM_HANDLE_INFORMATION;

typedef enum _SYSTEM_INFORMATION_CLASS {
  SystemBasicInformation,
  SystemProcessorInformation,             // obsolete...delete
  SystemPerformanceInformation,
  SystemTimeOfDayInformation,
  SystemPathInformation,
  SystemProcessInformation,
  SystemCallCountInformation,
  SystemDeviceInformation,
  SystemProcessorPerformanceInformation,
  SystemFlagsInformation,
  SystemCallTimeInformation,
  SystemModuleInformation,
  SystemLocksInformation,
  SystemStackTraceInformation,
  SystemPagedPoolInformation,
  SystemNonPagedPoolInformation,
  SystemHandleInformation,
  SystemObjectInformation,
  SystemPageFileInformation,
  SystemVdmInstemulInformation,
  SystemVdmBopInformation,
  SystemFileCacheInformation,
  SystemPoolTagInformation,
  SystemInterruptInformation,
  SystemDpcBehaviorInformation,
  SystemFullMemoryInformation,
  SystemLoadGdiDriverInformation,
  SystemUnloadGdiDriverInformation,
  SystemTimeAdjustmentInformation,
  SystemSummaryMemoryInformation,
  SystemMirrorMemoryInformation,
  SystemPerformanceTraceInformation,
  SystemObsolete0,
  SystemExceptionInformation,
  SystemCrashDumpStateInformation,
  SystemKernelDebuggerInformation,
  SystemContextSwitchInformation,
  SystemRegistryQuotaInformation,
  SystemExtendServiceTableInformation,
  SystemPrioritySeperation,
  SystemVerifierAddDriverInformation,
  SystemVerifierRemoveDriverInformation,
  SystemProcessorIdleInformation,
  SystemLegacyDriverInformation,
  SystemCurrentTimeZoneInformation,
  SystemLookasideInformation,
  SystemTimeSlipNotification,
  SystemSessionCreate,
  SystemSessionDetach,
  SystemSessionInformation,
  SystemRangeStartInformation,
  SystemVerifierInformation,
  SystemVerifierThunkExtend,
  SystemSessionProcessInformation,
  SystemLoadGdiDriverInSystemSpace,
  SystemNumaProcessorMap,
  SystemPrefetcherInformation,
  SystemExtendedProcessInformation,
  SystemRecommendedSharedDataAlignment,
  SystemComPlusPackage,
  SystemNumaAvailableMemory,
  SystemProcessorPowerInformation,
  SystemEmulationBasicInformation,
  SystemEmulationProcessorInformation,
  SystemExtendedHandleInformation,
  SystemLostDelayedWriteInformation,
  SystemBigPoolInformation,
  SystemSessionPoolTagInformation,
  SystemSessionMappedViewInformation,
  SystemHotpatchInformation,
  SystemObjectSecurityMode,
  SystemWatchdogTimerHandler,
  SystemWatchdogTimerInformation,
  SystemLogicalProcessorInformation,
  SystemWow64SharedInformation,
  SystemRegisterFirmwareTableInformationHandler,
  SystemFirmwareTableInformation,
  SystemModuleInformationEx,
  SystemVerifierTriageInformation,
  SystemSuperfetchInformation,
  SystemMemoryListInformation,
  SystemFileCacheInformationEx,
  MaxSystemInfoClass  // MaxSystemInfoClass should always be the last enum
} SYSTEM_INFORMATION_CLASS;

NTSTATUS
NTAPI
ZwQuerySystemInformation(
  __in SYSTEM_INFORMATION_CLASS SystemInformationClass,
  __out_bcount_opt(SystemInformationLength) PVOID SystemInformation,
  __in ULONG SystemInformationLength,
  __out_opt PULONG ReturnLength
);

typedef struct _SYSTEM_POOLTAG {
  union {
    UCHAR Tag[4];
    ULONG TagUlong;
  }Tag;
  ULONG PagedAllocs;
  ULONG PagedFrees;
  SIZE_T PagedUsed;
  ULONG NonPagedAllocs;
  ULONG NonPagedFrees;
  SIZE_T NonPagedUsed;
} SYSTEM_POOLTAG, * PSYSTEM_POOLTAG;

typedef struct _SYSTEM_SESSION_POOLTAG_INFORMATION {
  SIZE_T NextEntryOffset;
  ULONG SessionId;
  ULONG Count;
  SYSTEM_POOLTAG TagInfo[1];
} SYSTEM_SESSION_POOLTAG_INFORMATION, * PSYSTEM_SESSION_POOLTAG_INFORMATION;

typedef struct _SYSTEM_BIGPOOL_ENTRY {
  union {
    PVOID VirtualAddress;
    ULONG_PTR NonPaged : 1;     // Set to 1 if entry is nonpaged.
  }Addr;
  SIZE_T SizeInBytes;
  union {
    UCHAR Tag[4];
    ULONG TagUlong;
  }Tag;
} SYSTEM_BIGPOOL_ENTRY, * PSYSTEM_BIGPOOL_ENTRY;

typedef struct _SYSTEM_BIGPOOL_INFORMATION {
  ULONG Count;
  SYSTEM_BIGPOOL_ENTRY AllocatedInfo[1];
} SYSTEM_BIGPOOL_INFORMATION, * PSYSTEM_BIGPOOL_INFORMATION;


PULONG64 (__stdcall *MiGetPteAddress)(PVOID pAddress) = (PULONG64(__stdcall*)(PVOID))0xfffff80177b73dc8;
PULONG64(__stdcall* MiGetPdeAddress)(PVOID pAddress) = (PULONG64(__stdcall*)(PVOID))0xfffff80177b62f34;


NTSTATUS FkPG() {
  NTSTATUS Status;
  PSYSTEM_BIGPOOL_INFORMATION           PoolInfo = NULL;
  PVOID Buffer;
  ULONG BufferSize = 4096;
  ULONG ReturnLength;

  //KdBreakPoint();

retry:
  Buffer = ExAllocatePoolWithTag(NonPagedPool, BufferSize, '1234');

  if (!Buffer) {
    return STATUS_NO_MEMORY;
  }
  Status = ZwQuerySystemInformation(SystemBigPoolInformation,
    Buffer,
    BufferSize,
    &ReturnLength
  );

  if (Status == STATUS_INFO_LENGTH_MISMATCH) {
    ExFreePool(Buffer);
    BufferSize = ReturnLength;
    goto retry;
  }

  int nNumbers = 0;
  if (NT_SUCCESS(Status)) {
    PoolInfo = (PSYSTEM_BIGPOOL_INFORMATION)Buffer;

   
    for (ULONG i = 0; i < PoolInfo->Count; i++) {
      PVOID pVirtualAddress = PoolInfo->AllocatedInfo[i].Addr.VirtualAddress;
      SIZE_T nSize = PoolInfo->AllocatedInfo[i].SizeInBytes;



      if (nSize >= 0x8000) {
        

        PULONG64 ppde = MiGetPdeAddress(pVirtualAddress);
        ULONG64 pde = *ppde;
        PULONG64 ppte = MiGetPteAddress(pVirtualAddress);
        ULONG64 pte = ppte[1];
        if (pde & 0x80) { //PS == 1

        }
        else {
          if ((pte & 1) && (pte & 0x8000000000000000) == 0){ //p == 1  NX = 0 
          /*  DbgPrint("[51asm] Old address:%p size:%p pde:%p pte:%p\n", 
              pVirtualAddress, nSize, pde, pte);*/
            pte |= 0x8000000000000000;
            ppte[1] = pte;
            DbgPrint("[51asm] New address:%p size:%p pde:%p pte:%p\n",
              pVirtualAddress, nSize, pde, pte);
            nNumbers++;
          }
        }
       
      }
    }

    DbgPrint("[51asm] Count:%d nNumbers:%d\n", PoolInfo->Count, nNumbers);
  }

  if (Buffer)
    ExFreePool(Buffer);

  return Status;
}

/*����ж�غ��� clean_up*/
VOID Unload(__in struct _DRIVER_OBJECT* DriverObject)
{
  DbgPrint("[51asm] Unload! DriverObject:%p\n", DriverObject);
}


/*1.������ں���*/
 NTSTATUS DriverEntry(
  __in struct _DRIVER_OBJECT* DriverObject,
  __in PUNICODE_STRING  RegistryPath)
{
  UNREFERENCED_PARAMETER(DriverObject);
  UNREFERENCED_PARAMETER(RegistryPath);

  //4.ע��ж�غ���
  DriverObject->DriverUnload = Unload;

  DbgPrint("[51asm] DriverEntry DriverObject:%p\n", DriverObject);

  FkPG();

  return STATUS_SUCCESS;
}
