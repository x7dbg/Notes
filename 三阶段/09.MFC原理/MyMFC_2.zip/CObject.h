#pragma once
#include <Windows.h>
#include <stdio.h>

class CWinApp;

HINSTANCE AfxGetInstanceHandle();
CWinApp* AfxGetApp();


class CObject;

struct CRuntimeClass {
  LPCSTR m_lpszClassName;
  int m_nObjectSize;
  UINT m_wSchema;
  CObject* (*m_pfnCreateObject)();
  CRuntimeClass* m_pBaseClass;


  CRuntimeClass* m_pNextClass;
  const void* m_pClassInit;
};

#define DECLARE_DYNAMIC(class_name) \
public: \
	static const CRuntimeClass class##class_name; \
	virtual CRuntimeClass* GetRuntimeClass() const; \

#define _RUNTIME_CLASS(class_name) ((CRuntimeClass*)(&class_name::class##class_name))

#define RUNTIME_CLASS(class_name) _RUNTIME_CLASS(class_name)

#define IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, wSchema, pfnNew, class_init) \
	const CRuntimeClass class_name::class##class_name = { \
		#class_name, sizeof(class class_name), wSchema, pfnNew, \
			RUNTIME_CLASS(base_class_name), NULL, class_init }; \
	CRuntimeClass* class_name::GetRuntimeClass() const \
		{ return RUNTIME_CLASS(class_name); }


#define IMPLEMENT_DYNAMIC(class_name, base_class_name) \
	IMPLEMENT_RUNTIMECLASS(class_name, base_class_name, 0xFFFF, NULL, NULL)


class CObject
{
private:
public:
  static const CRuntimeClass classCObject;
  virtual CRuntimeClass* GetRuntimeClass() const;
};


