


#define SizeOf( x ) sizeof(x)/sizeof(wchar_t)

VOID _ExitProcess();

BOOL WINAPI SymbolsProc ( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
