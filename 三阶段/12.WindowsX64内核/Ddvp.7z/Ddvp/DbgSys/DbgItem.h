#ifndef _DBG_ITEM_
#define _DBG_ITEM_

#include "dbgktypes.h"

//
// Debugger Context
//
typedef struct _DEBUG_CONTEXT
{
    ULONG   Dr0;
    ULONG   Dr1;
    ULONG   Dr2;
    ULONG   Dr3;
    ULONG   Dr6;
    ULONG   Dr7;
} DEBUG_CONTEXT, *PDEBUG_CONTEXT;


typedef struct _THREAD_INFO
{
	LIST_ENTRY  ListEntry;
	HANDLE ThreadId;
    DEBUG_CONTEXT DebugContext;
} THREAD_INFO, *PTHREAD_INFO;

//
// Debuger Thread
//
typedef struct _DEBUGGER_THREAD
{
    LIST_ENTRY ThreadList;
    FAST_MUTEX Mutex;

} DEBUGGED_THREAD, *PDEBUGGED_THREAD;

typedef struct tagDbgItem
{
    LIST_ENTRY  ListEntry;
    PEPROCESS   Debugger;
    ULONG_PTR   DebuggerCr3;
    PEPROCESS   Debugged;
    ULONG_PTR	DebuggedCr3;
    ULONG       Active;
    ULONG		RefCount;
    ULONG		ProcessFlags;
    NTSTATUS    Status;
    BYTE		Buffer[64];
    DEBUG_OBJECT DebugObject;
    DEBUGGED_THREAD DebuggedThread;
} DBG_ITEM, *PDBG_ITEM;

NTSTATUS DbgItemInitDbgItem();

PDBG_ITEM DbgItemNewDbgItem(
    PEPROCESS Debugger,
    ULONG_PTR DebuggerCr3 );

VOID DbgItemDeRefItem(
    DBG_ITEM *DbgItem );

DBG_ITEM* DbgItemFindItem( PEPROCESS Debugger,
                           PEPROCESS Debugged );

VOID DbgItemDeleteItem(
    DBG_ITEM* DbgItem );

VOID DbgItemNewProcess( DBG_ITEM* DbgItem,
                        PEPROCESS Debugged,
                        ULONG_PTR DebuggedCr3 );

VOID DbgItemExitProcess(
    DBG_ITEM* DbgItem );

VOID DbgItemAttachProcess(
    DBG_ITEM* DbgItem,
    PEPROCESS Debugged,
    ULONG_PTR DebuggedCr3 );

DBG_ITEM* DbgItemCr3FindItem(
    ULONG_PTR DebuggerCr3,
    ULONG_PTR DebuggedCr3 );


#endif
