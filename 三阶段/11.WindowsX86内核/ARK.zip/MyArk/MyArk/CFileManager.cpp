﻿// CFileManager.cpp: 实现文件
//

#include "pch.h"
#include "MyArk.h"
#include "resource.h"
#include "afxdialogex.h"
#include "CFileManager.h"
#include "Data.h"
// CFileManager 对话框

IMPLEMENT_DYNAMIC(CFileManager, CDialogEx)

CFileManager::CFileManager(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_FILE, pParent)
{

}

CFileManager::~CFileManager()
{
    TravelAll(m_hItemHead);
}

void CFileManager::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, TREE_FILE, m_Tree);
	DDX_Control(pDX, LST_FILE, m_ListCtrl);
}


BEGIN_MESSAGE_MAP(CFileManager, CDialogEx)
	ON_NOTIFY(NM_CLICK, TREE_FILE, &CFileManager::OnClickTreeFile)
END_MESSAGE_MAP()


// CFileManager 消息处理程序



BOOL CFileManager::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIconComputer;
	HICON hIconFolder;//文件夹图标
	HICON hIconDisk;
	HICON hIconFile;
	hIconComputer = theApp.LoadIcon(IDI_COMPUTER);
	hIconFolder = theApp.LoadIcon(IDI_EXP);//文件夹图标
	hIconDisk = theApp.LoadIcon(IDI_DISK);
	hIconFile = theApp.LoadIcon(IDI_FILE);
	m_imgIcon.Create(24, 24, ILC_COLOR24 | ILC_MASK, 1, 1); //创建图像
	m_imgIcon.Add(hIconComputer); //添加计算机icon
	m_imgIcon.Add(hIconFolder); //添加文件夹icon
	m_imgIcon.Add(hIconDisk);
	m_imgIcon.Add(hIconFile);

	m_Tree.SetImageList(&m_imgIcon, LVSIL_NORMAL); //设置根节点图标
	m_ListCtrl.SetImageList(&m_imgIcon, LVSIL_SMALL);





	m_hItemHead = m_Tree.InsertItem(L"我的电脑", ICON_COMPUTER, ICON_COMPUTER);
	WCHAR szName[MAX_PATH] = { 0 };
	GetLogicalDriveStrings(MAX_PATH, szName);
	WCHAR rootPath[10] = { 0 };
	WCHAR driveType[21] = { 0 };
	DWORD nType = 0;
	for (char ch = 'A'; ch <= 'Z'; ch++)
	{
		wsprintf(rootPath, L"%c:\\", ch);
		nType = GetDriveType(rootPath);
		if (nType == DRIVE_FIXED)//硬盘
		{
			CString buff;
			buff.Format(L"%c:", ch);
			//将所有系统盘符设置到树中
			HTREEITEM hItem = m_Tree.InsertItem(buff, ICON_DISK, ICON_DISK,m_hItemHead);
			wchar_t* pBuff = _wcsdup(buff.GetBuffer());
			m_Tree.SetItemData(hItem, (DWORD_PTR)pBuff);
		}
	}
	LONG lStyle;
	lStyle = GetWindowLong(m_ListCtrl.m_hWnd, GWL_STYLE);//获取当前窗口style
	lStyle &= ~LVS_TYPEMASK; //清除显示方式位
	lStyle |= LVS_REPORT; //设置style
	SetWindowLong(m_ListCtrl.m_hWnd, GWL_STYLE, lStyle);//设置style
	DWORD dwStyle = m_ListCtrl.GetExtendedStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;//选中某行使整行高亮
	dwStyle |= LVS_EX_GRIDLINES;//网格线
	dwStyle |= LVS_EX_DOUBLEBUFFER | LVS_EX_SUBITEMIMAGES;
	m_ListCtrl.SetExtendedStyle(dwStyle);
	CRect cRect;
	m_ListCtrl.GetClientRect(cRect);
	m_ListCtrl.InsertColumn(0, L"文件名", 0, cRect.Width() / 4);
	m_ListCtrl.InsertColumn(1, L"文件大小", 0, cRect.Width() / 4);
	m_ListCtrl.InsertColumn(2, L"创建时间", 0, cRect.Width() / 4);
	m_ListCtrl.InsertColumn(3, L"修改时间", 0, cRect.Width() / 4);


	

	return TRUE;  // return TRUE unless you set the focus to a control
	// 异常: OCX 属性页应返回 FALSE
}


void CFileManager::OnClickTreeFile(NMHDR* pNMHDR, LRESULT* pResult)
{
	DWORD dwChild = 0;
	tagENUMFILES test;
	DWORD dwSize = 0;
	WCHAR wPath[256] = { 0 };
	CString LastPath;
	int nIndex = 0;
	FILETIME ftCreate;
	FILETIME ftUpdate;

	HTREEITEM hItem = m_Tree.GetSelectedItem();
	// 判断是否有值
	if (!hItem)
		return;
	HTREEITEM hChild = m_Tree.GetNextItem(hItem, TVGN_CHILD);
	// 判断是否有子节点
	if (hChild)
		dwChild = 1;
	CStringW Path = (wchar_t*)m_Tree.GetItemData(hItem);

	if (Path.IsEmpty())
		return;
	// 遍历文件
	m_ListCtrl.DeleteAllItems();
	LastPath = L"\\??\\" + Path + L"\\";
	wcscpy_s(wPath, LastPath.GetLength() * 2, LastPath.GetBuffer());
	int len = wcslen(wPath) * 2 + 2;
	// 获取所需空间
	DeviceIoControl(g_hDevice, IOCTL_FILE, wPath, len, &test, sizeof(tagENUMFILES), &dwSize, NULL);
	tagENUMFILES* pFile = new tagENUMFILES[dwSize]();
	// 发送路径信息
	DeviceIoControl(g_hDevice, IOCTL_FILE, wPath, len, pFile, dwSize, &dwSize, NULL);
	// 获取所有项数
	int nCount = dwSize / sizeof(tagENUMFILES);
	for (int i = 0; i < nCount; i++)
	{
		// 判断是目录还是文件
		BYTE Flag = pFile[i].m_szFileOrDirectory;
		CString Buffer = pFile[i].m_wzFileName;
		if (Flag == 0 && !dwChild)	// 目录
		{
			HTREEITEM hItem2 = m_Tree.InsertItem(Buffer, ICON_FOLDER, ICON_FOLDER, hItem);
			CString szFullPath;
			szFullPath.Format(L"%s\\%s", Path, Buffer);  //拼接起来
			wchar_t* pBuff = _wcsdup(szFullPath.GetBuffer()); //wcsdup 申请空间拷贝字符串 需要释放空间free
			OutputDebugString(szFullPath);
			m_Tree.SetItemData(hItem2, (DWORD_PTR)pBuff);
		}
		else if (Flag == 1) // 文件
		{
			m_ListCtrl.InsertItem(nIndex, _T(""),ICON_FILE);
			m_ListCtrl.SetItemText(nIndex, 0, Buffer);	// 文件名
			CString Temp;
			Temp.Format(L"%uB", pFile[i].m_nSize);
			m_ListCtrl.SetItemText(nIndex, 1, Temp);	// 大小
			memcpy(&ftCreate, &pFile[i].m_CreateTime, sizeof(ftCreate));
			memcpy(&ftUpdate, &pFile[i].m_UpdateTime, sizeof(ftUpdate));
			SYSTEMTIME stSystem = { 0 };
			FILETIME ftFileTime = { 0 };
			FileTimeToLocalFileTime(&ftCreate, &ftFileTime);//将文件时间格式转换为本地文件时间
			FileTimeToSystemTime(&ftFileTime, &stSystem); //将文件时间转为系统时间
			Temp.Format(L"%4d-%02d-%02d %02d:%02d:%02d", stSystem.wYear, stSystem.wMonth, stSystem.wDay, stSystem.wHour, stSystem.wMinute, stSystem.wSecond);
			m_ListCtrl.SetItemText(nIndex, 2, Temp);	// 创建时间
			FileTimeToLocalFileTime(&ftUpdate, &ftFileTime);
			FileTimeToSystemTime(&ftFileTime, &stSystem);
			Temp.Format(L"%4d-%02d-%02d %02d:%02d:%02d", stSystem.wYear, stSystem.wMonth, stSystem.wDay, stSystem.wHour, stSystem.wMinute, stSystem.wSecond);
			m_ListCtrl.SetItemText(nIndex, 3, Temp);	// 修改时间
			++nIndex;
		}
	}
	delete[] pFile;

	*pResult = 0;
}

void CFileManager::TravelAll(HTREEITEM ht)
{
	wchar_t* pFree = (wchar_t*)m_Tree.GetItemData(ht);
	if (pFree != NULL)
	{

		free(pFree);
	}
	HTREEITEM hCurItem = m_Tree.GetChildItem(ht);
	HTREEITEM hNextItem;

	while (hCurItem)
	{
		hNextItem = hCurItem;
		TravelAll(hNextItem);
		hCurItem = m_Tree.GetNextSiblingItem(hCurItem);
	}

}

BOOL CFileManager::DestroyWindow()
{
	// TODO: 在此添加专用代码和/或调用基类

	return CDialogEx::DestroyWindow();
}
