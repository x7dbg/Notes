#ifndef IO_CONTROL_CODE
#define IO_CONTROL_CODE

#define MAIN_VERSION			0
#define CHILD_VERSION			72 /* Dichlorvos�İ汾 */

#pragma pack (push, 1)

#define PSF_CREATE_REPORTED_BIT		1
#define PSF_LOAD_NTDLL				2
#define PSF_WAIT_FOR_EVENT			4

typedef struct tagSymbolsInfo
{
	PVOID lpDbgkCreateThread;
	PVOID lpKiFastCallEntry;
	PVOID lpDbgkExitProcess;
	PVOID lpDbgkExitThread;
	PVOID lpExitThread;
	PVOID lpDbgkForwardException;
	PVOID lpDbgkMapViewOfSection;
	PVOID lpDbgkUnMapViewOfSection;
	PVOID lpMmGetFileNameForSection;
	PVOID lpObDuplicateObject;
	PVOID lpObpCloseHandle;
	PVOID lpKeThawAllThreads;
	PVOID lpKeFreezeAllThreads;
	PVOID lpPspExitThread;
	PVOID lpPsGetContextThread;
	PVOID lpPsSetContextThread;
	PVOID lpLdrInitializeThunk;
	PVOID lpDbgBreakPoint;
	PVOID lpKeContextFromKframes;
	PVOID lpRtlDispatchException;
	PVOID lpRtlRaiseException;
	PVOID lpKiSegSsToTrapFrame;
	PVOID lpKiEspToTrapFrame;
	PVOID lpKeContextToKframes;
	PVOID lpPsGetNextProcessThread;
	PVOID lpPsResumeThread;
	PVOID lpKeSuspendThread;
	PVOID lpKeForceResumeThread;
	PVOID lpKiAttachProcess;
	PVOID lpMmGetFileNameForAddress;
	PVOID lpMmCopyVirtualMemory;
	PVOID lpKiDispatchException;
	PVOID lpKiCheckForAtlThunk;
	PVOID lpSeDebugPrivilege;
	PVOID lpPspUserThreadStartup;
	PVOID lpPspCreateThread;
	PVOID lpMiUnmapViewOfSection;
	PVOID lpPsGetThreadProcess;
	PVOID lpPsGetThreadId;
	PVOID lpMiProtectVirtualMemory;

	PVOID lpKiTrap01;
	PVOID lpKiTrap03;
	PVOID lpKiTrap0F;

	ULONG ulPsInitialSystemProcess;
	ULONG ulObpKernelHandleTable;
	ULONG ulKdDebuggerEnabled;
	PVOID KeUserExceptionDispatcher;
	ULONG ulMmUserProbeAddress;
	ULONG ulPsProcessType;
	ULONG ulMmHighestUserAddress;
	ULONG ulPsSystemDllBase;
	ULONG ulPsNtDllPathName;
	ULONG ulKeI386XMMIPresent;
	ULONG ulKeFeatureBits;
	ULONG ulKiDebugRoutine;
	PVOID lpPspSystemDll;
}SYMBOLS_INFO, *PSYMBOLS_INFO;

typedef struct _NT_LOAD_DLL_DEBUG_INFO {
	CLIENT_ID StClientID;
	HANDLE hFile;
	LPVOID lpBaseOfDll;
	DWORD dwDebugInfoFileOffset;
	DWORD nDebugInfoSize;
	LPVOID lpImageName;
	WORD fUnicode;
} NT_LOAD_DLL_DEBUG_INFO, *LPNT_LOAD_DLL_DEBUG_INFO;

typedef struct _NTEXCEPTION_DEBUG_INFO {
	EXCEPTION_RECORD ExceptionRecord;
	DWORD dwFirstChance;
} NT_EXCEPTION_DEBUG_INFO, *LPNT_EXCEPTION_DEBUG_INFO;

typedef struct NT_CREATE_THREAD_DEBUG_INFO {
	HANDLE hThread;
	LPVOID lpThreadLocalBase;
	LPTHREAD_START_ROUTINE lpStartAddress;
} NT_CREATE_THREAD_DEBUG_INFO, *LPNT_CREATE_THREAD_DEBUG_INFO;

typedef struct _NTCREATE_PROCESS_DEBUG_INFO {
	HANDLE hFile;
	HANDLE hProcess;
	HANDLE hThread;
	LPVOID lpBaseOfImage;
	DWORD dwDebugInfoFileOffset;
	DWORD nDebugInfoSize;
	LPVOID lpThreadLocalBase;
	LPTHREAD_START_ROUTINE lpStartAddress;
	LPVOID lpImageName;
	WORD fUnicode;
} NT_CREATE_PROCESS_DEBUG_INFO, *LPNT_CREATE_PROCESS_DEBUG_INFO;

typedef struct _NTEXIT_THREAD_DEBUG_INFO {
	DWORD dwExitCode;
} NT_EXIT_THREAD_DEBUG_INFO, *LPNT_EXIT_THREAD_DEBUG_INFO;

typedef struct _NTEXIT_PROCESS_DEBUG_INFO {
	DWORD dwExitCode;
} NT_EXIT_PROCESS_DEBUG_INFO, *LPNTEXIT_PROCESS_DEBUG_INFO;

typedef struct _NTUNLOAD_DLL_DEBUG_INFO {
	LPVOID lpBaseOfDll;
} NT_UNLOAD_DLL_DEBUG_INFO, *LPNTUNLOAD_DLL_DEBUG_INFO;

typedef struct _NTOUTPUT_DEBUG_STRING_INFO {
	LPSTR lpDebugStringData;
	WORD fUnicode;
	WORD nDebugStringLength;
} NT_OUTPUT_DEBUG_STRING_INFO, *LPNT_OUTPUT_DEBUG_STRING_INFO;

typedef struct _NTRIP_INFO {
	DWORD dwError;
	DWORD dwType;
} NT_RIP_INFO, *LPNTRIP_INFO;

typedef struct _NT_DEBUG_EVENT
{
	LIST_ENTRY  ListEntry;
	ULONG Flags;
	DWORD dwDebugEventCode;
	DWORD dwProcessId;
	DWORD dwThreadId;
	union {
		NT_EXCEPTION_DEBUG_INFO Exception;
		NT_CREATE_THREAD_DEBUG_INFO CreateThread;
		NT_CREATE_PROCESS_DEBUG_INFO CreateProcessInfo;
		NT_EXIT_THREAD_DEBUG_INFO ExitThread;
		NT_EXIT_PROCESS_DEBUG_INFO ExitProcess;
		NT_LOAD_DLL_DEBUG_INFO LoadDll;
		NT_UNLOAD_DLL_DEBUG_INFO UnloadDll;
		NT_OUTPUT_DEBUG_STRING_INFO DebugString;
		NT_RIP_INFO RipInfo;
	} u;

}NT_DEBUG_EVENT, *LPNT_DEBUG_EVENT;

typedef struct tagWaitForDebugEvent
{
	NT_DEBUG_EVENT DebugEvent;
	PLARGE_INTEGER TimeOut;

}WAITFOR_DEBUGEVENT, *PWAITFOR_DEBUGEVENT;

typedef struct tagContinueDebugEvent
{
	HANDLE dwProcessId;
	HANDLE dwThreadId;
	ULONG dwContinueStatus;

}CONTINUE_DEBUGEVENT, *PCONTINUE_DEBUGEVENT;

typedef struct tagDebugActiveProcess
{
	 HANDLE dwProcessId;

}DEBUG_ACTIVE_PROCESS, *PDEBUG_ACTIVE_PROCESS;


typedef struct tagNtProtectVirtualMemory
{
	HANDLE ProcessHandle;
	PVOID *UnsafeBaseAddress;
	SIZE_T *UnsafeNumberOfBytesToProtect;
	ULONG NewAccessProtection;
	PULONG UnsafeOldAccessProtection;

}NT_PROTECT_VIRTUALMEMORY, *PNT_PROTECT_VIRTUALMEMORY;

typedef struct tagCreateDevice
{
	SYMBOLS_INFO StSymbols;
	DWORD dwProcessID;
}CREATE_DEVICE, *PCREATE_DEVICE;

typedef struct tagReadMemory
{
	
	HANDLE hProcess;
	PVOID BaseAddress;
	PVOID Buffer;
	DWORD NumberOfBytesToRead;
	PDWORD NumberOfBytesRead;

}READ_MEMORY, *PREAD_MEMORY;

typedef struct tagWriteMemory
{

	HANDLE hProcess;
	PVOID BaseAddress;
	PVOID Buffer;
	DWORD NumberOfBytesToWrite;
	PDWORD NumberOfBytesWritten;

}WRITE_MEMORY, *PWRITE_MEMORY;


typedef struct tagOpenProcess
{
	PHANDLE ProcessHandle;
	ACCESS_MASK DesiredAccess;
	POBJECT_ATTRIBUTES ObjectAttributes;
	PCLIENT_ID ClientId;
}OPEN_PROCESS, *POPEN_PROCESS;


typedef struct tagGetThreadContext
{
	HANDLE hThread;
	PCONTEXT lpContext;

}GET_THREAD_CONTEXT, *PGET_THREAD_CONTEXT;

typedef struct tagSetThreadContext
{
	HANDLE hThread;
	PCONTEXT lpContext;

}SET_THREAD_CONTEXT, *PSET_THREAD_CONTEXT;

typedef struct tagSuspendThread
{
	HANDLE hThread;
	PULONG lpPreviousSuspendCount;

}SUSPEND_THREAD, *PSUSPEND_THREAD;

typedef struct tagResumeThread
{
	HANDLE hThread;
	PULONG lpPreviousSuspendCount;

}RESUME_THREAD, *PRESUME_THREAD;

typedef struct tagOpenThread
{	
	PHANDLE ThreadHandle;
	ACCESS_MASK DesiredAccess;
	POBJECT_ATTRIBUTES ObjectAttributes;
	PCLIENT_ID ClientId;
	
}OPEN_THREAD, *POPEN_THREAD;

typedef struct tagSystemCall
{
	int Number;
	PVOID lpInBuffer;
	ULONG ulInBufferSize;
	PVOID lpOutBuffer;
	ULONG ulOutBufferSize;

}SYSTEM_CALL, *PSYSTEM_CALL;

typedef int (*SYS_CALL)( SYSTEM_CALL* SysData );

#pragma pack( pop )



// R3��R0ͨ����Ϣ
typedef enum _WM_MESSAGE {
	SC_IRP_CREATE,
	SC_IRP_CLOSE,
	SC_GET_VERSION,
	SC_CREATE_PROCESS_BEFORE,
	SC_CREATE_PROCESS_CLEAN,
	SC_CREATE_PROCESS_AFTER,
	SC_NTWAITFOR_DEBUGEVENT,
	SC_CONTINUE_DEBUGEVENT,
	SC_DEBUGACTIVEPROCESS,
	SC_OPEN_PROCESS,
	SC_OPEN_THREAD,
	SC_READ_VIRTUAL_MEMORY,
	SC_WRITE_VIRTUAL_MEMORY,
	SC_GET_THREAD_CONTEXT,
	SC_SET_THREAD_CONTEXT,
	SC_SUSPEND_THREAD,
	SC_RESUME_THREAD,
	SC_CHECKBIOS_ISENABLED,
	SC_NTPROTECTVIRTUALMEMORY
} WM_MESSAGE;

#endif
