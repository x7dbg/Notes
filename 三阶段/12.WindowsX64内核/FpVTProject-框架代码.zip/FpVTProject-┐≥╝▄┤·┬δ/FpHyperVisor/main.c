#include "helpers.h"
#include <ntddk.h>
#include "vmx.h"
#include "VtSsdtHook.h"

/* LDR_DATA_TABLE_ENTR */
typedef struct _LDR_DATA_TABLE_ENTRY {
	LIST_ENTRY InLoadOrderLinks;
	LIST_ENTRY InMemoryOrderLinks;
	LIST_ENTRY InInitializationOrderLinks;
	PVOID DllBase;
	PVOID EntryPoint;
	ULONG_PTR SizeOfImage;
	UNICODE_STRING FullDllName;
	UNICODE_STRING BaseDllName;
	ULONG Flags;
	USHORT LoadCount;
	USHORT TlsIndex;
	union {
		LIST_ENTRY HashLinks;
		struct {
			PVOID SectionPointer;
			ULONG CheckSum;
		}u3;
	}u1;
	union {
		struct {
			ULONG TimeDateStamp;
		}u4;
		struct {
			PVOID LoadedImports;
		}u5;
	}u2;
}LDR_DATA_TABLE_ENTRY, * PLDR_DATA_TABLE_ENTRY;

typedef struct _KernelMdouleInfo
{
	ULONG_PTR Base; // ��ַ
	ULONG_PTR Size; // ��С
}KernelMdouleInfo, * PKernelMdouleInfo;

KernelMdouleInfo VtKernelInfo;

// ��ȡ�ں�ģ���ַ����С 
NTSTATUS GetKernelMoudleBaseAndSize(IN PDRIVER_OBJECT DriverObject,OUT PULONG_PTR szBase,OUT PULONG_PTR szSize)
{
	NTSTATUS dwStatus = STATUS_UNSUCCESSFUL;
	UNICODE_STRING dwKernelMoudleName;
	RtlInitUnicodeString(&dwKernelMoudleName, L"ntoskrnl.exe");

	// ��ȡ��������, ����ģ��
	PLDR_DATA_TABLE_ENTRY dwEentry = (PLDR_DATA_TABLE_ENTRY)(DriverObject->DriverSection);
	PLIST_ENTRY  dwFirstentry = NULL;
	PLIST_ENTRY  dwpCurrententry = NULL;
	PLDR_DATA_TABLE_ENTRY pCurrentModule = NULL;

	if (dwEentry)
	{
		dwFirstentry = dwEentry->InLoadOrderLinks.Flink;
		dwpCurrententry = dwFirstentry->Flink;

		while (dwFirstentry != dwpCurrententry)
		{
			// ��ȡLDR_DATA_TABLE_ENTRY�ṹ
			pCurrentModule = CONTAINING_RECORD(dwpCurrententry, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);

			if (pCurrentModule->BaseDllName.Buffer != 0)
			{
				if (RtlCompareUnicodeString(&dwKernelMoudleName, &(pCurrentModule->BaseDllName), FALSE) == 0)
				{
					*szBase = (__int64)pCurrentModule->DllBase;
					*szSize = (__int64)pCurrentModule->SizeOfImage;

					dwStatus = STATUS_SUCCESS;
					return dwStatus;
				}
			}
			// ��һ��
			dwpCurrententry = dwpCurrententry->Flink;
		}
	}
	return dwStatus;
}


VOID UnLoadDriver(PDRIVER_OBJECT pDriverObject)
{
	PDEVICE_OBJECT pDevObj;
	UNICODE_STRING sysLinkName;
	kprintf("unload!");
	//__debugbreak();
	VmxTermination();
}

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING pPath)
{
	PAGED_CODE();

	DbgPrint("DriverEntry");
	ExInitializeDriverRuntime(DrvRtPoolNxOptIn);

	NTSTATUS dwStatus = STATUS_SUCCESS;
	dwStatus = GetKernelMoudleBaseAndSize(DriverObject, &VtKernelInfo.Base, &VtKernelInfo.Size);
	if (!NT_SUCCESS(dwStatus))
	{
		DbgPrint(("GetKernelMoudleBaseAndSize Error: [%X]", dwStatus));
		return dwStatus;
	}



	DriverObject->DriverUnload = UnLoadDriver;


	//VMX��ʼ��
	if (!VmxInit())
	{
		return STATUS_UNSUCCESSFUL;
	}

	//��ʼ��ssdt hook
	if (!VtInitSsdtHook())
	{
		DbgPrint("VtInitSsdtHook_error");
		return STATUS_SUCCESS;
	}

	VmxStart();



	return STATUS_SUCCESS;
}









