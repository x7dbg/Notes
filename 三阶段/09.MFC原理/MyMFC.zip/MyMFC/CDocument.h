#pragma once
#include "CCmdTarget.h"
class CDocument :
    public CCmdTarget
{
};

