#pragma once
#include "CCmdTarget.h"
class CDocument :
    public CCmdTarget
{
    DECLARE_DYNAMIC(CDocument);
};

