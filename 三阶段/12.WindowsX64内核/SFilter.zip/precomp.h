

#include <ntifs.h>
#include <ntdddisk.h>
#include <ntimage.h>
#include <stdio.h>
#include <windef.h>
#include <ntstrsafe.h>

#include "namelookup.h"
#include "namelookupdef.h"

#pragma warning(disable:4995)



