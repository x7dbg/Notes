#pragma once
#include "CDocTemplate.h"
#include "CFrameWnd.h"
class CSingleDocTemplate :public CDocTemplate
{
public:
  CDocument* OpenDocumentFile(LPCTSTR lpszPathName, BOOL bMakeVisible = TRUE);
  CDocument* OpenDocumentFile(LPCTSTR lpszPathName, BOOL bAddToMRU, BOOL bMakeVisible);
protected:  
  CDocument* m_pOnlyDoc;
  UINT m_nIDResource;
};

