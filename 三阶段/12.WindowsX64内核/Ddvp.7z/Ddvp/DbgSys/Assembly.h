ULONG GetCr0();
ULONG GetCr2();
ULONG GetCr3();
ULONG GetCr4();
ULONG GetEflags();
NTSTATUS MakeHyperExitCall();
USHORT GetLdtrSelector();
USHORT GetTrSelector();
ULONG GetGdtBase();
USHORT GetGdtLimit();
USHORT GetIdtLimit();
VOID ExecuteInvd();
VOID NewKiFastCallEntry(VOID);
VOID NewKiFastCallEntryCallEbx(VOID);
VOID SetIdtr( ULONG Base, ULONG Limit );
ULONG64 WriteMsr(ULONG MSRIndex,ULONG LowPart,ULONG HighPart);
USHORT GetCsSelector();
USHORT GetDsSelector();
USHORT GetEsSelector();
USHORT GetFsSelector();
USHORT GetGsSelector();
USHORT GetSsSelector();

VOID _KiTrap01(VOID);

VOID
NTAPI
Naked_PspUserThreadStartup(VOID);


VOID ExecuteVmxOn( ULONG PtrLowPart, ULONG PtrHighPart );
VOID ExecuteVmPtrLd( ULONG PtrLowPart, ULONG PtrHighPart );
VOID ExecuteVmClear( ULONG PtrLowPart, ULONG PtrHighPart );
VOID WriteVMCS( ULONG Field, ULONG Value );
ULONG ReadVMCS( ULONG Field );
ULONG ExecuteVmLaunch( VOID );
ULONG VmLaunchFailValid( VOID );

VOID ExecuteVmxOff( ULONG_PTR RegEsp, ULONG_PTR RegEip );
VOID GuestExitPoint(VOID);
VOID GuestEntryPoint( PVOID _GuestEsp );

ULONG VmFailInvalid();
ULONG GetIdtBase();
ULONG_PTR GetCr3();
ULONG_PTR GetCr4();
ULONG64 ReadMsr( ULONG Index );
VOID SetCr2( ULONG_PTR ulValue );
VOID SetCr4( ULONG_PTR ulValue );

NTSTATUS HookKiFastCallEntry( PVOID* OldKiFastCallEntry, PVOID NewKiFastCallEntry );
VOID ExecuteCpuId( ULONG fn, OUT PULONG ret_eax, OUT PULONG ret_ebx, OUT PULONG ret_ecx, OUT PULONG ret_edx );
void WriteProtectedOpen();
void WriteProtectedClose();


ULONG_PTR GetKiFastCallEntry();