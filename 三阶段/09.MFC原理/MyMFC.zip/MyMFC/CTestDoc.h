#pragma once
#include "CDocument.h"
class CTestDoc :
    public CDocument
{
};

