﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 PlantDLL.rc 使用
//
#define IDD_DIALOG1                     1000
#define IDC_BUTTON1                     1000
#define IDB_BITMAP1                     1002
#define IDB_BITMAP2                     1003
#define IDC_STATIC_1                    1003
#define IDB_BITMAP3                     1004
#define IDC_STATIC_2                    1004
#define IDB_BITMAP4                     1005
#define IDC_STATIC_3                    1005
#define IDB_BITMAP5                     1006
#define IDC_STATIC_4                    1006
#define IDB_BITMAP6                     1007
#define IDC_STATIC_5                    1007
#define IDC_STATIC_6                    1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1018
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
