#include "Data.h"
HANDLE g_hDevice = NULL;