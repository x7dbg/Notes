﻿#pragma once

#include <afxcontrolbars.h>
// CGameDlg 对话框

class CGameDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CGameDlg)

public:
	CGameDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CGameDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = DLG_GAME };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOpenpickup();
	afx_msg void OnBnClickedCloseppickup();
	afx_msg void OnBnClickedAutoplant();
	afx_msg void OnBnClickedNextlevel();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedSunshine();
};



