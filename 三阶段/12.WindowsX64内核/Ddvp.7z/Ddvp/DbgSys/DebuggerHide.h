#include <ntddk.h>

#define NUMBER_HASH_BUCKETS 37

enum ObjectType
{
    ID_PROCESS,
    ID_THREAD
};

typedef struct _HANDLE_TABLE_ENTRY
{
    union
    {
        PVOID Object;
        ULONG ObAttributes;
    };
    union
    {
        union
        {
            ACCESS_MASK GrantedAccess;
            struct
            {
                USHORT GrantedAccessIndex;
                USHORT CreatorBackTraceIndex;
            };
        };
        LONG NextFreeTableEntry;
    };
} HANDLE_TABLE_ENTRY, *PHANDLE_TABLE_ENTRY;

//KPCR�����õ�
#pragma pack(push)//�ṹ����
#pragma pack(1)

#pragma pack(pop)
//
// Object Type Structure
//

typedef struct _OBJECT_HEADER
{
    LONG_PTR PointerCount;
    union
    {
        LONG_PTR HandleCount;
        PVOID NextToFree;
    };
    POBJECT_TYPE Type;
    UCHAR NameInfoOffset;
    UCHAR HandleInfoOffset;
    UCHAR QuotaInfoOffset;
    UCHAR Flags;

    union
    {
        PVOID ObjectCreateInfo;//POBJECT_CREATE_INFORMATION ObjectCreateInfo;
        PVOID QuotaBlockCharged;
    };

    PVOID SecurityDescriptor;//PSECURITY_DESCRIPTOR SecurityDescriptor;
    QUAD Body;
} OBJECT_HEADER, *POBJECT_HEADER;

//
// Object Directory Structure
//

#define NUMBER_HASH_BUCKETS 37
#define OBJ_INVALID_SESSION_ID 0xFFFFFFFF

typedef struct _OBJECT_DIRECTORY
{
    struct _OBJECT_DIRECTORY_ENTRY *HashBuckets[ NUMBER_HASH_BUCKETS ];
    ULONG Lock;//EX_PUSH_LOCK Lock;
    struct _DEVICE_MAP *DeviceMap;
    ULONG SessionId;
} OBJECT_DIRECTORY, *POBJECT_DIRECTORY;
// end_ntosp

//
// Object Directory Entry Structure
//
typedef struct _OBJECT_DIRECTORY_ENTRY
{
    struct _OBJECT_DIRECTORY_ENTRY *ChainLink;
    PVOID Object;
    ULONG HashValue;
} OBJECT_DIRECTORY_ENTRY, *POBJECT_DIRECTORY_ENTRY;

// begin_ntosp
typedef struct _OBJECT_HEADER_NAME_INFO
{
    POBJECT_DIRECTORY Directory;
    UNICODE_STRING Name;
    ULONG QueryReferences;
#if DBG
    ULONG Reserved2;
    LONG DbgDereferenceCount;
#ifdef _WIN64
    ULONG64  Reserved3;   // Win64 requires these structures to be 16 byte aligned.
#endif
#endif
} OBJECT_HEADER_NAME_INFO, *POBJECT_HEADER_NAME_INFO;
// end_ntosp

typedef struct _OBJECT_HEADER_CREATOR_INFO
{
    LIST_ENTRY TypeList;
    HANDLE CreatorUniqueProcess;
    USHORT CreatorBackTraceIndex;
    USHORT Reserved;
} OBJECT_HEADER_CREATOR_INFO, *POBJECT_HEADER_CREATOR_INFO;

typedef struct _TABLE_ENTRY
{
    DWORD object;
    ACCESS_MASK security;
} TABLE_ENTRY, *PTABLE_ENTRY, **PPTABLE_ENTRY, ***PPPTABLE_ENTRY;

//ObOpenObjectByName
NTSTATUS ObOpenObjectByName( IN POBJECT_ATTRIBUTES ObjectAttributes,
                             IN POBJECT_TYPE ObjectType OPTIONAL,
                             IN KPROCESSOR_MODE AccessMode,
                             IN OUT PACCESS_STATE AccessState OPTIONAL,
                             IN ACCESS_MASK DesiredAccess OPTIONAL,
                             IN OUT PVOID ParseContext OPTIONAL,
                             OUT PHANDLE Handle );
NTSTATUS
NTAPI
ObCreateObjectType(IN PUNICODE_STRING TypeName,
				   IN PVOID ObjectTypeInitializer,
				   IN PVOID Reserved,
				   OUT POBJECT_TYPE *ObjectType);

NTSTATUS
CreateNewObjectTypeByName(
    IN PCWSTR ObjectTypeName,//Ҫ�����Ķ������͵�����
    IN POBJECT_TYPE pObjectTypeForCopy,//ԭʼ��ObjectType
    OUT POBJECT_TYPE *pNewObjectType ); //�����´�����ObjectType


void DecrementObjectCount( POBJECT_TYPE p_objType );
POBJECT_TYPE FindObjectTypes( char *ac_tName );


typedef struct _HANDLE_TRACE_DB_ENTRY
{
    CLIENT_ID    ClientId;
    HANDLE       Handle;
    ULONG        Type;
    PVOID        StackTrace[16];

} HANDLE_TRACE_DB_ENTRY;
*PHANDLE_TRACE_DB_ENTRY;
typedef struct _HANDLE_TRACE_DEBUG_INFO
{
    ULONG CurrentStackIndex;
    HANDLE_TRACE_DB_ENTRY TraceDb[4096];

} HANDLE_TRACE_DEBUG_INFO, *PHANDLE_TRACE_DEBUG_INFO;
typedef struct _HANDLE_TABLE
{
    PVOID TableCode;
    PEPROCESS QuotaProcess;
    PVOID UniqueProcessId;
    EX_PUSH_LOCK HandleTableLock [4];
    LIST_ENTRY HandleTableList;
    EX_PUSH_LOCK HandleContentionEvent;
    PHANDLE_TRACE_DEBUG_INFO DebugInfo;
    ULONG ExtraInfoPages;
    ULONG FirstFree;
    ULONG LastFree;
    ULONG NextHandleNeedingPool;
    ULONG HandleCount;
    ULONG Flags;
} HANDLE_TABLE, *PHANDLE_TABLE;

typedef struct _OBJECT_DUMP_CONTROL
{
    PVOID Stream;
    ULONG Detail;
} OB_DUMP_CONTROL, *POB_DUMP_CONTROL;

typedef VOID ( *OB_DUMP_METHOD )(
    IN PVOID Object,
    IN POB_DUMP_CONTROL Control OPTIONAL
);

typedef enum _OB_OPEN_REASON
{
    ObCreateHandle,
    ObOpenHandle,
    ObDuplicateHandle,
    ObInheritHandle,
    ObMaxOpenReason
} OB_OPEN_REASON;

typedef VOID ( *OB_OPEN_METHOD )(
    IN OB_OPEN_REASON OpenReason,
    IN PEPROCESS Process OPTIONAL,
    IN PVOID Object,
    IN ACCESS_MASK GrantedAccess,
    IN ULONG HandleCount
);

typedef VOID ( *OB_CLOSE_METHOD )(
    IN PEPROCESS Process OPTIONAL,
    IN PVOID Object,
    IN ACCESS_MASK GrantedAccess,
    IN ULONG ProcessHandleCount,
    IN ULONG SystemHandleCount
);

typedef BOOLEAN( *OB_OKAYTOCLOSE_METHOD )(
    IN PEPROCESS Process OPTIONAL,
    IN PVOID Object,
    IN HANDLE Handle
);


typedef VOID ( *OB_DELETE_METHOD )(
    IN PVOID Object
);

typedef NTSTATUS( *OB_PARSE_METHOD )(
    IN PVOID ParseObject,
    IN PVOID ObjectType,
    IN OUT PACCESS_STATE AccessState,
    IN KPROCESSOR_MODE AccessMode,
    IN ULONG Attributes,
    IN OUT PUNICODE_STRING CompleteName,
    IN OUT PUNICODE_STRING RemainingName,
    IN OUT PVOID Context OPTIONAL,
    IN PSECURITY_QUALITY_OF_SERVICE SecurityQos OPTIONAL,
    OUT PVOID *Object
);

typedef NTSTATUS( *OB_SECURITY_METHOD )(
    IN PVOID Object,
    IN SECURITY_OPERATION_CODE OperationCode,
    IN PSECURITY_INFORMATION SecurityInformation,
    IN OUT PSECURITY_DESCRIPTOR SecurityDescriptor,
    IN OUT PULONG CapturedLength,
    IN OUT PSECURITY_DESCRIPTOR *ObjectsSecurityDescriptor,
    IN POOL_TYPE PoolType,
    IN PGENERIC_MAPPING GenericMapping
);

typedef NTSTATUS( *OB_QUERYNAME_METHOD )(
    IN PVOID Object,
    IN BOOLEAN HasObjectName,
    OUT POBJECT_NAME_INFORMATION ObjectNameInfo,
    IN ULONG Length,
    OUT PULONG ReturnLength
);

typedef struct _OBJECT_TYPE_INITIALIZER
{
    USHORT Length;
    BOOLEAN UseDefaultObject;
    BOOLEAN CaseInsensitive;
    ULONG InvalidAttributes;
    GENERIC_MAPPING GenericMapping;
    ULONG ValidAccessMask;
    BOOLEAN SecurityRequired;
    BOOLEAN MaintainHandleCount;
    BOOLEAN MaintainTypeList;
    POOL_TYPE PoolType;
    ULONG DefaultPagedPoolCharge;
    ULONG DefaultNonPagedPoolCharge;
    OB_DUMP_METHOD DumpProcedure;
    OB_OPEN_METHOD OpenProcedure;
    OB_CLOSE_METHOD CloseProcedure;
    OB_DELETE_METHOD DeleteProcedure;
    OB_PARSE_METHOD ParseProcedure;
    OB_SECURITY_METHOD SecurityProcedure;
    OB_QUERYNAME_METHOD QueryNameProcedure;
    OB_OKAYTOCLOSE_METHOD OkayToCloseProcedure;
} OBJECT_TYPE_INITIALIZER, *POBJECT_TYPE_INITIALIZER;

typedef struct _OBJECT_TYPE
{
    ERESOURCE Mutex;
    LIST_ENTRY TypeList;
    UNICODE_STRING Name;
    PVOID DefaultObject;
    ULONG Index;
    ULONG TotalNumberOfObjects;
    ULONG TotalNumberOfHandles;
    ULONG HighWaterNumberOfObjects;
    ULONG HighWaterNumberOfHandles;
    OBJECT_TYPE_INITIALIZER TypeInfo;
    ULONG Key;
} OBJECT_TYPE, *POBJECT_TYPE;

typedef struct _SECTION_IMAGE_INFORMATION
{
	PVOID	EntryPoint;
	ULONG	Unknown1;
	ULONG	StackReserve;
	ULONG	StackCommit;
	ULONG	Subsystem;
	USHORT	MinorSubsystemVersion;
	USHORT	MajorSubsystemVersion;
	ULONG	Unknown2;
	ULONG	Characteristics;
	USHORT	ImageNumber;
	BOOLEAN	Executable;
	UCHAR	Unknown3;
	ULONG	Unknown4[3];
} SECTION_IMAGE_INFORMATION, *PSECTION_IMAGE_INFORMATION;

typedef struct _SEGMENT
{
	struct _CONTROL_AREA *ControlArea;
	ULONG TotalNumberOfPtes;
	ULONG NonExtendedPtes;
	ULONG Spare0;
	ULONGLONG SizeOfSegment;
	PVOID SegmentPteTemplate;
	ULONG NumberOfCommittedPages;
	PVOID ExtendInfo;
	PVOID SystemImageBase;
	PVOID BasedAddress;
	union
	{
		SIZE_T ImageCommitment;
		PEPROCESS CreatingProcess;
	} u1;
	union
	{
		PSECTION_IMAGE_INFORMATION ImageInformation;
		PVOID FirstMappedVa;
	} u2;
	PVOID PrototypePte;
	PVOID ThePtes[1];
} SEGMENT, *PSEGMENT;

//
// Control Area Structures
//
typedef struct _CONTROL_AREA
{
	PSEGMENT Segment;
	LIST_ENTRY DereferenceList;
	ULONG NumberOfSectionReferences;
	ULONG NumberOfPfnReferences;
	ULONG NumberOfMappedViews;
	ULONG NumberOfSystemCacheViews;
	ULONG NumberOfUserReferences;
	union
	{
		ULONG LongFlags;
		ULONG Flags;
	} u;
	PFILE_OBJECT FilePointer;
	PVOID WaitingForDeletion;
	USHORT ModifiedWriteCount;
	USHORT FlushInProgressCount;
	ULONG WritableUserReferences;
	ULONG QuadwordPad;
} CONTROL_AREA, *PCONTROL_AREA;

//
// Flags used in the VAD
//
typedef struct _MMVAD_FLAGS
{
#ifdef _WIN64
	ULONG_PTR CommitCharge:51;
#else
	ULONG_PTR CommitCharge:19;
#endif
	ULONG_PTR NoChange:1;
	ULONG_PTR VadType:3;
	ULONG_PTR MemCommit:1;
	ULONG_PTR Protection:5;
	ULONG_PTR Spare:2;
	ULONG_PTR PrivateMemory:1;
} MMVAD_FLAGS, *PMMVAD_FLAGS;


//
// Extended flags used in the VAD
//
typedef struct _MMVAD_FLAGS2
{
	ULONG FileOffset:24;
	ULONG SecNoChange:1;
	ULONG OneSecured:1;
	ULONG MultipleSecured:1;
	ULONG ReadOnly:1;
	ULONG LongVad:1;
	ULONG ExtendableFile:1;
	ULONG Inherit:1;
	ULONG CopyOnWrite:1;
} MMVAD_FLAGS2, *PMMVAD_FLAGS2;

//
// Virtual Address Descriptor (VAD) Structure
//
typedef struct _MMVAD
{
	ULONG_PTR StartingVpn;
	ULONG_PTR EndingVpn;
	union
	{
		LONG_PTR Balance:2;
		struct _MMVAD *Parent;
	} u1;
	struct _MMVAD *LeftChild;
	struct _MMVAD *RightChild;
	union
	{
		ULONG_PTR LongFlags;
		MMVAD_FLAGS VadFlags;
	} u;
	PCONTROL_AREA ControlArea;
	PVOID FirstPrototypePte;
	PVOID LastContiguousPte;
	union
	{
		ULONG LongFlags2;
		MMVAD_FLAGS2 VadFlags2;
	} u2;
} MMVAD, *PMMVAD;


typedef BOOLEAN( *EX_ENUMERATE_HANDLE_ROUTINE )(
    IN PHANDLE_TABLE_ENTRY HandleTableEntry,
    IN HANDLE Handle,
    IN OUT PVOID EnumParameter
);

typedef BOOLEAN( *PExEnumHandleTable )(
    IN PHANDLE_TABLE HandleTable,
    IN EX_ENUMERATE_HANDLE_ROUTINE EnumHandleProcedure,
    IN PVOID EnumParameter,
    OUT PHANDLE Handle OPTIONAL
);

NTSTATUS HideDebuggerProcess( DBG_ITEM* DbgItem );