#include "CView.h"

IMPLEMENT_DYNAMIC(CView, CWnd)