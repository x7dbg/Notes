#pragma once


#include "ToolFunction.h"
extern "C"
{
#define DEVICE_NAME L"\\Device\\De1ta"
#define SYMBOL_NAME L"\\DosDevices\\ArkDriver"

#define MY_CODE_BASE 0x800
#define MY_CTL_CODE(code) CTL_CODE(FILE_DEVICE_UNKNOWN, MY_CODE_BASE + code, METHOD_OUT_DIRECT , FILE_ANY_ACCESS)
    enum MyCtlCode
    {
        IOCTL_FILE = MY_CTL_CODE(0),
        IOCTL_REGEDIT = MY_CTL_CODE(1)
    };





    VOID Unload(__in struct _DRIVER_OBJECT* DriverObject);
    NTSTATUS DriverEntry(__in struct _DRIVER_OBJECT* DriverObject, __in PUNICODE_STRING  RegistryPath);

    NTSTATUS DispatchCreate(_In_ struct _DEVICE_OBJECT* DeviceObject,_Inout_ struct _IRP* Irp);
    NTSTATUS DispatchClose(_In_ struct _DEVICE_OBJECT* DeviceObject,_Inout_ struct _IRP* Irp);
    NTSTATUS DispatchControl(_In_ struct _DEVICE_OBJECT* DeviceObject,_Inout_ struct _IRP* Irp);



#pragma alloc_text("PAGE",DispatchCreate) //��ҳ�ڴ��
#pragma alloc_text("PAGE",DispatchClose)
#pragma alloc_text("PAGE",DispatchControl)
#pragma alloc_text("PAGE",Unload)
#pragma alloc_text("INIT",DriverEntry)
}