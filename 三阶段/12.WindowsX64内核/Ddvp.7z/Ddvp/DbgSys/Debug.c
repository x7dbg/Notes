//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ����ģ�������ں˵�����Ϣ�ĺ����ļ�, �����ں���Ϣ�����ﴦ�����.
 *
 */
//===========================================================================

#include <ntifs.h>
#include "defines.h"
#include "extdef.h"
#include "WinBaseEx.h"
#include "IoControlCode.h"
#include "debug.h"
#include "DbgItem.h"
#include "DbgkUtil.h"
#include "driver.h"
#include "Assembly.h"
#include "SysMisc.h"
#include "KiFastCallEntry.h"
#include "HookDbgk.h"
#include "Version.h"
#include "ReloadKernel.h"
#include "VtMisc.h"
#include "DebuggerHide.h"
//---------------------------------------------------------------------------
static ULONG				g_ulReference;
extern DBG_RELOAD_KERNEL	g_StReloadKernel;
//---------------------------------------------------------------------------



#define IA32_SYSENTER_CS 					0x174
#define IA32_SYSENTER_ESP					0x175
#define IA32_SYSENTER_EIP					0x176

//
// �豸����һ���յ������Ϣ.
//
NTSTATUS DbgObjIrpCreate( SYSTEM_CALL *lpStSysCall )
{
    PEPROCESS Eprocess;
    NTSTATUS Status;
    DBG_ITEM* DbgItem = NULL;
	PVOID lpKiAttachProcess = NULL;
	PVOID lpNewKiAttachProcess = NULL;
    PCREATE_DEVICE lpCreateDevice = NULL;

    if( !lpStSysCall->lpInBuffer ||
            lpStSysCall->ulInBufferSize != sizeof( CREATE_DEVICE ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( !lpStSysCall->lpOutBuffer ||
            lpStSysCall->ulOutBufferSize != sizeof( PVOID ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // ����Ѿ�����һ��, ��ô���ﷵ��ʧ��
    //
    Eprocess = IoGetCurrentProcess();
    DbgItem = DbgItemFindItem( Eprocess, NULL );
    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
        KdPrint( ( "Ddvp-> DbgObjIrpCreate ����ε���, ʧ��. ����...\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

    lpCreateDevice = lpStSysCall->lpInBuffer;
    if( g_ulReference == 0 )
    {
        RtlMoveMemory( &g_StSymbolsInfo,
                       &lpCreateDevice->StSymbols, sizeof( SYMBOLS_INFO ) );

        //
        // ��ʼ���������Ϣ�����йص�һϵ�к���
        //
        DbgkInitRoutine();

        //
        // ��ʼ�������ں˵�ȫ�ֱ���
        //
        Status = DbgObjInitGlobalVariable( &g_StReloadKernel, &g_StSymbolsInfo );
        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> ȫ�ֱ�����ʼ��ʧ��\n" ) );
            return STATUS_UNSUCCESSFUL;
        }
		
		//
		// Hook ϵͳ��	KiAttachProcess, �����������HS��
		//
		lpKiAttachProcess = ( PVOID )( ( ULONG )g_StReloadKernel.OriginalKernelBase +
			( ULONG )g_StSymbolsInfo.lpKiAttachProcess );

		lpNewKiAttachProcess = ( PVOID )( ( ULONG )g_StReloadKernel.NewKernelBase +
			( ULONG )g_StSymbolsInfo.lpKiAttachProcess );

		Status = HookKiAttachProcess( lpKiAttachProcess, lpNewKiAttachProcess );
		if( !NT_SUCCESS( Status ) )
		{
			KdPrint( ( "Ddvp-> Hook KiAttachProcess ʧ�� \n" ) );
			return Status;
		}

        //
        // ��ϵͳ��LdrInitializeThunk��ַ��һ��
        //
        Status = HookLdrInitializeThunk(lpStSysCall->lpOutBuffer);
        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> HookLdrInitializeThunk Error!\n" ) );
            return STATUS_UNSUCCESSFUL;
        }

        //
        // ��ʼ�� Hook KiFlstCallEntry��һЩ���ݽṹ
        //
        Status = InitKiFastCallEntry();
        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> InitKiFastCallEntry Error!\n" ) );
            return STATUS_UNSUCCESSFUL;
        }
		
#ifdef USER_VIRTUAL_TECHNOLOGY


#if DBG
        {
            ULONG_PTR RegEax, RegEbx, RegEcx, RegEdx;

            ExecuteCpuId( 'Joen', &RegEax, &RegEbx, &RegEcx, &RegEdx );

            KdPrint( ( "Ddvp-> 0x174=%p 0x176=%p !\n",
                       ( ULONG )ReadMsr( IA32_SYSENTER_CS ), ( ULONG )ReadMsr( IA32_SYSENTER_EIP ) ) );
        }
#endif
        //
        // �������⻯
        //
        Status = StartVirtualTechnology();
        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> Start VirtualTechnology Lose! \n" ) );
            return STATUS_UNSUCCESSFUL;
        }

#if DBG
        {
            ULONG_PTR RegEax, RegEbx, RegEcx, RegEdx;

            ExecuteCpuId( 'Joen', &RegEax, &RegEbx, &RegEcx, &RegEdx );

            KdPrint( ( "Ddvp-> VT Cpu Id Eax = %X Ebx = %X Ecx = %X Edx = %X !\n",
                       RegEax, RegEbx, RegEcx, RegEdx ) );

            KdPrint( ( "Ddvp-> 0x174=%p 0x176=%p !\n",
                       ( ULONG )ReadMsr( IA32_SYSENTER_CS ), ( ULONG )ReadMsr( IA32_SYSENTER_EIP ) ) );
        }
#endif
#else
        //
        // Hook KiFastCallEntry, ���ж�
        //
        Status = DbgObjHookKiFastCallEntry();

        if( !NT_SUCCESS( Status ) )
        {
            RtlZeroMemory( &g_StSymbolsInfo, sizeof( SYMBOLS_INFO ) );

            KdPrint( ( "Ddvp-> Hook KiFastCallEntry Lose!\n" ) );
            return STATUS_UNSUCCESSFUL;
        }

#endif
        //
        // UnHook NtTerminateProcess
        //
        DbgObjUnHookNtTerminateProcess();

    }

    //
    // �½�һ������������
    //
    DbgItem = DbgItemNewDbgItem( IoGetCurrentProcess(), GetCr3() );
    if( !DbgItem )
    {
        return STATUS_UNSUCCESSFUL;
    }

    /* Initialize the Debug Object's Fast Mutex */
    ExInitializeFastMutex( &DbgItem->DebugObject.Mutex );

    /* Initialize the Debug Thread Fast Mutex */
    ExInitializeFastMutex( &DbgItem->DebuggedThread.Mutex );

    /* Initialize the State Event List */
    InitializeListHead( &DbgItem->DebugObject.EventList );

    /* Initialize the State Event List */
    InitializeListHead( &DbgItem->DebuggedThread.ThreadList );

    KdPrint( ( "Ddvp-> Call DbgObjIrpCreate &DbgItem->DebuggedThread.ThreadList: %p\n",
               &DbgItem->DebuggedThread.ThreadList ) );

    /* Initialize the Debug Object's Wait Event */
    KeInitializeEvent( &DbgItem->DebugObject.EventRecv, NotificationEvent, FALSE );

    KeResetEvent( &DbgItem->DebugObject.EventRecv );

    KeInitializeEvent( &DbgItem->DebugObject.EventSend, SynchronizationEvent, FALSE );

    DbgItem->ProcessFlags |= PSF_CREATE_REPORTED_BIT;

    //
    // ������KeWaitForSingleObjectһ��ĺ������ȴ�
    //
    // KeSetEvent( &DbgItem->DebugObject.EventSend, IO_NO_INCREMENT, TRUE );
    KeResetEvent( &DbgItem->DebugObject.EventSend );

//---------------------------------------------------------------------------
    //
    // ���ص���������
    //
    Status = HideDebuggerProcess( DbgItem );
    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> Call HideDebuggerProcess Error!\n" ) );
        if( DbgItem )
        {
            DbgItemDeleteItem( DbgItem );
            DbgItemDeRefItem( DbgItem );
        }
        return Status;
    }

    DbgItemDeRefItem( DbgItem );

    //
    // Irp_Create��Ϣ����++
    //
    InterlockedIncrement( &g_ulReference );

    KdPrint( ( "Ddvp-> Call DbgObjIrpCreate ��ǰ�ͻ���:%d\n",
               g_ulReference ) );

    return Status;
}


NTSTATUS DbgObjNtOpenThread( SYSTEM_CALL *lpStSysCall )
{

    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();
    CLIENT_ID SafeClientId;
    ULONG Attributes = 0;
    HANDLE hThread = NULL;
    NTSTATUS Status;
    PETHREAD Thread;
    BOOLEAN HasObjectName = FALSE;
    ACCESS_STATE AccessState;
    AUX_ACCESS_DATA AuxData;
    POPEN_THREAD lpOpenThread;
    LUID SeDebugPrivilege;
    PHANDLE ThreadHandle;
    PNTSTATUS lpStatus;
    ACCESS_MASK DesiredAccess;
    POBJECT_ATTRIBUTES ObjectAttributes;
    PCLIENT_ID ClientId;

    PAGED_CODE();

    if( !lpStSysCall->lpInBuffer ||
            lpStSysCall->ulInBufferSize != sizeof( OPEN_THREAD ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( !lpStSysCall->lpOutBuffer ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpOpenThread = lpStSysCall->lpInBuffer;
    lpStatus     = lpStSysCall->lpOutBuffer;

    *lpStatus = STATUS_UNSUCCESSFUL;

    ThreadHandle     = lpOpenThread->ThreadHandle;
    DesiredAccess    = lpOpenThread->DesiredAccess;
    ObjectAttributes = lpOpenThread->ObjectAttributes;
    ClientId         = lpOpenThread->ClientId;

    SeDebugPrivilege = *( PLUID )( ( ULONG_PTR )g_StSymbolsInfo.lpSeDebugPrivilege +
                                   ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase );

    /* Check if we were called from user mode */
    if( PreviousMode != KernelMode )
    {
        /* Enter SEH for probing */
        __try
        {
            /* Probe the thread handle */
            ProbeForWriteHandle( ThreadHandle );

            /* Check for a CID structure */
            if( ClientId )
            {
                /* Probe and capture it */
                ProbeForRead( ClientId, sizeof( CLIENT_ID ), sizeof( ULONG ) );
                SafeClientId = *ClientId;
                ClientId = &SafeClientId;
            }

            /*
             * Just probe the object attributes structure, don't capture it
             * completely. This is done later if necessary
             */
            ProbeForRead( ObjectAttributes,
                          sizeof( OBJECT_ATTRIBUTES ),
                          sizeof( ULONG ) );
            HasObjectName = ( ObjectAttributes->ObjectName != NULL );
            Attributes = ObjectAttributes->Attributes;
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            *lpStatus = GetExceptionCode();
            return GetExceptionCode();
        }
    }
    else
    {
        /* Otherwise just get the data directly */
        HasObjectName = ( ObjectAttributes->ObjectName != NULL );
        Attributes = ObjectAttributes->Attributes;
    }

    /* Can't pass both, fail */
    if( ( HasObjectName ) && ( ClientId ) )
    {
        *lpStatus = STATUS_INVALID_PARAMETER_MIX;
        return STATUS_INVALID_PARAMETER_MIX;
    }

    /* Create an access state */
    Status = SeCreateAccessState( &AccessState,
                                  &AuxData,
                                  DesiredAccess,
                                  GetObjectTypeTypeInfoGenericMapping( *PsProcessType ) );

    if( !NT_SUCCESS( Status ) )
    {
        *lpStatus = Status;
        return Status;
    }

    /* Check if this is a debugger */
    if( SeSinglePrivilegeCheck( SeDebugPrivilege, PreviousMode ) )
    {
        /* Did he want full access? */
        if( AccessState.RemainingDesiredAccess & MAXIMUM_ALLOWED )
        {
            /* Give it to him */
            AccessState.PreviouslyGrantedAccess |= THREAD_ALL_ACCESS;
        }
        else
        {
            /* Otherwise just give every other access he could want */
            AccessState.PreviouslyGrantedAccess |=
                AccessState.RemainingDesiredAccess;
        }

        /* The caller desires nothing else now */
        AccessState.RemainingDesiredAccess = 0;
    }

    /* Open by name if one was given */
    if( HasObjectName )
    {
        /* Open it */
        Status = ObOpenObjectByName( ObjectAttributes,
                                     *PsThreadType,
                                     PreviousMode,
                                     &AccessState,
                                     0,
                                     NULL,
                                     &hThread );

        /* Get rid of the access state */
        SeDeleteAccessState( &AccessState );
    }
    else if( ClientId )
    {
        /* Open by Thread ID */
        if( ClientId->UniqueProcess )
        {
            /* Get the Process */
            Status = PsLookupProcessThreadByCid( ClientId, NULL, &Thread );
        }
        else
        {
            /* Get the Process */
            Status = PsLookupThreadByThreadId( ClientId->UniqueThread, &Thread );
        }

        /* Check if we didn't find anything */
        if( !NT_SUCCESS( Status ) )
        {
            /* Get rid of the access state and return */
            SeDeleteAccessState( &AccessState );
            *lpStatus = Status;
            return Status;
        }

        /* Open the Thread Object */
        Status = ObOpenObjectByPointer( Thread,
                                        Attributes,
                                        &AccessState,
                                        0,
                                        *PsThreadType,
                                        PreviousMode,
                                        &hThread );

        /* Delete the access state and dereference the thread */
        SeDeleteAccessState( &AccessState );
        ObDereferenceObject( Thread );
    }
    else
    {
        /* Neither an object name nor a client id was passed */
        *lpStatus = STATUS_INVALID_PARAMETER_MIX;
        return STATUS_INVALID_PARAMETER_MIX;
    }

    /* Check for success */
    if( NT_SUCCESS( Status ) )
    {
        /* Protect against bad user-mode pointers */
        __try
        {
            /* Write back the handle */
            *ThreadHandle = hThread;
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            /* Get the exception code */
            Status = GetExceptionCode();
            *lpStatus = Status;
        }
    }

    /* Return status */
    *lpStatus = Status;
    return Status;
}



NTSTATUS DbgObjDebugActiveProcess( SYSTEM_CALL *lpStSysCall )
{
    PNTSTATUS lpStatus;
    PEPROCESS Debugged;
    PEPROCESS Debugger;
    PETHREAD LastThread;
    DBG_ITEM* DbgItem = NULL;
    NTSTATUS Status = STATUS_UNSUCCESSFUL;
    PDEBUG_ACTIVE_PROCESS lpDebugActive = NULL;

    PAGED_CODE();

    if( !lpStSysCall->lpInBuffer ||
            lpStSysCall->ulInBufferSize != sizeof( DEBUG_ACTIVE_PROCESS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( !lpStSysCall->lpOutBuffer ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpDebugActive = ( PDEBUG_ACTIVE_PROCESS )( lpStSysCall->lpInBuffer );
    lpStatus = ( PNTSTATUS )lpStSysCall->lpOutBuffer;

    *lpStatus = STATUS_UNSUCCESSFUL;

    //
    // ���ݽ���ID, ���ӵ�����.
    //
    Status = PsLookupProcessByProcessId( lpDebugActive->dwProcessId, &Debugged );
    if( !NT_SUCCESS( Status ) )
    {
        KdPrint( ( "Ddvp-> Call DbgObjDebugActiveProcess �򿪽���IDʧ��: %d\n",
                   lpDebugActive->dwProcessId ) );
        return Status;
    }

    DbgItem = DbgItemFindItem( NULL, Debugged );
    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
        KdPrint( ( "Ddvp-> DbgObjDebugActiveProcess �����Ѿ����󶨵�����...\n" ) );
        return STATUS_UNSUCCESSFUL;
    }

    //
    // ����������.
    //
    Debugger = IoGetCurrentProcess();

    do
    {
        DbgItem  = DbgItemFindItem( Debugger, NULL );
        if( !DbgItem )
        {
            break;
        }

        DbgItemAttachProcess( DbgItem, Debugged,
                              ( ULONG_PTR )GetEprocessCr3( Debugged ) );

        //
        // Don't let us debug ourselves or the system process.
        //
        if( Debugged == PsGetCurrentProcess() ||
                Debugged == PsInitialSystemProcess )
        {
            *lpStatus = Status = STATUS_ACCESS_DENIED;
            ObDereferenceObject( Debugged );
            break;
        }

        //
        // We will be touching process address space. Block process rundown.
        //
        if( ExAcquireRundownProtection(
                    GetEprocessRundownProtect( Debugged ) ) )
        {

            //
            // Post the fake process create messages etc.
            //
            Status = DbgkpPostFakeProcessCreateMessages(
                         DbgItem, &LastThread );
			
            ExReleaseRundownProtection(
                GetEprocessRundownProtect( Debugged ) );

            KdPrint( ( "Ddvp-> Call DbgObjDebugActiveProcess Debugger: %p Debugged: %p \n",
                       Debugger, Debugged ) );

            *lpStatus = Status = STATUS_SUCCESS;
        }
        else
        {
            *lpStatus = Status = STATUS_PROCESS_IS_TERMINATING;
        }
    }
    while( 0 );

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }

    return Status;
}


//
// �豸��ж��һ���յ������Ϣ. Ҳ������׼��ж��֮ǰ���͵���Ϣ
//
NTSTATUS DbgObjIrpClose( SYSTEM_CALL *lpStSysCall )
{
    NTSTATUS Status;
    DBG_ITEM* DbgItem = NULL;
    PEPROCESS Eprocess;

    if( !lpStSysCall->lpInBuffer || lpStSysCall->ulInBufferSize != sizeof( ULONG ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    Eprocess = IoGetCurrentProcess();

    DbgItem = DbgItemFindItem( Eprocess, NULL );
    if( !DbgItem )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( g_ulReference == 1 )
    {

        RtlZeroMemory( &g_StSymbolsInfo, sizeof( SYMBOLS_INFO ) );
		
		UnHookKiAttachProcess();

#ifdef USER_VIRTUAL_TECHNOLOGY

        Status = StopVirtualTechnology();
        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> Call StopVirtualTechnology Error! \n" ) );
            return Status;
        }

#else

        //
        // ж�� KiFastCallEntry����
        //
        Status = DbgUnHookKiFastCallEntry();
        if( !NT_SUCCESS( Status ) )
        {
            KdPrint( ( "Ddvp-> UnHook KiFastCallEntry ʧ��\n" ) );
            return Status;
        }
#endif

    }

    DbgItemExitProcess( DbgItem );

    if( DbgItem )
    {
        DbgItemDeleteItem( DbgItem );
        DbgItemDeRefItem( DbgItem );
    }

    InterlockedDecrement( &g_ulReference );

    *( ULONG* )lpStSysCall->lpInBuffer = g_ulReference;

    KdPrint( ( "Ddvp-> Call DbgObjIrpClose ��ǰ�ͻ���:%d\n", g_ulReference ) );
    return STATUS_SUCCESS;
}



//
// ��ȡ��ǰ���Կ�ܵİ汾
//
NTSTATUS DbgObjGetVersion( SYSTEM_CALL *lpStSysCall )
{
    PDICHLORVOS_VERISON lpVersion  = NULL;

    if( !lpStSysCall->lpOutBuffer ||
            lpStSysCall->ulOutBufferSize != sizeof( DICHLORVOS_VERISON ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpVersion = lpStSysCall->lpOutBuffer;

    lpVersion->ulMainVersion = MAIN_VERSION;
    lpVersion->ulChildVersion = CHILD_VERSION;

    strcpy( lpVersion->SzBuildTime, "" __DATE__ "/" __TIME__ );

    KdPrint( ( "Ddvp-> Call DbgObjGetVersion main:%d child:%d Build Time:%s\n",
               MAIN_VERSION, CHILD_VERSION, lpVersion->SzBuildTime ) );

    return STATUS_SUCCESS;
}

/* ��������֮ǰ�����´������̵�����*/

NTSTATUS DbgObjCreateProcessBefore( SYSTEM_CALL *lpStSysCall )
{
    wchar_t* lpExeName = NULL;

    if( !lpStSysCall->lpInBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpExeName = lpStSysCall->lpInBuffer;

    SetCreateProcessName( lpExeName );

    return STATUS_SUCCESS;
}

NTSTATUS DbgObjCreateProcessClean( SYSTEM_CALL *lpStSysCall )
{

    CleanCreateProcessName();

    return STATUS_SUCCESS;
}


//
// �������̵�����Ϣ. ������Խ��̺ͱ����Խ��̽�������
//
NTSTATUS DbgObjCreateProcessAfter( SYSTEM_CALL *lpStSysCall )
{
    NTSTATUS Status;
    DBG_ITEM* DbgItem = NULL;
    PEPROCESS DebuggedEprocess = NULL;
    PEPROCESS DebuggerEprocess = NULL;

    if( !lpStSysCall->lpInBuffer ||
            lpStSysCall->ulInBufferSize != sizeof( HANDLE* ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // ��ȡ�����Խ��̵�Eprocess
    //
    Status = PsLookupProcessByProcessId( *( HANDLE* )( lpStSysCall->lpInBuffer ),
                                         &DebuggedEprocess );
    if( !NT_SUCCESS( Status ) )
    {
        return Status;
    }

    //
    // ���Խ��̵�Eprocess
    //
    DebuggerEprocess = IoGetCurrentProcess();

    do
    {
        DbgItem  = DbgItemFindItem( DebuggerEprocess, NULL );
        if( !DbgItem )
        {
            break;
        }

        DbgItemNewProcess( DbgItem, DebuggedEprocess,
                           ( ULONG_PTR )GetEprocessCr3( DebuggedEprocess ) );

        KdPrint( ( "Ddvp-> Call Debugger: %p Debugged: %p \n",
                   DebuggerEprocess, DebuggedEprocess ) );

        CleanCreateProcessName();
        Status = STATUS_SUCCESS;

    }
    while( 0 );

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }
    return Status;
}



//
// �ȴ������¼�.
//
NTSTATUS DbgObjNtWaitForDebugEvent( SYSTEM_CALL *lpStSysCall )
{
    DBG_ITEM* DbgItem = NULL;
    PEPROCESS Eprocess = NULL;
    NTSTATUS  Status = STATUS_UNSUCCESSFUL;
    PWAITFOR_DEBUGEVENT lpWaitForDebugEvent =
        ( PWAITFOR_DEBUGEVENT )lpStSysCall->lpInBuffer;
    PNTSTATUS lpStatus = lpStSysCall->lpOutBuffer;

    *lpStatus = STATUS_UNSUCCESSFUL;


    if( !lpStSysCall->lpInBuffer || !lpStSysCall->lpOutBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( lpStSysCall->ulInBufferSize != sizeof( WAITFOR_DEBUGEVENT ) ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    Eprocess = IoGetCurrentProcess();

    do
    {
        DbgItem = DbgItemFindItem( Eprocess, NULL );
        if( !DbgItem )
        {
            break;
        }

        Status =  _NtWaitForDebugEvent( DbgItem,
                                        &lpWaitForDebugEvent->DebugEvent,
                                        lpWaitForDebugEvent->TimeOut );
        *lpStatus = Status;
        if( !NT_SUCCESS( Status ) )
        {
            break;
        }
    }
    while( 0 );

    if( DbgItem )
    {
        DbgItemDeRefItem( DbgItem );
    }

    return Status;
}

//
// ֪ͨ�������.
//
NTSTATUS
DbgObjContinueDebugEvent(
    SYSTEM_CALL *lpStSysCall )
{

    NTSTATUS Status;
    PNTSTATUS lpStatus;
    PCONTINUE_DEBUGEVENT lpContinueDebug =
        ( PCONTINUE_DEBUGEVENT )lpStSysCall->lpInBuffer;
    lpStatus = lpStSysCall->lpOutBuffer;

    if( !lpStSysCall->lpInBuffer || !lpStSysCall->lpOutBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( lpStSysCall->ulInBufferSize != sizeof( CONTINUE_DEBUGEVENT ) ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    // KdPrint( ( "Ddvp-> Call DbgObjContinueDebugEvent \n" ) );

    Status = _NtDebugContinue( lpContinueDebug->dwProcessId,
                               lpContinueDebug->dwThreadId,
                               lpContinueDebug->dwContinueStatus );

    *lpStatus = Status;
    return Status;
}

NTSTATUS
DbgObjNtReadVirtualMemory(
    SYSTEM_CALL *lpStSysCall )
{
    NTSTATUS Status;
    PEPROCESS Process;
    PETHREAD CurrentThread;
    SIZE_T BytesCopied;
    KPROCESSOR_MODE PreviousMode;
    PREAD_MEMORY lpReadMemory =
        ( PREAD_MEMORY )lpStSysCall->lpInBuffer;
    PNTSTATUS lpStatus = lpStSysCall->lpOutBuffer;
    static PMmCopyVirtualMemory lpMmCopyVirtualMemory = NULL;

    PAGED_CODE();

    if( !lpMmCopyVirtualMemory )
    {
        lpMmCopyVirtualMemory = ( PMmCopyVirtualMemory )
                                ( ( ULONG_PTR )g_StSymbolsInfo.lpMmCopyVirtualMemory +
                                  ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase );

    }

    ASSERT( lpMmCopyVirtualMemory );

    if( !lpStSysCall->lpInBuffer || !lpStSysCall->lpOutBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( lpStSysCall->ulInBufferSize != sizeof( READ_MEMORY ) ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // Get the previous mode and probe output argument if necessary.
    //
    CurrentThread = PsGetCurrentThread();
    PreviousMode = ExGetPreviousMode();
    if( PreviousMode != KernelMode )
    {

        if( ( ( PCHAR )lpReadMemory->BaseAddress + lpReadMemory->NumberOfBytesToRead <
                ( PCHAR )lpReadMemory->BaseAddress ) ||
                ( ( PCHAR )lpReadMemory->Buffer + lpReadMemory->NumberOfBytesToRead <
                  ( PCHAR )lpReadMemory->Buffer ) ||
                ( ( PVOID )( ( PCHAR )lpReadMemory->BaseAddress + lpReadMemory->NumberOfBytesToRead ) >
                  MM_HIGHEST_USER_ADDRESS ) ||
                ( ( PVOID )( ( PCHAR )lpReadMemory->Buffer + lpReadMemory->NumberOfBytesToRead ) >
                  MM_HIGHEST_USER_ADDRESS ) )
        {

            *lpStatus = STATUS_ACCESS_VIOLATION;
            return STATUS_ACCESS_VIOLATION;
        }

        if( ARGUMENT_PRESENT( lpReadMemory->NumberOfBytesRead ) )
        {
            __try
            {
                if( lpReadMemory->NumberOfBytesRead )
                {
                    ProbeForWriteSize_t( lpReadMemory->NumberOfBytesRead );
                }

            }
            __except( EXCEPTION_EXECUTE_HANDLER )
            {
                *lpStatus = GetExceptionCode();
                return GetExceptionCode();
            }
        }
    }

    //
    // If the buffer size is not zero, then attempt to read data from the
    // specified process address space into the current process address
    // space.
    //
    BytesCopied = 0;
    Status = STATUS_SUCCESS;

    if( lpReadMemory->NumberOfBytesToRead != 0 )
    {

        //
        // Reference the target process.
        //

        Status = ObReferenceObjectByHandle( lpReadMemory->hProcess,
                                            PROCESS_VM_READ,
                                            *PsProcessType,
                                            PreviousMode,
                                            ( PVOID * )&Process,
                                            NULL );

        //
        // If the process was successfully referenced, then attempt to
        // read the specified memory either by direct mapping or copying
        // through nonpaged pool.
        //

        if( Status == STATUS_SUCCESS )
        {

            Status = lpMmCopyVirtualMemory( Process,
                                            lpReadMemory->BaseAddress,
                                            PsGetCurrentProcess(),
                                            lpReadMemory->Buffer,
                                            lpReadMemory->NumberOfBytesToRead,
                                            PreviousMode,
                                            &BytesCopied );

            //
            // Dereference the target process.
            //

            ObDereferenceObject( Process );
        }
    }

    //
    // If requested, return the number of bytes read.
    //

    if( ARGUMENT_PRESENT( lpReadMemory->NumberOfBytesRead ) )
    {
        __try
        {
            *lpReadMemory->NumberOfBytesRead = BytesCopied;

        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            NOTHING;
        }
    }

    *lpStatus = Status;
    return Status;
}

//
//	���BIOS�Ƿ��Intel-VT
//
NTSTATUS DbgObjCheckBiosIsEnabled( SYSTEM_CALL *lpStSysCall )
{
#ifdef	USER_VIRTUAL_TECHNOLOGY

    return CheckBiosIsEnabled();
#else
    return STATUS_SUCCESS;

#endif

}

NTSTATUS
DbgObjNtWriteVirtualMemory(
    SYSTEM_CALL *lpStSysCall )
{
    PEPROCESS Process;
    SIZE_T BytesWritten = 0;
    NTSTATUS Status = STATUS_SUCCESS;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();
    PWRITE_MEMORY lpWriteMemory =
        ( PWRITE_MEMORY )lpStSysCall->lpInBuffer;
    PNTSTATUS lpStatus = lpStSysCall->lpOutBuffer;
    static PMmCopyVirtualMemory lpMmCopyVirtualMemory = NULL;

    PAGED_CODE();

    if( !lpMmCopyVirtualMemory )
    {
        lpMmCopyVirtualMemory = ( PMmCopyVirtualMemory )
                                ( ( ULONG_PTR )g_StSymbolsInfo.lpMmCopyVirtualMemory +
                                  ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase );
    }

    ASSERT( lpMmCopyVirtualMemory );

    if( !lpStSysCall->lpInBuffer || !lpStSysCall->lpOutBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( lpStSysCall->ulInBufferSize != sizeof( WRITE_MEMORY ) ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // Check if we came from user mode
    //
    if( PreviousMode != KernelMode )
    {
        //
        // Validate the read addresses
        //
        if( ( ( ( ULONG_PTR )lpWriteMemory->BaseAddress + lpWriteMemory->NumberOfBytesToWrite ) <
                ( ULONG_PTR )lpWriteMemory->BaseAddress ) ||
                ( ( ( ULONG_PTR )lpWriteMemory->Buffer + lpWriteMemory->NumberOfBytesToWrite ) <
                  ( ULONG_PTR )lpWriteMemory->Buffer ) ||
                ( ( ( ULONG_PTR )lpWriteMemory->BaseAddress + lpWriteMemory->NumberOfBytesToWrite ) >
                  MmUserProbeAddress ) ||
                ( ( ( ULONG_PTR )lpWriteMemory->Buffer + lpWriteMemory->NumberOfBytesToWrite ) >
                  MmUserProbeAddress ) )
        {
            //
            // Don't allow to write into kernel space
            //
            *lpStatus = STATUS_ACCESS_VIOLATION;
            return STATUS_ACCESS_VIOLATION;
        }

        //
        // Enter SEH for probe
        //
        __try
        {
            //
            // Probe the output value
            //
            if( lpWriteMemory->NumberOfBytesWritten )
            {
                ProbeForWriteSize_t( lpWriteMemory->NumberOfBytesWritten );
            }
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            //
            // Get exception code
            //
            *lpStatus = GetExceptionCode();
            return GetExceptionCode();
        }
    }

    //
    // Don't do zero-byte transfers
    //
    if( lpWriteMemory->NumberOfBytesToWrite )
    {
        //
        // Reference the process
        //
        Status = ObReferenceObjectByHandle( lpWriteMemory->hProcess,
                                            PROCESS_VM_WRITE,
                                            *PsProcessType,
                                            PreviousMode,
                                            ( PVOID* )&Process,
                                            NULL );
        if( NT_SUCCESS( Status ) )
        {
            //
            // Do the copy
            //
            Status = lpMmCopyVirtualMemory( PsGetCurrentProcess(),
                                            lpWriteMemory->Buffer,
                                            Process,
                                            lpWriteMemory->BaseAddress,
                                            lpWriteMemory->NumberOfBytesToWrite,
                                            PreviousMode,
                                            &BytesWritten );

            //
            // Dereference the process
            //
            ObDereferenceObject( Process );
        }
    }

    //
    // Check if the caller sent this parameter
    //
    if( lpWriteMemory->NumberOfBytesWritten )
    {
        //
        // Enter SEH to guard write
        //
        __try
        {
            //
            // Return the number of bytes written
            //
            *lpWriteMemory->NumberOfBytesWritten = BytesWritten;
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            NOTHING;
        }
    }

    //
    // Return status
    //
    *lpStatus = Status;
    return Status;
}

NTSTATUS
DbgObjNtOpenProcess(
    SYSTEM_CALL *lpStSysCall )
{

    NTSTATUS Status;
    HANDLE hProcess;
    PNTSTATUS lpStatus;
    LUID SeDebugPrivilege;
    ULONG Attributes = 0;
    BOOLEAN HasObjectName = FALSE;
    PETHREAD Thread = NULL;
    PEPROCESS Process = NULL;
    CLIENT_ID SafeClientId;
    ACCESS_STATE AccessState;
    AUX_ACCESS_DATA AuxData;
    POPEN_PROCESS lpOpenProcess;
    PCLIENT_ID ClientId;
    ACCESS_MASK DesiredAccess;
    PHANDLE ProcessHandle;
    POBJECT_ATTRIBUTES ObjectAttributes;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();

    PAGED_CODE();

    SeDebugPrivilege = *( PLUID )( ( ULONG_PTR )g_StSymbolsInfo.lpSeDebugPrivilege +
                                   ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase );

    ASSERT( SeDebugPrivilege.HighPart || SeDebugPrivilege.LowPart );

    if( !lpStSysCall->lpInBuffer || !lpStSysCall->lpOutBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( lpStSysCall->ulInBufferSize != sizeof( OPEN_PROCESS ) ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpOpenProcess    = lpStSysCall->lpInBuffer;
    lpStatus		 = lpStSysCall->lpOutBuffer;
    ClientId         = lpOpenProcess->ClientId;
    ProcessHandle    = lpOpenProcess->ProcessHandle;
    ObjectAttributes = lpOpenProcess->ObjectAttributes;
    DesiredAccess    = lpOpenProcess->DesiredAccess;

    /* Check if we were called from user mode */
    if( PreviousMode != KernelMode )
    {
        /* Enter SEH for probing */
        __try
        {
            /* Probe the thread handle */
            ProbeForWriteHandle( ProcessHandle );

            /* Check for a CID structure */
            if( ClientId )
            {
                /* Probe and capture it */
                ProbeForRead( ClientId, sizeof( CLIENT_ID ), sizeof( ULONG ) );
                SafeClientId = *ClientId;
                ClientId = &SafeClientId;
            }

            /*
             * Just probe the object attributes structure, don't capture it
             * completely. This is done later if necessary
             */
            ProbeForRead( ObjectAttributes,
                          sizeof( OBJECT_ATTRIBUTES ),
                          sizeof( ULONG ) );
            HasObjectName = ( ObjectAttributes->ObjectName != NULL );
            Attributes = ObjectAttributes->Attributes;
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            /* Return the exception code */
            *lpStatus = GetExceptionCode();
            return GetExceptionCode();
        }
    }
    else
    {
        /* Otherwise just get the data directly */
        HasObjectName = ( ObjectAttributes->ObjectName != NULL );
        Attributes = ObjectAttributes->Attributes;
    }

    /* Can't pass both, fail */
    if( ( HasObjectName ) && ( ClientId ) )
    {
        *lpStatus = STATUS_INVALID_PARAMETER_MIX;
        return STATUS_INVALID_PARAMETER_MIX;
    }

    /* Create an access state */
    Status = SeCreateAccessState( &AccessState,
                                  &AuxData,
                                  DesiredAccess,
                                  GetObjectTypeTypeInfoGenericMapping( *PsProcessType ) );
    if( !NT_SUCCESS( Status ) ) return Status;

    /* Check if this is a debugger */
    if( SeSinglePrivilegeCheck( SeDebugPrivilege, PreviousMode ) )
    {
        /* Did he want full access? */
        if( AccessState.RemainingDesiredAccess & MAXIMUM_ALLOWED )
        {
            /* Give it to him */
            AccessState.PreviouslyGrantedAccess |= PROCESS_ALL_ACCESS;
        }
        else
        {
            /* Otherwise just give every other access he could want */
            AccessState.PreviouslyGrantedAccess |=
                AccessState.RemainingDesiredAccess;
        }

        /* The caller desires nothing else now */
        AccessState.RemainingDesiredAccess = 0;
    }

    /* Open by name if one was given */
    if( HasObjectName )
    {
        /* Open it */
        Status = ObOpenObjectByName( ObjectAttributes,
                                     *PsProcessType,
                                     PreviousMode,
                                     &AccessState,
                                     0,
                                     NULL,
                                     &hProcess );

        /* Get rid of the access state */
        SeDeleteAccessState( &AccessState );
    }
    else if( ClientId )
    {
        /* Open by Thread ID */
        if( ClientId->UniqueThread )
        {
            /* Get the Process */
            Status = PsLookupProcessThreadByCid( ClientId, &Process, &Thread );
        }
        else
        {
            /* Get the Process */
            Status = PsLookupProcessByProcessId( ClientId->UniqueProcess,
                                                 &Process );
        }

        /* Check if we didn't find anything */
        if( !NT_SUCCESS( Status ) )
        {
            /* Get rid of the access state and return */
            SeDeleteAccessState( &AccessState );
            *lpStatus = Status;
            return Status;
        }

        /* Open the Process Object */
        Status = ObOpenObjectByPointer( Process,
                                        Attributes,
                                        &AccessState,
                                        0,
                                        *PsProcessType,
                                        PreviousMode,
                                        &hProcess );

        /* Delete the access state */
        SeDeleteAccessState( &AccessState );

        /* Dereference the thread if we used it */
        if( Thread )
        {
            ObDereferenceObject( Thread );
        }

        /* Dereference the Process */
        ObDereferenceObject( Process );
    }
    else
    {
        /* neither an object name nor a client id was passed */
        *lpStatus = STATUS_INVALID_PARAMETER_MIX;
        return STATUS_INVALID_PARAMETER_MIX;
    }

    /* Check for success */
    if( NT_SUCCESS( Status ) )
    {
        /* Use SEH for write back */
        __try
        {
            /* Write back the handle */
            *ProcessHandle = hProcess;
            *lpStatus = Status;
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            /* Get the exception code */
            Status = GetExceptionCode();
            *lpStatus = Status;
        }
    }

    /* Return status */
    return Status;
}

NTSTATUS
DbgObjNtGetContextThread(
    SYSTEM_CALL *lpStSysCall )
{
    PETHREAD Thread;
    NTSTATUS Status;
    PNTSTATUS lpStatus;
    HANDLE ThreadHandle;
    PCONTEXT ThreadContext;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();
    PGET_THREAD_CONTEXT lpGetContext = NULL;

    PAGED_CODE();

    if( !lpStSysCall->lpInBuffer || !lpStSysCall->lpOutBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( lpStSysCall->ulInBufferSize != sizeof( GET_THREAD_CONTEXT ) ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpGetContext = lpStSysCall->lpInBuffer;
    ThreadHandle = lpGetContext->hThread;
    ThreadContext = lpGetContext->lpContext;
    lpStatus     = lpStSysCall->lpOutBuffer;

    /* Get the Thread Object */
    Status = ObReferenceObjectByHandle( ThreadHandle,
                                        THREAD_GET_CONTEXT,
                                        *PsThreadType,
                                        PreviousMode,
                                        ( PVOID* )&Thread,
                                        NULL );

    if( !NT_SUCCESS( Status ) )
    {
        *lpStatus = Status;
        return Status;
    }

    /* Make sure it's not a system thread */
    if( GetEThreadSystemThread( Thread ) )
    {
        /* Fail */
        Status = STATUS_INVALID_HANDLE;
    }
    else
    {
        /* Call the kernel API */
        Status = PsGetContextThread( Thread, ThreadContext, PreviousMode );
    }

    /* Dereference it and return */
    ObDereferenceObject( Thread );

    *lpStatus = Status;
    return Status;
}

NTSTATUS
DbgObjNtSetContextThread(
    SYSTEM_CALL *lpStSysCall )
{
    PETHREAD Thread;
    NTSTATUS Status;
    HANDLE ThreadHandle;
    PCONTEXT ThreadContext;
    PNTSTATUS lpStatus;
    PSET_THREAD_CONTEXT lpSetContext = NULL;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();

    PAGED_CODE();

    if( !lpStSysCall->lpInBuffer || !lpStSysCall->lpOutBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( lpStSysCall->ulInBufferSize != sizeof( SET_THREAD_CONTEXT ) ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpSetContext = lpStSysCall->lpInBuffer;
    ThreadHandle = lpSetContext->hThread;
    ThreadContext = lpSetContext->lpContext;
    lpStatus     = lpStSysCall->lpOutBuffer;



    /* Get the Thread Object */
    Status = ObReferenceObjectByHandle( ThreadHandle,
                                        THREAD_SET_CONTEXT,
                                        *PsThreadType,
                                        PreviousMode,
                                        ( PVOID* )&Thread,
                                        NULL );

    if( !NT_SUCCESS( Status ) )
    {
        *lpStatus = Status;
        return Status;
    }

    /* Make sure it's not a system thread */
    if( GetEThreadSystemThread( Thread ) )
    {
        /* Fail */
        Status = STATUS_INVALID_HANDLE;
    }
    else
    {
        /* Call the kernel API */
        Status = PsSetContextThread( Thread, ThreadContext, PreviousMode );
    }

    /* Dereference it and return */
    ObDereferenceObject( Thread );
    *lpStatus = Status;
    return Status;
}

NTSTATUS
DbgObjNtSuspendThread(
    SYSTEM_CALL *lpStSysCall )
{
    PETHREAD Thread;
    ULONG Prev;
    NTSTATUS Status;
    PULONG PreviousSuspendCount;
    HANDLE ThreadHandle;
    PNTSTATUS lpStatus;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();
	PSUSPEND_THREAD lpStSuspendThread;

    PAGED_CODE();

    if( !lpStSysCall->lpInBuffer || !lpStSysCall->lpOutBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( lpStSysCall->ulInBufferSize != sizeof( SUSPEND_THREAD ) ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpStSuspendThread    = lpStSysCall->lpInBuffer;
    lpStatus             = lpStSysCall->lpOutBuffer;
    PreviousSuspendCount = lpStSuspendThread->lpPreviousSuspendCount;
    ThreadHandle         = lpStSuspendThread->hThread;

    /* Check if caller gave a suspend count from user mode */
    if( ( PreviousSuspendCount ) && ( PreviousMode != KernelMode ) )
    {
        /* Enter SEH for probing */
        __try
        {
            /* Probe the count */
            ProbeForWriteUlong( PreviousSuspendCount );
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            /* Return the exception code */
            *lpStatus = GetExceptionCode();
            return GetExceptionCode();
        }
    }

    /* Get the Thread Object */
    Status = ObReferenceObjectByHandle( ThreadHandle,
                                        THREAD_SUSPEND_RESUME,
                                        *PsThreadType,
                                        PreviousMode,
                                        ( PVOID* )&Thread,
                                        NULL );
    if( !NT_SUCCESS( Status ) )
    {
        *lpStatus = Status;
        return Status;
    }

    /* Call the internal function */
    Status = _PsSuspendThread( Thread, &Prev );
    ObDereferenceObject( Thread );

    if( !NT_SUCCESS( Status ) )
    {
        *lpStatus = Status;
        return Status;
    }

    /* Protect write with SEH */
    __try
    {
        /* Return the Previous Count */
        if( PreviousSuspendCount )
        {
            *PreviousSuspendCount = Prev;
        }
    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {
        /* Get the exception code */
        Status = GetExceptionCode();
    }

    /* Return */
    *lpStatus = Status;
    return Status;
}

NTSTATUS
DbgObjNtResumeThread(
    SYSTEM_CALL *lpStSysCall )
{
    PETHREAD Thread;
    ULONG Prev;
    HANDLE ThreadHandle;
    NTSTATUS Status;
    PNTSTATUS lpStatus;
    PRESUME_THREAD lpResumeThread = NULL;
    PULONG SuspendCount = NULL;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();
    PPsResumeThread lpPsResumeThread = NULL;

    PAGED_CODE();

    lpPsResumeThread = ( PPsResumeThread )( ( ULONG_PTR )g_StSymbolsInfo.lpPsResumeThread +
                                            ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase );

    ASSERT( lpPsResumeThread );

    if( !lpStSysCall->lpInBuffer || !lpStSysCall->lpOutBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( lpStSysCall->ulInBufferSize != sizeof( RESUME_THREAD ) ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpResumeThread = lpStSysCall->lpInBuffer;
    SuspendCount   = lpResumeThread->lpPreviousSuspendCount;
    ThreadHandle   = lpResumeThread->hThread;
    lpStatus       = lpStSysCall->lpOutBuffer;

    /* Check if caller gave a suspend count from user mode */
    if( ( SuspendCount ) && ( PreviousMode != KernelMode ) )
    {
        /* Enter SEH for probing */
        __try
        {
            /* Probe the count */
            ProbeForWriteUlong( SuspendCount );
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            /* Return the exception code */
            *lpStatus = GetExceptionCode();
            return GetExceptionCode();
        }

    }

    /* Get the Thread Object */
    Status = ObReferenceObjectByHandle( ThreadHandle,
                                        THREAD_SUSPEND_RESUME,
                                        *PsThreadType,
                                        PreviousMode,
                                        ( PVOID* )&Thread,
                                        NULL );
    if( !NT_SUCCESS( Status ) )
    {
        *lpStatus = Status;
        return Status;
    }

    /* Call the internal function */
    Status = lpPsResumeThread( Thread, &Prev );

    /* Check if the caller wanted the count back */
    if( SuspendCount )
    {
        /* Enter SEH for write back */
        __try
        {
            /* Write the count */
            *SuspendCount = Prev;
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            /* Get the exception code */
            Status = GetExceptionCode();
        }
    }

    /* Dereference and return */
    ObDereferenceObject( Thread );

    *lpStatus = Status;
    return Status;
}


NTSTATUS
DbgObjNtProtectVirtualMemory(
    SYSTEM_CALL *lpStSysCall )
{
    HANDLE ProcessHandle;
    PVOID *UnsafeBaseAddress;
    SIZE_T *UnsafeNumberOfBytesToProtect;
    ULONG NewAccessProtection;
    PULONG UnsafeOldAccessProtection;
    PEPROCESS Process;
    ULONG OldAccessProtection;
    ULONG Protection;
    NTSTATUS Status;
    KAPC_STATE ApcState;
    BOOLEAN Attached = FALSE;
    PVOID BaseAddress = NULL;
    SIZE_T NumberOfBytesToProtect = 0;
    KPROCESSOR_MODE PreviousMode = ExGetPreviousMode();
    PEPROCESS CurrentProcess = PsGetCurrentProcess();
    PNT_PROTECT_VIRTUALMEMORY lpStProtect;
    static PMiProtectVirtualMemory lpMiProtectVirtualMemory;

    PAGED_CODE();

    if( !lpMiProtectVirtualMemory )
    {
        lpMiProtectVirtualMemory = ( PMiProtectVirtualMemory )
                                   ( ( ULONG_PTR )g_StSymbolsInfo.lpMiProtectVirtualMemory +
                                     ( ULONG_PTR )g_StReloadKernel.OriginalKernelBase );
    }


    if( !lpStSysCall->lpInBuffer || !lpStSysCall->lpOutBuffer )
    {
        return STATUS_UNSUCCESSFUL;
    }

    if( lpStSysCall->ulInBufferSize != sizeof( NT_PROTECT_VIRTUALMEMORY ) ||
            lpStSysCall->ulOutBufferSize != sizeof( NTSTATUS ) )
    {
        return STATUS_UNSUCCESSFUL;
    }

    lpStProtect          = lpStSysCall->lpInBuffer;
    ProcessHandle        = lpStProtect->ProcessHandle;
    UnsafeBaseAddress    = lpStProtect->UnsafeBaseAddress;
	NewAccessProtection  = lpStProtect->NewAccessProtection;
    UnsafeNumberOfBytesToProtect = lpStProtect->UnsafeNumberOfBytesToProtect;
    UnsafeOldAccessProtection    = lpStProtect->UnsafeOldAccessProtection;
	
    //
    // Check for valid protection flags
    //
    Protection = NewAccessProtection & ~( PAGE_GUARD | PAGE_NOCACHE );
    if( Protection != PAGE_NOACCESS &&
            Protection != PAGE_READONLY &&
            Protection != PAGE_READWRITE &&
            Protection != PAGE_WRITECOPY &&
            Protection != PAGE_EXECUTE &&
            Protection != PAGE_EXECUTE_READ &&
            Protection != PAGE_EXECUTE_READWRITE &&
            Protection != PAGE_EXECUTE_WRITECOPY )
    {
        //
        // Fail
        //
        return STATUS_INVALID_PAGE_PROTECTION;
    }

    //
    // Check if we came from user mode
    //
    if( PreviousMode != KernelMode )
    {
        //
        // Enter SEH for probing
        //
        __try
        {
            //
            // Validate all outputs
            //
            ProbeForWritePointer( UnsafeBaseAddress );
            ProbeForWriteSize_t( UnsafeNumberOfBytesToProtect );
            ProbeForWriteUlong( UnsafeOldAccessProtection );

            //
            // Capture them
            //
            BaseAddress = *UnsafeBaseAddress;
            NumberOfBytesToProtect = *UnsafeNumberOfBytesToProtect;
        }
        __except( EXCEPTION_EXECUTE_HANDLER )
        {
            //
            // Get exception code
            //
            return GetExceptionCode();
        }
    }
    else
    {
        //
        // Capture directly
        //
        BaseAddress = *UnsafeBaseAddress;
        NumberOfBytesToProtect = *UnsafeNumberOfBytesToProtect;
    }

    //
    // Catch illegal base address
    //
    if( BaseAddress > MM_HIGHEST_USER_ADDRESS ) return STATUS_INVALID_PARAMETER_2;

    //
    // Catch illegal region size
    //
    if( ( MmUserProbeAddress - ( ULONG_PTR )BaseAddress ) < NumberOfBytesToProtect )
    {
        //
        // Fail
        //
        return STATUS_INVALID_PARAMETER_3;
    }

    //
    // 0 is also illegal
    //
    if( !NumberOfBytesToProtect )
    {
        return STATUS_INVALID_PARAMETER_3;
    }

    //
    // Get a reference to the process
    //
    Status = ObReferenceObjectByHandle( ProcessHandle,
                                        PROCESS_VM_OPERATION,
                                        *PsProcessType,
                                        PreviousMode,
                                        ( PVOID* )( &Process ),
                                        NULL );
    if( !NT_SUCCESS( Status ) )
    {
        return Status;
    }

    //
    // Check if we should attach
    //
    if( CurrentProcess != Process )
    {
        //
        // Do it
        //
        KeStackAttachProcess( GetEprocessPcbPointer(Process), &ApcState );
        Attached = TRUE;
    }

    //
    // Do the actual work
    //
    Status = lpMiProtectVirtualMemory( Process,
                                       &BaseAddress,
                                       &NumberOfBytesToProtect,
                                       NewAccessProtection,
                                       &OldAccessProtection );

    //
    // Detach if needed
    //
    if( Attached )
    {
        KeUnstackDetachProcess( &ApcState );
    }

    //
    // Release reference
    //
    ObDereferenceObject( Process );

    //
    // Enter SEH to return data
    //
    __try
    {
        //
        // Return data to user
        //
        *UnsafeOldAccessProtection = OldAccessProtection;
        *UnsafeBaseAddress = BaseAddress;
        *UnsafeNumberOfBytesToProtect = NumberOfBytesToProtect;
    }
    __except( EXCEPTION_EXECUTE_HANDLER )
    {
    }

    //
    // Return status
    //
    return Status;
}
