#include "exithandler.h"
#include "ia32.h"
#include "helpers.h"
#include "AsmVmx.h"
#include "vmx.h"
#include "ept.h"
#include <ntddk.h>
#include <intrin.h>


EXTERN_C PVOID KiSystemCall64Pointer;
EXTERN_C PVOID KiSystemServiceCopyEndPointer;

EXTERN_C int nMsrWrite;

//exit�쳣����
BOOLEAN VmxVmexitHandler(GpRegisters* pGuestRegisters)
{
	KIRQL irql= KeGetCurrentIrql();
	if (irql < DISPATCH_LEVEL) 
	{
		KeRaiseIrqlToDpcLevel();
	}

	ULONG CurrentProcessorIndex = KeGetCurrentProcessorNumberEx(NULL);
	VmExitInformation ExitReason = { 0 };
	FlagRegister guestRflag = { 0 };
	BOOLEAN ContinueVmx = TRUE;
	ULONG_PTR Rip = 0;
	__vmx_vmread(GuestRip,&Rip);

	__vmx_vmread(VmExitReason, &ExitReason);
	GuestContext guestContext = { pGuestRegisters ,Rip };

	//DbgPrint("exit�쳣����\r\n");
	//__debugbreak();
	switch (ExitReason.fields.reason)
	{
	case ExitTripleFault://��Triple - Fault����
		//kprintf("TripleFault %p\r\n",Rip);
		VmmAdjustGuestRip();
		//DbgBreakPoint();
		break;
	case ExitEptMisconfig:
		//kprintf("ExitEptMisconfig\r\n");
		//DbgBreakPoint();
		break;
	case ExitEptViolation:
		//kprintf("ExitEptViolation\r\n");
		EptExitHandler(&guestContext);
		break;
	case ExitCrAccess:
	{
		//��������ָ��ִ�е��µ�vmexit. ��ָ�������Ϣ�����ExitQualification��VmExitInstructionInformation
		//cr������,ֻ֧��cr0,3,4
		//��һ���ǼĴ���������
		//kprintf("ExitCrAccess %p\r\n", Rip);
		ExitQualification eq = { 0 };
		__vmx_vmread(VmExitQualification, &eq);

		char crOp = eq.ControlRegisterAccesses.control_register;
		char regOp = eq.ControlRegisterAccesses.gp_register;
		if (eq.ControlRegisterAccesses.access_type==AcMoveToCr)//д����
		{

		}
		else if (eq.ControlRegisterAccesses.access_type == AcMoveToCr)//������
		{

		}
		else
		{
			kprintf("crAccess error\r\n");
			DbgBreakPoint();
		}
		break;
	}
	//msr��д���봦��
	case ExitMsrRead:
	{
		
		//__debugbreak();
		//ExitQualification eq = { 0 };
		//__vmx_vmread(VmExitQualification, &eq);
		LARGE_INTEGER msr = { 0 };
		//DbgPrint("ExitMsrRead %d\r\n");
		msr.QuadPart = __readmsr(pGuestRegisters->cx);
		//pGuestRegisters->ax = msr.LowPart;
		//pGuestRegisters->dx = msr.HighPart;
		//VmmAdjustGuestRip();

		DbgPrint("msr����\r\n");
		//ULONGLONG MsrValue = __readmsr((ULONG)pGuestRegisters->cx);

		//DbgPrint("msrpGuestRegisters->cx:%lX\r\n");
		switch (pGuestRegisters->cx)
		{
			case MSR_LSTAR: // ��ȡ MSR RIP����ʱ����㿴������
			{
				
				//KdBreakPoint();
				if (KiSystemCall64Pointer)
				{
					msr.QuadPart = (ULONG_PTR)KiSystemCall64Pointer; // SSDT HOOK
					DbgPrint("msr������ssdt%p\r\n", msr.QuadPart);
				}
			}
			default:
			{
				// Ĭ���������̣�����ִ�еĻ��������ǸĹ��ı���
				DbgPrint("msrû��%p\r\n", msr.QuadPart);
				pGuestRegisters->ax = msr.LowPart;
				pGuestRegisters->dx = msr.HighPart;
				
			}
			break;
		}

		// ��Ĭ������
		VmmAdjustGuestRip();

		break;
	}
	case ExitMsrWrite://дmsr
	{
		//__debugbreak();

		LARGE_INTEGER msr = { 0 };

		msr.LowPart = pGuestRegisters->ax;
		msr.HighPart = pGuestRegisters->dx;
		if (nMsrWrite)//�����Ƿ�ֹ�����޸�msr
		{
			__writemsr(pGuestRegisters->cx, msr.QuadPart); 
			nMsrWrite = FALSE;
			//__debugbreak();
		}
		else
		{
			DbgPrint("MsrWriteд�Ѿ���ֹ\r\n");
		}
		
		VmmAdjustGuestRip();
		
		break;
	}
	case ExitCpuid:
	{
		//DbgPrint("ExitCpuid\r\n");
		//���ʺ�Ƶ��
		int leaf = (int)pGuestRegisters->ax;
		int sub_leaf = (int)pGuestRegisters->cx;
		int result[4] = { 0 };
		__cpuidex(&result, leaf, sub_leaf);

		if (pGuestRegisters->r10 == 0x99999999)
		{
			pGuestRegisters->r11 = 0x99999999;
			pGuestRegisters->r12 = 0x99999999;
		}
		pGuestRegisters->ax = result[0];
		pGuestRegisters->bx = result[1];
		pGuestRegisters->cx = result[2];
		pGuestRegisters->dx = result[3];

		VmmAdjustGuestRip();
		break;
	}
	case ExitIoInstruction:
	{
		kprintf("ExitIoInstruction\r\n");
		VmmAdjustGuestRip();
		break;
	}
	case ExitVmcall://�˳�
	{
		ContinueVmx = FALSE;
		VmxPrepareOff(pGuestRegisters);
		break;
	}
	case ExitExceptionOrNmi:
	{
		//kprintf("ExitExceptionOrNmi");
		VmExitInterruptionInformationField exception = { 0 };
		__vmx_vmread(VmExitInterruptionInformation, &exception);

		DbgPrint("---------\r\n");
		if (exception.fields.interruption_type == kHardwareException)//Ӳ���쳣
		{
			DbgPrint("Ӳ��---------%d\r\n",exception.fields.vector);
			//VmmpInjectInterruption(exception.fields.interruption_type,)
			exception.fields.valid = TRUE;
			UtilVmxWrite(VmEntryInterruptionInformation, exception.all);
		}
		else if (exception.fields.interruption_type == kSoftwareException)//�����쳣
		{
			DbgPrint("int 3 -----\r\n");
			//__debugbreak();
			UtilVmxWrite(VmEntryInterruptionInformation, exception.all);
			int exit_inst_length = 0;
			__vmx_vmread(VmExitInstructionLength,&exit_inst_length);
			UtilVmxWrite(VmEntryInstructionLength, exit_inst_length);
		}
		break;
	}
	case ExitMonitorTrapFlag:
	{
		kprintf("ExitMonitorTrapFlag\r\n");

		break;
	}
	case ExitHlt:
	{
		kprintf("ExitHlt\r\n");
		break;
	}
	case ExitVmclear:
	case ExitVmptrld:
	case ExitVmptrst:
	case ExitVmread:
	case ExitVmwrite:
	case ExitVmresume:
	case ExitVmoff:
	case ExitVmon:
	case ExitVmlaunch:
	case ExitVmfunc:
	case ExitInvept:
	case ExitInvvpid:
	{
		kprintf("vm inst");
		__vmx_vmread(GuestRflags, &guestRflag);
		guestRflag.fields.cf = 1;
		UtilVmxWrite(GuestRflags, guestRflag.all);
		VmmAdjustGuestRip();
		break;
	}
	case ExitInvd:
	{
		kprintf("ExitInvd\r\n");
		AsmInvd();
		VmmAdjustGuestRip();
		break;
	}
	case ExitInvlpg:
	{
		kprintf("ExitInvlpg\r\n");
		ExitQualification eq = { 0 };
		__vmx_vmread(VmExitQualification, &eq);
		InvVpidDescriptor desc = { 0 };
		desc.vpid = CurrentProcessorIndex + 1;
		desc.linear_address= eq.all;
		AsmInvvpid(kIndividualAddressInvalidation,&desc);
		VmmAdjustGuestRip();
		break;
	}
	case ExitRdtsc:
	{
		kprintf("ExitRdtsc\r\n");

		ULARGE_INTEGER tsc = {0};
		tsc.QuadPart = __rdtsc();
		pGuestRegisters->dx = tsc.HighPart;
		pGuestRegisters->ax = tsc.LowPart;
		VmmAdjustGuestRip();
		break;
	}
	case ExitRdtscp:
	{
		kprintf("ExitRdtscp\r\n");

		unsigned int tsc_aux = 0;
		ULARGE_INTEGER tsc = {0};
		tsc.QuadPart = __rdtscp(&tsc_aux);
		pGuestRegisters->dx = tsc.HighPart;
		pGuestRegisters->ax = tsc.LowPart;
		pGuestRegisters->cx = tsc_aux;
		VmmAdjustGuestRip();
		break;
	}
	case ExitXsetbv:
	{
		kprintf("ExitXsetbv\r\n");

		ULARGE_INTEGER value = {0};
		value.LowPart = pGuestRegisters->ax;
		value.HighPart = pGuestRegisters->dx;
		_xsetbv(pGuestRegisters->cx, value.QuadPart);

		VmmAdjustGuestRip();
		break;
	}
	default:
		DbgPrint("Unexpected Exit %d\r\n", ExitReason.fields.reason);
		DbgBreakPoint();
		break;
	}

	if (irql < DISPATCH_LEVEL) {
		KeLowerIrql(irql);
	}

	return ContinueVmx;
}

void VmmAdjustGuestRip()
{
	ULONG instLen = 0;
	ULONG_PTR rip = 0;
	__vmx_vmread(GuestRip, &rip);
	__vmx_vmread(VmExitInstructionLength, &instLen);
	UtilVmxWrite(GuestRip, rip + instLen);
}

void VmmpInjectInterruption(
	ULONG interruption_type, ULONG vector,
	BOOLEAN deliver_error_code, ULONG32 error_code) {
	VmEntryInterruptionInformationField inject = {0};
	inject.fields.valid = TRUE;
	inject.fields.interruption_type =interruption_type;
	inject.fields.vector =vector;
	inject.fields.deliver_error_code = deliver_error_code;
	UtilVmxWrite(VmEntryInterruptionInformation, inject.all);

	if (deliver_error_code) {
		UtilVmxWrite(VmEntryExceptionErrorCode, error_code);
	}
}

