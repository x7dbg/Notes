#include "ToolFunction.h"
#include <wdm.h>
#include "Data.h"

ULONG TraverseDocument(PVOID pOutputBuffer, ULONG ulBufferSize, PVOID pDirectoryName)
{
	ULONG ulRet;
	UNICODE_STRING uStrFileFullName;
	uStrFileFullName.Buffer = (PWSTR)ExAllocatePool(PagedPool, 1024);
	uStrFileFullName.MaximumLength = 1024;
	ULONG ulCount;
	ulCount = 0;
	UNICODE_STRING uStrDirectoryPath;
	RtlInitUnicodeString(&uStrDirectoryPath, (PCWSTR)pDirectoryName);
	HANDLE hFile = NULL;
	SIZE_T nFileInfoSize = sizeof(FILE_BOTH_DIR_INFORMATION) + 256 * sizeof(WCHAR);
	SIZE_T nSize = nFileInfoSize * 0x256;
	char strFileName[0x256] = { 0 };
	PFILE_BOTH_DIR_INFORMATION pFileInfo = NULL;
	PFILE_BOTH_DIR_INFORMATION pFileList = NULL;
	pFileList = (PFILE_BOTH_DIR_INFORMATION)ExAllocatePool(PagedPool, nSize);
	pFileInfo = (PFILE_BOTH_DIR_INFORMATION)ExAllocatePool(PagedPool, nFileInfoSize);

	RtlZeroMemory(pFileList, nSize);
	RtlZeroMemory(pFileInfo, nFileInfoSize);
	hFile = GetFileHandle(&uStrDirectoryPath);


	tagENUMFILES* pFileHead;
	tagENUMFILES* pFileTemp;
	pFileHead = (tagENUMFILES*)ExAllocatePool(PagedPool, sizeof(tagENUMFILES));
	RtlZeroMemory(pFileHead, sizeof(tagENUMFILES));
	pFileTemp = pFileHead;
	if (GetDirectoryInfo(hFile, nSize, pFileList, nFileInfoSize, pFileInfo))
	{
		LONG nOffset = 0;
		do
		{
			RtlZeroMemory(strFileName, 0x256);
			RtlCopyMemory(strFileName, pFileInfo->FileName, pFileInfo->FileNameLength);
			if (strcmp(strFileName, "..") == 0 || strcmp(strFileName, ".") == 0)
				continue;
			++ulCount;
			if (pFileInfo->FileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				//DbgPrint("[De1ta] Directory : %s\n", strFileName);
				RtlCopyMemory(pFileTemp->m_szFileName, strFileName, 512);
				pFileTemp->m_szFileOrDirectory = 0;
			}
			else
			{
				//DbgPrint("[De1ta] File : %S\n", strFileName);
				RtlCopyMemory(pFileTemp->m_szFileName, strFileName, NAME_SIZE);	// �ļ���
				pFileTemp->m_CreateTime = pFileInfo->CreationTime;				// ����ʱ��
				pFileTemp->m_UpdateTime = pFileInfo->LastWriteTime;				// �޸�ʱ��
				UNICODE_STRING FileName;
				RtlInitUnicodeString(&FileName, (PCWSTR)strFileName);
				uStrFileFullName.Length = 0;
				RtlZeroMemory(uStrFileFullName.Buffer, 1024);
				RtlAppendUnicodeStringToString(&uStrFileFullName, &uStrDirectoryPath); //��Դ�е��ֽڸ��Ƶ�ָ����Ŀ���ַ���
				RtlAppendUnicodeStringToString(&uStrFileFullName, &FileName);//��Դ�е��ֽڸ��Ƶ�ָ����Ŀ���ַ���
				pFileTemp->m_nSize = GetFileSize(&uStrFileFullName);					// �ļ�ȫ��
				pFileTemp->m_szFileOrDirectory = 1;
			}
			tagENUMFILES* pTemp;
			pTemp = (tagENUMFILES*)ExAllocatePool(PagedPool, sizeof(tagENUMFILES));
			pTemp->Next = NULL;
			pFileTemp->Next = pTemp;
			pFileTemp = pTemp;
		} while (GetNextFileInfo(pFileList, pFileInfo, &nOffset));
	}
	ExFreePool(uStrFileFullName.Buffer);
	ulRet = ZwClose(hFile);
	ULONG OutPutSize = ulCount * sizeof(tagENUMFILES);
	tagENUMFILES* OutFiles = (tagENUMFILES*)pOutputBuffer;
	if (OutPutSize <= ulBufferSize)
	{
		pFileTemp = pFileHead;
		for (ULONG i = 0; i < ulCount; ++i)
		{
			OutFiles[i].m_szFileOrDirectory = pFileTemp->m_szFileOrDirectory;				// flags
			RtlCopyMemory(OutFiles[i].m_szFileName, pFileTemp->m_szFileName, NAME_SIZE);	// �ļ���
			OutFiles[i].m_CreateTime = pFileTemp->m_CreateTime;							    // ����ʱ��
			OutFiles[i].m_UpdateTime = pFileTemp->m_UpdateTime;							    // �޸�ʱ��
			OutFiles[i].m_nSize = pFileTemp->m_nSize;										// �ļ���С
			pFileTemp = pFileTemp->Next;
		}
	}
	// �����ռ�
	pFileTemp = pFileHead;
	for (ULONG i = 0; i <= ulCount; ++i)
	{
		ExFreePool(pFileTemp);
		pFileTemp = pFileTemp->Next;
	}
	return OutPutSize;

}

HANDLE GetFileHandle(PUNICODE_STRING pStrFile)
{
	HANDLE hFile = NULL;
	NTSTATUS ntStatus = STATUS_UNSUCCESSFUL;
	IO_STATUS_BLOCK StatusBlock = { 0 };
	// ��ʼ��OBJECT_ATTRIBUTES������
	OBJECT_ATTRIBUTES objAttributes = { 0 };
	InitializeObjectAttributes(&objAttributes, pStrFile, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);
	// �����ļ�����
	ntStatus = ZwCreateFile(&hFile, FILE_LIST_DIRECTORY | SYNCHRONIZE | FILE_ANY_ACCESS, 
		&objAttributes, 
		&StatusBlock, 0, FILE_ATTRIBUTE_NORMAL, 
		FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, FILE_OPEN_IF,
		FILE_SYNCHRONOUS_IO_NONALERT | FILE_DIRECTORY_FILE, NULL, 0);
	if (!NT_SUCCESS(ntStatus))
		return (HANDLE)-1;
	return hFile;
}

BOOLEAN GetDirectoryInfo(HANDLE hFile, ULONG ulLen, PFILE_BOTH_DIR_INFORMATION pDirectory, ULONG ulFileLen, PFILE_BOTH_DIR_INFORMATION pFirstFile)
{
	NTSTATUS Status = STATUS_UNSUCCESSFUL;
	IO_STATUS_BLOCK StatusBlock = { 0 };
	//��ȡ�ļ���Ϣ ������3����TRUE
	Status = ZwQueryDirectoryFile(hFile, NULL, NULL, NULL, &StatusBlock, pFirstFile, ulFileLen, FileBothDirectoryInformation, TRUE, NULL, FALSE);
	//��ȡ�ļ��б� ������3����FALSE
	if (NT_SUCCESS(Status) == FALSE)
		return FALSE;
	Status = ZwQueryDirectoryFile(hFile, NULL, NULL, NULL, &StatusBlock, pDirectory, ulLen, FileBothDirectoryInformation, FALSE, NULL, FALSE);
	return NT_SUCCESS(Status);
}

BOOLEAN GetNextFileInfo(PFILE_BOTH_DIR_INFORMATION pDirList, PFILE_BOTH_DIR_INFORMATION pFileInfo, LONG* nOffset)
{
	//ָ����һ��
	PFILE_BOTH_DIR_INFORMATION pDir = (PFILE_BOTH_DIR_INFORMATION)((PCHAR)pDirList + *nOffset);
	if (pDir->FileName[0] != 0)
	{
		memcpy(pFileInfo, pDir, sizeof(FILE_BOTH_DIR_INFORMATION) + pDir->FileNameLength);
		*nOffset = *nOffset + pDir->NextEntryOffset;
		if (pDir->NextEntryOffset == 0)
			//ָ���
			*nOffset = *nOffset + sizeof(FILE_BOTH_DIR_INFORMATION) + pDir->FileNameLength;
		return TRUE;
	}
	return FALSE;
}

LONGLONG GetFileSize(PUNICODE_STRING pFileStr)
{
	FILE_STANDARD_INFORMATION fsi;
	HANDLE hFile = NULL;
	IO_STATUS_BLOCK iosb = { 0 };
	OBJECT_ATTRIBUTES objAttributes = { 0 };
	InitializeObjectAttributes(&objAttributes, pFileStr, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);
	ULONG ulCreateOpt = FILE_SYNCHRONOUS_IO_NONALERT | FILE_NON_DIRECTORY_FILE;
	ZwOpenFile(&hFile, FILE_READ_ATTRIBUTES, &objAttributes, &iosb, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, ulCreateOpt);
	ZwQueryInformationFile(hFile, &iosb, &fsi, sizeof(FILE_STANDARD_INFORMATION), FileStandardInformation);
	if (!hFile)
		return 0;

	ZwClose(hFile);


	return fsi.EndOfFile.QuadPart;
}







ULONG ThroughRegistry(PVOID pOutputBuffer, ULONG ulBufferSize, PVOID pRegisterName)
{
	ULONG ulCount = 0;
	ULONG ulSize = 0;
	NTSTATUS ntStatus;
	PKEY_FULL_INFORMATION pfi;
	OBJECT_ATTRIBUTES objectAttributes;
	HANDLE hRegister;
	UNICODE_STRING RegUnicodeString;
	tagREGISTER *pReg = (tagREGISTER*)pOutputBuffer;
	// ��ʼ��UNICODE_STRING�ַ���
	RtlInitUnicodeString(&RegUnicodeString, (PCWSTR)pRegisterName);
	InitializeObjectAttributes(&objectAttributes, &RegUnicodeString, OBJ_CASE_INSENSITIVE, NULL, NULL);
	// ��ע���
	ntStatus = ZwOpenKey(&hRegister, KEY_ALL_ACCESS, &objectAttributes);
	if (NT_SUCCESS(ntStatus))
	//DbgPrint("Open Register Successfully\n");
	// ��ѯVALUE�Ĵ�С
	ZwQueryKey(hRegister, KeyFullInformation, NULL, 0, &ulSize);
	pfi = (PKEY_FULL_INFORMATION)ExAllocatePool(PagedPool, ulSize);
	ZwQueryKey(hRegister, KeyFullInformation, pfi, ulSize, &ulSize);
	ulCount = pfi->SubKeys + pfi->Values;
	// �жϴ�С
	if (ulCount * sizeof(tagREGISTER) > ulBufferSize)
		return ulCount * sizeof(tagREGISTER);
	// �������������
	ULONG ulIndex = 0;
	for (ULONG i = 0; i < pfi->SubKeys; ++i)
	{
		pReg[ulIndex].m_uType = 0;
		ulSize = 0;
		ZwEnumerateKey(hRegister, i, KeyBasicInformation, NULL, 0, &ulSize);
		PKEY_BASIC_INFORMATION pbi = (PKEY_BASIC_INFORMATION)ExAllocatePool(PagedPool, ulSize);
		ZwEnumerateKey(hRegister, i, KeyBasicInformation, pbi, ulSize, &ulSize);
		RtlCopyMemory(&pReg[ulIndex].m_szKeyName, pbi->Name, pbi->NameLength);
		ExFreePool(pbi);
		ulIndex++;
	}
	for (ULONG i = 0; i < pfi->Values; ++i)
	{
		pReg[ulIndex].m_uType = 1;
		PKEY_VALUE_FULL_INFORMATION pvbi;
		//��ѯ����VALUE�Ĵ�С
		ZwEnumerateValueKey(hRegister, i, KeyValueFullInformation, NULL, 0, &ulSize);
		pvbi = (PKEY_VALUE_FULL_INFORMATION)ExAllocatePool(PagedPool, ulSize);
		//��ѯ����VALUE������
		ZwEnumerateValueKey(hRegister, i, KeyValueFullInformation, pvbi, ulSize, &ulSize);
		// ��ȡ��ֵ������
		RtlCopyMemory(&pReg[ulIndex].m_szValueName, pvbi->Name, pvbi->NameLength);
		pReg[ulIndex].m_uValueType = pvbi->Type;
		RtlCopyMemory(pReg[ulIndex].m_uValue, ((UCHAR*)(ULONG)pvbi + pvbi->DataOffset), pvbi->DataLength);
		ExFreePool(pvbi);
		++ulIndex;
	}
	ExFreePool(pfi);
	ZwClose(hRegister);
	return ulCount * sizeof(tagREGISTER);

}