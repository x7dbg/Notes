#include "CObject.h"


const CRuntimeClass CObject::classCObject = { "CObject",
sizeof(CObject), 0xFFFF, NULL, NULL };

CRuntimeClass* CObject::GetRuntimeClass() const {
  return RUNTIME_CLASS(CObject);
}