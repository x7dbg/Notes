//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 *
 * ����ļ��Ǵ���Shadow SSDT����һЩ����, ��ֹö�����ǵĵ��Խ��̵Ĵ���
 */
//===========================================================================
#include <ntddk.h>
#include "defines.h"
#include "ExtDef.h"
#include "ShadowSSDT.h"
#include "Version.h"

extern	PSERVICE_DESCRIPTOR_TABLE KeServiceDescriptorTableShadow;
//---------------------------------------------------------------------------
//API FindWindowA/W, FindWindowExA/W
HWND
_NtUserFindWindowEx(
    IN HWND hwndParent,
    IN HWND hwndChild,
    IN PUNICODE_STRING pstrClassName,
    IN PUNICODE_STRING pstrWindowName,
    DWORD dwType )

{
    HWND hWndRet;
    PNtUserFindWindowEx lpNtUserFindWindowEx;
    PEPROCESS Eprocess = IoGetCurrentProcess();

    lpNtUserFindWindowEx =
        KeServiceDescriptorTableShadow->win32k.ServiceTable[GetNtUserFindWindowExIndex()];

    hWndRet = lpNtUserFindWindowEx( hwndParent, hwndChild, pstrClassName, pstrWindowName, dwType );

// 	KdPrint( ( "Ddvp-> Call _NtUserFindWindowEx Eprocess:%p,Name:%s, RetWnd:%p!\n", 
// 		Eprocess, GetEprocessNamePointer(Eprocess), hWndRet ) );
// 
//     KdPrint( ( "Ddvp-> hWndParent:%p, hWndChild:%p, ClasssName:%wZ, WindowName:%wZ!\n",
//                hwndParent, hwndChild, pstrClassName, pstrWindowName ) );

    return hWndRet;
}

// API GetForegroundWindow
HWND _NtUserGetForegroundWindow(
    VOID )
{
    HWND hWndRet;
    PNtUserGetForegroundWindow lpNtUserGetForegroundWindow;
    PEPROCESS Eprocess = IoGetCurrentProcess();

    lpNtUserGetForegroundWindow =
        KeServiceDescriptorTableShadow->win32k.ServiceTable[GetNtUserGetForegroundWindowIndex()];

    hWndRet = lpNtUserGetForegroundWindow();

   // KdPrint( ( "Ddvp-> Call _NtUserGetForegroundWindow Eprocess:%p, RetWnd:%p!\n", Eprocess, hWndRet ) );

    return hWndRet;
}

// worker for EnumWindows, EnumThreadWindows etc.
NTSTATUS _NtUserBuildHwndList(  
							 IN HDESK hdesk,
							 IN HWND hwndNext,
							 IN BOOL fEnumChildren,
							 IN DWORD idThread,
							 IN UINT cHwndMax,
							 OUT HWND *phwndFirst,
							 OUT PUINT pcHwndNeeded)
{
	NTSTATUS Status;
	PNtUserBuildHwndList lpNtUserBuildHwndList;
	PEPROCESS Eprocess = IoGetCurrentProcess();

	lpNtUserBuildHwndList =
		KeServiceDescriptorTableShadow->win32k.ServiceTable[GetNtUserBuildHwndListIndex()];

	Status = lpNtUserBuildHwndList( hdesk, hwndNext, 
		fEnumChildren, idThread, cHwndMax, phwndFirst, pcHwndNeeded );

// 	KdPrint( ( "Ddvp-> Call _NtUserBuildHwndList Eprocess:%p Name:%s!\n",
// 		Eprocess, GetEprocessNamePointer(Eprocess) ) );

	return Status;
}

HWND
_NtUserWindowFromPoint(LONG X, LONG Y)
{
	HWND hWndRet;
	PNtUserWindowFromPoint lpNtUserWindowFromPoint;
	PEPROCESS Eprocess = IoGetCurrentProcess();

	lpNtUserWindowFromPoint =
		KeServiceDescriptorTableShadow->win32k.ServiceTable[GetNtUserWindowFromPointIndex()];

	hWndRet = lpNtUserWindowFromPoint( X, Y );

// 	KdPrint( ( "Ddvp-> Call _NtUserWindowFromPoint Eprocess:%p Name:%s!\n",
// 		Eprocess, GetEprocessNamePointer(Eprocess) ) );
// 
// 	KdPrint( ( "Ddvp-> X =%p, Y=%p, Hwnd Is:%p!\n", X, Y, hWndRet ) );

	return hWndRet;
}