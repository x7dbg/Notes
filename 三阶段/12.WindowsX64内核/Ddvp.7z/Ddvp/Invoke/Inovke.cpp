//===========================================================================
/*
 * Dichlorvos:�޸ĵ�Windows���Լܹ�, pass�����Կ��
 * Auto		 :Joen
 * QQ		 :51753931
 * E-mail	 :Joen@JoenChen.com
 * Website:  :http://www.joenchen.com
 * ����ļ��ǲ����ļ�, ���Ե��Կ��
 */
//===========================================================================

#include <stdlib.h>
#define WINVER 0x0501
#include <tchar.h>
#include <windows.h>
#include <Psapi.h>
#include <strsafe.h>
#include <stdio.h>
#include <DbgHelp.h>
#include "ntdll.h"
#include "Invoke.h"
#include "DbgObj.h"



#pragma comment( lib, "Psapi.lib")

// ************************************************************************
// FUNCTION : DbgNewProcess( LPTSTR, LPTSTR )
// PURPOSE  : starts a new process as a debuggee
// COMMENTS :
// ************************************************************************
BOOL
DbgNewProcess( LPTSTR szCmdLine )
{
    STARTUPINFO           StartupInfo = {0};
    PROCESS_INFORMATION   ProcessInfo = {0};

    StartupInfo.cb = sizeof ( STARTUPINFO ) ;

    //-- create the Debuggee process
    if( !DbgObjCreateProcess(
                0L,
                szCmdLine,
                L"Test.exe",
                ( LPSECURITY_ATTRIBUTES ) 0L,
                ( LPSECURITY_ATTRIBUTES ) 0L,
                TRUE,
                DEBUG_PROCESS | CREATE_NEW_CONSOLE | NORMAL_PRIORITY_CLASS,
                ( LPVOID ) 0L,
                ( LPTSTR ) 0L,
                &StartupInfo, &ProcessInfo ) )
    {
        TCHAR szMsg[MAX_PATH];

        FormatMessage(
            FORMAT_MESSAGE_FROM_SYSTEM |
            FORMAT_MESSAGE_IGNORE_INSERTS,
            NULL,
            GetLastError(),
            0, // Default language
            ( LPTSTR ) szMsg,
            MAX_PATH,
            NULL
        );

        wprintf( _T( "Failed in CreateProcess() with error:\n  " ) );
        wprintf( szMsg );
        wprintf( _T( "\n" ) );
        return( FALSE );
    }
    else
    {
        printf( "����ID :%d \n", ProcessInfo.dwProcessId );
        CloseHandle( ProcessInfo.hProcess );
        CloseHandle( ProcessInfo.hThread );
    }
    return TRUE;
}

DWORD
DbgNewProcessHandle( LPTSTR szCmdLine )
{
    STARTUPINFO           StartupInfo = {0};
    PROCESS_INFORMATION   ProcessInfo = {0};

    StartupInfo.cb = sizeof ( STARTUPINFO ) ;

    //-- create the Debuggee process
    if( !CreateProcess(
                0L,
                szCmdLine,
                ( LPSECURITY_ATTRIBUTES ) 0L,
                ( LPSECURITY_ATTRIBUTES ) 0L,
                TRUE,
                CREATE_NEW_CONSOLE | NORMAL_PRIORITY_CLASS,
                ( LPVOID ) 0L,
                ( LPTSTR ) 0L,
                &StartupInfo, &ProcessInfo ) )
    {
        TCHAR szMsg[MAX_PATH];

        FormatMessage(
            FORMAT_MESSAGE_FROM_SYSTEM |
            FORMAT_MESSAGE_IGNORE_INSERTS,
            NULL,
            GetLastError(),
            0, // Default language
            ( LPTSTR ) szMsg,
            MAX_PATH,
            NULL
        );

        wprintf( _T( "Failed in CreateProcess() with error:\n  " ) );
        wprintf( szMsg );
        wprintf( _T( "\n" ) );
        return( FALSE );
    }
    else
    {
        CloseHandle( ProcessInfo.hProcess );
        CloseHandle( ProcessInfo.hThread );
    }
    return ProcessInfo.dwProcessId;
}
#define MAX_DBG_EVENT 9

LPTSTR DbgEventName[ MAX_DBG_EVENT + 1] =
{
    L"EXCEPTION_DEBUG_EVENT",
    L"CREATE_THREAD_DEBUG_EVENT",
    L"CREATE_PROCESS_DEBUG_EVENT",
    L"EXIT_THREAD_DEBUG_EVENT",
    L"EXIT_PROCESS_DEBUG_EVENT",
    L"LOAD_DLL_DEBUG_EVENT",
    L"UNLOAD_DLL_DEBUG_EVENT",
    L"OUTPUT_DEBUG_STRING_EVENT",
    L"RIP_EVENT",
    L"Unknown Debug Event"
};

//---------------------------------------------------------------------------
//
//	��ȡHandle ��С
//
//---------------------------------------------------------------------------
ULONG GetFileSizeFromHandle( HANDLE hFile )
{
    DWORD dwFileSizeHi = 0;

    return  GetFileSize( hFile, &dwFileSizeHi );

}

//---------------------------------------------------------------------------
//
//	��ȡHandle��·��
//
//---------------------------------------------------------------------------
BOOL GetFileNameFromHandle( HANDLE hFile, wchar_t* lpSzDllName, DWORD dwBufferSize )
{
    BOOL bSuccess = FALSE;
    HANDLE hFileMap;

    // Get the file size.
    DWORD dwFileSizeHi = 0;
    DWORD dwFileSizeLo = GetFileSize( hFile, &dwFileSizeHi );
    if( dwFileSizeLo == 0 && dwFileSizeHi == 0 )
    {
        return FALSE;
    }


    // Create a file mapping object.
    hFileMap = CreateFileMapping( hFile,
                                  NULL,
                                  PAGE_READONLY,
                                  0,
                                  1,
                                  NULL );
    if ( hFileMap )
    {
        // Create a file mapping to get the file name.
        void* pMem = MapViewOfFile( hFileMap, FILE_MAP_READ, 0, 0, 1 );
        if ( pMem )
        {
            if ( GetMappedFileName ( GetCurrentProcess(),
                                     pMem,
                                     lpSzDllName,
                                     MAX_PATH ) )
            {
                // Translate path with device name to drive letters.
                TCHAR szTemp[1024];
                szTemp[0] = '\0';

                if ( GetLogicalDriveStrings( 1024 - 1, szTemp ) )
                {
                    TCHAR szName[MAX_PATH];
                    TCHAR szDrive[3] = TEXT( " :" );
                    BOOL bFound = FALSE;
                    TCHAR* p = szTemp;
                    do
                    {
                        // Copy the drive letter to the template string
                        *szDrive = *p;

                        // Look up each device name
                        if ( QueryDosDevice( szDrive, szName, MAX_PATH ) )
                        {
                            size_t uNameLen = wcslen( szName );
                            if ( uNameLen < MAX_PATH )
                            {
                                bFound = _tcsnicmp ( lpSzDllName, szName, uNameLen ) == 0;
                                if ( bFound && *( lpSzDllName + uNameLen ) == '\\' )
                                {
                                    // Reconstruct pszFilename using szTempFile
                                    // Replace device path with DOS path
                                    TCHAR szTempFile[MAX_PATH];

                                    StringCchPrintf( szTempFile,
                                                     MAX_PATH,
                                                     _T( "%s%s" ),
                                                     szDrive,
                                                     lpSzDllName + uNameLen );

                                    StringCchCopyN( lpSzDllName, MAX_PATH + 1, szTempFile, wcslen( szTempFile ) );
                                }
                            }
                        }
                        // Go to the next NULL character.
                        while ( *p++ );
                    }
                    while ( !bFound && *p ); // end of string
                }
            }
            bSuccess = TRUE;
            UnmapViewOfFile( pMem );
        }
        CloseHandle( hFileMap );
    }

    return( bSuccess );
}

BOOL IsPEFile( LPVOID ImageBase )
{
    PIMAGE_DOS_HEADER  pDH = NULL;
    PIMAGE_NT_HEADERS  pNtH = NULL;

    if( !ImageBase )
        return FALSE;

    pDH = ( PIMAGE_DOS_HEADER )ImageBase;
    if( pDH->e_magic != IMAGE_DOS_SIGNATURE )
        return FALSE;

    pNtH = ( PIMAGE_NT_HEADERS32 )( ( DWORD )pDH + pDH->e_lfanew );
    if ( pNtH->Signature != IMAGE_NT_SIGNATURE )
        return FALSE;

    return TRUE;

}
//
PIMAGE_NT_HEADERS  GetNtHeaders( LPVOID ImageBase )
{

    if( !IsPEFile( ImageBase ) )
    {
        return NULL;
    }

    PIMAGE_NT_HEADERS  pNtH;
    PIMAGE_DOS_HEADER  pDH;

    pDH = ( PIMAGE_DOS_HEADER )ImageBase;
    pNtH = ( PIMAGE_NT_HEADERS )( ( DWORD )pDH + pDH->e_lfanew );

    return pNtH;

}

BOOL GetPeFileEntryPoint( HANDLE hFile, ULONG* pEntry )
{
    BOOL bRet = TRUE;
    HANDLE hMapping;
    PIMAGE_NT_HEADERS ImageNtHeaders;
    LPVOID ImageBase = NULL;

    do
    {
        hMapping = CreateFileMapping( hFile, NULL, PAGE_READONLY, 0, 0, NULL );
        if( !hMapping )
        {
            bRet = FALSE;
            break;
        }

        ImageBase = MapViewOfFile( hMapping, FILE_MAP_READ, 0, 0, 0 );
        if( !ImageBase )
        {
            bRet = FALSE;
            break;
        }

        if ( !IsPEFile( ImageBase ) )
        {
            bRet = FALSE;
            break;
        }

        ImageNtHeaders = GetNtHeaders( ImageBase );
        if ( !ImageNtHeaders )
        {
            bRet = FALSE;
            break;
        }

        *pEntry =
            ImageNtHeaders->OptionalHeader.ImageBase +
            ImageNtHeaders->OptionalHeader.AddressOfEntryPoint;
    }
    while ( FALSE );


    if ( ImageBase )
    {
        UnmapViewOfFile( ImageBase );
    }
    if ( hMapping )
    {
        CloseHandle( hMapping );
    }
    return bRet;
}

BOOL DbgMainLoop( DWORD dwWaitMS )
{
    static char Int3Value;
    static BOOL bIsSystemBreak = TRUE;
    static HANDLE hProcess;
    static ULONG ulEntry;
    HANDLE hThread;
    CONTEXT StContext;
    DEBUG_EVENT DbgEvt;
    DWORD dwContinueStatus = DBG_CONTINUE;
    BOOL bExit = FALSE;
    DWORD dwByteRead;
    PVOID ulErrorAddress = NULL;
    PVOID ulErrorAddress2 = NULL;
    wchar_t SzBuffer[1024] = {0};
    static PVOID lpSysBreak = GetProcAddress( LoadLibrary( _T( "ntdll.dll" ) ), "DbgBreakPoint" );

    CREATE_PROCESS_DEBUG_INFO CreateProcessInfo;
    LOAD_DLL_DEBUG_INFO LoadDllInfo;
    EXCEPTION_DEBUG_INFO ExceptionInfo;
    EXCEPTION_RECORD ExceptionRecord;
    CREATE_THREAD_DEBUG_INFO CreateThreadInfo;
    EXIT_PROCESS_DEBUG_INFO ExitProcessInfo;
    EXIT_THREAD_DEBUG_INFO ExitThreadInfo;
    UNLOAD_DLL_DEBUG_INFO UnLoadDllInfo;
    OUTPUT_DEBUG_STRING_INFO StDebugStringInfo;

    while( !bExit )
    {
        if( !DbgObjWaitForDebugEvent( &DbgEvt, dwWaitMS ) )
        {
            printf( "WaitForDebugEvent() returned False %d.\n", GetLastError() );
            bExit = TRUE;
            continue;
        }

        // Process the debugging event code.
        wprintf( L"Debug event received from process %d thread %d: %s \n",
                 DbgEvt.dwProcessId, DbgEvt.dwThreadId,
                 DbgEventName[DbgEvt.dwDebugEventCode >
                              MAX_DBG_EVENT ? MAX_DBG_EVENT :
                              DbgEvt.dwDebugEventCode - 1] );
//---------------------------------------------------------------------------
        switch ( DbgEvt.dwDebugEventCode )
        {
        case EXCEPTION_DEBUG_EVENT:

            ExceptionInfo = DbgEvt.u.Exception;
            ExceptionRecord = DbgEvt.u.Exception.ExceptionRecord;

            printf( "\tException Type: 0x%p Exception address: 0x%p\n",
                    ExceptionRecord.ExceptionCode,
                    ExceptionRecord.ExceptionAddress );

            switch ( DbgEvt.u.Exception.ExceptionRecord.ExceptionCode )
            {
            case EXCEPTION_ACCESS_VIOLATION:

                // First chance: Pass this on to the system.
                // Last chance: Display an appropriate error.
				printf( "\t�����쳣, ������ȥ��, �����Լ�������!\n"  );
				
				//dwContinueStatus = DBG_EXCEPTION_NOT_HANDLED;

				/*
                if ( ulErrorAddress2 == ExceptionRecord.ExceptionAddress )
                {
                    

                }
                else
                {
                    printf( "\t�����쳣, ���ǲ��ᴦ���� ����DBG_EXCEPTION_NOT_HANDLED \n"  );
                    dwContinueStatus = DBG_EXCEPTION_NOT_HANDLED;

                    ulErrorAddress2 = ExceptionRecord.ExceptionAddress;
                }
				*/
                break;

            case EXCEPTION_BREAKPOINT:

                //
                // �״��쳣��ϵͳ�ϵ�����, ���ǲ�����, �ȴ��ڶ��δ���
                //
                if ( bIsSystemBreak && lpSysBreak == ExceptionRecord.ExceptionAddress )
                {
                    //
                    // ���������һ���ϵ�
                    //
                    DbgObjReadProcessMemory( hProcess, ( PVOID )ulEntry, &Int3Value , 1, &dwByteRead );

                    SzBuffer[0] = ( char )0xcc;

                    DbgObjWriteProcessMemory( hProcess, ( PVOID )ulEntry, &SzBuffer, 1, &dwByteRead );

                    printf( "\t��1�� int 3�ϵ�, ���˴���, ����0x%p �ϵ� \n", ulEntry  );

                    break;

                }
                else if ( ExceptionRecord.ExceptionAddress == ( PVOID )ulEntry )
                {
                    //
                    // �ָ�������������õĶϵ�
                    //
                    DbgObjWriteProcessMemory( hProcess, ( PVOID )ulEntry, &Int3Value, 1, &dwByteRead );

                    //
                    // �ָ���int 3֮ǰ��һ��ָ��ִ��
                    //
                    hThread = OpenThread( THREAD_GET_CONTEXT | THREAD_SET_CONTEXT , FALSE, DbgEvt.dwThreadId );
                    if ( !hThread )
                    {
                        break;
                    }

                    StContext.ContextFlags = CONTEXT_CONTROL | CONTEXT_INTEGER | CONTEXT_SEGMENTS;
                    if ( !DbgObjGetThreadContext( hThread, &StContext ) )
                    {
                        break;
                    }

                    StContext.Eip = ( ULONG )ExceptionRecord.ExceptionAddress;

                    //
                    // ����һ��
                    //
                    StContext.EFlags |= 0x100;
                    DbgObjSetThreadContext( hThread, &StContext );

                    if ( hThread )
                    {
                        CloseHandle( hThread );
                    }

                    printf( "\t��2�� int 3�ϵ�, ���˴���, �����˵���! \n"  );
                }
                else
                {
                    if ( ulErrorAddress == ExceptionRecord.ExceptionAddress )
                    {
                        printf( "\t����δ�������쳣 ExceptionCode 0x%p ������ȥ��. �����Լ�������! \n",
                                ExceptionRecord.ExceptionCode );

                    }
                    else
                    {
                        printf( "\t�����쳣δ������ ExceptionCode 0x%p! \n",
                                ExceptionRecord.ExceptionCode );
                        dwContinueStatus = DBG_EXCEPTION_NOT_HANDLED;

                        ulErrorAddress = ExceptionRecord.ExceptionAddress;
                    }
                }
                break;
//---------------------------------------------------------------------------
            case EXCEPTION_DATATYPE_MISALIGNMENT:
                //
                // First chance: Pass this on to the system.
                // Last chance: Display an appropriate error.
                //
                system( "pause" );
                break;
//---------------------------------------------------------------------------
            case EXCEPTION_SINGLE_STEP:

                //
                // ����
                //
                printf( "\tDebuggee breaks Step 0x%p\n",
                        ExceptionRecord.ExceptionAddress );
                break;
//---------------------------------------------------------------------------
            case DBG_CONTROL_C:
                // First chance: Pass this on to the system.
                // Last chance: Display an appropriate error.
                system( "pause" );
                break;

            default:

                //
                // �����쳣�ǳ��������, ���ǲ�����
                //
                dwContinueStatus = DBG_EXCEPTION_NOT_HANDLED;

                printf( "\tProgram Raise unknown Exception, Exception Code 0x%p \n",
                        ExceptionRecord.ExceptionCode );
                system( "pause" );
                break;
            }
            break;
//---------------------------------------------------------------------------
        case CREATE_THREAD_DEBUG_EVENT:

            CreateThreadInfo = DbgEvt.u.CreateThread;

            printf( "\tThread TLS data address 0x%p, Start address 0x%p \n",
                    CreateThreadInfo.lpThreadLocalBase,
                    CreateThreadInfo.lpStartAddress );

            printf( "Info \n\tDbgEvt.dwDebugEventCode\t\t %d \n", DbgEvt.dwDebugEventCode );
            printf( "\tDbgEvt.dwProcessId\t\t %d \n", DbgEvt.dwProcessId );
            printf( "\tDbgEvt.dwThreadId\t\t %d \n", DbgEvt.dwThreadId );

            printf( "\tCreateThreadInfo.hThread\t\t %d \n", CreateThreadInfo.hThread );
            printf( "\tCreateThreadInfo.lpStartAddress\t\t %p \n", CreateThreadInfo.lpStartAddress );
            printf( "\tCreateThreadInfo.lpThreadLocalBase \t\t %p \n", CreateThreadInfo.lpThreadLocalBase );

            break;
//---------------------------------------------------------------------------
        case CREATE_PROCESS_DEBUG_EVENT:

            CreateProcessInfo = DbgEvt.u.CreateProcessInfo;

            RtlZeroMemory( SzBuffer, sizeof( SzBuffer ) / sizeof( wchar_t ) );

            GetFileNameFromHandle( CreateProcessInfo.hFile, SzBuffer, sizeof( SzBuffer ) / sizeof( wchar_t ) );

            ulEntry = ( ULONG )CreateProcessInfo.lpStartAddress;

            printf( "\tImageBase Is 0x%p\n\tEntry Is 0x%p\n\tExe Name Is %ws\n",
                    CreateProcessInfo.lpBaseOfImage, ulEntry, SzBuffer );

            hProcess = CreateProcessInfo.hProcess;

            if ( CreateProcessInfo.hFile )
            {
                CloseHandle( CreateProcessInfo.hFile );
            }

            printf( "Info \n\tDbgEvt.dwDebugEventCode\t\t %d \n", DbgEvt.dwDebugEventCode );
            printf( "\tDbgEvt.dwProcessId\t\t %d \n", DbgEvt.dwProcessId );
            printf( "\tDbgEvt.dwThreadId\t\t %d \n", DbgEvt.dwThreadId );

            printf( "\tCreateProcessInfo.hProcess\t\t %d \n", CreateProcessInfo.hProcess );
            printf( "\tCreateProcessInfo.hThread\t\t %d \n", CreateProcessInfo.hThread );
            printf( "\tCreateProcessInfo.hFile \t\t %d \n", CreateProcessInfo.hFile );
            printf( "\tCreateProcessInfo.lpBaseOfImage \t\t %p \n", CreateProcessInfo.lpBaseOfImage );
            printf( "\tCreateProcessInfo.dwDebugInfoFileOffset\t\t %p \n", CreateProcessInfo.dwDebugInfoFileOffset );
            printf( "\tCreateProcessInfo.nDebugInfoSize\t\t %p \n", CreateProcessInfo.nDebugInfoSize );
            printf( "\tCreateProcessInfo.lpThreadLocalBase\t\t %p \n", 	CreateProcessInfo.lpThreadLocalBase );
            printf( "\tCreateProcessInfo.lpStartAddress\t\t %p \n", CreateProcessInfo.lpStartAddress );
            printf( "\tCreateProcessInfo.lpImageName\t\t %d \n", CreateProcessInfo.lpImageName );
            printf( "\tCreateProcessInfo.fUnicode\t\t %d \n", CreateProcessInfo.fUnicode );

            break;
//---------------------------------------------------------------------------
        case EXIT_THREAD_DEBUG_EVENT:

            ExitThreadInfo = DbgEvt.u.ExitThread;

            printf( "\tThread Exit, ExitCode 0x%p\n",
                    ExitThreadInfo.dwExitCode );
            break;
//---------------------------------------------------------------------------
        case EXIT_PROCESS_DEBUG_EVENT:

            ExitProcessInfo = DbgEvt.u.ExitProcess;

            printf( "\tProcess Exit, ExitCode 0x%p\n",
                    ExitProcessInfo.dwExitCode );

            bExit = TRUE;
            break;
//---------------------------------------------------------------------------
        case LOAD_DLL_DEBUG_EVENT:

            LoadDllInfo = DbgEvt.u.LoadDll;

            GetFileNameFromHandle( LoadDllInfo.hFile, SzBuffer, sizeof( SzBuffer ) );

            printf( "\tDLL Base 0x%p DLL Size 0x%p\n",
                    LoadDllInfo.lpBaseOfDll, GetFileSizeFromHandle( LoadDllInfo.hFile ) );

            printf( "\tDLL Name is %ws\n", SzBuffer  );

            if ( LoadDllInfo.hFile )
            {
                CloseHandle( LoadDllInfo.hFile );
            }

            printf( "Info \n\tDbgEvt.dwDebugEventCode\t\t %d \n", DbgEvt.dwDebugEventCode );
            printf( "\tDbgEvt.dwProcessId\t\t %d \n", DbgEvt.dwProcessId );
            printf( "\tDbgEvt.dwThreadId\t\t %d \n", DbgEvt.dwThreadId );

            printf( "\tLoadDllInfo.dwDebugInfoFileOffset\t\t %d \n", LoadDllInfo.dwDebugInfoFileOffset );
            printf( "\tLoadDllInfo.fUnicode\t\t %d \n", LoadDllInfo.fUnicode );
            printf( "\tLoadDllInfo.hFile \t\t %d \n", LoadDllInfo.hFile );
            printf( "\tLoadDllInfo.lpBaseOfDll \t\t %p \n", LoadDllInfo.lpBaseOfDll );
            printf( "\tLoadDllInfo.lpImageName\t\t %p \n", LoadDllInfo.lpImageName );
            printf( "\tCreateProcessInfo.nDebugInfoSize\t\t %p \n", LoadDllInfo.nDebugInfoSize );

            break;
//---------------------------------------------------------------------------
        case UNLOAD_DLL_DEBUG_EVENT:

            UnLoadDllInfo = DbgEvt.u.UnloadDll;

            printf( "\tUnload DLL DLL Base address 0x%p\n",
                    UnLoadDllInfo.lpBaseOfDll );
            break;
//---------------------------------------------------------------------------
        case OUTPUT_DEBUG_STRING_EVENT:

            StDebugStringInfo = DbgEvt.u.DebugString;

            if ( StDebugStringInfo.fUnicode )
            {
                WCHAR* SzString = NULL;

                SzString = ( WCHAR* )malloc( StDebugStringInfo.nDebugStringLength + 2 );
                RtlZeroMemory( SzString, StDebugStringInfo.nDebugStringLength + 2 );

                DbgObjReadProcessMemory( hProcess,
                                         StDebugStringInfo.lpDebugStringData,
                                         SzString,
                                         StDebugStringInfo.nDebugStringLength,
                                         &dwByteRead );

                wprintf( L"\tOutDebugString :%s\n", SzString );
            }
            else
            {
                char* SzString = NULL;

                SzString = ( char* )malloc( StDebugStringInfo.nDebugStringLength + 1 );
                RtlZeroMemory( SzString, StDebugStringInfo.nDebugStringLength + 1 );

                DbgObjReadProcessMemory( hProcess,
                                         StDebugStringInfo.lpDebugStringData,
                                         SzString,
                                         StDebugStringInfo.nDebugStringLength,
                                         &dwByteRead );

                printf( "\tOutDebugString :%s\n", SzString );

                if ( SzString )
                {
                    free( SzString );
                }
            }
            break;
        }
//---------------------------------------------------------------------------
        // Resume executing the thread that reported the debugging event.
        DbgObjContinueDebugEvent( DbgEvt.dwProcessId,
                                  DbgEvt.dwThreadId, dwContinueStatus );

        dwContinueStatus = DBG_CONTINUE;
    }
    return TRUE;
}

void Help()
{
    printf ( "TinyDbgr <PID of Program to Debug>|\n    "
             "<Full Exe File Name> [Prgram Parameters]\n" ) ;
}

/* ��ȡģ�����ڵľ���·��*/
BOOL _GetModuleFilePath( wchar_t* SzPath, size_t Size  )
{
    int i;

    //
    // ��ȡ���������·��
    //
    i = GetModuleFileName( NULL, SzPath, Size );

    while( SzPath[i] != L'\\' )
    {
        i--;
    }

    SzPath[i + 1] = L'\0';

    return i;
}


int __cdecl wmain( int argc, wchar_t* argv[] )
{
    DWORD dwProcessId;
    SYSTEM_MODULE SymMod;
    wchar_t SzSymbolsPath[MAX_PATH] = {0};
    DICHLORVOS_VERISON StDichlorovs = {0};
    wchar_t SzString[] = {_T( "test.exe" )};

    argv[1] = SzString;
    argc++;
//---------------------------------------------------------------------------
    printf( "��ʼ������ϵͳ\n" );

    DbgObjGetSysModuleInfo( &SymMod );

    _GetModuleFilePath( SzSymbolsPath, sizeof( SzSymbolsPath ) / sizeof( wchar_t ) );
    DbgObjEnumSymbols( SzSymbolsPath );

    wcscat_s( SzSymbolsPath, sizeof( SzSymbolsPath ) / sizeof( wchar_t ), _T( "DbgSys.sys" ) );

    if ( !DbgObjInitialize( SzSymbolsPath, _T( "DbgSys" ) ) )
    {
        printf( "����ϵͳ��ʼ��ʧ��!\n" );
        return -1;
    }

    if ( !DbgObjGetVersion( &StDichlorovs ) )
    {
        printf( "��ȡ����ϵͳ�汾ʧ��!\n" );
    }

	printf( "�������汾: main: %d child: %d Build Time :%s \n",
            StDichlorovs.ulMainVersion,
            StDichlorovs.ulChildVersion,
			StDichlorovs.SzBuildTime );

//---------------------------------------------------------------------------
    if ( !DbgObjCreateDevice( _T( "DbgSys" ) ) )
    {
        printf( "'�򿪵����豸ʧ��!\n" );
        return -1;
    }

    printf( "�򿪵����豸�ɹ�!\n" );
//---------------------------------------------------------------------------
    do
    {
        if ( _tcsstr( _tcsupr( argv[1] ), _T( ".EXE" ) ) )
        {
            wchar_t szCmdLine[ MAX_PATH ] ;
            szCmdLine[ 0 ] = '\0' ;

            for ( int i = 1 ; i < argc ; i++ )
            {
                _tcscat_s ( szCmdLine , sizeof( szCmdLine ) / sizeof( wchar_t ), argv[ i ] ) ;
                if ( i < argc )
                {
                    _tcscat_s ( szCmdLine , sizeof( szCmdLine ) / sizeof( wchar_t ), _T( " " ) ) ;
                }
            }

            if( !DbgNewProcess( szCmdLine ) )
            {
                break;
            }
        }
        else
        {
            wchar_t szCmdLine[ MAX_PATH ] ;

            wcscpy_s( szCmdLine, L"Test.exe" );

            if( !( dwProcessId = DbgNewProcessHandle( szCmdLine ) ) )
            {
                break;
            }
            else
            {
                printf( "��������ID :%d \n", dwProcessId );
                Sleep( 1000 );
            }

            if( !DbgObjDebugActiveProcess( dwProcessId ) )
            {
                printf( "Failed in DebugActiveProcess() with %d.\n", GetLastError() );
                break;
            }
            else
            {
                printf( "�󶨵����������̳ɹ� %d!\n", dwProcessId );
            }

            if( argc > 2 && _tcsicmp( argv[2], _T( "-e" ) ) == 0 )
            {
                //
                // ָ���������˳�ʱ, �Ƿ��˳������Խ���
                //
                if( !DbgObjDebugSetProcessKillOnExit( FALSE ) )
                {
                    printf( "Failed in DebugSetProcessKillOnExit() with %d.\n", GetLastError() );
                }
            }

            if( argc > 2 && _tcsicmp( argv[2], _T( "-s" ) ) == 0 )
            {
                DbgMainLoop( 10 );

                //
                // ���������, ţ��Ӧ��������. ������ǱȽ���ȷ�İ취..
                //
                if( !DbgObjDebugActiveProcessStop( _wtoi( argv[1] ) ) )
                {
                    printf( "Failed in DebugActiveProcessStop() with %d.\n", GetLastError() );
                }
                else
                {
                    printf( "Detach debuggee successfully.\n" );
                }
                break;
            }
        }

        DbgMainLoop( INFINITE );
    }
    while ( 0 );
//---------------------------------------------------------------------------
    system( "pause" );
    if ( !DbgObjCloseHanle( _T( "DbgSys" ) ) )
    {
        printf( "�رյ����豸ʧ��!\n" );
        return -1;
    }

    printf( "���½���\n" );
    system( "pause" );
    return 0;
}
