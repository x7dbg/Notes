ニコニコ動画「テトリスを1時間強で作ってみた【実況解説】」のソースコード

オリジナル動画：http://www.nicovideo.jp/watch/sm8517855

![画面キャプチャ](https://raw.github.com/DQNEO/CppTetris/master/capture.png "画面キャプチャ")

コミットログの"30:00" "40:00"みたいな数字は、動画内の経過時間です。


遊び方
--------------------------
tetris.exeを実行するとすぐに遊ぶことができます。




ソースコードをコンパイルする方法
--------------------------
基本的に動画のとおりです。

* MinGWをインストール
* Pathを通す
* コンパイル(make.batを実行)
* a.exeを実行



ライセンスについて
--------------------------

MIT License

Copyright @tkihira

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Thanks to
https://twitter.com/tkihira/status/262437799775592449

